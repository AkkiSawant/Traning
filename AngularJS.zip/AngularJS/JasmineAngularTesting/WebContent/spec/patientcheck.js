describe('pateientspecsuite', function() {

	
	it("should return a patient object", function() {
		expect(searchPat(300)).toEqual(jasmine.any(patient)); // assertion
	});

	/*it("should return the correct patient object", function() {
		var p = new patient(300,'Peter');
		expect(searchPat(300)).toEqual(p); // assertion
	});*/

	/*it("should throw an exception, if patient is not found", function() 
	{
        expect(function() { searchPat(999); }).toThrow();
	});*/
	
	/*it("should return null, if no patientid is passed", function() 
	{
		        expect(searchPat()).toBeNull();
	});*/
});