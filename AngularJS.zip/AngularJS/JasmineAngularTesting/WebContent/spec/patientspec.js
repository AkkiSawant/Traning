describe('pateientspecsuite', function() {
	it("Dummy test case-1", function() {
		expect(10).toEqual(10); // assertion
	});

	
	it("Dummy test case-2", function() {
		expect(4).toBeLessThan(10); // assertion
	});
	
	it("Dummy test case-3", function() {
		expect(20).toBeLessThan(10); // assertion
	});
});