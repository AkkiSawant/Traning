﻿var module = angular.module("MainApp", []);

module.controller("CalculatorController", function ($scope)
{
    $scope.result = 0.00;
    $scope.Operand1 = 0.00;
    $scope.Operand2 = 0.00;

    $scope.Add = function()
    {
       if ($scope.Operand1 == undefined || $scope.Operand2 == undefined)
       {
           //throw some exception
           throw "Undefined operand";
       }
        $scope.result =  parseFloat($scope.Operand1) + parseFloat($scope.Operand2);
    }
});