﻿describe('calculator', function () {

	    beforeEach(angular.mock.module('MainApp'));

    var $c;

    
    // beforeEach() is like a setup function that gets executed before each spec that is, it, test case
    beforeEach(angular.mock.inject(function (_$controller_) {
    console.log("beforeeach called");
    	$c = _$controller_;
    }));

    describe('Add', function () {
        it('1 + 1 should equal 2', function () {
            var $scope = {};
            var controller = $c('CalculatorController', { $scope: $scope });
            $scope.Operand1 = 1;
            $scope.Operand2 = 2;
            $scope.Add();
            expect($scope.result).toBe(3);
        });

        it('should throw an exception if one of the operands is not defined', function () {
            var $scope = {};
            var controller = $c('CalculatorController', { $scope: $scope });
            $scope.Operand1 = undefined;
            $scope.Operand2 = 2;
            expect(function () {$scope.Add();}).toThrow();
        });
    });

});