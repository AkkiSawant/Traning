var patientArray = [ new patient(100, 'John'), new patient(200, 'Jill'),
		new patient(300, 'Peter'), new patient(400, 'John'),
		new patient(500, 'Andrew') ];

function searchPat(id) {
	if(id == undefined)
	{
		return null;
	}
	
	
	var result = undefined;
	patientArray.forEach(function(element) {
		// console.log(element);
		// console.log(id)
		if (element.patientId == id) {
			
			result = element;
			return;
		}
	});
	
	if (result == undefined) {
		//console.log("Inside");
		throw "patient not found";
	}
	
		return result;
}
;