// create the module
var module = angular.module("CRUDModule");

module.service('TerrService', function()
{
     this.territories = 
     [
        new Territory('0876', 'Cambridge', 3),
        new Territory('0877', 'Wilton', 2),
        new Territory('0878', 'Boston', 1)
      ];
      
      this.AddNewTerrritory = function(newObject)
      {
           this.territories.push(newObject);
           alert('New Product added' + newObject.territoryId);
      };
     
});


