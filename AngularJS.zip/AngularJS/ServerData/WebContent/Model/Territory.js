function Territory(tid, tdesc, regionId)
{
	this.territoryId = tid;
	this.territoryDesc = tdesc;
    this.regionId = regionId;
};