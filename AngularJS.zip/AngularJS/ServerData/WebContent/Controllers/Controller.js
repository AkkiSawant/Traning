var module = angular.module("CRUDModule");

//since the controller uses the ProductService, it must declare a dependency
module.controller("TerritoryController", function ($scope, TerrService) {
    
	alert('controller called..');
	$scope.GetAllTerritory = function ()
    {
        return TerrService.territories;
    };
    
});
    