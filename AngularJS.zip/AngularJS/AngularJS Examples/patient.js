function patient(id, name)
{
	this.patientId = id;
	this.patientName = name;
}