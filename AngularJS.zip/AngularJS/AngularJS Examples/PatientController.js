var patientArray = [ new patient(100, 'John'), new patient(200, 'Jill'),
		new patient(300, 'Peter'), new patient(400, 'John'),
		new patient(500, 'Andrew') ];

function searchPat(id) {
	var result = undefined;
	patientArray.forEach(function(element) {
		//console.log(element);
		//console.log(id)
		if (element.patientId == id) {
			result = element;
			return;
		}
	});
	
	return result;
}

function abc() {
	document.write("hello");
}