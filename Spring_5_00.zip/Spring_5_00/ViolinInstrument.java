package com.citiustech.springcore.autowire;

public class ViolinInstrument implements Instrument{

	@Override
	public void displayMusic() {
		System.out.println("Violin played");
		
	}

	
}
