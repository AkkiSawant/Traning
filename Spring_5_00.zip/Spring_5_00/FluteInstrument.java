package com.citiustech.springcore.autowire;

public class FluteInstrument implements Instrument {

	@Override
	public void displayMusic() {
		System.out.println("Flute played");

	}

}
