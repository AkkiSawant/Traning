package com.citiustech.springcore.autowire;

public interface Instrument {
	
	public void displayMusic();
	
}
