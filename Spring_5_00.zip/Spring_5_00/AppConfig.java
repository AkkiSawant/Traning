package com.springbeans;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration //<beans>
public class AppConfig {

	//<bean id="" class="">
	@Bean(name="messageBean")
	public Message abc()
	{
		return new Message();
	}
	
}
