package com.springDI.SpringCoreApplication;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.springbeans.AppConfig;
import com.springbeans.Message;

public class TestJavaConfig {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		// Get the object from BeanFactory
		Message messageObj = context.getBean("messageBean", Message.class);
		// messageObj.setText("Welcome");
		// Invokes the methods
		messageObj.greetMessage();

	}

}
