(function () {
    'use strict';

    angular.module('stsClientApp').service('userService', userService);

    userService.$inject = ['globalService','Config'];

    function userService(globalService,userConfig) {
    	
    	this.getUser = function(data) {
    		userConfig.setUrl("UsersInformationRequest-post");
    		userConfig.setMethod("POST");
    		userConfig.setData(data);
			return  globalService.callApi(userConfig);
		}	
    }

})();