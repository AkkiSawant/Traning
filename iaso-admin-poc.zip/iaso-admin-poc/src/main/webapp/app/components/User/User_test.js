'use strict';

describe('stsClientApp.User module', function() {

  beforeEach(module('stsClientApp.User'));

  describe('User controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var userCtrl = $controller('UserCtrl');
      expect(userCtrl).toBeDefined();
    }));

  });
});