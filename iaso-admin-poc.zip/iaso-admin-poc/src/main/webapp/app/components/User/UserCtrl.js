(function () {
    'use strict';

    angular.module('stsClientApp')
        .controller('UserCtrl', UserCtrl);
    
    UserCtrl.$inject = ['userService','User','$rootScope'];

    function UserCtrl(userService,user,$rootScope) {
        var vm = this;
        vm.user = user;
        vm.saveUser = saveUser;
	    vm.inc = 0;

        function saveUser(isValid) {
            if (isValid) {
            	
            	var data = {
            			"ZoneId": vm.user.zoneId,
    					"DomainName": vm.user.domainName,
    					"OpaqueId": vm.user.opaqueId,
    					"FirstName": vm.user.firstName,
    					"LastName": vm.user.lastName
    				};
    				
            	userService.getUser(data)
    					.then(function (res) {
    						console.log(res);
    				    	if(res && res.ResponseCode === "Success"){
    				    		$rootScope.userCount=res.Users.UserInformation.length;
    				    		vm.myData = res.Users.UserInformation;
    				    		vm.msg = "Data found";
                				vm.type = "alert-success";
    				    	}else{
                				vm.msg = res.Error.ErrorMessage;
                				vm.type = "alert-info";
    				    	}
    					}, function (err) {
    						console.log(err);
    						vm.msg = "Problem in fetching data";
                			vm.type = "alert-danger";
    					}); 
    		
            } else {
                vm.msg = "Invalid input";
                vm.type = "alert-danger";
            }
        }

    }

})();