var myapp = angular.module("stsClientApp")
.controller("navCtrl", navCtrl);

navCtrl.$inject = ['$rootScope' ,'countService'];

function navCtrl($rootScope,countService){
	this.currentState  = "role";
	this.isAccordianView = true;
	this.active = true;
	this.roleCount=countService.getRoleCount();
	
	$rootScope.enableProgress = false;
	this.countService=countService;
	/*$rootScope.progressWidth = 50 + "%";*/
	
	this.setState = function(state){
		console.log("i m in " + state);
		this.currentState = state;
	}
	
	
}