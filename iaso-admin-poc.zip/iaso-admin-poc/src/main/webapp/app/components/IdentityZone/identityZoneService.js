(function () {
	'use strict';
	
	angular.module('stsClientApp')
	.service('identityZoneService', identityZoneService);
	
	identityZoneService.$inject = ['globalService','Config'];
	function identityZoneService(globalService,identityZoneConfig) {
		
		this.getIdentityZone = function(data) {
			identityZoneConfig.setUrl("IdentityZonesForGroupsRequest-post");
			identityZoneConfig.setData(data);
			identityZoneConfig.setMethod("POST");
			return  globalService.callApi(identityZoneConfig);
		}		
	}

})();
