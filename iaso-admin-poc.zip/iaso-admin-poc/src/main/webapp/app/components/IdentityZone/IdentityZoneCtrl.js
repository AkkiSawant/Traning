(function () {
	'use strict';

	angular.module('stsClientApp')
	.controller('IdentityZoneCtrl', IdentityZoneCtrl);

	IdentityZoneCtrl.$inject = ['IdentityZone','identityZoneService','$rootScope'];
	function IdentityZoneCtrl(identityZone, identityZoneService,$rootScope) {
		var vm = this;
		vm.saveIdentityZone = saveIdentityZone;
		
			
		function saveIdentityZone(isValid) {
			if (isValid) {
				
				var data = {
					"DomainName": vm.identityZone.domainName,
					"GroupNames" : {"string":vm.identityZone.groupNames}
				};
				
				identityZoneService.getIdentityZone(data)
					.then(function (res) {
						console.log(res);
				    	if(res && res.ResponseCode === "Success"){
				    		$rootScope.identityZoneCount=res.IdentityZones.KeyValueOfstringArrayOfIdentityZoneRQ3UONSZlength;
				    		vm.myData = res;
				    		vm.msg = "Data found";
            				vm.type = "alert-success";
				    	}else{
            				vm.msg = res.Error.ErrorMessage;;
            				vm.type = "alert-info";
				    	}
					}, function (err) {
						console.log(err);
						vm.msg = "Problem in fetching data";
            			vm.type = "alert-danger";
					}); 
			}	
			else {
				alert('Invalid input');
			}
		}
		
	}

})();