'use strict';

describe('stsClientApp.Role module', function() {

  beforeEach(module('stsClientApp.Role'));

  describe('Role controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var roleCtrl = $controller('RoleCtrl');
      expect(roleCtrl).toBeDefined();
    }));

  });
});