(function () {
    'use strict';

    angular.module('stsClientApp')
        .controller('RoleCtrl', RoleCtrl);

    RoleCtrl.$inject = ['Role', 'roleService','countService'];

    function RoleCtrl(role, roleService,countService) {
        var vm = this;
        vm.role = role;
        vm.saveRole = saveRole;
        vm.myData = [];
        //vm.countService=countService;

        function saveRole(isValid) {
            if (isValid) {

                var data = {
                    "DomainName": vm.role.domainName
                };

                roleService.getRole(data)
                    .then(function (res) {
                        console.log(res);
                        if (res && res.ResponseCode === "Success") {
                            
                            vm.myData = res.RetrieveAllRolesForDomainResponse.Roles.Role;
                            countService.setRoleCount(vm.myData.length);
                            vm.msg = "Data found";
                            vm.type = "alert-success";
                        } else {
                            vm.msg = res.Error.ErrorMessage;
                            vm.type = "alert-warning";
                        }
                    }, function (err) {
                        console.log(err);
                        vm.msg = "Problem in fetching data";
                        vm.type = "alert-danger";
                    });
            } else {
                alert('Invalid input');
            }
        }

    }

})();