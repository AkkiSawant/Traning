(function () {
	'use strict';
	
	angular.module('stsClientApp')
	.service('roleService', roleService);
	
	roleService.$inject = ['globalService','Config'];
	function roleService(globalService,roleConfig) {
		
		this.getRole = function(data) {
			roleConfig.setUrl("roles-post");
			roleConfig.setData(data);
			roleConfig.setMethod("POST");
			return  globalService.callApi(roleConfig);
		}		
	}

})();

