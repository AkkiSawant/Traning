(function () {
	'use strict';
	
	angular.module('stsClientApp')
	.service('userWithRoleIdentityService', userWithRoleIdentityService);
	
	userWithRoleIdentityService.$inject = ['globalService','Config'];
	function userWithRoleIdentityService(globalService,userWithRoleIdConfig) {
		
		this.getUserWithRoleIdentity=function (data) {
			userWithRoleIdConfig.setUrl("UsersWithRoleInIdentityZone-post");
			userWithRoleIdConfig.setData(data);
			userWithRoleIdConfig.setMethod("POST");
			return  globalService.callApi(userWithRoleIdConfig);
		}
		
	}

})();

