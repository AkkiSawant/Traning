(function () {
	'use strict';

	angular.module('stsClientApp')
	.controller('UserWithRoleIdentityCtrl', UserWithRoleIdentity);

	UserWithRoleIdentity.$inject = ['UserWithRoleIdentity','userWithRoleIdentityService','$rootScope'];
	function UserWithRoleIdentity(userWithRoleId,userWithRoleIdentityService,$rootScope) {
		var vm = this;
		vm.userWithRoleIdentity = userWithRoleId;
		vm.saveUserWithRoleIdentity = saveUserWithRoleIdentity;
			
		function saveUserWithRoleIdentity(isValid) {
			if (isValid) {
				
				var data = {
						"ZoneId" : vm.userWithRoleIdentity.zoneId,
						"DomainName" : vm.userWithRoleIdentity.domainName,
						"Roles" : vm.userWithRoleIdentity.roles
					};
					
				userWithRoleIdentityService.getUserWithRoleIdentity(data)
						.then(function (res) {
							console.log(res);
					    	if(res && res.ResponseCode === "Success"){
					    		vm.myData=res.Users.UserInformation;
					    		$rootScope.userWithRoleIdCount = vm.myData.length;
					    		vm.msg = "Data found";
	            				vm.type = "alert-success";
					    	}else{
	            				vm.msg = res.Error.ErrorMessage;
	            				vm.type = "alert-info";
					    	}
						}, function (err) {
							console.log(err);
							vm.msg = "Problem in fetching data";
	            			vm.type = "alert-danger";
						}); 
			}	
			else {
				vm.msg = "Invalid input";
                vm.type = "alert-danger";
			}
		}
		
	}

})();
