(function () {
    'use strict';

    angular.module('stsClientApp')
        .controller('AccordianCtrl', AccordianCtrl);

    AccordianCtrl.$inject = ['$rootScope'];

    function AccordianCtrl($rootScope) {
        var accordionvm=this;
        accordionvm.accordion=1;
    }

})();