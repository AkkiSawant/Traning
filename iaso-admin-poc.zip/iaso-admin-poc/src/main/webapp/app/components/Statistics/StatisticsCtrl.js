(function () {
    'use strict';

    angular.module('stsClientApp')
        .controller('StatisticsCtrl', StatisticsCtrl);

    StatisticsCtrl.$inject = ['$scope', '$interval', '$window'];

    function StatisticsCtrl($scope, $interval, $window) {

        //Static data: start
        $scope.serviceData = {
            "yahoo.com": [{
                "label": "user",
                "width": 30
                    }, {
                "label": "role",
                "width": 50
                 }],
            "citiustech.com": [{
                "label": "user",
                "width": 90
                    }, {
                "label": "role",
                "width": 20
                 }],
            "merge.com": [{
                "label": "user",
                "width": 45
                    }, {
                "label": "role",
                "width": 20
                 }]
        };
        //$scope.barData = [10,20];
        $scope.barData = [{
            "label": "user",
            "width": 10
        }, {
            "label": "role",
            "width": 20
        }];
        $scope.barLabel = $scope.barData.map(function (x) {
            return x.label;
        });

        $scope.data = [1000, 500, 100];

        $scope.options = {
            responsive: true
        };
        $scope.labels = ["yahoo.com", "citiustech.com", "merge.com"];
        $scope.colors = ["red", "blue", "green"];
        //Static data: end

        var vm = this;
        vm.getDomainList = getDomainList;

        function getDomainList() {
            //$scope.data  = fill number of role agains each domain;
            //$scope.labels = fill label of domain
            console.log('sss');
        };

        $scope.onHover = function (points) {
            if (points[0]) {
                var domain = points[0]._model.label;
                $scope.barData = $scope.serviceData[domain];
                $scope.$apply();
                //barsChart.reflectData();
            }
        };

    }



})();