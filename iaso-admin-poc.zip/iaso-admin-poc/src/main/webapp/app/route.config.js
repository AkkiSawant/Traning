(function () {
    'use strict';

    angular.module('stsClientApp')
        .config(configureStates);

    configureStates.$inject = ['$urlRouterProvider', '$stateProvider'];

    function configureStates($urlRouterProvider, $stateProvider) {
        $stateProvider.state('role', {
            templateUrl: 'app/components/Role/role.html',
            controller: 'RoleCtrl as vm',
            url: '/role'
        }).state('user', {
            templateUrl: 'app/components/User/user.html',
            controller: 'UserCtrl as vm',
            url: '/user'
        }).state('userWithRoleIdentity', {
            templateUrl: 'app/components/UserWithRoleIdentity/userWithRoleIdentity.html',
            controller: 'UserWithRoleIdentityCtrl as vm',
            url: '/UserWithRoleIdentity'
        }).state('statistics', {
            templateUrl: 'app/components/Statistics/statistics.html',
            controller: 'StatisticsCtrl as vm',
            url: '/statistics'
        }).state('identityZone', {
            templateUrl: 'app/components/IdentityZone/identityZone.html',
            controller: 'IdentityZoneCtrl as vm',
            url: '/IdentityZone'
        }).state('professional', {
        	url: '/professional',
            views: {
                '': {
                    templateUrl: 'app/components/accordian/accordian.html',
                    controller: 'AccordianCtrl as vm',
                    url: '/professional'
                },
                'role@professional': {
                    templateUrl: 'app/components/Role/role.html',
                    controller: 'RoleCtrl as vm',
                    url: '/role'
                },
                'user@professional': {
                    templateUrl: 'app/components/User/user.html',
                    controller: 'UserCtrl as vm',
                    url: '/user'
                },
                'userWithRoleIdentity@professional': {
                    templateUrl: 'app/components/UserWithRoleIdentity/userWithRoleIdentity.html',
                    controller: 'UserWithRoleIdentityCtrl as vm',
                    url: '/UserWithRoleIdentity'
                },
                'statistics@professional': {
                    templateUrl: 'app/components/Statistics/statistics.html',
                    controller: 'StatisticsCtrl as vm',
                    url: '/statistics'
                },
                'identityZone@professional': {
                    templateUrl: 'app/components/IdentityZone/identityZone.html',
                    controller: 'IdentityZoneCtrl as vm',
                    url: '/IdentityZone'
                }
                // for column two, we'll define a separate controller 

            }

        });

        $urlRouterProvider.otherwise('/professional');
    }
})();