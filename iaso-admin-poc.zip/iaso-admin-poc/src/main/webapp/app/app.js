(function () {
	'use strict';

// Declare app level module which depends on views, and components
var stsClient = angular.module('stsClientApp', ['ui.router','chart.js','ui.grid','ngTouch']);

stsClient.config(['ChartJsProvider', function (ChartJsProvider) {
    'use strict';
   ChartJsProvider.setOptions({ colors : [ 'red', 'blue', 'green', 'pink', 'yellow', 'black', 'gray'] });
}])

})();
