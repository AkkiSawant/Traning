angular.module('stsClientApp')
	.directive("showAlert", function() {
	    return {
	        restrict:'E',
	        scope: {
	            alertmsg:'<',
	            type:'<'
	        },
	        templateUrl : "app/shared/directive/show-modal/showModal.html",
	        controller : function($scope) {
	            
	            $scope.hideMessage = function() {
	                $scope.alertmsg = "";
	            }
	        }
	    }
	});