angular.module('stsClientApp').

directive('barsChart', function ($parse) {

    var directiveDefinitionObject = {

        restrict: 'EA',

        replace: false,

        scope: {
            chartData: '=',
            lable: '=chartLable'
        },

        link: function (scope, element, attrs) {
            var self = scope;
            self.element = element[0];
            self.chart = d3.select(element[0]);

            function updateChart() {
                self.chart.append("div").attr("class", "chart")
                    .selectAll('div')
                    .data(scope.chartData).enter().append("div")
                    .transition().ease("elastic")
                    .style("width", function (d, i) {
                        return d.width + "%";
                    })
                    .text(function (d) {
                        return d.label + " " + d.width + " %";
                    });
            }

            scope.$watch("chartData", function (newVal) {
                element[0].innerHTML = "";
                self.chart = d3.select(element[0]);
                updateChart();
            }, true);
        },
        controller: function ($scope, $element, $attrs) {


            console.log('Inside controller');
            this.refresh = function () {
                console.log('middle method');
            }
        }

    };
    return directiveDefinitionObject;
});