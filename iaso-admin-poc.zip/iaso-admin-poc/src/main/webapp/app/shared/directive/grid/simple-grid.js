angular.module('stsClientApp').directive("simpleGrid", function () {
    return {
        restrict: 'E',
        replace: false,
        scope: {
            gridData: '<'
        },
        templateUrl: "app/shared/directive/grid/simple-grid.html",
        link: function (scope, element, attrs) {
        },
        controller: function ($scope) {
        	
        	function updateData() {
	            if($scope.gridData && $scope.gridData[0]) {
	            	$scope.gridColumns = Object.keys($scope.gridData[0]);
	            }
            }
            
        	$scope.$watch('gridData', function(newVal,oldVal, scope){
            	console.log('Grid Modified '+newVal);
            	gridData = newVal;
            	updateData();
            }, true);

        }
    }
});