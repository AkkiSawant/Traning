app.directive('validateRoles', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attr, mCtrl) {
        	var regexPattern="[^,\s][^\,]*[^,\s]*";
            function myValidation(value) {
                if (value.matches(regexPattern)) {
                    mCtrl.$setValidity('charE', true);
                } else {
                    mCtrl.$setValidity('charE', false);
                }
                return value;
            }
            mCtrl.$parsers.push(myValidation);
        }
    };
});