(function () {
	'use strict';

	angular.module('stsClientApp')
		.factory('globalService', globalService);

	globalService.$inject = ['$http', '$q', '$rootScope', '$interval'];

	function globalService($http, $q, $rootScope, $interval) {
		var self = this;
		var base_url = "http://10.30.10.49:8080/api/rest/";
		
		
		self.callApi = function(apiConfig) {
			
			var deferred = $q.defer();
			
			var httpRequest = {
					'method': apiConfig.getMethod(),
					'url': base_url + apiConfig.getUrl(),
					'data': apiConfig.getData(),
					'content-type': 'application/json'
				};
			$rootScope.enableProgress = true;
			updateProgressBar(10);
			
			var progressCount = 10;
			var stop = $interval(function() {
				if(progressCount<90){
					updateProgressBar(progressCount+=5);
				}
	        }, 500);
			
			function updateProgressBar(value){
				$rootScope.progressWidth = value + "%";
			}
			
			$http(httpRequest)
				.success(function (data) {
					deferred.resolve(data);
				})
				.error(function (error) {
					deferred.reject(error);
				})
				.finally(function() {
					updateProgressBar(100);
					$rootScope.enableProgress = false;
					$interval.cancel(stop);
				});
				return deferred.promise;
			}
		
		return self;
	}
})();