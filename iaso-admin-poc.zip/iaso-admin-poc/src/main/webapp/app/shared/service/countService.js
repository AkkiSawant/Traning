(function () {
    'use strict';

    angular.module('stsClientApp')
        .service('countService', countService);

    function countService() {

        var identityZoneCount;
        var roleCount="data";
        var userCount;
        var userWithRoleIdentityCount;

        this.getRoleCount = function() {
        	return roleCount;
        }
        
        this.setRoleCount = function(pRoleCount){
        	roleCount=pRoleCount;
        }
        /*return {
            getIdentityZoneCount: function () {
                return identityZoneCount;
            },
            setIdentityZoneCount: function (pidentityZoneCount) {
            	identityZoneCount = pidentityZoneCount;
            },
            getRoleCount: function () {
                return roleCount;
            },
            setRoleCount: function (pRoleCount) {
            	roleCount = pRoleCount;
            },
            getUserCount: function () {
                return userCount;
            },
            setUserCount: function (pUserCount) {
            	userCount = pUserCount;
            },
            getCount: function () {
                return userWithRoleIdentityCount;
            },
            setCount: function (pUserWithRoleIdentityCount) {
            	userWithRoleIdentityCount = pUserWithRoleIdentityCount;
            }
        }*/
    }

})();