(function () {
	'use strict';

	 angular.module('stsClientApp')
	.factory('Role', Role);
	
	function Role() {
		
		return Role;
		
		function Role() {
			var role = this;
			role.domainName = null;
		}
	}

})();

