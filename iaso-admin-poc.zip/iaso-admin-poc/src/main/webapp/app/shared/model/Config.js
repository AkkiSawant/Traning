(function () {
    'use strict';

    angular.module('stsClientApp')
        .factory('Config', Config);

    function Config() {

        var url;
        var data;
        var method;

        return {
            getData: function () {
                return data;
            },
            setData: function (pdata) {
                data = pdata;
            },
            getUrl: function () {
                return url;
            },
            setUrl: function (purl) {
                url = purl;
            },
            getMethod: function () {
                return method;
            },
            setMethod: function (pmethod) {
                method = pmethod;
            }
        }
    }

})();