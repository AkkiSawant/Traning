(function () {
	'use strict';

	 angular.module('stsClientApp')
	.factory('UserWithRoleIdentity', UserWithRoleIdentity);
	
	function UserWithRoleIdentity() {
		
		return UserWithRoleIdentity;
		
		function UserWithRoleIdentity() {
			var userWithRoleIdentity = this;
			userWithRoleIdentity.zoneId = null;
			userWithRoleIdentity.domainName = null;
			userWithRoleIdentity.roles = null;
		}
	}

})();