(function () {
    'use strict';

    angular.module('stsClientApp').factory('User', User);

    function User() {

        return User;

        function User() {
            var vm = this;
            vm.zoneId = null;
            vm.domainName = null;
            vm.opaqueId = null;
            vm.firstName = null;
            vm.lastName = null;
        }
    }



})();