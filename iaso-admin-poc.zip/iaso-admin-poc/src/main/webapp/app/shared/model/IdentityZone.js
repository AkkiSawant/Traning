(function () {
	'use strict';

	 angular.module('stsClientApp')
	.factory('IdentityZone', IdentityZone);
	
	function IdentityZone() {
		
		return IdentityZone;
		
		function IdentityZone() {
			var identityZone = this;
			identityZone.domainName = null;
			identityZone.groupName=null;
		}
	}

})();