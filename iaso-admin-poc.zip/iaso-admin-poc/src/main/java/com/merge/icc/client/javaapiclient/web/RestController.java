package com.merge.icc.client.javaapiclient.web;

import com.mergehealthcare.icc.web.model.RoleDetail;
import com.mergehealthcare.icc.web.model.UserInformation;
import com.mergehealthcare.icc.web.service.UserService;
import com.mergehealthcare.icc.web.service.UserServiceImpl;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Set;

@Controller
public class RestController {

    UserService userService;


    public RestController() {
        this.userService = new UserServiceImpl();
    }


    @RequestMapping (value = "/users", method = RequestMethod.GET)
    public ResponseEntity<List<UserInformation>> findAllUsers() {

        List<UserInformation> users = userService.findAllUsers();
        if (users == null || users.isEmpty()) {
            return new ResponseEntity<List<UserInformation>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<List<UserInformation>>(users, HttpStatus.OK);

    }


    @RequestMapping (value = "/user/{domainName}", method = RequestMethod.GET)
    public ResponseEntity<List<UserInformation>> findUsersByUserName(@PathVariable ("domainName") String domainName) {
        List<UserInformation> usersInfo = userService.findUsersByUserName(domainName);
        if (usersInfo == null || usersInfo.isEmpty()) {
            return new ResponseEntity<List<UserInformation>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<List<UserInformation>>(usersInfo, HttpStatus.OK);
    }


    @RequestMapping (value = "/roles", method = RequestMethod.GET)
    public ResponseEntity<Set<RoleDetail>> findAllRoles() {
        Set<RoleDetail> roles = userService.findAllRoles();
        if (roles == null || roles.isEmpty()) {
            return new ResponseEntity<Set<RoleDetail>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Set<RoleDetail>>(roles, HttpStatus.OK);
    }


    @RequestMapping (value = "/role/{domainId}", method = RequestMethod.GET)
    public ResponseEntity<Set<RoleDetail>> findRolesByDomainId(@PathVariable ("domainId") String domainId) {
        System.out.println("Fetching User with domainId " + domainId);
        Set<RoleDetail> roledetail = userService.findRolesByDomainId(domainId);
        if (roledetail == null || roledetail.isEmpty()) {
            System.out.println("Role with domainId " + domainId + " not found");
            return new ResponseEntity<Set<RoleDetail>>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Set<RoleDetail>>(roledetail, HttpStatus.OK);
    }
}
