package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

@Component
@Scope ("prototype")
public class IdentityZonesForGroupsResponse {

    private Map<String, Set<IdentityZone>> identityZones;


    public Map<String, Set<IdentityZone>> getIdentityZones() {
        return identityZones;
    }


    public void setIdentityZones(Map<String, Set<IdentityZone>> identityZones) {
        this.identityZones = identityZones;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("IdentityZonesForGroupsResponse [identityZones=");
        builder.append(identityZones);
        builder.append("]");
        return builder.toString();
    }

}
