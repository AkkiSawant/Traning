package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Scope ("prototype")
public class SystemUsageResponse {

    private TimeOffset interval;

    private Set<IntervalUsage> usage;


    public SystemUsageResponse() {
        usage = new HashSet<IntervalUsage>();
    }


    public TimeOffset getInterval() {
        return interval;
    }


    public void setInterval(TimeOffset interval) {
        this.interval = interval;
    }


    public Set<IntervalUsage> getUsage() {
        return usage;
    }


    public void setUsage(Set<IntervalUsage> usage) {
        this.usage = usage;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SystemUsageResponse [interval=");
        builder.append(interval);
        builder.append(", usage=");
        builder.append(usage);
        builder.append("]");
        return builder.toString();
    }

}
