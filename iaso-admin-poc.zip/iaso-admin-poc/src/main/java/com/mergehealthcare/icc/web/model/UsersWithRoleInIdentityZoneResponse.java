package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Scope ("prototype")
public class UsersWithRoleInIdentityZoneResponse {

    private String zoneId;

    private String domainName;

    private Set<String> roles;


    public UsersWithRoleInIdentityZoneResponse() {
        roles = new HashSet<String>();
    }


    public String getZoneId() {
        return zoneId;
    }


    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }


    public String getDomainName() {
        return domainName;
    }


    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }


    public Set<String> getRoles() {
        return roles;
    }


    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("UsersWithRoleInIdentityZoneRequest [zoneId=");
        builder.append(zoneId);
        builder.append(", domainName=");
        builder.append(domainName);
        builder.append(", roles=");
        builder.append(roles);
        builder.append("]");
        return builder.toString();
    }

}
