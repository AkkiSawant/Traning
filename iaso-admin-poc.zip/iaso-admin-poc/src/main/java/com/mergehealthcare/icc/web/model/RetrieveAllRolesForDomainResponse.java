package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope ("prototype")
public class RetrieveAllRolesForDomainResponse {

    private String domainName;


    public String getDomainName() {
        return domainName;
    }


    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RolesForDomainRequest [domainName=");
        builder.append(domainName);
        builder.append("]");
        return builder.toString();
    }

}
