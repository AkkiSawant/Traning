package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Scope ("prototype")
public class SystemUsageRequest {

    private Date startDate;

    private Date endDate;

    private TimeOffset interval;

    private CodedValueType sourceSystem;

    private String domainName;


    public Date getStartDate() {
        return startDate;
    }


    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }


    public Date getEndDate() {
        return endDate;
    }


    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }


    public TimeOffset getInterval() {
        return interval;
    }


    public void setInterval(TimeOffset interval) {
        this.interval = interval;
    }


    public CodedValueType getSourceSystem() {
        return sourceSystem;
    }


    public void setSourceSystem(CodedValueType sourceSystem) {
        this.sourceSystem = sourceSystem;
    }


    public String getDomainName() {
        return domainName;
    }


    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SystemUsageRequest [startDate=");
        builder.append(startDate);
        builder.append(", endDate=");
        builder.append(endDate);
        builder.append(", interval=");
        builder.append(interval);
        builder.append(", sourceSystem=");
        builder.append(sourceSystem);
        builder.append(", domainName=");
        builder.append(domainName);
        builder.append("]");
        return builder.toString();
    }

}
