package com.mergehealthcare.icc.web.model;

public class CodedValueType {

    private String code;

    private String codeSystem;

    private String codeSystemName;

    private String displayName;

    private String originalText;


    public String getCode() {
        return code;
    }


    public void setCode(String code) {
        this.code = code;
    }


    public String getCodeSystem() {
        return codeSystem;
    }


    public void setCodeSystem(String codeSystem) {
        this.codeSystem = codeSystem;
    }


    public String getCodeSystemName() {
        return codeSystemName;
    }


    public void setCodeSystemName(String codeSystemName) {
        this.codeSystemName = codeSystemName;
    }


    public String getDisplayName() {
        return displayName;
    }


    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }


    public String getOriginalText() {
        return originalText;
    }


    public void setOriginalText(String originalText) {
        this.originalText = originalText;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CodedValueType [code=");
        builder.append(code);
        builder.append(", codeSystem=");
        builder.append(codeSystem);
        builder.append(", codeSystemName=");
        builder.append(codeSystemName);
        builder.append(", displayName=");
        builder.append(displayName);
        builder.append(", originalText=");
        builder.append(originalText);
        builder.append("]");
        return builder.toString();
    }

}
