package com.mergehealthcare.icc.web.model;

public class IntervalUsage {

    private int hourOfDay;

    private int userCount;


    public int getHourOfDay() {
        return hourOfDay;
    }


    public void setHourOfDay(int hourOfDay) {
        this.hourOfDay = hourOfDay;
    }


    public int getUserCount() {
        return userCount;
    }


    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("IntervalUsage [hourOfDay=");
        builder.append(hourOfDay);
        builder.append(", userCount=");
        builder.append(userCount);
        builder.append("]");
        return builder.toString();
    }

}
