package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope ("prototype")
public class RoleDetail {

    private String id;

    private String description;

    private String domainId;

    private String roleName;


    public RoleDetail(String id, String description, String domainId, String roleName) {
        super();
        this.id = id;
        this.description = description;
        this.domainId = domainId;
        this.roleName = roleName;
    }


    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }


    public String getDomainId() {
        return domainId;
    }


    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }


    public String getRoleName() {
        return roleName;
    }


    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RoleDetail [id=");
        builder.append(id);
        builder.append(", description=");
        builder.append(description);
        builder.append(", domainId=");
        builder.append(domainId);
        builder.append(", roleName=");
        builder.append(roleName);
        builder.append("]");
        return builder.toString();
    }

}
