package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Scope ("prototype")
public class UsersInformationResponse {

    private Set<UserInformation> users;


    public UsersInformationResponse() {
        users = new HashSet<UserInformation>();
    }


    public Set<UserInformation> getUsers() {
        return users;
    }


    public void setUsers(Set<UserInformation> users) {
        this.users = users;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("UsersInformationResponse [users=");
        builder.append(users);
        builder.append("]");
        return builder.toString();
    }

}
