package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope ("prototype")
public class IdentityZone {

    private String zoneId;

    private String email;


    public String getZoneId() {
        return zoneId;
    }


    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("IdentityZone [zoneId=");
        builder.append(zoneId);
        builder.append(", email=");
        builder.append(email);
        builder.append("]");
        return builder.toString();
    }

}
