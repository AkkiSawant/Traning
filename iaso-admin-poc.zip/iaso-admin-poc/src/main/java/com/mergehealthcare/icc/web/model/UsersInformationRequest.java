package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope ("prototype")
public class UsersInformationRequest {

    private String DomainName;

    private String OpaqueId;

    private String FirstName;

    private String LastName;

    private String ZoneId;


    public String getDomainName() {
        return DomainName;
    }


    public void setDomainName(String domainName) {
        DomainName = domainName;
    }


    public String getOpaqueId() {
        return OpaqueId;
    }


    public void setOpaqueId(String opaqueId) {
        OpaqueId = opaqueId;
    }


    public String getFirstName() {
        return FirstName;
    }


    public void setFirstName(String firstName) {
        FirstName = firstName;
    }


    public String getLastName() {
        return LastName;
    }


    public void setLastName(String lastName) {
        LastName = lastName;
    }


    public String getZoneId() {
        return ZoneId;
    }


    public void setZoneId(String zoneId) {
        ZoneId = zoneId;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("UsersInformationRequest [DomainName=");
        builder.append(DomainName);
        builder.append(", OpaqueId=");
        builder.append(OpaqueId);
        builder.append(", FirstName=");
        builder.append(FirstName);
        builder.append(", LastName=");
        builder.append(LastName);
        builder.append(", ZoneId=");
        builder.append(ZoneId);
        builder.append("]");
        return builder.toString();
    }
}
