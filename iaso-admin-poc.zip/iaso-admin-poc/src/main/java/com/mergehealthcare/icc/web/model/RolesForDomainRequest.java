package com.mergehealthcare.icc.web.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
@Scope ("prototype")
public class RolesForDomainRequest {

    @Autowired
    private Set<RoleDetail> roles;


    public Set<RoleDetail> getRoles() {
        return roles;
    }


    public void setRoles(Set<RoleDetail> roles) {
        this.roles = roles;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RolesForDomainRequest [roles=");
        builder.append(roles);
        builder.append("]");
        return builder.toString();
    }

}
