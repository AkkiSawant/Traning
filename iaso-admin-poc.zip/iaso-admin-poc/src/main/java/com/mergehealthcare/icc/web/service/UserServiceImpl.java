package com.mergehealthcare.icc.web.service;

import com.mergehealthcare.icc.web.model.RoleDetail;
import com.mergehealthcare.icc.web.model.UserInformation;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service ("userService")
public class UserServiceImpl implements UserService {

    private static List<UserInformation> users;

    private static Set<RoleDetail> roles;

    static {
        roles = populateDummyRoles();
        users = populateDummyUsers();
    }


    public List<UserInformation> findAllUsers() {
        return users;
    }


    public Set<RoleDetail> findAllRoles() {
        return roles;
    }


    public List<UserInformation> findUsersByUserName(String domainName) {
        List<UserInformation> usersInformation = new ArrayList<UserInformation>();
        for (UserInformation userInformation : users) {
            if (userInformation.getUserName().equalsIgnoreCase(domainName)) {
                usersInformation.add(userInformation);
            }
        }
        return usersInformation;
    }


    public Set<RoleDetail> findRolesByDomainId(String domainId) {
        Set<RoleDetail> roledetails = new HashSet<RoleDetail>();
        for (RoleDetail roledetail : roles) {
            if (roledetail.getDomainId().equalsIgnoreCase(domainId)) {
                roledetails.add(roledetail);
            }
        }
        return roledetails;
    }


    private static List<UserInformation> populateDummyUsers() {
        List<UserInformation> users = new ArrayList<UserInformation>();
        users.add(new UserInformation("Hac", "Sam", "NY", "sam@abc.com", "India", "Us"));
        users.add(new UserInformation("Com", "Tomy", "ALBAMA", "tomy@abc.com", "Nepal", "Bhutan"));
        users.add(new UserInformation("Hls", "Kelly", "NEBRASKA", "kelly@abc.com", "Austrelia", "US"));
        return users;
    }


    private static Set<RoleDetail> populateDummyRoles() {
        Set<RoleDetail> roledetails = new HashSet<RoleDetail>();
        roledetails.add(new RoleDetail("Hac", "Sam", "NY", "Ldap"));
        roledetails.add(new RoleDetail("Com", "Tomy", "ALBAMA", "Sts"));
        roledetails.add(new RoleDetail("Hls", "Kelly", "NEBRASKA", "kelly"));
        return roledetails;
    }

}
