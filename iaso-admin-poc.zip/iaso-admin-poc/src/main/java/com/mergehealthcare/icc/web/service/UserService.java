package com.mergehealthcare.icc.web.service;

import com.mergehealthcare.icc.web.model.RoleDetail;
import com.mergehealthcare.icc.web.model.UserInformation;

import java.util.List;
import java.util.Set;

public interface UserService {

    // This is for Users
    public List<UserInformation> findUsersByUserName(String userName);


    public Set<RoleDetail> findRolesByDomainId(String domainId);


    public List<UserInformation> findAllUsers();


    public Set<RoleDetail> findAllRoles();

}
