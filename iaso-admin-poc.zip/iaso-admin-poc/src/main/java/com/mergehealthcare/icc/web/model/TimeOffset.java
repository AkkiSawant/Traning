package com.mergehealthcare.icc.web.model;

public enum TimeOffset {

    ONE_HOUR("OneHour"),

    TWO_HOURS("TwoHours"),

    THREE_HOURS("ThreeHours"),

    FOUR_HOURS("FourHours"),

    EIGHT_HOURS("EightHours");

    private final String value;


    TimeOffset(String v) {
        value = v;
    }


    public String value() {
        return value;
    }


    public static TimeOffset fromValue(String v) {
        for (TimeOffset c : TimeOffset.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
