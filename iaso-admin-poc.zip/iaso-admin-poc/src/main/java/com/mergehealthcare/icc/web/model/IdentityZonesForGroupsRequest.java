package com.mergehealthcare.icc.web.model;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Scope ("prototype")
public class IdentityZonesForGroupsRequest {

    private String domainName;

    private Set<String> groupNames;


    public IdentityZonesForGroupsRequest() {
        groupNames = new HashSet<String>();
    }


    public String getDomainName() {
        return domainName;
    }


    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }


    public Set<String> getGroupNames() {
        return groupNames;
    }


    public void setGroupNames(Set<String> groupNames) {
        this.groupNames = groupNames;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("IdentityZonesForGroupsRequest [domainName=");
        builder.append(domainName);
        builder.append(", groupNames=");
        builder.append(groupNames);
        builder.append("]");
        return builder.toString();
    }

}
