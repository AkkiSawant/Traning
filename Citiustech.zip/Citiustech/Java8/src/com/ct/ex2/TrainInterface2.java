package com.ct.ex2;

@FunctionalInterface
public interface TrainInterface2 {

	public void process();
	
}
