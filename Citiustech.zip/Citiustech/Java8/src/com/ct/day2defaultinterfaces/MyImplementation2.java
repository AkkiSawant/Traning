package com.ct.day2defaultinterfaces;

public class MyImplementation2 implements Interface1, Interface2 {

	@Override
	public void callme() {
		Interface1.super.callme();
	}
	
	public static void main(String[] args) {
		
		Interface2 ikn = new MyImplementation2();
		ikn.callme();
		
		Interface3.callmestatic();
		
	}
	
}
