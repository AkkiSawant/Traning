package com.ct.day2defaultinterfaces;

public class MyImplementation implements Interface3 {

	@Override
	public void callme() {
		System.out.println("hi");
	}
	
	public static void main(String[] args) {
		
		Interface3 ikn = new MyImplementation();
		ikn.callme();
		
	}
	
}
