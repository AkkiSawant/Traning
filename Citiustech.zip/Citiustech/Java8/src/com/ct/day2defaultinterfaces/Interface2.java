package com.ct.day2defaultinterfaces;


public interface Interface2 {
	
    default void callme() { System.out.println("interface2"); }


}
