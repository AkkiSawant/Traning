package com.ct.ex4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyComparator {
	
	public static void main(String[] args) {
		
		Comparator<Integer> comparator = new Comparator<Integer>() {
			
			@Override
			public int compare(Integer i1, Integer i2) {
				return Integer.compare(i1, i2);
			}
		};
		
		List<Integer> list = new ArrayList<Integer>() {{
			add(3);
			add(8);
			add(1);
		}};
		
		
		for(Integer varInt : list ){
			if(varInt == 8){
				return;
			}
			
		}
		
		System.out.println(list);
		System.out.println("\n\n");
		
		Collections.sort(list, (i1, i2) -> Integer.compare(i1, i2));
		
		System.out.println(list);		
		
	}

}
