package com.ct.ex1;

import java.io.File;
import java.io.FileFilter;

public class Main {

	public static void main(String[] args) {
		
		FileFilter filefilter1 = new FileFilter() {
			
			@Override
			public boolean accept(File file) {
				return file.getPath().endsWith(".java");
			}
		};

		//first lambda expression
		FileFilter filefilter = (File file) -> {
			return file.getPath().endsWith(".java");
		};
		
		
		File file = new File("D:\\Java8-Training\\eclipse-workspace\\DecJava8Training\\src\\com\\ct\\ex1");
		File[] files = file.listFiles(filefilter);
//		File[] files = file.listFiles(filefilter1);
		for(File ff : files) {
			System.out.println(ff);
		}
		
		
		
	}
	
}
