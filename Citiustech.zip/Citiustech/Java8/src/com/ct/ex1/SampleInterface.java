package com.ct.ex1;

@FunctionalInterface
public interface SampleInterface {
	
	public void process();
	
	public boolean equals(Object obj);

	//public void exit();

}
