package com.ct.day2.mr;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Sample {

	public static void main(String[] args) {

		List<String> l = new ArrayList<String>() {
			{
				add("A");
				add("BB");
				add("C");
			}
		};
		l.forEach(((Consumer<String>) String::toLowerCase)
				.andThen(System.out::println));

	}

}
