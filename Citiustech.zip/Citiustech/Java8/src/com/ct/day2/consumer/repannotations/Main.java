package com.ct.day2.consumer.repannotations;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@interface LogHistory {
	Log[] value();
}

@Repeatable(LogHistory.class)
@interface Log {
	String date();

	String comments();
}

@Log(date = "02/01/2014", comments = "A")
@Log(date = "01/22/2014", comments = "B")
public class Main {
	public static void main(String[] args) {
		Class<Main> mainClass = Main.class;

		Log[] annList = mainClass.getAnnotationsByType(Log.class);
		for (Log log : annList) {
			System.out.println("Date=" + log.date() + ", Comments="
					+ log.comments());
		}

		Class<LogHistory> containingAnnClass = LogHistory.class;
		LogHistory logs = mainClass.getAnnotation(containingAnnClass);

		for (Log log : logs.value()) {
			System.out.println("Date=" + log.date() + ", Comments="
					+ log.comments());
		}
		
		try {
			Thread.sleep(1000*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}