package com.ct.day2.consumer.repannotations;

@Author(name = "John")
@Author(name = "George")
public class Book {

	private String name;

	public Book(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
