package com.ct.day2.consumer.repannotations;

public class BookAuthorTest {

	public static void main(String[] args) {
		Class<Book> clazz = Book.class;
		
		//Authors authors = (Authors) clazz.getAnnotation(Authors.class);
		//Authors authors = Book.class.getAnnotation(Authors.class);
		//for (Author author : authors.value())
		//	System.out.println("Author=" + author.name());

		
		Author[] authors2 = clazz.getAnnotationsByType(Author.class);
		System.out.println("authors2 size "+authors2.length);
		for (Author author : authors2)
		    System.out.println("Author=" + author.name());
	}

}
