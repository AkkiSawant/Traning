package com.ct.day2.consumer.repannotations;

import java.lang.annotation.Repeatable;
 
@Repeatable(value = Authors.class)
public @interface Author {
    String name() default "";
}
