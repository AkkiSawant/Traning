package com.ct.day2.typeinfer;

public interface TypeInterface<T> {
	static <T> T pick(T a1, T a2) { return a2; }
}
