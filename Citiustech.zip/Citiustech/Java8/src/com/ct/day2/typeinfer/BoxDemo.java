package com.ct.day2.typeinfer;

import java.util.Collections;
import java.util.List;

public class BoxDemo {

	public static <U> void addBox(U u, java.util.List<Box<U>> boxes) {
		Box<U> box = new Box<>();
		box.set(u);
		boxes.add(box);
	}

	public static <U> void outputBoxes(java.util.List<Box<U>> boxes) {
		int counter = 0;
		for (Box<U> box : boxes) {
			U boxContents = box.get();
			System.out.println("Box #" + counter + " contains ["
					+ boxContents.toString() + "]");
			counter++;
		}
	}

	public static void main(String[] args) {
		java.util.ArrayList<Box<Integer>> listOfIntegerBoxes = new java.util.ArrayList<>();
		// to invoke the generic method addBox, you can specify the type
		// parameter with a type
		BoxDemo.<Integer> addBox(Integer.valueOf(10), listOfIntegerBoxes);
		// omit the type witness,a Java compiler automatically infers (from the
		// method's arguments) that the type parameter is Integer:
		BoxDemo.addBox(Integer.valueOf(20), listOfIntegerBoxes);
		BoxDemo.addBox(Integer.valueOf(30), listOfIntegerBoxes);
		BoxDemo.outputBoxes(listOfIntegerBoxes);

		List<String> listOne = Collections.emptyList();
		System.out.println(listOne);
		
		//String s = invoke(() -> "done");
		invoke(() -> { return "dd"; });
		invoke(() -> { });

	}
	
	public static void invoke(MyRunnable r) {
	    r.run();
	    System.out.println("MyRunnable");
	}

/*	public static <T> T invoke(MyCallable<T> c) {
		System.out.println("MyCallable");
	    return c.call();
	}*/
	
	public static <T> void invoke(MyCallable<T> c) {
		System.out.println("MyCallable");
	}
}

interface MyRunnable {
	void run();
}

interface MyCallable<V> {
	V call();
}