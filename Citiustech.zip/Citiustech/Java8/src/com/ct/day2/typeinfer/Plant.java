package com.ct.day2.typeinfer;

public interface Plant {
    enum Pace { FAST, SLOW; }

    void grow(Pace pace);
    //void growFast();
    //void growSlow();
    
    default void growFast() { grow(Pace.FAST); }
    default void growSlow() { grow(Pace.SLOW); }
    
}
