package com.ct.day2.mrcons;

public interface FuncIf {
    String strFunc(char[] chArray);
    
    default String doit() {
    	return "aaaa";
    }
    
}
