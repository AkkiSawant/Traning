package com.ct.day2.mrcons;

import com.ct.day2.model.Person;

public class FuncIfImpl {
	public static void main(String[] args) {

		FuncIf fi = String::new;

		char[] charArray = { 's', 'p', 'e', 'a', 'k', 'i', 'n', 'g', 'c', 's' };

		System.out.println(fi.strFunc(charArray));

		Person person = new Person("Joe", 48);
		// FuncIf2 fi2 = String::new;
		FuncIf2 fi2 = Person::new;
		Person person2 = fi2.strFunc("Faiz", 10);
		System.out.println(person2.getAge());

		FuncIf3 fi3 = int[]::new;
		int[] intArr = fi3.intArrMaker(10);

		for (int i = 0; i < intArr.length; i++) {

			intArr[i] = i * 10;

			System.out.print(" " + i);

		}

	}
}
