package com.ct.day2.mrcons;

import com.ct.day2.model.Person;

public interface FuncIf4 {
    String strFunc(Person person);
    
    default String doit() {
    	return "aaaa";
    }
    
}
