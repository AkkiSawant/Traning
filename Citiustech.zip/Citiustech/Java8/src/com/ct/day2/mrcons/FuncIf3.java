package com.ct.day2.mrcons;


public interface FuncIf3 {
    int[] intArrMaker(int noOfEle);    
}
