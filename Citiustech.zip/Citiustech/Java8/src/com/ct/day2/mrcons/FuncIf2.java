package com.ct.day2.mrcons;

import com.ct.day2.model.Person;

public interface FuncIf2 {
//    String strFunc(Person person);
    Person strFunc(String name, int age);
}
