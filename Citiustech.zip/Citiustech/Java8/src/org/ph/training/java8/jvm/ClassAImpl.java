package org.ph.training.java8.jvm;

/**
 * ClassAImpl
 * @author Pierre-Hugues Charbonneau
 *
 */
public class ClassAImpl implements ClassA {
	
	public void method(String name) {
		// do nothing
	}
}
