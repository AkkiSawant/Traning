package org.ph.training.java8.jvm;

/**
 * ClassA
 * @author Pierre-Hugues Charbonneau
 *
 */
public interface ClassA {
	void method(String input);
}
