package com.citi;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CheckingARM {

	public static void main(String[] args) throws IOException {
		
	traditional_prion_java7way();
		
		
/*After the whole process both streams will be closed automatically either the
 *  code has been executed normally or not that means stockQuoteReader.close() and
 *   stockQuoteWriter.close() called automatically which is the best part of ARM.*/

	
	
	try (
				FileInputStream stockQuoteReader = new FileInputStream("StockQuotes.txt");
				FileOutputStream stockQuoteWriter = new FileOutputStream("StockQuotesOut.txt")
				) {
				      int var;
				    
				      while((var= stockQuoteReader.read()) != -1 )
				            stockQuoteWriter.write(var);;
				  }
		
		
		
	}

static void traditional_prion_java7way() throws IOException{
	
	
	FileInputStream stockQuoteReader= null;
    FileOutputStream stockQuoteWriter = null;
    try {

      stockQuoteReader = new FileInputStream("StockQuotes.txt");
      stockQuoteWriter = new FileOutputStream("StockQuotesOut.txt");
      int var;
      while((var= stockQuoteReader.read()) != -1 )
        stockQuoteWriter.write(var);
    } finally {
      if (stockQuoteReader!= null)
        stockQuoteReader.close();
      if (stockQuoteWriter!= null)
        stockQuoteWriter.close();
    }


	
	
	
	
}

}
