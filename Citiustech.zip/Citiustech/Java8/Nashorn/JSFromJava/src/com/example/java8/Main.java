package com.example.java8;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Main {

	public static void main(String[] args) throws ScriptException {
 
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("nashorn");
	
		String script1="var welcome= 'Hello'; "
				+ "	welcome +=', David';"
				+ "welcome;";
		Object result1 = engine.eval(script1);
	//	String strresult1 = (String)engine.eval(script1);
		System.out.println(result1);
		String script2 = "'Hello World'.length";
		Object result2 = engine.eval(script2);
		System.out.println(result2);
		
	}
	
	
}
