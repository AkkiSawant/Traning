var MyJavaClass = Java.type('invoking_java_methods_from_js.MyJavaClass');

var result = MyJavaClass.fun1('Chand and Faiz');
print(result);

var obj = new MyJavaClass();
var result2 =obj.fun2("Checking ");
print(result2);

 MyJavaClass.check_JavaType('a');
 MyJavaClass.check_JavaType(23.55);
 MyJavaClass.check_JavaType(true);
 MyJavaClass.check_JavaType(new Number(23));