package invoking_javascript_functions_from_java;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.time.LocalDateTime;
import java.util.Date;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class InvokingJSFunctions {

	
	public static void main(String[] args) throws NoSuchMethodException, ScriptException {
		
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("nashorn");
		
		try {
			engine.eval(new FileReader("scripts/func.js"));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ScriptException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Invocable invocable = (Invocable) engine;
		//Object result = invocable.invokeFunction("fun1", "Peter Parker");
		//System.out.println(result);
		//System.out.println(result.getClass());
		
		invocable.invokeFunction("fun2", new Date());

invocable.invokeFunction("fun2", LocalDateTime.now());
invocable.invokeFunction("fun2", new Person());
	}
}
