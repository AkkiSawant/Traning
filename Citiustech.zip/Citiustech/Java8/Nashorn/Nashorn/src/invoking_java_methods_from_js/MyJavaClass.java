package invoking_java_methods_from_js;

public class MyJavaClass {
	
public	static String fun1(String name) {
	    System.out.format("Hi there from Java, %s", name);
	    return "greetings from static method";
	}
 
public static void check_JavaType(Object object) {
    System.out.println("JavaType is : "+ object.getClass());
}

public String fun2(String name){
	
	System.out.format("Hi there from Java, %s", name);
    return "greetings from instance Method";
}


}
