var feed = 'http://www.w3schools.com/xml/plant_catalog.xml';
var url = new java.net.URL(feed);
input = new java.util.Scanner(url.openStream());
input.useDelimiter('$')
var contents = input.next()
contents
