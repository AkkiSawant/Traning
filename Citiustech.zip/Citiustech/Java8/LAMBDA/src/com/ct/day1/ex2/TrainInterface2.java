package com.ct.day1.ex2;

@FunctionalInterface
public interface TrainInterface2 {

	public void process();
	
	public default void  run() {
		
	}
	
}
