package com.ct.day1.ex3;

public class MyRunnable {

	public static void main(String[] args) {

		Runnable runnable = new Runnable() {

			@Override
			public void run() {

				for (int i = 1; i <= 10; i++) {
					System.out.println("ThreadName "
							+ Thread.currentThread().getName());
				}

			}
		};
		
		Runnable runnableLambda = () -> {
			for (int i = 1; i <= 10; i++) {
				System.out.println("ThreadName "
						+ Thread.currentThread().getName());
			}
			
		};
		

		Thread thread = new Thread(runnableLambda);
		
/*		Thread thread = new Thread(() -> {
			for (int i = 1; i <= 10; i++) {
				System.out.println("ThreadName "
						+ Thread.currentThread().getName());
			}
			
		});*/

		
		thread.start();

		
		
		
	}

}
