package com.ct.day1.ex1;

import java.io.File;
import java.io.FileFilter;

public class Example1 {
	
	public static void main(String[] args) {
		
		FileFilter filter = new FileFilter() {
			
			@Override
			public boolean accept(File pathname) {
				return pathname.getName().endsWith(".java");
			}
		}; 
		
		FileFilter filter2 = (File file) -> {
			return file.getName().endsWith(".java");
		};
		
		File filedir = new File(System.getProperty("user.dir")+"/src/com/ct/day1/ex1");
//		File[] files = filedir.listFiles(filter2);
		File[] files = filedir.listFiles((File file) -> {
			return file.getName().endsWith(".java");
		});
		
		for(File file : files) {
			System.out.println(file);
		}
		
		
		
		
	}

}
