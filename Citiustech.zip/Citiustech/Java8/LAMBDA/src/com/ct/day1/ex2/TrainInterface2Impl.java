package com.ct.day1.ex2;

public class TrainInterface2Impl {

	public static void main(String[] args) {
		
		TrainInterface2 interface2 = new TrainInterface2() {
			
			@Override
			public void process() {
				System.out.println("Hello Rajesh");
				
			}
		};
		
		
		TrainInterface2 interfaceLambda = () -> System.out.println("Hello Class");;
		
		
		interface2.process();
		interfaceLambda.process();
		
	}

}
