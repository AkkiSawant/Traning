package com.ct.listiter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class TraversingExample {

	public static void main(String[] args) {
		List<String> lists = new ArrayList<String>();
		lists.add("AAA");
		lists.add("bbb");
		lists.add("CCC");
		lists.add("ddd");
		lists.add("EEE");

/*		Collections.sort(lists);
		System.out.println("Simple sort");

		// Traverse with for:each
		for (String str : lists) {
			System.out.println(str);
		}

		Comparator<String> comp = (str1, str2) -> {
			return str1.compareToIgnoreCase(str2);
		};
		Collections.sort(lists, comp);

		System.out.println("Sort with comparator");

		// Traverse with iterator
		Iterator<String> i = lists.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}

		System.out.println("\n\nSort with foreach");

		lists.sort((str1, str2) -> {
			return str1.compareToIgnoreCase(str2);
		});*/

		System.out.println("----------------------------------------------------------");
		lists.forEach(str -> System.out.println(str));
		
		System.out.println("----------------------------------------------------------");
		//lists.forEach(System.out::println);
		
		
		lists.stream()
		.map(String::toUpperCase)
		.forEach(System.out::println);
	}

}
