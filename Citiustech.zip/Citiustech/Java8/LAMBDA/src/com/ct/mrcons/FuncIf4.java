package com.ct.mrcons;

import com.ct.mrstatic.Person;


public interface FuncIf4 {
    String strFunc(Person person);
    
    default String doit() {
    	return "aaaa";
    }
    
}
