package com.ct.mrcons;

public interface FuncIf {
    String strFunc(char[] chArray);
    
    default String doit() {
    	return "aaaa";
    }
    
}
