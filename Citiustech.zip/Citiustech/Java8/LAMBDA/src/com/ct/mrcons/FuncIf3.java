package com.ct.mrcons;


public interface FuncIf3 {
    int[] intArrMaker(int noOfEle);    
}
