package com.ct.mrcons;

import com.ct.mrstatic.Person;

public interface FuncIf2 {
//    Person strFunc(String name, int age);
    Person strFunc(Person person);
}
