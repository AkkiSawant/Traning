package com.ct.mrstatic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StaticMethodReference {
	
	public static void main(String[] args) {
		
		Person person1 = new Person("John", 34);
		Person person2 = new Person("Johny", 85);
		Person person3 = new Person("Janardhan", 12);
		
		List<Person> peoples = new ArrayList<Person>() { 
			private static final long serialVersionUID = 1L;

		{
			add(person1);
			add(person2);
			add(person3);
		}};
		peoples.forEach(person -> System.out.println(person));

		System.out.println("\n\nafter sort\n\n");
		//Collections.sort(peoples, (p1, p2) -> Person.compareByAge(p1, p2));

		Collections.sort(peoples, Person :: compareByAge);

		peoples.forEach(person -> System.out.println(person));
		
	}

}
