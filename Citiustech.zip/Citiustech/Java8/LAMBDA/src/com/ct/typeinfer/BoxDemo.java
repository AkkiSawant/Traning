package com.ct.typeinfer;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;

public class BoxDemo {

	public static <U> void addBox(U u, java.util.List<Box<U>> boxes) {
		Box<U> box = new Box<>();
		box.set(u);
		boxes.add(box);
	}

	public static <U> void outputBoxes(java.util.List<Box<U>> boxes) {
		int counter = 0;
		for (Box<U> box : boxes) {
			U boxContents = box.get();
			System.out.println("Box #" + counter + " contains ["
					+ boxContents.toString() + "]");
			counter++;
		}
	}

	public static void main(String[] args) throws Exception {
		java.util.ArrayList<Box<Integer>> listOfIntegerBoxes = new java.util.ArrayList<>();
		// to invoke the generic method addBox, you can specify the type
		// parameter with a type
		BoxDemo.<Integer> addBox(Integer.valueOf(10), listOfIntegerBoxes);
		// omit the type witness,a Java compiler automatically infers (from the
		// method's arguments) that the type parameter is Integer:
		BoxDemo.addBox(Integer.valueOf(20), listOfIntegerBoxes);
		BoxDemo.addBox(Integer.valueOf(30), listOfIntegerBoxes);
		BoxDemo.outputBoxes(listOfIntegerBoxes);

		List<String> listOne = Collections.emptyList();
		System.out.println(listOne);

		//String s = invoke(() -> "done");

		invoke(() -> {
			 return "dd";
		});
		
		invoke(() -> {
		});

	}

	static void invoke(Runnable r) {
		System.out.println("Runnable");
		r.run();
	}

	static <T> T  invoke(Callable<T> c) throws Exception {
		System.out.println("Callable");
		return c.call();
	}
}
