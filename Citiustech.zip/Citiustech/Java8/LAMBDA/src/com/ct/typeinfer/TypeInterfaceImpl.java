package com.ct.typeinfer;

import java.io.Serializable;
import java.util.ArrayList;

public class TypeInterfaceImpl {

	public static void main(String[] args) {
		
		
		Serializable se = TypeInterface.pick("d", new ArrayList<String>());
		
		
		
	}
	
}
