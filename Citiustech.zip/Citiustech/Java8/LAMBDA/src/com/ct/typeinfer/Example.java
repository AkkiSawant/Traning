package com.ct.typeinfer;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class Example {

	public static void main(String[] args) {
		Set<String> birds = new TreeSet<String>();
		birds.add("Robin");
		birds.add("Hawk");
		birds.addAll(Arrays.asList());
		
		
		
		//birds.addAll(Arrays.<String>asList());
	}
	
}
