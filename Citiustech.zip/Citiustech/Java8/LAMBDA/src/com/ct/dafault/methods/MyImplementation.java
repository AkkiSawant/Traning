package com.ct.dafault.methods;

public class MyImplementation implements Interface3 {

	public void callme() {
		System.out.println("hi3");
	}
	
	public static void main(String[] args) {
		
		Interface3 ikn = new MyImplementation();
		ikn.callme();
		
	}
	
}
