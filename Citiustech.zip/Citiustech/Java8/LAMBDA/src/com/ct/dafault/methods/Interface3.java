package com.ct.dafault.methods;

public interface Interface3 extends Interface2 {
	
	@Override
	public default void callme() {
		System.out.println("interface3");
	}

	
	public static void callmestatic() {
		System.out.println("interface3");
	}
}
