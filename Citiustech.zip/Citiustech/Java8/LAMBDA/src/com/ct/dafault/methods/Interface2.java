package com.ct.dafault.methods;


public interface Interface2 {
	
    default void callme() { System.out.println("interface2"); }


}
