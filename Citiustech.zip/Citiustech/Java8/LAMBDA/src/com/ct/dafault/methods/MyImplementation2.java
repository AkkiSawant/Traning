package com.ct.dafault.methods;

/**
 * default & static methods have bridged down the differences between interfaces
 * and abstract classes.
 * 
 * Interface default methods:
 * 
 * It helps in avoiding utility classes, such as all the Collections class
 * method can be provided in the interfaces itself. It helps in extending
 * interfaces without having the fear of breaking implementation classes.
 * 
 * Interface static methods:
 * 
 * They are part of interface, we can�t use it for implementation class objects.
 * It helps in providing security by not allowing implementation classes to
 * override them.
 */
public class MyImplementation2 implements Interface1, Interface2, Interface3 {

	@Override
	public void callme() {
		Interface1.super.callme();
	}

	public static void main(String[] args) {

		Interface2 ikn = new MyImplementation2();
		ikn.callme();

		Interface3.callmestatic();
/*
		 Interface3 ikn3 = new MyImplementation2();
		 ikn3.callmestatic(); //-- doesn't works
*/
	}

}
