package com.ct.dafault.methods;


public interface Interface1 {
	
    default void callme() { System.out.println("interface1"); }


}
