package ora_forkJoin;

public class Test {
public static void main(String[] args) {
	int numberOfProcessors = Runtime.getRuntime().availableProcessors();
	System.out.println(numberOfProcessors);
}
}
