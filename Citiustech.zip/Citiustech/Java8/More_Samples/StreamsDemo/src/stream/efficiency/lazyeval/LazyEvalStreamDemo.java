package stream.efficiency.lazyeval;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class LazyEvalStreamDemo {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);

		/**
		 * we want to achieve something just a bit more convoluted like:-
		 * 1) Take only the even numbers in the list,
		 * 2) Double them F
		 * 3) Finally print the first one bigger than 5:
		 **/

		System.out.println("------USING JAVA 7-----");
		//PRIOR TO JAVA 8
		Instant st1 = Instant.now();
		for (int number : numbers) {
			System.out.println("in for "+number);
			if (number % 2 == 0) {
				
				int n2 = number * 2;
				System.out.println("double the no : "+number);
				if (n2 > 5) {
					System.out.println(n2);
					break;
				}
			}
		}
		Instant end1 = Instant.now();
		System.out.println("imperative way "+Duration.between(st1, end1));
		/**
		 * WHATS WRONG?????????
		 * It does too much in a single, deeply nested and then difficult to read and maintain block of code.
		 * To fix this problem we can split the 3 operations performed by that code in 3 one-line methods each 
		 * having a single well defined responsibility:
		 * See Lazy.java
		 */
		System.out.println();
		System.out.println("------USING JAVA 7 BUT WITH SEGGREGATION-----");
		//REWRITE THE FORMER CODE 
		List<Integer> l1 = new ArrayList<Integer>();
		for (int n : numbers) {
			if (Lazy.isEven(n)) l1.add(n);
		}
		List<Integer> l2 = new ArrayList<Integer>();
		for (int n : l1) {
			l2.add(Lazy.doubleIt(n));
		}
		List<Integer> l3 = new ArrayList<Integer>();
		for (int n : l2) {
			if (Lazy.isGreaterThan5(n)) l3.add(n);
		}
		System.out.println(l3.get(0));
		
		//Here we can note that all the 6 numbers in the list get evaluated by our pipeline while the former nested for cycle evaluated only the first 4, 
		//being the 4th number the first that satisfies all the requested conditions.
		//Streams can help a lot to fix both this problems.
		
		System.out.println();
		System.out.println("------USING JAVA 8 STREAMS-----");
		Instant st2 = Instant.now();
		System.out.println(
				numbers.stream()
				.filter(Lazy::isEven)
				.map(Lazy::doubleIt)
				.filter(Lazy::isGreaterThan5)
				.findFirst()
				);
		Instant end2 = Instant.now();
		System.out.println("functional way "+Duration.between(st2, end2));
	}


}


/**
 * Streams differ from Collections in several ways:

No storage: Streams don't have storage for values; they carry values from a data structure through a pipeline of operations.
Functional in nature: an operation on a stream produces a result, but does not modify its underlying data source. A Collection can be used as a source for a stream.
Laziness-seeking: many stream operations, such as filtering, mapping, sorting, or duplicate removal can be implemented lazily, meaning we only need to examine as many elements from the stream as we need to find the desired answer.
Bounds optional: there are many problems that are sensible to express as infinite streams, letting clients consume values until they are satisfied. Collections don't let you do this, but streams do.
**/

/*System.out.println(
numbers.stream()
.filter(Lazy::isEven)
.map(Lazy::doubleIt)
.filter(Lazy::isGreaterThan5)
.findFirst().get());*/
