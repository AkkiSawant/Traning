package stream.efficiency.lazyeval;

public class Lazy {

	//3 different methods for 3 different operations
	
		public static boolean isEven(int number) {
			System.out.println("isEven "+number);
			return number % 2 == 0;
		}

		public static int doubleIt(int number) {
			System.out.println("doubleIt "+number);
			return number * 2;
		}

		public static boolean isGreaterThan5(int number) {
			System.out.println("isGreaterThan5 "+number);
			return number > 5;
		}


}
