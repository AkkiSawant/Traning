package streamsbasics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CoreTerminalOperations {

	public static void main(String[] args) {
		/*		List<String> memberNames = new ArrayList<>();
		memberNames.add("Amitabh");
		memberNames.add("Shekhar");
		memberNames.add("Aman");
		memberNames.add("Rahul");
		memberNames.add("Shahrukh");
		memberNames.add("Salman");
		memberNames.add("Yana");
		memberNames.add("Lokesh");
		//TERMINAL OPERATIONS
		//Terminal operations return a result of a certain type instead of again a Stream.
		 *//**
		 * forEach()
		This method helps in iterating over all elements of a stream and perform some 
		operation on each of them. 
		The operation is passed as lambda expression parameter.
		  *//*
		memberNames.forEach(System.out::println);
		System.out.println();

		   *//**
		   * collect()
		   * collect() method used to recieve elements from a stream 
		   * and store them in a collection
		   * and mentioned in parameter function.
		   *//*
		List<String> memNamesInUppercase = memberNames.stream().sorted()
				.map(String::toUpperCase)
				.collect(Collectors.toList());

		System.out.print(memNamesInUppercase);
		System.out.println();
		    *//**
		    * match()
		    * Various matching operations can be used to check whether a certain 
		    * predicate matches the stream. All of those operations are terminal and return 
		    * a boolean result.
		    * 
		    *//*
		boolean matchedResult = memberNames.stream()
				.anyMatch((s) -> s.startsWith("A"));

		System.out.println(matchedResult);
		System.out.println();
		matchedResult = memberNames.stream()
				.allMatch((s) -> s.startsWith("A"));

		System.out.println(matchedResult);
		System.out.println();
		matchedResult = memberNames.stream()
				.noneMatch((s) -> s.startsWith("A"));

		System.out.println(matchedResult);
		System.out.println();
		     *//**
		     *  count()
		     *  Count is a terminal operation returning the number of elements in the 
		     *  stream as a long.
		     *//*
		long totalMatched = memberNames.stream()
				.filter((s) -> s.startsWith("A"))
				.count();

		System.out.println(totalMatched);
		System.out.println();
		      *//**
		      *  reduce()
		      *  This terminal operation performs a reduction on the elements of the
		      *   stream with the given function. 
		      *  The result is an Optional holding the reduced value.
		      *//*
		Optional<String> reduced = memberNames.stream()
				.reduce((s1,s2) -> s1 + "#" + s2);

		reduced.ifPresent(System.out::println);*/
		System.out.println();
		//List of names
		List<String> names = Arrays.asList(new String[]{"barry", " andy", "ben", "chris", "bill","Bisk"});
 
		//map and filter are piped and the stream is stored
				Stream<String> namesStream = names.stream()
		                .map(n -> {
		                System.out.println("In map - " + n); 
		                return n.toUpperCase();})
		                .filter(upperName -> {
		                System.out.println("In filter - " + upperName); 
		                return upperName.startsWith("B");});

		//namesStream.forEach(System.out::println);
		namesStream.limit(3).forEach(System.out::println);
		 
		/*Stream<String> namesStream = names.stream().filter(upperName -> {
			System.out.println("In filter - " + upperName); 
			return upperName.startsWith("B")||upperName.startsWith("b");})
				.map(n -> {
					System.out.println("In map - " + n); 
					return n.toUpperCase();})
					;

		//namesStream.forEach(System.out::println);
		namesStream.limit(3).forEach(System.out::println);
*/
		
	}
}
