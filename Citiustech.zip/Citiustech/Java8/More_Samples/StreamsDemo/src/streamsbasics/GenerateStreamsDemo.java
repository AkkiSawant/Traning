package streamsbasics;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class GenerateStreamsDemo {

	public static void main(String[] args) {

		//Using Stream.of(val1, val2, val3�.)
		Stream<Integer> streamof = Stream.of(1,2,3,4,5,6,7,8,9);
		streamof.forEach(p -> System.out.println(p));

		System.out.println();
		//Using Stream.of(arrayOfElements)
		Stream<Integer> streamofarr = Stream.of( new Integer[]{1,2,3,4,5,6,7,8,9} );
		streamofarr.forEach(p -> System.out.println(p));
		System.out.println();
		//Using someList.stream()
		List<Integer> list = new ArrayList<Integer>();
		for(int i = 1; i< 10; i++){
			list.add(i);
		}
		Stream<Integer> streamlist = list.stream();
		streamlist.forEach(p -> System.out.println(p));
		System.out.println();
		
		//Using Stream.generate() or Stream.iterate() functions
		Stream<Date> streamgen = Stream.generate(() -> { return new Date();});
		//streamgen.forEach(p -> System.out.println(p));

		System.out.println();
		//Using String chars or String tokens
		IntStream streamchars = "12345_abcdefg".chars();
		streamchars.forEach(p -> System.out.println(p));

		//OR
		System.out.println();
		Stream<String> stream = Stream.of("A$B$C".split("\\$"));
		//System.out.println(stream.count());
		stream.forEach(p -> System.out.println(p));
	}

}
