package streams.eg;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneOffset;
import java.util.List;
import java.util.stream.Collectors;

public class TestCity {

	
	public static void main(String[] args) {

		Instant start = Instant.now();
		List<City> cities = PrepareData.prepareData(5,5);
		System.out.println(cities);
		System.out.println();
		System.out.println("------IMPERATIVE STYLE----------");
		//IMPERATIVE STYLE PRIOR TO JAVA 8
		BigDecimal total = BigDecimal.ZERO;
		int count = 0;
		for(City c : cities){
		    for(Temperature t : c.getTemperatures()){
		        LocalDate ld = LocalDateTime.ofEpochSecond(
		                          t.getDate().getTime(),
		                          0,
		                          ZoneOffset.UTC).toLocalDate();
		        if(ld.getMonth() == Month.AUGUST){
		            total = total.add(t.getReading());
		            count++;
		        }
		    }
		}
		
		double averageTemperature1 = total.doubleValue() / count;

		Instant end = Instant.now();
		System.out.println(
			    "imperative calculated in " +
			    Duration.between(start, end) +
			    ": " + averageTemperature1);
System.out.println("\n--------FUNCTIONAL STYLE----------");
		//FUNCTIONAL STYLE JAVA 8
		Instant start1 = Instant.now();
		Double averageTemperature = cities.stream().flatMap(c ->
		    c.getTemperatures().stream()
		).filter(t -> {
		    LocalDate ld = LocalDateTime.ofEpochSecond(
		                       t.getDate().getTime(),
		                       0,
		                       ZoneOffset.UTC
		                    ).toLocalDate();
		    return ld.getMonth() == Month.AUGUST;
		}).map(t ->
		    t.getReading()
		).collect(
		    Collectors.averagingDouble(
		        TestFilterMapReducePerformance::toDouble
		    )
		);
		Instant end1 = Instant.now();
		System.out.println(
		    "functional calculated in " +
		    Duration.between(start1, end1) +
		    ": " + averageTemperature);

	}

}
