package streamsbasics;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ConvertStreamsDemo {

	public static void main(String[] args) {
		//Convert Stream to List using stream.collect(Collectors.toList())
		
        List<Integer> list = new ArrayList<Integer>();
        for(int i = 1; i< 10; i++){
            list.add(i);
        }
        Stream<Integer> streamlist = list.stream();
        List<Integer> evenNumbersList = streamlist.filter(i -> i%2 == 0).collect(Collectors.toList());
        System.out.print(evenNumbersList);
        
        //Convert Stream to array using stream.toArray(EntryType[]::new)
        System.out.println();
        List<Integer> listarr = new ArrayList<Integer>();
        for(int i = 1; i< 10; i++){
            listarr.add(i);
        }
        Stream<Integer> stream = listarr.stream();
        Integer[] evenNumbersArr = stream.filter(i -> i%2 == 0).toArray(Integer[]::new);
        System.out.print(evenNumbersArr);


	}

}
