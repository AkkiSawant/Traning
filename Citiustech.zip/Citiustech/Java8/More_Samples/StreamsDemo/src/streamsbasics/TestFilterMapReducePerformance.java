package streams.eg;

import java.math.BigDecimal;

public class TestFilterMapReducePerformance {

	public static Double toDouble(BigDecimal a)
	{
		return a.doubleValue();
	}
}
