package streamsbasics;

import java.util.Arrays;

public class ParallelStream {

	public static void main(String[] args) {
		/**
		 * Parallel streams use a common ForkJoinPool available via the static
		 * ForkJoinPool.commonPool() method. The size of the underlying thread-pool uses  
		 * up to five threads - depending on the amount of available physical CPU cores:
		 */
		Arrays.asList("a1", "a2", "b1", "c2", "c1")
		.parallelStream()
		.filter(s -> {
			System.out.format("filter: %s [%s]\n",
					s, Thread.currentThread().getName());
			return true;
		})
		.map(s -> {
			System.out.format("map: %s [%s]\n",
					s, Thread.currentThread().getName());
			return s.toUpperCase();
		})
		.forEach(s -> System.out.format("forEach: %s [%s]\n",
				s, Thread.currentThread().getName()));
	}
}
