package method.references;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StaticMethodRefernceDemo {

	// :: delimeter
	public static void main(String[] args) {
		
		Converter<String, Integer> converter = from -> Integer.valueOf(from);
		Integer converted = converter.convert("123");
		System.out.println(converted);    // 123


		//STATIC METHOD REFERENCE USING :: keyword
		Converter<String, Integer> converter1 = Integer::valueOf;
		Integer converted1 = converter1.convert("123");
		System.out.println(converted1);   // 123

		/**
		 * The method reference doesn't even have to be an instance method of the object in which it is used. 
		 * The method reference can be an instance method of any arbitrary class object. 
		 * For example, a String List can be sorted using the compareTo method from the String class with a method reference:
		 */
		String e1 = new String("A");   
		String e2 = new String("E");
		String e3 = new String("B");    
		String e4 = new String("C");    
		List<String> list = new ArrayList<String>();   
		list.add(e1);list.add(e2);
		list.add(e3);list.add(e4);
		Collections.sort(list, String::compareTo);
		System.out.println(list);
		
		
		
	}
			
}
