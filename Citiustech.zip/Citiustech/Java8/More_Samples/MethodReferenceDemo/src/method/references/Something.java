package method.references;

class Something {
	String startsWith(String s) {
		return String.valueOf(s.charAt(0));
	}
}