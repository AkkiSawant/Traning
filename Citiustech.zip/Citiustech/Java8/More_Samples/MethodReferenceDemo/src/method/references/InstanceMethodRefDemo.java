package method.references;

public class InstanceMethodRefDemo {

	public static void main(String[] args) {
		//PRIOR TO JAVA 8
		Something something = new Something();
		Converter<String, String> converter2 = new Converter<String, String>() {

			@Override
			public String convert(String from) {
				return something.startsWith(from);

			}
		};
		System.out.println(converter2.convert("Shalini"));

		//SINCE JAVA 8 CAN ACCESS REFERENCE OBJECT METHODS USING :: KEYWORD OR DELIMETER
		Converter<String, String> converter1 = something::startsWith;
		String converted1 = converter1.convert("Java");
		System.out.println(converted1);    // "J"
		
	}
}
