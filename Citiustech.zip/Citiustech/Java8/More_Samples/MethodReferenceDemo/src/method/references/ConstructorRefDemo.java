package method.references;

class ConstructorRefDemo {

	public static void main(String[] args) {
		
		//WITHOUT LAMBDA OR :: KEYWORD
		PersonFactory<Person> p = new PersonFactory<Person>() {
			
			@Override
			public Person create(String firstName, String lastName) {
				return new Person(firstName,lastName);
			}
		};
		Person person1 = p.create("shalini","mittal");
		System.out.println(person1.firstName);
		
		//WITH LAMBDA
		PersonFactory<Person> p1 = (s1,s2)->new Person(s1,s2);
		Person p2 = p1.create("Citius","Tech");
		System.out.println(p2.firstName);
		
		//USING :: KEYWORD
		//Instead of implementing the factory manually, we glue everything together via constructor references:
		PersonFactory<Person> personFactory = Person::new;
		Person person = personFactory.create("Peter", "Parker");
//		We create a reference to the Person constructor via Person::new. 
//		The Java compiler automatically chooses the right constructor by matching the signature of PersonFactory.create.
		System.out.println(person.firstName);
	}
}
