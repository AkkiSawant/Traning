package method.references;

import java.util.function.Supplier;

import demo.Car;

//define an example bean with different constructors:
class Person {
    String firstName;
    String lastName;

    Person() {}

    Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
   
   public static Person create( final Supplier<Person> supplier ) {
		return supplier.get();
	}
   
   public static void entered( final Person person ) {
		System.out.println( "Entered " + person.toString() );
	}
   
	public void followed( final Person another ) {
		System.out.println( "Following the " + another.toString() );
	}

	public void exited() {  
		System.out.println( "Exited " + this.toString() );
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return firstName+" : "+lastName;
	}

}