package demo;

public interface CarFactory<T extends Car> {
	T factory(String name);
}
