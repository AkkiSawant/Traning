package demo;

import java.util.function.Supplier;

public class Car {
	String name;
	
	public Car() {
		// TODO Auto-generated constructor stub
	}
	public Car(String name) {
		super();
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static Car create( final Supplier< Car> supplier ) {
		return supplier.get();
	} 
/*	public  Car create( final CarFactory< Car> factory ) {
		return factory.factory(name);
	} 
*/	public static void collide( final Car car ) {
		System.out.println( "Collided " + car.toString() );
	}
	public void follow( final Car another ) {
		System.out.println( "Following the " + another.toString() );
	}

	public void repair() {  
		System.out.println( "Repaired " + this.toString() );
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

}
