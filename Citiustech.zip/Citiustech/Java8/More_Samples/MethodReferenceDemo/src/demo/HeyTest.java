package demo;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class HeyTest {

	public static void main(String[] args) throws Exception {
		//STATIC METHOD CALL
		/*Function<Double, Double> square = Hey::square;
		double ans = square.apply(23d);*/
		
		//NON STATIC METHOD CALL
		Hey hey = new Hey();
		Function<Double, Double> square = hey::square;
		double ans = square.apply(23d);
		String []s1 = new String[]{"hello","bye","welcome"};
		Consumer<Integer> b1 = System::exit; // void exit(int status)
		Consumer<String[]> b2 = Arrays::sort; // void sort(Object[] a)
		b2.accept(s1);
		for(String s :s1)
			System.out.println(s);
		
		Callable<Double> call = hey::getRandom;
		Supplier<Double> call2 = hey::getRandom;
		System.out.println(call.call());
		System.out.println(call2.get());
		//Supplier is functional interface that takes no argument and gives a result
		
		Set<String> set = new HashSet<>();
		set.addAll(Arrays.asList("leo","bale","hanks"));
		Predicate<String> pred = set::contains;
		boolean exists = pred.test("leo");
		System.out.println(exists);
		}

}
