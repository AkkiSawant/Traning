package demo;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Supplier;

public class CarDemo {

	public static void main(String[] args) {

		//WITHOUT LAMBDA I AM ABLE TO DEFINE get() AND ASK IT TO INVOKE A PARAMETERIZED CONSTRUCTOR
		Car.create(new Supplier<Car>() {
			
			@Override
			public Car get() {
				// TODO Auto-generated method stub
				return new Car("askldj");
			}
		});
		
		//WITH LAMBDA ALSO ITS THE SAME 
		Car ob = Car.create(()->new Car("Sedan"));
		
		/**
		 * The first type of method references is constructor reference with the syntax Class::new 
		 * or alternatively, for generics, Class< T >::new. 
		 * Please notice that the constructor has no arguments.
		 */
		final Car car = Car.create( Car::new );
		final List< Car > cars = Arrays.asList( car );

		/**
		 * The second type is reference to static method with the syntax Class::static_method. 
		 * Please notice that the method accepts exactly one parameter of type Car.
		 */
		cars.forEach(Car::collide);
		/**
		 * The third type is reference to instance method of arbitrary object of specific type with the syntax Class::method.
		 * Please notice, no arguments are accepted by the method.
		 */
		cars.forEach( Car::repair );
				
		/**
		 * And the last, fourth type is reference to instance method of particular class instance the syntax instance::method. 
		 * Please notice that method accepts exactly one parameter of type Car.
		 */
		
		
		Car police = Car.create(Car::new);
		cars.forEach(police::follow);
		
	}

}
/*		CarFactory<Car> fact = Car::new;
fact.factory("Sedan");
*/		

//to invoke param const
/*Car car1 = new Car("Sedan").create((CarFactory<Car>)Car::new);
Car car2 = new Car("Tata").create((CarFactory<Car>)Car::new);
List<Car> cars = Arrays.asList(car1,car2);

//Car car = Car.create((Supplier<Car>)Car::new);
*/
/*Car c1 = new Car();
Car c2 = new Car();
Car c3 = new Car();
Car c4 = new Car();

List<Car> l1 = Arrays.asList(c1,c2,c3,c4);
l1.forEach(c->{
Scanner sc = new Scanner(System.in);
c.setName(sc.next());
});

l1.forEach(System.out::println);
*/