package demo;

public class Hey {
	
	//STATIC METHOD
	/*public static double square(double num){
		return Math.pow(num , 2);
		}*/
	
	//NON STATIC METHOD
	public double square(double num){
		return Math.pow(num , 2);
		}
	
	public double getRandom(){
		return Math.random();
		}
}
