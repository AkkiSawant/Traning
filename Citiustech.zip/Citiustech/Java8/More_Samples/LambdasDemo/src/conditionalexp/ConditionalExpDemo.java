package conditionalexp;

import java.util.Scanner;

public class ConditionalExpDemo {

	public static void main(String[] args) {
		
		boolean flag;
		Scanner sc = new Scanner(System.in);
		flag = sc.nextBoolean();
		
		Conditional condition = flag ? (()->System.out.println("on true")) : (()->System.out.println("on false")); 
		condition.call();
	}

}
