package conditionalexp;

public interface Conditional {

	public void call();
}
