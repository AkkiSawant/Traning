package arrayinitializer;

import java.security.AccessController;
import java.util.concurrent.Callable;

public class ArrayInitializerDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		
		Runnable r[] = new Runnable[]{
			()->System.out.println("runnable 1"),
			()->System.out.println("runnable 2"),
			()->System.out.println("runnable 3")
			};

		for(int i=0;i<r.length;i++)
			new Thread(r[i]).start();
		
		//Lambda expressions can be used in array initializers, but generic array initializers cannot be used
		//Callable<String>[] c=new Callable<String>[]{ ()->"a", ()->"b", ()->"c" };
		
		try{

			//To use lambda expressions in an array initializer, specify a non-generic array initializer,
			Callable<String>[] c=new Callable[]{ ()->"Hello from Callable a", 
			()->"Hello from Callable b", ()->"Hello from Callable c" };

			System.out.println(c[1].call());
			}catch(Exception e){System.err.println(e.getMessage());}
			
	}

}
