package cast.lambda;

import java.util.Comparator;

public class CastLambdaDemo {

	public static void display(Shape shape)
	{
		System.out.println("shape as a parameter");
		shape.area();
	}
	
	public static void display(Ball ball)
	{
		System.out.println("ball as a parameter");
		ball.bounce();
	}
	
	public static void display(Tyre tyre)
	{
		System.out.println("Tyre as a parameter");
		System.out.println(tyre.getType());
	}
	public static void main(String[] args) {
		
		/**
		 * display is an overloaded method which takes one paremeter as an interface.
		 * When invoking the display with lambda it need to know which overloaded method needs to b invoked
		 * so type casting is required
		 */
		//display(()->{System.out.println("ambogous yeah!!!!");});
		
		display((Shape)()->{System.out.println("type cast done yeah!!!!");});

		/**
		 * As opposed to above method call using lambda where casting is required, if we have 2 overloaded methods
		 * with same signature parameter type different, but 1 parameter implementation  method has a return type
		 * then its not ambigous 
		 * 
		 * When you invoke a method that is overloaded, the method that best matches the lambda expression is used.
		 *  The target type and the method argument type are used to resolve the best method.
		 */
		display(()->{return "hey getType of tire got invoked";});
		//OR
		display(()->"hey getType of tire got invoked");
	}

}
