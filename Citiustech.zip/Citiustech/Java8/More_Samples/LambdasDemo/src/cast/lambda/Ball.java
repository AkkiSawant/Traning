package cast.lambda;

public interface Ball {
	void bounce();
}
