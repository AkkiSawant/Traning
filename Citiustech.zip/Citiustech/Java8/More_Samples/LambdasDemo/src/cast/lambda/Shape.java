package cast.lambda;

public interface Shape {
void area();
}
