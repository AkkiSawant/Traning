package cast.lambda;

public interface Tyre {
	String getType();
}
