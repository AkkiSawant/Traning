package scope.thistest;

import java.util.Objects;
import java.util.function.Predicate;

public class ThisLambdaInterpret {

	/**
	 * �this� in a lambda refers to main class, not inner class that 
	was created for the lambda. There is no OuterClass.this. 
	Also, no new level of scoping.
	 */
	Runnable r = ()->{System.out.println("In anonymous Inner "+this);};

	public static void main(String[] args) {

		new ThisLambdaInterpret().new MyRunnable().run();

		System.out.println();
		new ThisLambdaInterpret().r.run();

		System.out.println();
		new Runnable() {

			@Override
			public void run() {
				System.out.println("In Runnable 3 "+this);
			}
		}.run();

		System.out.println();
		Runnable r1 = new Runnable() {

			@Override
			public void run() {
				System.out.println("In Runnable 3 "+this);

			}
		};
		r1.run();
	}
	class MyRunnable implements Runnable
	{

		@Override
		public void run() {
			System.out.println("In MyRunnable "+this);
		}
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "From MyRunnable";
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "From ThisLambdaInterpret class";
	}
}

/**
 * this in Lambda Expressions
Outside a lambda expression, this refers to the current object. In a lambda expression also, this refers to the enclosing current object. 
Lambda expressions that do not refer to members of the enclosing instance do not store a strong reference to it,
 which solves a memory leak problem that often occurs in inner class instances that hold a strong reference to the enclosing class.

In the example above, Runnable is the target type of a lambda expression.(r as an instance member)
 In the lambda expression body, a reference to this is specified. When an instance of Runnable r is created and the run() method is invoked,
  the this reference invokes the enclosing instance and a String value of the enclosing instance is obtained from the toString() method. 
The message Hello from Class HelloLambda gets output.
 */

