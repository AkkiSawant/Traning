package interfaces;

@FunctionalInterface
public interface I1 {

	public void m1();
}
