package interfaces;

import java.util.Comparator;

public class InterfaceDemo {

	public static void m2(I1 ob)
	{
	System.out.println("in m2");
	ob.m1();
	}
	
	public static void main(String[] args) {
		
		//WITHOUT LAMBDA
		m2(new I1() {
			
			@Override
			public void m1() {
				System.out.println("Hey its java 7 call... tedious huhhhhh");				
			}
		});
		
		//WITH LAMBDA
m2(()->System.out.println("Hey its java 8 call... EASY LINE OF CODE REDUCE WOWWWW"));

show((s)->{
	System.out.println("Hey u called me!!!!!");
	System.out.println(s);
	return 10;
});

	show((s)->{return 20;});
	show((s)->20);
		/*show(s->System.out.println(s));
		show((s)->{
			System.out.println("Hey u called me!!!!!");
			System.out.println(s);});
		show((String s)->{
			System.out.println("Hey u called me!!!!!");
			System.out.println(s);});
		*/
	}

	public static void show(I2 ob)
	{
		System.out.println(ob.show("Heyy Welcome"));
	}
	
}
