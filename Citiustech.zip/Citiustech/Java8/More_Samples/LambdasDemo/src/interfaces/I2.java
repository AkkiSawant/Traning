package interfaces;
public interface I2 {
	int show(String s);
}
