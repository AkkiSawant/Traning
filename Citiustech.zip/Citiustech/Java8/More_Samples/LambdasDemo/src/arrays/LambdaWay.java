package arrays;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class LambdaWay {

	/**Write a method that sums all the Integers in the list as for instance:**/

	public int sumAll(List<Integer> numbers) {
		int total = 0;
		for (int number : numbers) {
			total += number;
		}
		return total;
	}

	/**
	 * The day after a manager comes to our cubicle and tells you that the business also requires to have a function that 
	sums only the even number in the list. So what is the quickest thing we could do? Easy. 
	Just copy and paste the former method and add to it the required filtering condition:
	 */

	public int sumAllEven(List<Integer> numbers) {
		int total = 0;
		for (int number : numbers) {
			if (number % 2 == 0) {
				total += number;
			}
		}
		return total;
	}

	/**
	 * 	Another day, another requirement: this time they need to sum the numbers in the list again but only if they are greater than 3.
	 *  So what could we do? Well, we could again copy and paste the former method and just change that boolean condition ... 
	 *  but it feels so dirty, isn't it? Now, following the "First Write, Second Copy, 
	 *  Third Refactor" principle it is time to wonder if there is a smarter and more generic way to do this. 
	 *  In this case implementing an higher-order function accepting together with the list also a Predicate 
	 *  (another functional interface added in Java 8) that defines how to filter the numbers in the list itself before to sum them up. 
	 * 
	 */

	public static int sumAll(List<Integer> numbers, Predicate<Integer> p) {
		int total = 0;
		for (int number : numbers) {
			if (p.test(number)) {
				total += number;
			}
		}
		return total;}
	/**
	 * 	In other words we are passing to the method not only the data (the list of numbers) but also a behavior (the Predicate) 
	 * defining how to use them. In this way we can satisfy all the 3 requirements with a single more generic and 
	 * then more reusable method: 
	 */


	public static void main(String[] args) {
		//Consider this as an example
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6);

		System.out.println("sum of all nos : "+sumAll(numbers, n -> true));

		System.out.println("sum of even nos : "+sumAll(numbers, n -> n % 2 == 0));

		System.out.println("sum of nos greater than 3 : "+sumAll(numbers, n -> n > 3));
	}

}
