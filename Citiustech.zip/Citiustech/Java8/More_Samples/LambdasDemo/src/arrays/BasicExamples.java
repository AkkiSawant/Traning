package arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BasicExamples {

	static int i = 10;

	public static void main(String[] args) {
		List<String> list = Arrays.asList( "a", "e", "d" );

		for(String s:list)
			System.out.println(s);
		System.out.println();
		
		/*Please notice the type of argument e is being inferred by the compiler.*/
		Arrays.asList( "a", "b", "d" ).forEach( (e) -> System.out.println( e ) );
		
		//OR WITHOUT () AROUND e
		Arrays.asList( "a", "b", "d" ).forEach( e -> System.out.println( e ) );

		//STATIC METHOD REFERENCES
		Arrays.asList( "a", "b", "d" ).forEach( System.out::println );
		
		/*Alternatively, you may explicitly provide the type of the parameter,
		 * wrapping the definition in brackets. 
		For example:
		 */
		System.out.println();
		Arrays.asList( "a", "b", "d" ).forEach( ( String e ) -> System.out.println( e ) );
		
		/*In case lambda�s body is more complex, it may be wrapped into square brackets, 
		 * as the usual function definition in Java. For example:*/
		System.out.println();
		Arrays.asList( "a", "b", "d" ).forEach( e -> {
			System.out.print( e );
			System.out.print( e );
		} );

		/*Lambdas may reference the class members and local variables (implicitly making them effectively final if they are not).
		 *For example, those two snippets are equivalent:*/
		System.out.println();
		String separator = ",";
		Arrays.asList( "a", "b", "d" ).forEach(
		( String e ) -> System.out.print( e + separator ) );
		
		//WITHOUT LAMBDA
		Collections.sort(list, new Comparator<String>() {

			@Override
			public int compare(String arg0, String arg1) {
				return arg0.compareTo(arg1);
			}			
		});

		//WITH LAMBDA
		System.out.println();
		Collections.sort(list, (s1,s2)->{return s1.compareTo(s2);});
		list.forEach(s->System.out.println(s));
		
		//OR
		System.out.println();
		Collections.sort(list, (s1,s2)->s2.compareTo(s1));//NO NEED TO SPECIFY RETURN IT IS AUTOMATICALLY INFERRED
		list.forEach(System.out::println);
	}
}
