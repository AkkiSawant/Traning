function printArray(array) {
  for (var i = 0; i < array.length; i++)
    print(array[i]);
}

Since 'doing something' can be represented as a function, and functions are also values, we can pass our action as a function value:
	
function forEach(array, action) {
	  for (var i = 0; i < array.length; i++)
	    action(array[i]);
	}

	forEach(["Wampeter", "Foma", "Granfalloon"], print);
	
And by making use of an anonymous function, something just like a for loop can be written with less useless details:

		function sum(numbers) {
		  var total = 0;
		  forEach(numbers, function (number) {
		    total += number;
		  });
		  return total;
		}
		show(sum([1, 10, 100]));

		Note that the variable total is visible inside the anonymous function because of the lexical scoping rules.
		Also note that this version is hardly shorter than the for loop and requires a rather clunky }); 
		at its end ― the brace closes the body of the anonymous function, the parenthesis closes the function call to forEach,
		and the semicolon is needed because this call is a statement.

You do get a variable bound to the current element in the array, number, so there is no need to use numbers[i] anymore,
		and when this array is created by evaluating some expression, 
		there is no need to store it in a variable, because it can be passed to forEach directly
		
		var paragraphs = mailArchive[mail].split("\n");
		for (var i = 0; i < paragraphs.length; i++)
		  handleParagraph(paragraphs[i]);
		¶ This can now be written as...

		NEED OF THIS***
		
		forEach(mailArchive[mail].split("\n"), handleParagraph);
		
		//Reduce method implementation
		function reduce(combine, base, array) {
			  forEach(array, function (element) {
			    base = combine(base, element);
			  });
			  return base;
			}

			function add(a, b) {
			  return a + b;
			}

			function sum(numbers) {
			  return reduce(add, 0, numbers);
			}