package com.citi;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

/*This small code snippet uses method parallelSetAll() to fill up arrays with 20000 random values.
After that, the parallelSort() is being applied. The program outputs first 10 elements before 
and after sorting so to ensure the array is really ordered. The sample program output may look 
like that (please notice that array elements are randomly generated):*/

public class Parallel_Arrays {
    public static void main( String[] args ) {
        long[] arrayOfLong = new long [ 20000 ];		
		
        
        /*The new parallelSetAll() method creates an array and sets each element's value with
         *  a given generator function, using concurrency for added 
         *  efficiency and performance. */
        Arrays.parallelSetAll( arrayOfLong, index -> ThreadLocalRandom.current().nextInt( 1000000 ) );
        Arrays.stream( arrayOfLong ).limit( 10 ).forEach( 
            i -> System.out.print( i + " " ) );
        System.out.println();
		
     Arrays.parallelSort( arrayOfLong );		
        Arrays.stream( arrayOfLong ).limit( 10 ).forEach( 
            i -> System.out.print( i + " " ) );
        System.out.println();
    }
}