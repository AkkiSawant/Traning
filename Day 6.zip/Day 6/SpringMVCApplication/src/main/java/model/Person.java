package model;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

public class Person {

    @Size(min=3, max=10, message="Username should be between 3 to 10 characters")
	String username;
    
	@Min(value=0, message="Minimum allowed in age is 0")
    int age;
	
	public Person()
	{
		
	}
	public Person(String username, int age) {
		super();
		this.username = username;
		this.age = age;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	
}
