package controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import model.Person;
// @Controller - indicates that the class will be instantiated by spring container
@Controller
public class HelloController {

	// This annotation maps the request to the controller method
	@RequestMapping("greet")
	public String hello()
	{
		// logical name of the view
		return "abc";
	}
	@RequestMapping("hello.html")
	public String display()
	{
		return "abc";
	}
	
	@RequestMapping("greet/{name}/country/{country}")
	public String greetPerson(@PathVariable("name") String str, Model model)
	{
		// logical name of the view
       
		model.addAttribute("msg", str);
		return "abc";
	}
	
	@RequestMapping(value="index.html", method=RequestMethod.GET)
	public String displayForm()
	{
		return "newPerson";
	}
	
	/*@RequestMapping(value="success.html")
	public String createForm(@RequestParam("username") String str,@RequestParam("age") String age, Model model)
	{
		Person p = new Person();
		p.setUsername(str);
		p.setAge(Integer.parseInt(age));
		model.addAttribute("msg", p);
		return "abc";
	}*/
	
	/*
	 * Extends the interface for error registration capabilities, 
	 * allowing for a Validator to be applied, and adds binding-specific analysis and model building
	 */
	@RequestMapping(value="success.html")
	public String createForm1(@Valid @ModelAttribute("person") Person p, BindingResult result, Model model)
	{
		
		if(result.hasErrors())
		{
			System.out.println("Conversion errors");
			return "newPerson";
		}
		//Person p = new Person();
		//p.setUsername(str);
		//p.setAge(Integer.parseInt(age));
		model.addAttribute("msg", p);
		return "abc";
	}
	
	@RequestMapping(value="/persons", method=RequestMethod.GET)
	public String getData(@RequestParam("age") String age, Model model)
	{
		model.addAttribute("msg", age);
		return "hello";
	}
	
}
