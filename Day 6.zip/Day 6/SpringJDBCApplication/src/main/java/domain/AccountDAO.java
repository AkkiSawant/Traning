package domain;

import java.util.List;

public interface AccountDAO {

	/*
	 * This method returns the number of accounts from the Account table.
	 */
	public int getAccounts();

	/**
	 * 
	 * @param accountId
	 * @return
	 */
	public String getAccountDetail(int accountId);

	/**
	 * This is the method to be used to create a record in the Account table.
	 */
	public void create(String name, int id);

	/**
	 * This is the method to be used to list down a record from the Account
	 * table corresponding to a passed Account id.
	 */
	public Account getAccount(Integer id);

	/**
	 * This is the method to be used to list down all the records from the
	 * Account table.
	 */
	public List<Account> listAccounts();

	/**
	 * This is the method to be used to delete a record from the Account table
	 * corresponding to a passed account id.
	 */
	public void delete(Integer id);

	/**
	 * This is the method to be used to update a record into the Account table.
	 */
	public void update(Integer id, String name);
}
