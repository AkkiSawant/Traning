package domain;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AccountMapper implements RowMapper {

	public Account mapRow(ResultSet rs, int rownum) throws SQLException {
		Account account = new Account();
	      account.setId(rs.getInt("accountId"));
	      account.setName(rs.getString("accountName"));
	      return account;
	}

}
