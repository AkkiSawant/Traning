package domain;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class AccountDAOImpl implements AccountDAO {

	// 2. DataSource
	@Autowired
	private DataSource dataSource;

	// 3. JDBCTemplate instance
	private JdbcTemplate jdbcTemplate = new JdbcTemplate();

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public int getAccounts() {
		return 0;
	}

	public String getAccountDetail(int accountId) {
		return null;
	}

	public void create(String name, int id) {

	}

	public Account getAccount(Integer id) {

		return null;
	}

	public List<Account> listAccounts() {

		return null;
	}

	public void delete(Integer id) {

	}

	public void update(Integer id, String name) {
	}

}
