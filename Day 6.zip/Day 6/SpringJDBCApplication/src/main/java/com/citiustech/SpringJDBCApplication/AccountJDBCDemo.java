package com.citiustech.SpringJDBCApplication;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import domain.AccountDAOImpl;

public class AccountJDBCDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Load the spring container -- Setup the container and instantiate the
		// bean
		// a. BeanFactory -- core container b. ApplicationContext -- framework
		// -- core container + internationalization + formatting
		// ApplicationContext using ClassPathXmlApplicationContext or
		// FileSystemXMLApplicationContext or WebApplicationContext
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringBeans.xml");
		// register the bean for destroy
		((AbstractApplicationContext) context).registerShutdownHook();

		// Ask for Message object from spring container
		AccountDAOImpl accountObj = context.getBean("accountDAOImpl", AccountDAOImpl.class);

	   System.out.println("Number of Accounts:" +accountObj.getAccounts());
		// System.out.println("Number of Accounts:"
		// +accountObj.getAccountDetail(2));

		/* ------------------------------------------------------------------ */
		/*
		 * create an Account
		 */
		accountObj.create("Account 21", 21);

		/* ------------------------------------------------------------------ */
		/*
		 * Get Account object in a RowMapper object
		 */
		// Account acc1 = accountObj.getAccount(3);
		// System.out.println(acc1.getId() + " " + acc1.getName());

		/*
		 * --------------------------------------------------------------------
		 */

		/*
		 * Collection of Account objects
		 */
		// List<Account> accList = accountObj.listAccounts();
		// System.out.println(accList);

		/* ------------------------------------------------------------------ */
		/*
		 * Delete the Account
		 */
		// accountObj.delete(3);

		/* ------------------------------------------------------------------ */
		/* update the account */
		//accountObj.update(2, "John Mathew");
	}

}
