package com.citiustech.bookmeeting.controller.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.citiustech.bookameetingroom.BookMeetingApplication;
import com.citiustech.bookameetingroom.controller.BookingController;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = BookMeetingApplication.class, loader = AnnotationConfigContextLoader.class)
public class BookingControllerTest {

	
    @Autowired
    private BookingController bookingController;
    
    @BeforeClass
    public static void setUp() {
        System.out.println("-----> SETUP <-----");
    }

    @Test
    public void testSampleService() {
        assertEquals("class com.citiustech.bookameetingroom.controller.BookingController", this.bookingController.getClass().toString());
    }


    @AfterClass
    public static void afterTest() {
        System.out.println("-----> DESTROY <-----");
    }
}
