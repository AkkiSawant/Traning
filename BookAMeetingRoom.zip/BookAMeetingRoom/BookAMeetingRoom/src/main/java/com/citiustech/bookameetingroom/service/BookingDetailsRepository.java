package com.citiustech.bookameetingroom.service;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.bookameetingroom.model.BookingDetails;
import com.citiustech.bookameetingroom.model.Room;

@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetails, Long> {

    @SuppressWarnings("unchecked")
    @Override
    public BookingDetails save(BookingDetails bookingDetails);


    @Override
    public List<BookingDetails> findAll();

    public List<BookingDetails> findByMeetingRoomAndFromDateBetweenOrToDateBetween(Room meetingRoom, Date fromDate, Date toDate,Date fromDate1, Date toDate1);
   
    public List<BookingDetails> findByMeetingRoomAndFromDateBeforeAndToDateAfter(Room meetingRoom, Date fromDate, Date toDate);
    
    public List<BookingDetails> findByMeetingRoomAndStartTimeBetweenOrEndTimeBetween(Room meetingRoom, Time startTime, Time endTime,Time startTime1, Time endTime1);
    
    public List<BookingDetails> findByMeetingRoomAndStartTimeBeforeAndEndTimeAfter(Room meetingRoom, Time startTime, Time endTime);
}
