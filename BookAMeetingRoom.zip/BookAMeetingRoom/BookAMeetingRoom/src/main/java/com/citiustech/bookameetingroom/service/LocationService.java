/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citiustech.bookameetingroom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.bookameetingroom.model.Location;

/**
 *
 * @author sarikam2
 */
@Service
public class LocationService {

    @Autowired
    private LocationRepository locationRepository;


    public List<Location> getAllLocation() {
        return locationRepository.findAll();
    }


    public Location findOne(Long locationId) {
        return locationRepository.findOne(locationId);
    }

}
