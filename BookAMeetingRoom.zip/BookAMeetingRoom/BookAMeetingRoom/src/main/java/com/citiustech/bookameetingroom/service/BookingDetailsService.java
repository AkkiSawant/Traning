package com.citiustech.bookameetingroom.service;

import java.sql.Time;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.bookameetingroom.model.BookingDetails;
import com.citiustech.bookameetingroom.model.Room;

@Service
public class BookingDetailsService {

    @Autowired
    private BookingDetailsRepository bookingDetailsRepository;

    // @Autowired
    // private Room meetingRoom;


    public boolean isBookingAvailable(BookingDetails bookingDetails) {

        List<BookingDetails> bookingDetailsByDate=findByMeetingRoomAndDate(bookingDetails.getMeetingRoom(), bookingDetails.getFromDate(), bookingDetails.getToDate());
    	List<BookingDetails> bookingDetailsByTime=findByMeetingRoomAndTime(bookingDetails.getMeetingRoom(), bookingDetails.getStartTime(), bookingDetails.getEndTime());
        
    	bookingDetailsByDate.retainAll(bookingDetailsByTime);
    	
    	if(!bookingDetailsByDate.isEmpty()){
    		return false;
        }else{
        	return true;
        }
		
    }


    public BookingDetails saveBooking(BookingDetails bookingDetails) {

        return bookingDetailsRepository.save(bookingDetails);
    }


    public List<BookingDetails> getAllBookings() {
        return bookingDetailsRepository.findAll();
    }

    public List<BookingDetails> findByMeetingRoomAndTime(Room meetingRoom, Time startTime,Time endTime) {
    	
    	List<BookingDetails> firstQueryList=bookingDetailsRepository.findByMeetingRoomAndStartTimeBetweenOrEndTimeBetween(meetingRoom, startTime, endTime, startTime, endTime);
    	List<BookingDetails> secondQueryList=bookingDetailsRepository.findByMeetingRoomAndStartTimeBeforeAndEndTimeAfter(meetingRoom, startTime, endTime);
        firstQueryList.removeAll(secondQueryList);
        firstQueryList.addAll(secondQueryList);
    	return listFilter(firstQueryList,meetingRoom);
    }
    
    public List<BookingDetails> findByMeetingRoomAndDate(Room meetingRoom, Date fromDate, Date toDate) {
    	
    	List<BookingDetails> firstQueryList=bookingDetailsRepository.findByMeetingRoomAndFromDateBetweenOrToDateBetween(meetingRoom, fromDate, toDate, fromDate, toDate);
    	List<BookingDetails> secondQueryList=bookingDetailsRepository.findByMeetingRoomAndFromDateBeforeAndToDateAfter(meetingRoom, fromDate, toDate);    	
        firstQueryList.removeAll(secondQueryList);
        firstQueryList.addAll(secondQueryList);
    	return listFilter(firstQueryList,meetingRoom);
    }
    
    public List<BookingDetails> listFilter(List<BookingDetails> list,Room meetingRoom){
    	
    	Iterator<BookingDetails> iter = list.iterator();

    	while (iter.hasNext()) {
    		BookingDetails details = iter.next();
    		Long roomId=details.getMeetingRoom().getRoomId();
    		if(!roomId.equals(meetingRoom.getRoomId())){
    			iter.remove();
    		} 	    
    	}
		return list;
    	
    }
    
}
