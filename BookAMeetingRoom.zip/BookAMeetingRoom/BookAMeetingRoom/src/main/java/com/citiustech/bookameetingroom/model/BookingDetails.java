package com.citiustech.bookameetingroom.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name = "BOOKING_DETAILS")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "bookingId")
public class BookingDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -1018887518298602325L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Long bookingId;

    @Column
    @DateTimeFormat(iso = ISO.DATE)
    // @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private Date fromDate;

    @Column
    @DateTimeFormat(iso = ISO.DATE)
    // @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private Date toDate;

    private Time startTime;

    private Time endTime;

    @ManyToOne
    @JoinColumn(name = "room_id")
    private Room meetingRoom;

    private String user;


    public Date getFromDate() {
        return fromDate;
    }


    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }


    public Date getToDate() {
        return toDate;
    }


    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }


    public Time getStartTime() {
        return startTime;
    }


    public void setStartTime(Time startTime) {
        this.startTime = startTime;
    }


    public Time getEndTime() {
        return endTime;
    }


    public void setEndTime(Time endTime) {
        this.endTime = endTime;
    }


    public Room getMeetingRoom() {
        return meetingRoom;
    }


    public void setMeetingRoom(Room meetingRoom) {
        this.meetingRoom = meetingRoom;
    }


    public String getUser() {
        return user;
    }


    public void setUser(String user) {
        this.user = user;
    }


    public Long getBookingId() {
        return bookingId;
    }


    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

}
