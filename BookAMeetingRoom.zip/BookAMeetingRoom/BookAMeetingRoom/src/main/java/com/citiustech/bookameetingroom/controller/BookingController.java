package com.citiustech.bookameetingroom.controller;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.bookameetingroom.model.BookingDetails;
import com.citiustech.bookameetingroom.model.Location;
import com.citiustech.bookameetingroom.model.Room;
import com.citiustech.bookameetingroom.service.BookingDetailsService;
import com.citiustech.bookameetingroom.service.LocationService;
import com.citiustech.bookameetingroom.service.RoomService;

@RestController
@RequestMapping("/book")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private LocationService locationService;

    @Autowired
    private BookingDetailsService bookingDetailsService;

    @Autowired
    private RoomService roomService;


    @RequestMapping("/locations")
    public List<Location> getAllLocation() {
        List<Location> locations = locationService.getAllLocation();
        logger.debug("Locations found: " + locations);

        return locations;
    }


    @RequestMapping(value = "/getAllRooms/{locationId}/{hasConference}/{hasProjector}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<Room>> getAllRooms(@PathVariable Long locationId, @PathVariable boolean hasConference,
            @PathVariable boolean hasProjector) {

        Location location = locationService.findOne(locationId);
        List<Room> lstRoom = roomService.getRoomsByCriteria(location, hasConference, hasProjector);
        logger.debug("lstRoom size" + lstRoom.size());
        logger.debug("lstRoom " + lstRoom);
        return new ResponseEntity<List<Room>>(lstRoom, HttpStatus.OK);
    }


    @RequestMapping(value = "/getBookingDetails/{roomId}/{fromUtilDate}/{toUtilDate}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<BookingDetails>> getBookingDetails(@PathVariable Long roomId, @PathVariable java.util.Date fromUtilDate,
            @PathVariable java.util.Date toUtilDate) {

        Room room = roomService.findOne(roomId);
        Date fromDate = new Date(fromUtilDate.getTime());
        Date toDate = new Date(toUtilDate.getTime());
        List<BookingDetails> lstBookingDetails = bookingDetailsService.findByMeetingRoomAndDate(room, fromDate, toDate);
        logger.debug("lstBookingDetails size" + lstBookingDetails.size());
        logger.debug("lstBookingDetails " + lstBookingDetails);
        return new ResponseEntity<List<BookingDetails>>(lstBookingDetails, HttpStatus.OK);
    }


    @RequestMapping("/getBookedRoomForLocation")
    public List<BookingDetails> getBookedRoomForLocation() {

        List<BookingDetails> lstBookinDetails = new ArrayList<>();

        for (long i = 1; i < 10; i++) {
            BookingDetails bookinDetails = new BookingDetails();
            bookinDetails.setBookingId(i);
            bookinDetails.setStartTime(Time.valueOf("12:00"));
            bookinDetails.setEndTime(Time.valueOf("13:00"));
            bookinDetails.setUser("nitin.meshram");
            bookinDetails.setMeetingRoom(null);

            lstBookinDetails.add(bookinDetails);
        }

        return lstBookinDetails;
    }


    @RequestMapping(value = "/savedummy", consumes = "application/json", method = RequestMethod.POST)
    public String save(@RequestBody BookingDetails bookingDetails) {
        logger.debug("Saving a booking details object: " + bookingDetails);

        bookingDetailsService.saveBooking(bookingDetails);
        return "Dummy data is saved";
    }


    /*
     * Input JSON Format { "meetingRoom":{"roomId":501}, "startTime": "6:00:00",
     * "endTime": "6:00:00", "toDate":"04-04-2016", "fromDate":"21-04-2016" }
     */

    @RequestMapping(value = "/roombook", consumes = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> saveBookingDetails(@RequestBody BookingDetails bookingDetails) {

		if (bookingDetailsService.isBookingAvailable(bookingDetails)) {
			bookingDetailsService.saveBooking(bookingDetails);
			return new ResponseEntity<>(bookingDetails,HttpStatus.OK);
		} else {
			return new ResponseEntity<>(bookingDetails,HttpStatus.NOT_FOUND);
		}

    }

}
