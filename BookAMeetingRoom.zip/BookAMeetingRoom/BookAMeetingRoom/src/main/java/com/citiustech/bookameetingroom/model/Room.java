package com.citiustech.bookameetingroom.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 *
 * @author sagart
 */
@Entity
@Table(name = "ROOM_DETAILS")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "location")

public class Room implements Serializable {

    @Override
    public String toString() {
        return "Room{" + "roomId=" + roomId + ", code=" + code + ", description=" + description + ", name=" + name + ", status=" + status
                + ", location=" + location + ", capacity=" + capacity + ", hasConference=" + hasConference + ", hasProjector=" + hasProjector
                + '}';
    }


    private static final long serialVersionUID = -8575543357276320952L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "room_id")
    private long roomId;

    private String code;

    private String description;

    private String name;

    private String status;

    @ManyToOne
    @JoinColumn(name = "location_id")
    private Location location;

    /*
     * @OneToMany(mappedBy = "meetingRoom")
     * private List<BookingDetails> bookingDetails;
     */

    private int capacity;

    private boolean hasConference;
    private boolean hasProjector;


    public long getRoomId() {
        return roomId;
    }


    public void setRoomId(long roomId) {
        this.roomId = roomId;
    }


    public Location getLocation() {
        return location;
    }


    public void setLocation(Location location) {
        this.location = location;
    }


    public int getCapacity() {
        return capacity;
    }


    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }


    public boolean isHasConference() {
        return hasConference;
    }


    public void setHasConference(boolean hasConference) {
        this.hasConference = hasConference;
    }


    public boolean isHasProjector() {
        return hasProjector;
    }


    public void setHasProjector(boolean hasProjector) {
        this.hasProjector = hasProjector;
    }


    public String getCode() {
        return code;
    }


    public void setCode(String roomCode) {
        this.code = roomCode;
    }


    public String getDescription() {
        return description;
    }


    public void setDescription(String roomDesc) {
        this.description = roomDesc;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }


    public Location getLocationId() {
        return location;
    }
    /*
     * public List<BookingDetails> getBookingDetails() {
     * return bookingDetails;
     * }
     * 
     * public void setBookingDetails(List<BookingDetails> bookingDetails) {
     * this.bookingDetails = bookingDetails;
     * }
     */
}
