/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citiustech.bookameetingroom.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.bookameetingroom.model.Location;
import com.citiustech.bookameetingroom.model.Room;

/**
 *
 * @author Sagart
 */
@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {

    @Override
    public List<Room> findAll();


    public List<Room> findRoomByLocation(Location locationId);


    public List<Room> findByLocationAndHasProjectorAndHasConference(Location location, boolean hasProjector, boolean hasConference);


    @Override
    public Room findOne(Long roomId);
}
