/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citiustech.bookameetingroom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.bookameetingroom.model.Location;
import com.citiustech.bookameetingroom.model.Room;

/**
 *
 * @author Sagart
 */
@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;


    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }


    public List<Room> getRoomsByCriteria(Location location, boolean hasProjector, boolean hasConference) {
        return roomRepository.findByLocationAndHasProjectorAndHasConference(location, hasProjector, hasConference);
    }


    public Room findOne(Long roomId) {
        return roomRepository.findOne(roomId);
    }
}
