package com.citiustech.bookameetingroom.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 *
 * @author sagart
 */
@Entity
@Table(name = "LOCATION_DETAILS")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "locationId")
public class Location implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 8257754678830662634L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "location_id")
    private long locationId;

    private String locationName;

    private String building;

    private String floor;

    @OneToMany(mappedBy = "location")
    @JsonIdentityReference(alwaysAsId = true)
    private Set<Room> rooms;


    public long getLocationId() {
        return locationId;
    }


    public void setLocationId(long locationId) {
        this.locationId = locationId;
    }


    public String getLocationName() {
        return locationName;
    }


    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }


    public String getBuilding() {
        return building;
    }


    public void setBuilding(String building) {
        this.building = building;
    }


    public String getFloor() {
        return floor;
    }


    public void setFloor(String floor) {
        this.floor = floor;
    }


    public Set<Room> getRooms() {
        return rooms;
    }


    public void setRooms(Set<Room> rooms) {
        this.rooms = rooms;
    }

}
