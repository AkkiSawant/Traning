insert into LOCATION_DETAILS values (101, 'Powai', 'Ground', 'TX Ground');
insert into LOCATION_DETAILS values (102, 'Powai', 'First Floor', 'TX 1st Flr');
insert into LOCATION_DETAILS values (103, 'Powai', 'Second Floor', 'Tx 2nd Flr');
insert into LOCATION_DETAILS values (104, 'Mindspace1', 'Eighth Floor', 'MS1 Phase 1');
insert into LOCATION_DETAILS values (105, 'Mindspace1', 'Eighth Floor', 'MS1 Phase 2');
insert into LOCATION_DETAILS values (106, 'Mindspace1', 'Sixth Floor', 'MS1 Phase 3');
insert into LOCATION_DETAILS values (107, 'Mindspace1', 'Sixth Floor', 'MS1 Phase 4');	
insert into LOCATION_DETAILS values (108, 'Mindspace2', 'Eighth Floor', 'MS2 Phase 5');

/*MS phase 1*/
insert into ROOM_DETAILS values (501, 4, '14-08-01','Room',1,1, '14-08-01(4)', 'A', 104);
insert into ROOM_DETAILS values (502, 8, '14-08-02','Room',1,0, '14-08-02(8)', 'A', 104);
insert into ROOM_DETAILS values (503, 8, '14-08-03','Room',0,1, '14-08-03(8)', 'A', 104);
insert into ROOM_DETAILS values (504, 16, '14-08-04','Room',0,0, '14-08-04(16)', 'A', 104);
insert into ROOM_DETAILS values (505, 8, '14-08-05','Room',1,1, '14-08-05(8)', 'A', 104);
insert into ROOM_DETAILS values (506, 4, '14-08-06','Room',1,0, '14-08-06(4)', 'A', 104);
insert into ROOM_DETAILS values (507, 4, '14-08-07','Room',0,1, '14-08-07(4)', 'A', 104);
insert into ROOM_DETAILS values (508, 4, '14-08-08','Room',0,0, '14-08-08(4)', 'A', 104);
insert into ROOM_DETAILS values (509, 4, '14-08-09','Room',1,1, '14-08-09(4)', 'A', 104);
insert into ROOM_DETAILS values (510, 6, '14-08-17','Room',1,0, '14-08-17(6)', 'A', 104);
insert into ROOM_DETAILS values (511, 6, '14-08-18','Room',0,1, '14-08-18(6)', 'A', 104);
insert into ROOM_DETAILS values (512, 6, '14-08-19','Room',0,0, '14-08-19(6)', 'A', 104);
insert into ROOM_DETAILS values (513, 4, '14-08-20','Room',1,1, '14-08-20(4)', 'A', 104);

/*MS phase 2*/
insert into ROOM_DETAILS values (514, 8, '14-08-10','Room',1,0, '14-08-10(8)', 'A', 105);
insert into ROOM_DETAILS values (515, 8, '14-08-11','Room',1,1, '14-08-11(8)', 'A', 105);
insert into ROOM_DETAILS values (516, 8, '14-08-12','Room',1,1, '14-08-12(8)', 'A', 105);
insert into ROOM_DETAILS values (517, 6, '14-08-13','Room',1,1, '14-08-13(6)', 'A', 105);
insert into ROOM_DETAILS values (518, 16, '14-08-14','Room',1,1, '14-08-14(16)', 'A', 105);
insert into ROOM_DETAILS values (519, 8, '14-08-15','Room',1,1, '14-08-15(8)', 'A', 105);
insert into ROOM_DETAILS values (520, 4, '14-08-16','Room',1,1, '14-08-16(4)', 'A', 105);

/*MS phase 3*/
insert into ROOM_DETAILS values (521, 4, '14-06-01','Room',1,1, '14-06-01(4)', 'A', 106);
insert into ROOM_DETAILS values (522, 4, '14-06-02','Room',1,1, '14-06-02(4)', 'A', 106);
insert into ROOM_DETAILS values (523, 8, '14-06-03','Room',1,1, '14-06-03(8)', 'A', 106);
insert into ROOM_DETAILS values (524, 8, '14-06-04','Room',1,1, '14-06-04(8)', 'A', 106);
insert into ROOM_DETAILS values (525, 16, '14-06-05','Room',1,1, '14-06-05(16)', 'A', 106);
insert into ROOM_DETAILS values (526, 4, '14-06-06','Room',1,1, '14-06-06(4)', 'A', 106);
insert into ROOM_DETAILS values (527, 4, '14-06-07','Room',1,1, '14-06-07(4)', 'A', 106);

/*MS phase 4*/
insert into ROOM_DETAILS values (528, 4, '14-06-08','Room',1,1, '14-06-08(4)', 'A', 107);
insert into ROOM_DETAILS values (529, 4, '14-06-09','Room',1,1, '14-06-09(4)', 'A', 107);
insert into ROOM_DETAILS values (530, 4, '14-06-10','Room',1,1, '14-06-10(4)', 'A', 107);
insert into ROOM_DETAILS values (531, 4, '14-06-11','Room',1,1, '14-06-11(4)', 'A', 107);
insert into ROOM_DETAILS values (532, 4, '14-06-12','Room',1,1, '14-06-12(4)', 'A', 107);
insert into ROOM_DETAILS values (533, 8, '14-06-13','Room',1,1, '14-06-13(8)', 'A', 107);
insert into ROOM_DETAILS values (534, 6, '14-06-14','Room',1,1, '14-06-14(6)', 'A', 107);
insert into ROOM_DETAILS values (535, 8, '14-06-15','Room',1,1, '14-06-15(8)', 'A', 107);
insert into ROOM_DETAILS values (536, 8, '14-06-16','Room',1,1, '14-06-16(16)', 'A', 107);
insert into ROOM_DETAILS values (537, 8, '14-06-17','Room',1,1, '14-06-17(8)', 'A', 107);
insert into ROOM_DETAILS values (538, 6, '14-06-18','Room',1,1, '14-06-18(6)', 'A', 107);
insert into ROOM_DETAILS values (539, 6, '14-06-19','Room',1,1, '14-06-19(6)', 'A', 107);
insert into ROOM_DETAILS values (540, 4, '14-06-20','Room',1,1, '14-06-20(4)', 'A', 107);
insert into ROOM_DETAILS values (541, 4, '14-06-21','Room',1,1, '14-06-21(4)', 'A', 107);

/*MS2 phase 5*/
insert into ROOM_DETAILS values (542, 3, '11-08-01','Room',1,1, '11-08-01(3)', 'A', 108);
insert into ROOM_DETAILS values (543, 3, '11-08-02','Room',1,1, '11-08-02(3)', 'A', 108);
insert into ROOM_DETAILS values (544, 6, '11-08-03','Room',1,1, '11-08-03(6)', 'A', 108);
insert into ROOM_DETAILS values (545, 6, '11-08-04','Room',1,1, '11-08-04(6)', 'A', 108);
insert into ROOM_DETAILS values (546, 8, '11-08-05','Room',1,1, '11-08-05(8)', 'A', 108);
insert into ROOM_DETAILS values (547, 5, '11-08-06','Room',1,1, '11-08-06(5)', 'A', 108);
insert into ROOM_DETAILS values (548, 6, '11-08-07','Room',1,1, '11-08-07(6)', 'A', 108);
insert into ROOM_DETAILS values (549, 3, '11-08-08','Room',1,1, '11-08-08(3)', 'A', 108);
insert into ROOM_DETAILS values (550, 8, '11-08-09','Room',1,1, '11-08-09(8)', 'A', 108);
insert into ROOM_DETAILS values (551, 8, '11-08-10','Room',1,1, '11-08-10(8)', 'A', 108);
insert into ROOM_DETAILS values (552, 14, '11-08-11','Room',1,1, '11-08-11(14)', 'A', 108);
insert into ROOM_DETAILS values (553, 8, '11-08-12','Room',1,1, '11-08-12(8)', 'A', 108);
insert into ROOM_DETAILS values (554, 6, '11-08-13','Room',1,1, '11-08-13(6)', 'A', 108);

--TX ROOM DETAILS
insert into ROOM_DETAILS values (556, 3, '0A-01','ROOM',1,1, '0A-01(3)', 'A', 101);
INSERT INTO ROOM_DETAILS VALUES (557,3,'0A-02','ROOM',1,1,'0A-02(3)','A',101);
INSERT INTO ROOM_DETAILS VALUES (558,3,'0A-03','ROOM',1,0,'0A-03(3)','A',101);
INSERT INTO ROOM_DETAILS VALUES (559,3,'0B-01','ROOM',0,1,'0B-01(3)','A',101);
INSERT INTO ROOM_DETAILS VALUES (560,3,'0B-02','ROOM',0,0,'0B-02(3)','A',101);
INSERT INTO ROOM_DETAILS VALUES (561,11,'0B-03','ROOM',1,1,'0B-03(11)','A',101);
INSERT INTO ROOM_DETAILS VALUES (562,8,'0B-04','ROOM',1,1,'0B-04(8)','A',101);
INSERT INTO ROOM_DETAILS VALUES (563,15,'0B-05','ROOM',1,1,'0B-05(15)','A',101);
INSERT INTO ROOM_DETAILS VALUES (564,3,'0B-06','ROOM',0,0,'0B-06(3)','A',101);

INSERT INTO ROOM_DETAILS VALUES (565,8,'1A-01','ROOM',1,1,'1A-01(8)','A',102);
INSERT INTO ROOM_DETAILS VALUES (566,3,'1A-02','ROOM',1,0,'1A-02(3)','A',102);
INSERT INTO ROOM_DETAILS VALUES (567,3,'1A-03','ROOM',0,1,'1A-03(3)','A',102);
INSERT INTO ROOM_DETAILS VALUES (568,8,'1B-01','ROOM',1,1,'1B-01(8)','A',102);
INSERT INTO ROOM_DETAILS VALUES (569,3,'1B-02','ROOM',1,1,'1B-02(3)','A',102);
INSERT INTO ROOM_DETAILS VALUES (570,8,'1B-03','ROOM',1,1,'1B-03(8)','A',102);
INSERT INTO ROOM_DETAILS VALUES (571,6,'1B-04','ROOM',0,0,'1B-04(6)','A',102);
INSERT INTO ROOM_DETAILS VALUES (572,6,'1B-05','ROOM',1,1,'1B-05(6)','A',102);
INSERT INTO ROOM_DETAILS VALUES (573,8,'1B-06','ROOM',1,1,'1B-06(8)','A',102);
INSERT INTO ROOM_DETAILS VALUES (574,15,'1B-07','ROOM',1,1,'1B-07(15)','A',102);
INSERT INTO ROOM_DETAILS VALUES (575,3,'1B-08','ROOM',0,0,'1B-08(3)','A',102);
INSERT INTO ROOM_DETAILS VALUES (576,8,'1B-09','ROOM',0,1,'1B-09(8)','A',102);

INSERT INTO ROOM_DETAILS VALUES (577,8,'2A-01','ROOM',1,1,'2A-01(8)','A',103);
INSERT INTO ROOM_DETAILS VALUES (578,8,'2B-01','ROOM',1,1,'2B-01(8)','A',103);
INSERT INTO ROOM_DETAILS VALUES (579,1,'2B-02','ROOM',0,0,'2B-02(1)','A',103);
INSERT INTO ROOM_DETAILS VALUES (580,15,'2B-03','ROOM',1,1,'2B-03(15)','A',103);
INSERT INTO ROOM_DETAILS VALUES (581,8,'2B-04','ROOM',0,1,'2B-04(8)','A',103);
INSERT INTO ROOM_DETAILS VALUES (582,8,'2B-05','ROOM',1,1,'2B-05(8)','A',103);
INSERT INTO ROOM_DETAILS VALUES (583,15,'Teritex 2B Board Room (15pax)','ROOM',1,1,'Teritex 2B Board Room (15pax)','A',103);

/*
INSERT INTO BOOKING_DETAILS VALUES(201,CURRENT_TIMESTAMP(),CURRENT_DATE(),CURRENT_TIMESTAMP(),CURRENT_DATE(),'SARIKA',501);
INSERT INTO BOOKING_DETAILS VALUES(202,CURRENT_TIMESTAMP(),CURRENT_DATE(),CURRENT_TIMESTAMP(),CURRENT_DATE(),'RINAL',502);
INSERT INTO BOOKING_DETAILS VALUES(203,CURRENT_TIMESTAMP(),CURRENT_DATE(),CURRENT_TIMESTAMP(),CURRENT_DATE(),'SAGAR',503);
INSERT INTO BOOKING_DETAILS VALUES(204,CURRENT_TIMESTAMP(),CURRENT_DATE(),CURRENT_TIMESTAMP(),CURRENT_DATE(),'HEMANT',502);
INSERT INTO BOOKING_DETAILS VALUES(205,CURRENT_TIMESTAMP(),CURRENT_DATE(),CURRENT_TIMESTAMP(),CURRENT_DATE(),'AKSHAY',501);
*/