'use strict';

/**
 * @ngdoc overview
 * @name meetingRoomApp
 * @description
 * # meetingRoomApp
 *
 * Main module of the application.
 */
angular
  .module('meetingRoomApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ui.router',
    'ngSanitize',
    'ngTouch',
    'ui.bootstrap',
    'ui.grid'
  ])
  .config(function ($stateProvider, $urlRouterProvider) {
	  $urlRouterProvider.otherwise('/');
	  $stateProvider
	      .state("SearchPage", {
	    	  url:"/",
	        controller:"SearchPageController",
	        templateUrl:"/app/views/searchPage.html"
	        	
	      }).state("SearchPage.accordianView", {
	          controller:"AccordianController",
                  params: {
                        allRooms: null,
                        locationId: 1
                  },
	          templateUrl:"/app/views/accordianView.html"
                  
	      });
  });
