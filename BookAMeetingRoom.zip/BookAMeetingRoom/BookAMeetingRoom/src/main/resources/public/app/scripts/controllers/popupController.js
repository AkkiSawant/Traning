
angular.module('meetingRoomApp').controller('ModalDemoCtrl', function ($scope, $uibModal, $log) {

  $scope.animationsEnabled = true;

 
  $scope.open = function (detail) {
	  
	  detail.formData=$scope.formData;
	  var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'app/views/bookPopup.html',
      controller: 'BookPopupCtrl',
      size: 'sm',
      resolve: {
          roomDetail: function () {
            return detail;
          }
        }
    });
    
  };

  $scope.toggleAnimation = function () {
    $scope.animationsEnabled = !$scope.animationsEnabled;
  };

});

angular.module('meetingRoomApp').controller('BookPopupCtrl', function ($scope,$filter, $uibModalInstance,$http,$log,locationService,roomDetail,$rootScope) {

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
  $scope.close = function () {
	  $uibModalInstance.close();
  };
  $scope.roomName=roomDetail.name;
  $scope.roomCode=roomDetail.code;
  $scope.displayStartDate = $filter('date')($rootScope.startDate, "dd-MM-yyyy");
  $scope.displayEndDate = $filter('date')($rootScope.endDate, "dd-MM-yyyy");
  $scope.disableSubmit = false;
  var roomBookDetails={
		  roomId:roomDetail.roomId,
		  code:roomDetail.code,
		  description:roomDetail.description,
		  name:roomDetail.name,
		  status:roomDetail.status,
		  capacity:roomDetail.capacity,
		  hasConference:roomDetail.hasConference,
		  hasProjector:roomDetail.hasProjector
  }
  $scope.submitform=function(){
	  $scope.message="";
	  if(!$scope.user){
		  $scope.message="Enter user name";
		  $scope.type="danger";
		  return;
	  }
	  if($scope.startTime>$scope.endTime){
		  $scope.message="Start time should be less than end time";
		  $scope.type="danger";
		  return;
	  }
	  var bookingDetails={
			  startTime:$filter('date')($scope.startTime, 'HH:mm:ss'),
			  endTime:$filter('date')($scope.endTime, 'HH:mm:ss'),
			  fromDate:$filter('date')($rootScope.startDate, "yyyy-MM-dd"),
			  toDate:$filter('date')($rootScope.endDate, "yyyy-MM-dd"),
			  user:$scope.user,
			  meetingRoom:roomBookDetails	  
	  };
	  locationService.saveBooking(bookingDetails).then(function(response){
			$scope.message="You have booked a room...!";
			$scope.type="success";
			$scope.disableSubmit = true;
			
			for(var i=0;i<$rootScope.allRoom.length;i++){
				if (response.meetingRoom.roomId == $rootScope.allRoom[i].roomId){
	    			  $rootScope.allRoom[i].gridvar.data.push(response);
	    			  	
	    		  }
			}
			
			
		},function(response){
			$scope.message="Sorry room is unavailable...!";
			$scope.type="danger";
		});	
    
  };
  
  $scope.closeAlert = function() {
	  $scope.message=null;
  };
  
  $scope.time = "";

  $scope.hstep = 1;
  $scope.mstep = 15;
  var d = new Date();
    d.setHours( 8 );
    d.setMinutes( 0 );
    $scope.startTime = d;
    var d1 = new Date();
    d1.setHours( 8 );
    d1.setMinutes( 30 );
    $scope.endTime = d1;
  $scope.options = {
    hstep: [1, 2, 3],
    mstep: [1, 5, 10, 15, 25, 30]
  };

  $scope.ismeridian = false;
  $scope.toggleMode = function() {
    $scope.ismeridian = ! $scope.ismeridian;
  };

  $scope.update = function() {
    var d = new Date();
    d.setHours( 14 );
    d.setMinutes( 0 );
    $scope.time = d;
  };

  $scope.changed = function () {
    var d1 =new Date($scope.startTime.getTime() + 30*60000);
   
    
    //$scope.mytime2 = d1;
    $log.log('Time changed to: ' + $scope.time);
  };

  $scope.clear = function() {
    $scope.time = null;
  };
  
});