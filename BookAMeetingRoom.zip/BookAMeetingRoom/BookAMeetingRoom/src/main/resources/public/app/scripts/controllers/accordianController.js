angular.module('meetingRoomApp')
	.controller('AccordianController',function($scope,$stateParams,$http,$rootScope,locationService,$timeout){
		
	$scope.columnDefinition=[
	       			      { name: 'Booking Id', field: 'bookingId',  width: 100, cellClass:"text-center" },
	    			      { name:'Start Date',field :'fromDate', cellClass:"text-center" },
	    			      { name: 'End Date', field : 'toDate', cellClass:"text-center" },
	    			      { name: 'Start Time',field :'startTime', cellClass:"text-center" },
	    			      { name: 'End Time',field :'endTime', cellClass:"text-center" },
	    			      { name: 'Booked By',field:'user' }
	    			    ];
	
	$rootScope.allRoom = $stateParams.allRooms;
	$scope.gridOptions = {
		enableSorting : true,
		columnDefs : $scope.columnDefinition,
		enableColumnMenus : false
	};
	
        console.log(JSON.stringify($stateParams));
        
	 	  $scope.form = {};
		  $scope.applyDiv = function(index) {
		    return index !== $scope.form.val;
		  };
		  
		  
		  $scope.assignVal = function(val,roomDetails) {
		    if ($scope.form.val === val) {
		      $scope.form.val = -1;
		    } else {		    		    	
		      $scope.form.val = val;
		      if(!roomDetails.hasOwnProperty("gridvar")){
		    	  var data = {};
			      data.roomId = roomDetails.roomId;
		          data.fromDate = $rootScope.startDate;
		          data.toDate = $rootScope.endDate;
			  
			      locationService.getBookingDetails(data).then(function(response){
			    	  for(var i=0;i<$rootScope.allRoom.length;i++){
			    		  if (roomDetails.roomId == $rootScope.allRoom[i].roomId){
			    			  $rootScope.allRoom[i].gridvar = JSON.parse(JSON.stringify($scope.gridOptions));
			    			  $rootScope.allRoom[i].gridvar.data = JSON.parse(JSON.stringify(response));
			    			  $rootScope.allRoom[i].gridvar.columnDefs = JSON.parse(JSON.stringify($scope.columnDefinition));
			    		  }
			    	  }
			    	   
					},function(response){
						
					});
		      }
		      	
		    }
		  };
});