var module = angular.module('meetingRoomApp');
module.service("RestService", ['$http', function ($http) {
       this.makeCallPassingParameter = function (method, url, parameterKey, parameterVal, successCallback, failureCallBack) {
            var data = {};
            data[parameterKey] = parameterVal;

            $http({
                method: method,
                url: url,
                data: data,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                }
            }).then(function (response) {

                successCallback(response.data, response.status, response);
            }, function (response) {

                failureCallBack(response.data, response.status, response);
            });
        };

        this.makeCallPassingJsonAsString = function (method, url, key, object, successCallback, failureCallBack) {
            var data = {};
            data[key] = JSON.stringify(object);

            $http({
                method: method,
                url: url,
                data: data,
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                }
            }).then(function (response) {

                successCallback(response.data, response.status, response);
            }, function (response) {

                failureCallBack(response.data, response.status, response);
            });
        };
        
        this.makeCallPassingJsonObject = function (method, url, data, successCallback, failureCallBack) {
            //data[parameterKey]=parameterVal;		  
            $http({
                method: method,
                url: url,
                data: data,
                responseType: 'json',
                headers: {
                    //'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    'Content-Type': 'application/json'
                }
            }).then(function (response) {
                successCallback(response.data, response.status, response);
            }, function (response) {
                failureCallBack(response.data, response.status, response);
            });
        };
}]);        


