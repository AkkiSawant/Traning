angular.module('meetingRoomApp').service(
		'locationService',
		[
				'apiService',
				'configService',
				'RestService',
				function(apiService, configService, RestService) {
					this.getAllLocations = function() {
						var config = configService.API.LOCATION;
						return apiService.callApi(config);
					};

					this.getRoomByLocation = function(data) {
						var config = JSON.parse(JSON
								.stringify(configService.API.FETCH_ROOM));
						config.url = config.url + data.locationId + "/"
								+ data.hasConference + "/" + data.hasProjector;
						return apiService.callApi(config);
					};

					this.getBookingDetails = function(data) {
						var config = JSON.parse(JSON
								.stringify(configService.API.BOOKING_DETAIL));
						config.url = config.url + data.roomId + "/"
								+ data.fromDate + "/" + data.toDate;
						return apiService.callApi(config);
					}

					this.saveBooking = function(bookingDetails) {
						var config = JSON.parse(JSON
								.stringify(configService.API.BOOK_ROOM));
						config.data = bookingDetails;
						return apiService.callApi(config);
					};

				} ]);