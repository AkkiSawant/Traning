angular.module('meetingRoomApp')
	.controller("SearchPageController",["$scope", "locationService", "$state","$rootScope",
		function($scope, locationService, $state, $rootScope){
			$scope.startDatePopup = {
				opened: false
			};
			$scope.endDatePopup = {
				opened: false
			};
			$scope.format = 'dd.MM.yyyy';
			$scope.formData = {};
			$rootScope.startDate = new Date();
			$rootScope.endDate = new Date();
			$scope.formData.hasTelephone = true;
			$scope.formData.hasProjector = true;
	  		$scope.dateOptions = {
			    startingDay: 1
			};
			$scope.startDatePopupClick = function() {
			   $scope.startDatePopup.opened = true;
			};
			$scope.endDatePopupClick = function() {
			   $scope.endDatePopup.opened = true;
			};

			locationService.getAllLocations()
				.then(function(response){
					$scope.locations = response;
				});			

			
			$scope.SearchRoomSubmit = function(){
				$rootScope.startDate = $scope.startDate;
				$rootScope.endDate = $scope.endDate;
				$scope.message=null;
				if($rootScope.startDate>$rootScope.endDate){
					$scope.message="Start Date should be less than end Date";
					$scope.rooms=[];
					$state.go("SearchPage.accordianView",{"allRooms":$scope.rooms});
					return
				}
				var successCallback = function (data, status, response) {
					$scope.rooms = data;
					$state.go("SearchPage.accordianView",{"allRooms":$scope.rooms});
		        };
		        var failureCallback = function (data, status, response) {
		        	
		        };
		        var data = {
		        	"locationId":$scope.formData.selectedLocation.locationId,
		        	"hasConference": $scope.formData.hasTelephone,
	        		"hasProjector":$scope.formData.hasProjector
		        };
				locationService.getRoomByLocation(data).then(successCallback, failureCallback)
			
			};
		}
	]);