angular.module('meetingRoomApp').factory('apiService',
		[ '$http', '$q', function($http, $q) {
			var self = this;

			self.callApi = function(apiConfig) {
				var deferred = $q.defer();
				var httpRequest = {};

				httpRequest.method = apiConfig.method;
				httpRequest.url = apiConfig.url;
				httpRequest.headers = {};

				httpRequest.data = apiConfig.data;

				$http(httpRequest).success(function(data) {
					deferred.resolve(data);
				}).error(function(err) {
					deferred.reject(err);
				});
				return deferred.promise;
			};
			return self;
		} ]);