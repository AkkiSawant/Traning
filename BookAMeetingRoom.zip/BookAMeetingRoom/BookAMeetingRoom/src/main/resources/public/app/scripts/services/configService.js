angular.module('meetingRoomApp').factory('configService', function($window) {

	var self = this;
	self.GLOBALURL = "http://localhost:8181/book";

	self.API = {
		LOCATION : {
			url : self.GLOBALURL + '/locations',
			method : 'get',
			contentType : 'application/json',
			data : {}
		},
		FETCH_ROOM : {
			url : self.GLOBALURL + '/getAllRooms/',
			method : 'get',
			contentType : 'application/json',
			data : {}
		},
		BOOKING_DETAIL : {
			url : self.GLOBALURL + '/getBookingDetails/',
			method : 'get',
			contentType : 'application/json',
			data : {}
		},
		BOOK_ROOM : {
			url : self.GLOBALURL + '/roombook',
			method : 'post',
			contentType : 'application/json',
			data : {}
		}
	};

	self.MESSAGES = {

	};
	return self;
});