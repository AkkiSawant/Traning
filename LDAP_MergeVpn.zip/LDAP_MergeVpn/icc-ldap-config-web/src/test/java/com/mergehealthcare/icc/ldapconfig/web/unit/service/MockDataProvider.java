
package com.mergehealthcare.icc.ldapconfig.web.unit.service;

import icc.ldap.server.configuration.ServerConfiguration;

import java.util.List;
import java.util.Set;

// TODO: add mock data
class MockDataProvider {

  public static ServerConfiguration getAddServerConfigurationInp() {
    return null;
  }


  public static ServerConfiguration getModifyServerConfigurationInp() {
    return null;
  }


  public static List<ServerConfiguration> getAllServerConfigurations() {
    return null;
  }


  public static ServerConfiguration getDeleteServerConfigurationInp() {
    return null;
  }


  public static ServerConfiguration getUpdateServerConfigurationInp() {
    return null;
  }


  public static Set<String> getServerNames() {
    return null;
  }


  public static ServerConfiguration getServerConfigurationInp() {
    return null;
  }
}
