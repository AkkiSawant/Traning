/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.integration.controller.test.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.web.MainApplication;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.apache.log4j.Logger;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;

import java.nio.charset.Charset;

/*
 * @author sarikam2
 */
@WebAppConfiguration
@ContextConfiguration (classes = { LdapConfigApplication.class })
@RunWith (SpringJUnit4ClassRunner.class)
// @TestPropertySource ("classpath:icc-ldap-cacerts.jks")
public class LdapConfigurationControllerTest {

    private static final int DEFAULT_PORT = 389;

    private static final Logger logger = LogService.getLogger(LdapConfigurationControllerTest.class);

    private final MediaType content = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(),
                    Charset.forName("utf8"));

    private MockMvc mockMvc;

    @Autowired
    private ModelMapperHelper modelMapperHelper;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private ModelMapperHelper modelMapper;

    @Autowired
    private ConnectionModelMapper connectionModelMapper;

    private ServerDetailsModel serverInformationModel;

    private ConnectionDetailsModel connectionDetailsModel;

    @Autowired
    ReturnAttributeSettings returnAttributeSettings;

    @Autowired
    MainApplication app;


    /**
     * Setup.
     *
     * @throws Exception the exception
     */
    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(this.webApplicationContext).build();

        this.serverInformationModel = new ServerDetailsModel();
        this.serverInformationModel.setNetworkDomain("icc");
        this.serverInformationModel.setPassword("Cedara102");
        this.serverInformationModel.setServerName("internal");
        this.serverInformationModel.setServerType(ServerType.AD.toString());
        this.serverInformationModel.setUserName("Administrator");

        this.modelMapperHelper.saveServerConfiguration(this.serverInformationModel);

        connectionDetailsModel = new ConnectionDetailsModel();
        connectionDetailsModel.setDomainHost("icc-ldap.products.network.internal");
        connectionDetailsModel.setDefaultPort(DEFAULT_PORT);
        connectionDetailsModel.setConnectionType("basic");
        connectionDetailsModel.setAdvancedConnectionVm(connectionModelMapper.getDefaultJavaData());
        logger.debug("this.serverInformationModel = " + this.serverInformationModel);

    }


    // @Test
    public void testModifyParam() {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "" + true);
        Boolean modi = Boolean.valueOf((String) webApplicationContext.getServletContext().getAttribute(LdapConfigConstant.MODIFY_MODE));
        assertNotNull(modi);
    }


    // @Test
    public void saveServerDetails() throws Exception {
        webApplicationContext.getServletContext().removeAttribute(LdapConfigConstant.MODIFY_MODE);
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "internal")
                                        .param("serverType", "AD").param("networkDomain", "google.com").param("userName", "sarika")
                                        .param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveServerDetailsServerNameFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "true");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "").param("serverType", "AD")
                        .param("networkDomain", "networkDomain").param("userName", "userName").param("password", "password"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("serverDetails", "serverName"));
    }


    // @Test
    public void saveServerDetailsNetworkDomainFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "true");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "server name")
                                        .param("serverType", "AD").param("networkDomain", "").param("userName", "userName")
                                        .param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(view().name("dashboard"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("serverDetails", "networkDomain"));
    }


    // @Test
    public void saveServerDetailsUserNameFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "true");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "server name")
                                        .param("serverType", "AD").param("networkDomain", "networkDomain").param("userName", "")
                                        .param("password", "password")).andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(view().name("dashboard"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("serverDetails", "userName"));
    }


    // @Test
    public void saveServerModifySuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "true");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "internal")
                                        .param("serverType", "AD").param("networkDomain", "icc")
                                        .param("userName", "icc-ldap.products.network.internal").param("password", "Cedara102"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveNewServerForJavaPlatformSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODIFY_MODE, "false");
        this.modelMapperHelper.deleteServer("Test");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/saveServer").contentType(this.content).param("serverName", "Test")
                                        .param("serverType", "AD").param("networkDomain", "icc")
                                        .param("userName", "icc-ldap.products.network.internal").param("password", "Cedara102"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
                        .andExpect(MockMvcResultMatchers.model().attribute("message", "New Server details added successfully"));

        this.modelMapperHelper.deleteServer("Test");
    }


    // @Test
    public void showAddServer() throws Exception {
        webApplicationContext.getServletContext().removeAttribute(LdapConfigConstant.MODIFY_MODE);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/saveServer").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("wizardState.serverDetails.serverName", Matchers.nullValue()));
    }


    // @Test
    public void showAddNewServerSuccess() throws Exception {

        webApplicationContext.getServletContext().removeAttribute(LdapConfigConstant.MODIFY_MODE);
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");

        this.mockMvc.perform(MockMvcRequestBuilders.get("/saveServer").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("wizardState.serverDetails.serverName", Matchers.nullValue()));

        assertNotNull(webApplicationContext.getServletContext().getAttribute(LdapConfigConstant.MODIFY_MODE));
        assertEquals(webApplicationContext.getServletContext().getAttribute(LdapConfigConstant.MODIFY_MODE), "true");
    }


    // @Test
    public void saveBasicConnectionDetailsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/connections").contentType(this.content).param("domainHost", "localhost")
                                        .param("defaultPort", "11111").param("connectionType", "basic")
                                        .param("advancedConnectionViewModel.type", "Simple")
                                        .param("advancedConnectionViewModel.timeLimit", "00:00:00")
                                        .param("advancedConnectionViewModel.sizeLimit", "700")
                                        .param("advancedConnectionViewModel.pageSize", "699")
                                        .sessionAttr("serverConnection", new ConnectionDetailsModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveModelOptionsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "ungrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveModelOptionsForSingleDomainUngroupedSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "singleDomainUngrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveModelOptionsValidationFailure() throws Exception {

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content)
                                        .sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("modelOption", "rootDistinguishedName"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("modelOption", "organizationalUnitDomain"));
    }


    // @Test
    public void saveUserOverrideMapValidationFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/userOverrideMap").contentType(this.content)
                                        .param("userOverrideMapDetailsViewModel[0].userId", "user id")
                                        .param("userOverrideMapDetailsViewModel[0].systemAdminLevel", "ADMIN")
                                        .param("userOverrideMapDetailsViewModel[0].groupDetails[0]", "")
                                        .param("userOverrideMapDetailsViewModel[0].domainDetails[0]", "")
                                        .sessionAttr("userOverrideMapViewModel", new UserOverrideMapViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("userOverrideMapViewModel",
                                        "userOverrideMapDetailsViewModel[0].groupDetails[0]"))
                                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("userOverrideMapViewModel",
                                                        "userOverrideMapDetailsViewModel[0].domainDetails[0]"));
    }


    // @Test
    public void saveUserOverrideMapValidationLessThen2ErrorsFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/userOverrideMap").contentType(this.content)
                                        .param("userOverrideMapDetailsViewModel[0].userId", "user id")
                                        .param("userOverrideMapDetailsViewModel[0].systemAdminLevel", "ADMIN")
                                        .param("userOverrideMapDetailsViewModel[0].domainDetails[0]", "")
                                        .sessionAttr("userOverrideMapViewModel", new UserOverrideMapViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("userOverrideMapViewModel",
                                        "userOverrideMapDetailsViewModel[0].domainDetails[0]"));
    }


    // @Test
    public void saveUserOverrideMapSuccess() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/userOverrideMap").contentType(this.content)
                                        .param("userOverrideMapDetailsViewModel[0].userId", "user id")
                                        .param("userOverrideMapDetailsViewModel[0].systemAdminLevel", "ADMIN")
                                        .param("userOverrideMapDetailsViewModel[0].groupDetails[0].domainId", "Domain1")
                                        .param("userOverrideMapDetailsViewModel[0].domainDetails[0].domainId", "Domain1")
                                        .param("userOverrideMapDetailsViewModel[0].groupDetails[0].groupId", "Group1")
                                        .param("userOverrideMapDetailsViewModel[0].domainDetails[0].domainAdminLevel", "ADMIN")
                                        .param("userOverrideMapDetailsViewModel[0].groupDetails[0].role", "testrole")
                                        .param("userOverrideMapDetailsViewModel[0].domainDetails[0].role", "testrole")
                                        .sessionAttr("userOverrideMapViewModel", new UserOverrideMapViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("userOverrideMapViewModel"));

    }


    // @Test
    public void getModelOptionSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.get("/modelOptions").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("modelOption", Matchers.notNullValue()));
    }


    // @Test
    public void getUserOverrideMapSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.get("/userOverrideMap").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("userOverrideMap", Matchers.notNullValue()));
    }


    // @Test
    public void showAddConnectionsViewSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.get("/connections").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("serverConnection", Matchers.notNullValue()));
    }


    // @Test
    public void modifyServerDetailsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.post("/modifyServer").contentType(this.content).param("serverName", "internal"))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("serverDetails", Matchers.notNullValue()));
    }


    // @Test
    public void deleteServerSuccess() throws Exception {

        ServerDetailsModel deleteServerModel = BeanUtils.instantiate(ServerDetailsModel.class);
        deleteServerModel.setNetworkDomain("google.com");
        deleteServerModel.setPassword("password");
        deleteServerModel.setServerName("DeleteServer");
        deleteServerModel.setServerType("AD");
        deleteServerModel.setUserName("username");
        modelMapper.saveServerConfiguration(deleteServerModel);
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.post("/deleteServer").contentType(this.content).param("serverName", "DeleteServer"))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveDomainIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/domainIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveDomainIdentitySettingsForEmptyServerFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, null);
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, null);

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/domainIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
                                        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"));
    }


    // @Test
    public void saveDomainIdentitySettingsForTargetDnInvalidFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/domainIdentitySettings").contentType(this.content).param("basicInfoVm.targetDn", "")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("domainIdentitySettingsViewModel"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("domainIdentity", "basicInfoVm.targetDn"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void getDomainIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.get("/domainIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("domainIdentitySettingsViewModel", Matchers.notNullValue()));
    }


    // @Test
    public void getDomainIdentitySettingsFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, null);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/domainIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"));
    }


    // @Test
    public void getRoleIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.get("/roleIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("roleIdentitySettingsViewModel", Matchers.notNullValue()));
    }


    // @Test
    public void getRoleIdentitySettingsFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, null);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/roleIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"));
    }


    // @Test
    public void saveRoleIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/roleIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.filter", "filter").param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("roleIdentity"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveRoleIdentitySettingsForTargetDnInvalidFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/roleIdentitySettings").contentType(this.content).param("basicInfoVm.targetDn", "")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("roleIdentitySettingsViewModel"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("roleIdentity", "basicInfoVm.targetDn"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveRoleIdentitySettingsForWrongServerFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "wrongServer");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/roleIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleDomain")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveUserIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODEL_GROUPING,
                        LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED);

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/userIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSUserHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleUser")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveUserIdentitySettingsAndShowUserOverrideMapSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.MODEL_GROUPING, LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED);

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/userIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSUserHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleUser")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
                                        .andExpect(MockMvcResultMatchers.model().attribute("currentPage", "userOverrideMap"));
        ;
    }


    // @Test
    public void saveUserIdentitySettingsFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/userIdentitySettings").contentType(this.content).param("basicInfoVm.targetDn", "")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleUser")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("userIdentitySettingsViewModel"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("userIdentity", "basicInfoVm.targetDn"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveUserIdentitySettingsForWrongServerFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "wrongserver");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/userIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apuser4 merge,OU=Subgroup1,OU=Group1,OU=APSUserHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleUser")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void getUserIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(MockMvcRequestBuilders.get("/userIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("userIdentitySettingsViewModel", Matchers.notNullValue()));
    }


    // @Test
    public void showFinishViewSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        this.mockMvc.perform(MockMvcRequestBuilders.post("/finish").contentType(this.content)).andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(view().name("dashboard"));
    }


    // @Test
    public void showLandingViewSuccess() throws Exception {

        this.mockMvc.perform(MockMvcRequestBuilders.post("/home").contentType(this.content)).andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("serverList", Matchers.hasSize(Matchers.greaterThan(0))));
    }


    // @Test
    public void testServerAuthenticationSuccessful() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "ungrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/testServer").contentType(this.content).param("userName", "apuser3")
                                        .param("password", "Cedara123").param("action", "authenticate"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("testServerConfigurationModel"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void testServerAuthenticationValidationFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "ungrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/testServer").contentType(this.content).param("userName", "").param("password", "")
                                        .param("action", "authenticate"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("testServer", "userName", "password"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void testServerAuthoraizationSuccessful() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "ungrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/testServer").contentType(this.content).param("userName", "apuser3")
                                        .param("password", "Cedara123").param("userAdminLevelTestEnabled", "true")
                                        .param("domainsAdministratorTestEnabled", "true").param("groupsAdministratorTestEnabled", "true")
                                        .param("rolesInDomainTestEnabled", "true").param("groupRolesInDomainTestEnabled", "true")
                                        .param("action", "authorize").param("groupDomainText", "APSDomainHG")
                                        .param("roleDomainText", "APSDomainHG").param("groupRoleGroupText", "Group1")
                                        .param("groupRoleDomainText", "APSDomainHG"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("testServerConfigurationModel"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void testServerAuthoraizationvalidationFailure() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");
        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/modelOptions").contentType(this.content).param("domainModel", "single")
                                        .param("modelGrouping", "ungrouped")
                                        .param("rootDistinguishedName", "OU=APSDomainHG,dc=icc,dc=internal")
                                        .param("organizationalUnitDomain", "subgroup").sessionAttr("modelOption", new ModelOptionsViewModel()))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/testServer").contentType(this.content).param("userName", "apuser3")
                                        .param("password", "Cedara123").param("userAdminLevelTestEnabled", "true")
                                        .param("domainsAdministratorTestEnabled", "true").param("groupsAdministratorTestEnabled", "true")
                                        .param("rolesInDomainTestEnabled", "true").param("groupRolesInDomainTestEnabled", "true")
                                        .param("action", "authorize").param("groupDomainText", "").param("roleDomainText", "")
                                        .param("groupRoleGroupText", "").param("groupRoleDomainText", ""))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("testServerConfigurationModel", "groupDomainText",
                                        "roleDomainText", "groupRoleGroupText", "groupRoleDomainText"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void addNewServer() throws Exception {
        webApplicationContext.getServletContext().removeAttribute(LdapConfigConstant.MODIFY_MODE);
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, null);

        this.mockMvc.perform(MockMvcRequestBuilders.get("/saveServer").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("wizardState.serverDetails.serverName", Matchers.nullValue()));
    }


    // @Test
    public void saveGroupIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/groupIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apgroup4 merge,OU=Subgroup1,OU=Group1,OU=APSGroupHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleGroup")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveGroupIdentitySettingsFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders.post("/groupIdentitySettings").contentType(this.content).param("basicInfoVm.targetDn", "")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleGroup")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasNoErrors("groupIdentitySettingsViewModel"))
                        .andExpect(MockMvcResultMatchers.model().attributeHasFieldErrors("groupIdentity", "basicInfoVm.targetDn"))
                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // @Test
    public void saveGroupIdentitySettingsForWrongServerFailure() throws Exception {

        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "wrongserver");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(
                        MockMvcRequestBuilders
                                        .post("/groupIdentitySettings")
                                        .contentType(this.content)
                        .param("basicInfoVm.targetDn",
                                        "CN=apgroup4 merge,OU=Subgroup1,OU=Group1,OU=APSGroupHG,dc=icc,dc=internal")
                                        .param("basicInfoVm.returnedAttributesEnabled", "true")
                                        .param("_basicInfoVm.returnedAttributesEnabled", "on").param("basicInfoVm.attributeMapEnabled", "true")
                                        .param("_basicInfoVm.attributeMapEnabled", "on").param("basicInfoVm.valueMapEnabled", "true")
                                        .param("_basicInfoVm.valueMapEnabled", "on").param("basicInfoVm.locatorType", "singleGroup")
                                        .param("basicInfoVm.filter", "(objectclass=organizationalUnit)")
                                        .param("returnedAttributesVm.configureEnabled", "true")
                                        .param("_returnedAttributesVm.configureEnabled", "on")
                                        .param("returnedAttributesVm.selectedDefaultAttribute", "ou,description,street,postalCode")
                                        .param("attributeMapVm.mapOption", "DICTIONARY").param("valueMapVm.mapOption", "DICTIONARY")
                                        .param("valueMapVm.valueMap[0].ldapValue", "$dnhG1Role1")
                                        .param("valueMapVm.valueMap[0].applicationValue", "Family Doctor"))
                                        .andExpect(MockMvcResultMatchers.model().attribute("error", "OOPs something went wrong"))
                                        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"));
    }


    // //@Test
    public void testLdapServerFailure() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.post("/testLdapServer").contentType(this.content).param("serverName", "internal"))
        .andExpect(MockMvcResultMatchers.model().attribute("serverName", "internal"))
        .andExpect(MockMvcResultMatchers.model().attribute("teststatus", false))
                        .andExpect(MockMvcResultMatchers.model().attribute("message",
                                        "Test Connection to internal is failed due to Improper details"));

    }


    // @Test
    public void getGroupIdentitySettingsSuccess() throws Exception {
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        webApplicationContext.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "AD");

        this.mockMvc.perform(MockMvcRequestBuilders.get("/groupIdentitySettings").contentType(this.content))
        .andExpect(MockMvcResultMatchers.status().isOk()).andExpect(view().name("dashboard"))
        .andExpect(MockMvcResultMatchers.model().attribute("groupIdentitySettingsViewModel", Matchers.notNullValue()));
    }


    /**
     * Test delete server.
     *
     * @throws Exception the exception
     */
    public void testDeleteServer() throws Exception {
        assertNotNull(this.modelMapperHelper);
        logger.info("testAddServer = " + this.serverInformationModel);
        this.modelMapperHelper.deleteServer(this.serverInformationModel.getServerName());

    }


    // @After
    public void tear() throws Exception {
        testDeleteServer();
    }


    @Test
    public void getTest() {
        app.authenticate();
    }
}
