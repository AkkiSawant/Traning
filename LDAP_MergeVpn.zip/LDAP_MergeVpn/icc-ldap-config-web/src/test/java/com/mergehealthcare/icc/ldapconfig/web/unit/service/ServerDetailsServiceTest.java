
package com.mergehealthcare.icc.ldapconfig.web.unit.service;

import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;

import icc.ldap.server.configuration.ServerConfiguration;
import org.springframework.test.context.ContextConfiguration;

@WebAppConfiguration
@ContextConfiguration (classes = { ServerDetailsService.class, MockServiceTest.class })
@RunWith (SpringJUnit4ClassRunner.class)
public class ServerDetailsServiceTest {

    @Autowired
    private ServerDetailsService serverDetailsService;


    @Test
    public void addSuccess() throws Exception {
        ServerConfiguration serverConfiguration = MockDataProvider.getAddServerConfigurationInp();
        serverDetailsService.add(serverConfiguration);
    }


    @Test
    public void loadAllServerNamesSuccess() throws Exception {
        List<ServerConfiguration> serverList = serverDetailsService.loadAllServerNames();
        assertNull(serverList);
    }


    @Test
    public void removeSuccess() throws Exception {
        String serverName = "TestServer";
        serverDetailsService.remove(serverName);
    }


    @Test
    public void modifySuccess() throws Exception {
        ServerConfiguration serverConfiguration = MockDataProvider.getModifyServerConfigurationInp();
        serverDetailsService.modify(serverConfiguration);
    }


    @Test
    public void listServerNamesSuccess() {
        Set<String> servers = serverDetailsService.listServerNames();
        assertNull(servers);
    }


    @Test
    public void fetchSaveConfigurationSuccess() throws LdapConfigDataException {
        String serverName = "TestServer";
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
        assertNull(serverConfiguration);
    }


    @Test
    public void enableServerSuccess() throws LdapConfigDataException, IOException {
        String serverName = "TestServer";
        serverDetailsService.enableServer(serverName, true);
    }


    @Test
    public void saveSelectedConfigurationSuccess() throws LdapConfigDataException, IOException {
        String serverName = "TestServer";
        serverDetailsService.saveSelectedConfiguration(serverName);
    }
}
