
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;

public class MockRest {

  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws Exception {
    mockDeleteServer(context, serverDetailsService);
    mockEnableServer(context, serverDetailsService);
  }


  private static void mockDeleteServer(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).remove(with(equal("TestServer")));
      }
    });
  }


  private static void mockEnableServer(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService)
            .enableServer(with(equal("TestServer")), with(any(Boolean.class)));
      }
    });
  }
}
