
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.UserMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockUser {

  private static String serverName = "user";


  public static void mockUserOverrideModelMapper(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws Exception {
    mockFindOverride(context, userOverrideModelMapper);
  }


  public static void mockIdentitySearchUtility(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws Exception {
    mockFindIdentity(context, identitySearchUtility);
  }


  public static void mockIdentityObjectCreationUtility(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) throws Exception {
    mockGetNewUser(context, identityObjectCreationUtility);

  }


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    mockSaveIdentity(context, identityModelOptionModelMapper);

  }


  private static void mockFindIdentity(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        UserIdentitySettingsViewModel userIdentitySettingsVm = UserMockData.getIdentitySettings();
        GroupIdentitySettingsViewModel groupIdentitySettingsVm =
            UserMockData.getGroupIdentitySettings();

        IdentitySettingsMethodVM identitySettingsMethodVM =
            UserMockData.getIdentitySettingsMethodUserVM();

        IdentitySettingsMethodVM identitySettingsMethodGroupVM =
            UserMockData.getIdentitySettingsMethodGroupVM();

        IdentitySettingsMethodVM identitySettingsMethodGroupExceptionVM =
            UserMockData.getIdentitySettingsMethodGroupExceptionVM();

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodVM)));
        will(returnValue(userIdentitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodGroupVM)));
        will(returnValue(groupIdentitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodGroupExceptionVM)));
        will(throwException(new LdapConfigDataException("LDAPConfigException")));

      }
    });
  }


  private static void mockGetNewUser(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) {
    context.checking(new Expectations() {

      {
        UserIdentitySettingsViewModel identitySettingsVm = UserMockData.getNewUser();
        allowing(identityObjectCreationUtility)
            .getNewUserIdentitySettingViewModel(with(any(ServerType.class)));
        will(returnValue(identitySettingsVm));
      }
    });
  }


  private static void mockSaveIdentity(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        UserIdentitySettingsViewModel userVm = UserMockData.getIdentitySettings();
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(userVm)), with(equal(serverName)));
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(userVm)), with(equal("LDAPException")));
      }
    });
  }


  private static void mockFindOverride(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        UserOverrideMapViewModel userOverrideVm = UserMockData.getUserOverrideMap();
        allowing(userOverrideModelMapper).findOverrideMapByServerName(with(equal(serverName)));
        will(returnValue(userOverrideVm));
      }
    });
  }


  public static void mockBasicInformationValidator(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    mockSetIdentity(context, basicInformationValidator);
    mockValidate(context, basicInformationValidator);
  }


  private static void mockSetIdentity(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator).setIdentityName(with(any(String.class)));
        allowing(basicInformationValidator).setIdentityName(with(aNull(String.class)));
        allowing(basicInformationValidator).setIdentityName(with(equal(LdapConfigConstant.USER)));
      }
    });
  }


  private static void mockValidate(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator)
            .validate(with(any(BasicInfoItemViewModelBase.class)), with(any(Errors.class)));
      }
    });
  }

}
