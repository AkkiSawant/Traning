
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.SaveServerMockData;

import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.ServiceCredentials;

public class MockSaveServer {

  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws Exception {
    mockAdd(context, serverDetailsService);
    mockModify(context, serverDetailsService);
    mockFetchSaveConfiguration(context, serverDetailsService);
  }


  private static void mockAdd(Mockery context, final ServerDetailsService serverDetailsService)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).add(with(any(ServerConfiguration.class)));
      }
    });
  }


  private static void mockModify(Mockery context, final ServerDetailsService serverDetailsService)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).modify(with(any(ServerConfiguration.class)));
      }
    });
  }


  private static void mockFetchSaveConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ServerConfiguration mockServerConfiguration = SaveServerMockData.getServerConfiguration();
        allowing(serverDetailsService).fetchSaveConfiguration(with(equal("saveServer")));
        will(returnValue(mockServerConfiguration));
      }
    });
  }


  public static void mockObjectFactory(Mockery context, final ObjectFactory objectFactory)
      throws Exception {
    mockCreateServerConfiguration(context, objectFactory);
    mockCreateServerDetails(context, objectFactory);
    mockCreateServiceCredentials(context, objectFactory);
  }


  private static void mockCreateServerConfiguration(Mockery context,
      final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        ServerConfiguration serverConfiguration = SaveServerMockData.getServerConfiguration();
        allowing(objectFactory).createServerConfiguration();
        will(returnValue(serverConfiguration));
      }
    });
  }


  private static void mockCreateServerDetails(Mockery context, final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        ServerDetails serverDetails = SaveServerMockData.getServerDetails();
        allowing(objectFactory).createServerDetails();
        will(returnValue(serverDetails));
      }
    });
  }


  private static void mockCreateServiceCredentials(Mockery context,
      final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        ServiceCredentials serviceCredentials = SaveServerMockData.getServerCredentials();
        allowing(objectFactory).createServiceCredentials();
        will(returnValue(serviceCredentials));
      }
    });
  }
}
