
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.validator.TestLdapServerValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.TestServerConfigurationViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.TestServerHelper;
import com.unboundid.ldap.sdk.LDAPException;

import icc.base.exception.IOCException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockTestServer {

  private static String serverName = "test";


  public static void mockMapperHelper(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws Exception {

  }


  public static void mockTestValidator(Mockery context,
      final TestLdapServerValidator testServerValidator) {
    mockValidate(context, testServerValidator);
  }


  private static void mockValidate(Mockery context,
      final TestLdapServerValidator testServerValidator) {
    context.checking(new Expectations() {

      {
        allowing(testServerValidator)
            .validate(with(any(TestServerConfigurationViewModel.class)), with(any(Errors.class)));
      }
    });
  }


  public static void mockTestServerHelper(Mockery context, final TestServerHelper testServerHelper)
      throws IOCException,
        LDAPException,
        LdapConfigDataException {
    mockAuthenticate(context, testServerHelper);
    mockGetAuthorizationResult(context, testServerHelper);
  }


  private static void mockAuthenticate(Mockery context, final TestServerHelper testServerHelper) throws LdapConfigDataException
       {
    context.checking(new Expectations() {

      {
        allowing(testServerHelper)
            .authenticateUser(with(equal("Administrator")), with(any(String.class)));
        will(returnValue(true));
        allowing(testServerHelper).authenticateUser(with(equal("Test")), with(any(String.class)));
        will(returnValue(false));
        allowing(testServerHelper)
            .authenticateUser(with(equal("LDAPException")), with(any(String.class)));
        will(throwException(new LdapConfigDataException("LDAPConfigException")));
      }
    });
  }


  private static void mockGetAuthorizationResult(Mockery context,
      final TestServerHelper testServerHelper)
      throws LDAPException,
        IOCException,
        LdapConfigDataException {
    context.checking(new Expectations() {

      {
        allowing(testServerHelper).getAuthorizationResult(
            with(any(TestServerConfigurationViewModel.class)), with(any(String.class)),
            with(equal("Administrator")));
        will(returnValue("authorized"));
        allowing(testServerHelper).getAuthorizationResult(
            with(any(TestServerConfigurationViewModel.class)), with(any(String.class)),
            with(equal("Test")));
        will(returnValue("not authorized"));
        allowing(testServerHelper).getAuthorizationResult(
            with(any(TestServerConfigurationViewModel.class)), with(any(String.class)),
            with(equal("LADPException")));
        will(throwException(new IOCException("IOCException")));
      }
    });
  }


  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    mockSaveSelectedConfiguration(context, serverDetailsService);
  }


  private static void mockSaveSelectedConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).saveSelectedConfiguration(with(equal(serverName)));
        allowing(serverDetailsService).saveSelectedConfiguration(with(equal("LDAPException")));
        will(throwException(new LdapConfigDataException("LDAPConfigException")));
      }
    });
  }
}
