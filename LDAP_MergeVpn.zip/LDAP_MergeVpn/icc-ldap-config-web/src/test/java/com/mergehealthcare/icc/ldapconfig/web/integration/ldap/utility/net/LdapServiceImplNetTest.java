
package com.mergehealthcare.icc.ldapconfig.web.integration.ldap.utility.net;

import static org.junit.Assert.assertNotNull;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.net.LdapServiceImplNet;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebAppConfiguration
@ContextConfiguration (classes = LdapConfigApplication.class)
@RunWith (SpringJUnit4ClassRunner.class)
public class LdapServiceImplNetTest {

    private static final Logger logger = LogService.getLogger(LdapServiceImplNet.class);

    @Autowired
    private LdapServiceImplNet ldapService;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;


    @Before
    public void setup() throws Exception {
        createConfigFile();
        ldapService.setCurrentServer("merge_AD");
    }


    private void createConfigFile() {
        File inputFile = new File(LdapServiceImplNetTest.class.getResource("/merge_AD.xml").getFile());
        try {
            FileUtils.copyFile(inputFile, new File(iCCEnvironmentConfig.getTempFileName("merge_AD")));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    @Test
    public void testAuthenticateUser() {
        assertNotNull(this.ldapService);
        try {
            ldapService.authenticateUser("user2", "Cedara99");
        } catch (Exception ex) {
            logger.error("Authentication Error ", ex);
        }

    }


    // @Test
    public void testGetServerIdentity() {
        assertNotNull(this.ldapService);
        try {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put(LdapConfigConstant.CURRENT_SERVER, "AP-SDomainHG");
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20389");
            connectionDetails.put("connectionType", ServerType.Apache.toString());
            String serverIden = ldapService.getServerIdentity(connectionDetails);
            logger.info("Server Identity = " + serverIden);
        } catch (Exception ex) {
            logger.error("testGetServerIdentity Error ", ex);
        }

    }


    // @Test
    public void testGetServerCertificate() {
        assertNotNull(this.ldapService);
        try {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put(LdapConfigConstant.CURRENT_SERVER, "AP-SDomainHG");
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20389");
            connectionDetails.put("storeLocation", "");
            connectionDetails.put("storePassword", "");
            String serverCerificate = ldapService.getServerCertificate(connectionDetails);
            logger.info("Return values for testGetServerCertificate = " + serverCerificate);
        } catch (Exception ex) {
            logger.error("testGetServerIdentity Error ", ex);
        }

    }


    @Test
    public void testGetUserDomainRoles() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserDomainRoles("user2", "SDomainHG");
            logger.info("Return values for testGetUserDomainRoles = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserDomainRoles Error ", ex);
        }
    }


    @Test
    public void testGetUserGroupRoles() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserGroupRoles("user3", "Group1", "SDomainHG");
            logger.info("Return values for testGetUserDomainRoles = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserDomainRoles Error ", ex);
        }
    }


    @Test
    public void testGetUserManagedGroups() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserManagedGroups("user2", "SDomainHG");
            logger.info("Return values for testGetUserManagedGroups = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserManagedGroups Error ", ex);
        }
    }


    @Test
    public void testGetUserSystemAdminLevel() {
        assertNotNull(this.ldapService);
        try {
            String data = ldapService.getUserSystemAdminLevel("user2");
            logger.info("Return values for testGetUserSystemAdminLevel = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserSystemAdminLevel Error ", ex);
        }
    }

}
