
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.rest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.controller.rest.LdapConfigurationRestController;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = { LdapConfigApplication.class, MockRestServiceProviderTest.class })
@WebAppConfiguration
public class LdapConfigurationRestControllerTest {

    @Autowired
    MockHttpSession session;

    @Autowired
    MockHttpServletRequest request;

    @Autowired
    MockHttpServletResponse response;

    @Autowired
    WebApplicationContext webApplicationContext;

    @Autowired
    LdapConfigurationRestController ldapConfigurationRestController;


    @Test
    public void getTreeByRootDNSuccess() throws Exception {
        ModelOptionsViewModel modelOptions = MockRestDataProvider.getModelOptions("Success");
        BindingResult bindingResult = MockRestDataProvider.getBindingResult(modelOptions, "modelOptions");
        ModelMap modelMap = MockRestDataProvider.getModelMap();
        LdapTree ldapTree = (LdapTree) ldapConfigurationRestController.getTreeByRootDistinguishedName(modelOptions, modelMap, bindingResult,
                        response, session);
        LdapTree mockLdapTree = MockRestDataProvider.getLdapTree();
        assertEquals(ldapTree.toString(), mockLdapTree.toString());
        assertEquals(ldapTree.toString(), session.getAttribute("ldapTree").toString());
        assertTrue(modelMap.isEmpty());
        assertTrue(!bindingResult.hasFieldErrors());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    // @Test
    public void getTreeByRootDNError() throws Exception {
        ModelOptionsViewModel modelOptions = MockRestDataProvider.getModelOptions("Success");
        BindingResult bindingResult = MockRestDataProvider.getBindingResultErrors(modelOptions, "modelOptions");
        ModelMap modelMap = MockRestDataProvider.getModelMap();
        @SuppressWarnings ("unchecked")
        List<FieldError> errors = (List<FieldError>) ldapConfigurationRestController.getTreeByRootDistinguishedName(modelOptions, modelMap,
                        bindingResult, response, session);
        assertTrue(errors.size() == 1);
        assertTrue(!modelMap.isEmpty());
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    @Test
    public void getTreeByRootDNLDAPException() throws Exception {
        ModelOptionsViewModel modelOptions = MockRestDataProvider.getModelOptions("LDAPException");
        BindingResult bindingResult = MockRestDataProvider.getBindingResult(modelOptions, "modelOptions");
        ModelMap modelMap = MockRestDataProvider.getModelMap();
        ldapConfigurationRestController.getTreeByRootDistinguishedName(modelOptions, modelMap, bindingResult, response, session);
        assertTrue(modelMap.isEmpty());
        assertNull(session.getAttribute("ldapTree"));
        assertEquals(response.getStatus(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }


    @Test
    public void getTreeByRootDNIOCException() throws Exception {
        ModelOptionsViewModel modelOptions = MockRestDataProvider.getModelOptions("IOCException");
        BindingResult bindingResult = MockRestDataProvider.getBindingResult(modelOptions, "modelOptions");
        ModelMap modelMap = MockRestDataProvider.getModelMap();
        ldapConfigurationRestController.getTreeByRootDistinguishedName(modelOptions, modelMap, bindingResult, response, session);
        assertTrue(modelMap.isEmpty());
        assertNull(session.getAttribute("ldapTree"));
        assertEquals(response.getStatus(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }


    @Test
    public void getLdapTreeSuccess() throws Exception {
        LdapTree ldapTree = MockRestDataProvider.getLdapTree();
        session.setAttribute("ldapTree", ldapTree);
        request.setSession(session);
        ldapConfigurationRestController.getLdapTree(session, response);
        assertEquals(ldapTree, session.getAttribute("ldapTree"));
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void getLdapTreeFailure() throws Exception {
        session.setAttribute("ldapTree", null);
        request.setSession(session);
        ldapConfigurationRestController.getLdapTree(session, response);
        assertNull(session.getAttribute("ldapTree"));
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    @Test
    public void ldapSearchMapSuccess() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryInp(false);
        List<LdapTree> ldapTreeList = ldapConfigurationRestController.ldapSearch(obj, response);
        List<LdapTree> mockLdapTreeList = MockRestDataProvider.getLdapTreeNodes();
        assertEquals(ldapTreeList.toString(), mockLdapTreeList.toString());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    // @Test
    public void ldapSearchNoMapSuccess() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryInp(true);
        List<LdapTree> ldapTreeList = ldapConfigurationRestController.ldapSearch(obj, response);
        List<LdapTree> mockLdapTreeList = MockRestDataProvider.getLdapTreeNodes();
        assertEquals(ldapTreeList.toString(), mockLdapTreeList.toString());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    // @Test
    public void ldapSearchNoMapRoleSuccess() throws LdapConfigDataException {
        ServletContext servletContext = webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.SERVER_TYPE, ServerType.OpenLdap.toString());
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryInp(true, LdapConfigConstant.ROLE);
        List<LdapTree> ldapTreeList = ldapConfigurationRestController.ldapSearch(obj, response);
        List<LdapTree> mockLdapTreeList = MockRestDataProvider.getLdapTreeNodes();
        assertEquals(ldapTreeList.toString(), mockLdapTreeList.toString());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void ldapSearchNoMapUserSuccess() throws LdapConfigDataException {
        ServletContext servletContext = webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.SERVER_TYPE, ServerType.AD.toString());
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryInp(false, LdapConfigConstant.USER);
        List<LdapTree> ldapTreeList = ldapConfigurationRestController.ldapSearch(obj, response);
        List<LdapTree> mockLdapTreeList = MockRestDataProvider.getLdapTreeNodes();
        assertEquals(ldapTreeList.toString(), mockLdapTreeList.toString());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void ldapSearchNoMapGroupSuccess() throws LdapConfigDataException {
        ServletContext servletContext = webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.SERVER_TYPE, ServerType.Apache.toString());
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryInp(true, LdapConfigConstant.GROUP);
        List<LdapTree> ldapTreeList = ldapConfigurationRestController.ldapSearch(obj, response);
        List<LdapTree> mockLdapTreeList = MockRestDataProvider.getLdapTreeNodes();
        assertEquals(ldapTreeList.toString(), mockLdapTreeList.toString());
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void ldapSearchNoMapIOCException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryIOCExceptionInp(false);
        ldapConfigurationRestController.ldapSearch(obj, response);
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    @Test
    public void ldapSearchNoMapLDAPException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getSearchQueryLDAPExceptionInp(false);
        ldapConfigurationRestController.ldapSearch(obj, response);
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    @Test
    public void enableServerSuccess() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getEnableServerObject("Success", true);
        String enabled = ldapConfigurationRestController.enableServer(obj, response);
        assertEquals(enabled, "success");
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void enableServerIOException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getEnableServerObject("IOException", false);
        String enabled = ldapConfigurationRestController.enableServer(obj, response);
        assertEquals(enabled, "failure");
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    @Test
    public void enableServerLdapConfigDataException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getEnableServerObject("LdapConfigDataException", false);
        String enabled = ldapConfigurationRestController.enableServer(obj, response);
        assertEquals(enabled, "failure");
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    private void setSessionData() {
        ServletContext servletContext = webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.CURRENT_SERVER, "internal");
        servletContext.setAttribute(LdapConfigConstant.MODEL_GROUPING, "SDomainUngrouped");
    }


    @Test
    public void getAttributeMapDataSuccess() throws Exception {
        setSessionData();
        Map<String, Object> obj = MockRestDataProvider.getAttributeMapInp();

        ldapConfigurationRestController.getAttributeMapData(obj, response);
        // Map<String, Map<String, String>> mockAttributeMapData =
        // MockRestDataProvider.getAttributeMapData();
        // assertEquals(attributeMapData, mockAttributeMapData);
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    @Test
    public void getAttributeMapDataDNError() throws Exception {
        setSessionData();
        Map<String, Object> obj = MockRestDataProvider.getAttributeMapDNError();
        Map<String, Map<String, String>> attributeMapData = ldapConfigurationRestController.getAttributeMapData(obj, response);
        assertTrue(!attributeMapData.isEmpty());
        assertEquals(response.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
    }


    // @Test
    public void getAttributeMapDataLdapConfigDataException() throws Exception {
        setSessionData();
        Map<String, Object> obj = MockRestDataProvider.getAttributeMapErrorInp();
        Map<String, Map<String, String>> attributeMapData = ldapConfigurationRestController.getAttributeMapData(obj, response);
        assertNotNull(attributeMapData);
        assertEquals(response.getStatus(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }


    // @Test
    public void getServerIdentitySuccess() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getServerIdentityInp();
        String serverIdentity = ldapConfigurationRestController.getServerIdentity(obj, response);
        String mockServerIdentity = MockRestDataProvider.getServerIdentity();
        assertEquals(serverIdentity, mockServerIdentity);
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    // @Test
    public void getServerIdentityIOCException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getServerIdentityErrorInp();
        String serverIdentity = ldapConfigurationRestController.getServerIdentity(obj, response);
        assertEquals(serverIdentity, "IOCException");
        assertEquals(response.getStatus(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }


    // @Test
    public void getServerCertsSuccess() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getServerCertsInp();
        String serverCerts = ldapConfigurationRestController.getServerCerts(obj, response);
        String mockServerCerts = MockRestDataProvider.getServerCerts();
        assertEquals(serverCerts, mockServerCerts);
        assertEquals(response.getStatus(), HttpServletResponse.SC_OK);
    }


    // @Test
    public void getServerCertsIOCException() throws Exception {
        Map<String, Object> obj = MockRestDataProvider.getServerCertsErrorInp();
        String serverCerts = ldapConfigurationRestController.getServerCerts(obj, response);
        assertEquals(serverCerts, "IOCException");
        assertEquals(response.getStatus(), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    }
}
