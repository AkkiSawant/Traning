
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.DomainMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockDomain {

  private static String serverName = "domain";


  public static void mockIdentitySearchUtility(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws Exception {
    mockFindIdentity(context, identitySearchUtility);
  }


  public static void mockIdentityObjectCreationUtility(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) throws Exception {
    mockGetNewDomain(context, identityObjectCreationUtility);
  }


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper) throws Exception {
    mockSaveIdentity(context, identityModelOptionModelMapper);
  }


  private static void mockFindIdentity(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        DomainIdentitySettingsViewModel identitySettingsVm = DomainMockData.getIdentitySettings();
        RoleIdentitySettingsViewModel roleIdentitySettingsVm =
            DomainMockData.getRoleIdentitySettings();

        IdentitySettingsMethodVM identitySettingsMethodDomainVM =
            DomainMockData.getIdentitySettingsMethodDomainVM();

        IdentitySettingsMethodVM identitySettingsMethodRoleVM =
            DomainMockData.getIdentitySettingsMethodRoleVM();

        IdentitySettingsMethodVM identitySettingsMethodExceptionVM =
            DomainMockData.getIdentitySettingsMethodDomainExceptionVM();

        IdentitySettingsMethodVM identitySettingsMethodRoleExceptionVM =
            DomainMockData.getIdentitySettingsMethodRoleExceptionVM();

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodDomainVM)));
        will(returnValue(identitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodExceptionVM)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodRoleVM)));
        will(returnValue(roleIdentitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodRoleExceptionVM)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));

      }
    });
  }


  private static void mockGetNewDomain(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) {
    context.checking(new Expectations() {

      {
        DomainIdentitySettingsViewModel identitySettingsVm = DomainMockData.getNewDomain();
        allowing(identityObjectCreationUtility)
            .getNewDomainIdentitySettingViewModel(with(any(ServerType.class)));
        will(returnValue(identitySettingsVm));
      }
    });
  }


  private static void mockSaveIdentity(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        DomainIdentitySettingsViewModel domainVm = DomainMockData.getIdentitySettings();
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(domainVm)), with(equal(serverName)));
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(domainVm)), with(equal("LDAPException")));
      }
    });
  }


  public static void mockBasicInformationValidator(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    mockSetIdentity(context, basicInformationValidator);
    mockValidate(context, basicInformationValidator);
  }


  private static void mockSetIdentity(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator).setIdentityName(with(any(String.class)));
      }
    });
  }


  private static void mockValidate(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator)
            .validate(with(any(BasicInfoItemViewModelBase.class)), with(any(Errors.class)));
      }
    });
  }
}
