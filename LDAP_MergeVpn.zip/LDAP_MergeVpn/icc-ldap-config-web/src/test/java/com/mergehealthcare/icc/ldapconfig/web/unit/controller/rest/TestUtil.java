
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.rest;

import java.io.IOException;
import java.nio.charset.Charset;

import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestUtil {

  public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
      MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(),
      Charset.forName("utf8"));


  public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
    ObjectMapper mapper = new ObjectMapper();
    mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    return mapper.writeValueAsBytes(object);
  }


  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType,
      Object obj) throws IOException {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(url);
    request.contentType(mediaType);
    request.content(TestUtil.convertObjectToJsonBytes(obj));
    return request;
  }


  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType,
      String obj) throws IOException {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(url);
    request.contentType(mediaType);
    request.content(obj);
    return request;
  }


  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType,
      String parameterName, String obj) throws IOException {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(url);
    request.contentType(mediaType);
    request.param(parameterName, obj);
    return request;
  }


  // TODO: verify modelAttribute mapping
  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType,
      String parameterName, Object obj) throws IOException {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post(url);
    request.contentType(mediaType);
    request.requestAttr(parameterName, obj);
    return request;
  }


  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType,
      MockHttpSession session) throws IOException {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(url);
    request.contentType(mediaType);
    request.session(session);
    return request;
  }


  public static MockHttpServletRequestBuilder buildRequest(String url, MediaType mediaType) {
    MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get(url);
    request.contentType(mediaType);
    return request;
  }
}
