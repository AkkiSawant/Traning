
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;

import icc.ldap.server.configuration.Attribute;
import icc.ldap.server.configuration.Attributes;
import icc.ldap.server.configuration.OperationCommand;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnection;
import icc.ldap.server.configuration.SslConnection;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

public class ConnectionsMockData {

    private static ConnectionDetailsModel connectionDetails = new ConnectionDetailsModel();

    private static ModelOptionsViewModel modelOptions = new ModelOptionsViewModel();

    private static ServerConfiguration serverConfiguration = new ServerConfiguration();


    public static ConnectionDetailsModel getConnectionDetails() {
        connectionDetails.setDomainHost("icc-ldap.products.network.internal");
        connectionDetails.setDefaultPort(389);
        connectionDetails.setFullyQualifiedDomainName(true);
        connectionDetails.setConnectionType("basic");
        return connectionDetails;
    }


    public static ConnectionDetailsModel getConnectionDetailsInp() {
        return getConnectionDetails();
    }


    public static ModelOptionsViewModel getModelOptions() {
        modelOptions.setDomainModel("Single Domain");
        modelOptions.setModelGrouping("ungrouped");
        modelOptions.setRootDistinguishedName("OU=SDomainUngrouped,DC=icc,DC=internal");
        modelOptions.setOrganizationalUnitDomain("SDomainUngrouped");
        modelOptions.setFetchNewTree(false);

        return modelOptions;
    }


    public static BindingResult getBindingResult(ConnectionDetailsModel connectionDetails, String objectName) {
        BindingResult bindingResult = new DirectFieldBindingResult(connectionDetails, objectName);
        return bindingResult;
    }


    public static BindingResult getBindingResultErrors(ConnectionDetailsModel connectionDetails, String objectName) {
        BindingResult bindingResult = new DirectFieldBindingResult(connectionDetails, objectName);
        ObjectError error = getError();
        bindingResult.addError(error);
        return bindingResult;
    }


    private static ObjectError getError() {
        ObjectError error = new ObjectError("error", "invalid connection details");
        return error;
    }


    public static ModelMap getModelMap() {
        ModelMap modelMap = new ModelMap();
        return modelMap;
    }


    // TODO: add mock data
    public static ServerConfiguration getServerConfiguration() {
        ServerConnection serverConnection = getServerConnection();
        serverConfiguration.setServerConnection(serverConnection);
        return serverConfiguration;
    }


    private static ServerConnection getServerConnection() {
        ServerConnection serverConnection = new ServerConnection();
        serverConnection.setDomainHost("icc-ldap.products.network.internal");
        serverConnection.setDefaultPort(389);
        serverConnection.setFullyQualifiedDomainName("true");
        serverConnection.setType("basic");
        return serverConnection;
    }


    // TODO: add mock data
    public static SslConnection getSslConnection() {
        SslConnection sslConnection = new SslConnection();
        return sslConnection;
    }


    // TODO: add mock data
    public static OperationCommand getOperationCommand() {
        OperationCommand operationCommand = new OperationCommand();
        return operationCommand;
    }


    public static Attributes getAttributes() {
        Attributes attributes = new Attributes();
        return attributes;
    }


    public static Attribute getAttribute() {
        Attribute attribute = new Attribute();
        return attribute;
    }
}
