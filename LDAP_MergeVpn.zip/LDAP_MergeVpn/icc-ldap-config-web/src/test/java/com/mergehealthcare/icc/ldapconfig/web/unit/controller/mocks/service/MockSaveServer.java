
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.SaveServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.ServerDetailsValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.wizard.PropertyReader;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockSaveServer {

  private static String serverName = "saveServer";


  public static void mockMapperHelper(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws Exception {
    mockFindServer(context, modelMapperHelper);
    mockSetPlatform(context, modelMapperHelper);
    mockModifyServer(context, modelMapperHelper);
    mockSaveServer(context, modelMapperHelper);

  }


  public static void mockConnectionModelMapper(Mockery context,
      final ConnectionModelMapper connectionModelMapper) {
    mockFindConnectionModel(context, connectionModelMapper);
    mockGetJavaData(context, connectionModelMapper);
    mockGetNetData(context, connectionModelMapper);
  }


  private static void mockFindServer(Mockery context, final ModelMapperHelper modelMapperHelper) {
    context.checking(new Expectations() {

      {
        ServerDetailsModel serverDetails = SaveServerMockData.getServerDetailsModel();
        allowing(modelMapperHelper).findServerModelByServerName(with(equal(serverName)));
        will(returnValue(serverDetails));
      }
    });
  }


  private static void mockSetPlatform(Mockery context, final ModelMapperHelper modelMapperHelper) {
    context.checking(new Expectations() {

      {
        allowing(modelMapperHelper).setPlatform(with(any(Platform.class)));
      }
    });
  }


  private static void mockModifyServer(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        ServerDetailsModel serverDetails = SaveServerMockData.getServerDetailsModel();
        allowing(modelMapperHelper).modifyServerInfo(with(equal(serverDetails)));
      }
    });
  }


  private static void mockSaveServer(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws Exception {
    context.checking(new Expectations() {

      {
        ServerDetailsModel serverDetails = SaveServerMockData.getServerDetailsModel();
        allowing(modelMapperHelper).saveServerConfiguration(with(equal(serverDetails)));
        serverDetails = SaveServerMockData.getServerDetailsExceptionInp();
        allowing(modelMapperHelper).saveServerConfiguration(with(equal(serverDetails)));
        will(throwException(new Exception("Exception")));
      }
    });
  }


  private static void mockFindConnectionModel(Mockery context,
      final ConnectionModelMapper connectionModelMapper) {
    context.checking(new Expectations() {

      {
        ConnectionDetailsModel connectionDetailsModel = SaveServerMockData.getConnectionDetails();
        allowing(connectionModelMapper).findConnectionModelByServerName(with(equal(serverName)));
        will(returnValue(connectionDetailsModel));
      }
    });
  }


  private static void mockGetJavaData(Mockery context,
      final ConnectionModelMapper connectionModelMapper) {
    context.checking(new Expectations() {

      {
        AdvancedConnectionOptionsViewModel advancedConnectionVm =
            SaveServerMockData.getAdvancedConnectionsJava();
        allowing(connectionModelMapper).getDefaultJavaData();
        will(returnValue(advancedConnectionVm));
      }
    });
  }


  private static void mockGetNetData(Mockery context,
      final ConnectionModelMapper connectionModelMapper) {
    context.checking(new Expectations() {

      {
        AdvancedConnectionOptionsViewModel advancedConnectionVm =
            SaveServerMockData.getAdvancedConnectionsNet();
        allowing(connectionModelMapper).getDefaultJavaData();
        will(returnValue(advancedConnectionVm));
      }
    });
  }


  public static void mockPropertyReader(Mockery context, final PropertyReader propertyReader) {
    mockServerMessage(context, propertyReader);
    mockAddServerSuccess(context, propertyReader);
  }


  private static void mockServerMessage(Mockery context, final PropertyReader propertyReader) {
    context.checking(new Expectations() {

      {
        allowing(propertyReader).getUpdateServerMessage();
        will(returnValue("message"));
      }
    });
  }


  private static void mockAddServerSuccess(Mockery context, final PropertyReader propertyReader) {
    context.checking(new Expectations() {

      {
        allowing(propertyReader).getAddServerSuccess();
        will(returnValue("add server success"));
      }
    });
  }


  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    mockSaveSelectedConfiguration(context, serverDetailsService);
  }


  private static void mockSaveSelectedConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).saveSelectedConfiguration(with(equal(serverName)));
      }
    });
  }


  public static void mockServerDetailsValidator(Mockery context,
      final ServerDetailsValidator serverDetailsValidator) {
    mockValidate(context, serverDetailsValidator);
  }


  private static void mockValidate(Mockery context,
      final ServerDetailsValidator serverDetailsValidator) {
    context.checking(new Expectations() {

      {
        ServerDetailsModel serverDetails = SaveServerMockData.getServerDetailsInp();
        allowing(serverDetailsValidator)
            .validate(with(equal(serverDetails)), with(any(Errors.class)));
        serverDetails = SaveServerMockData.getServerDetailsExceptionInp();
        allowing(serverDetailsValidator)
            .validate(with(equal(serverDetails)), with(any(Errors.class)));
      }
    });
  }
}
