
package com.mergehealthcare.icc.ldapconfig.web.unit.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository;

import icc.ldap.server.configuration.ServerConfiguration;

@Configuration
public class MockServiceTest {

  private static Mockery context = new JUnit4Mockery();

  private static ServerConfigurationRepository serverConfigurationRepository;


  public MockServiceTest() {
    context.setImposteriser(ClassImposteriser.INSTANCE);
  }


  public static Mockery getContext() {
    return context;
  }


  @Bean
  public ServerConfigurationRepository serverConfigurationRepository() throws Exception {
    serverConfigurationRepository = context.mock(ServerConfigurationRepository.class);
    mockAddServerConfiguration();
    mockGetAllServerConfiguration();
    mockDeleteServerConfiguration();
    mockUpdateServerConfiguration();
    mockListServerNames();
    mockGetServerConfiguration();
    mockSaveServerConfiguration();
    return serverConfigurationRepository;
  }


  private static void mockAddServerConfiguration() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        ServerConfiguration serverConfiguration = MockDataProvider.getAddServerConfigurationInp();
        allowing(serverConfigurationRepository)
            .addServerConfiguration(with(equal(serverConfiguration)));
        allowing(serverConfigurationRepository)
            .addServerConfiguration(with(aNull(ServerConfiguration.class)));
      }
    });
  }


  private static void mockGetAllServerConfiguration() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        List<ServerConfiguration> serverConfigurations =
            MockDataProvider.getAllServerConfigurations();
        allowing(serverConfigurationRepository).getAllServerConfiguration();
        will(returnValue(serverConfigurations));
      }
    });
  }


  private static void mockDeleteServerConfiguration() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverConfigurationRepository).deleteServerConfiguration(with(any(String.class)));
      }
    });
  }


  private static void mockUpdateServerConfiguration() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        ServerConfiguration serverConfiguration =
            MockDataProvider.getUpdateServerConfigurationInp();
        allowing(serverConfigurationRepository)
            .updateServerConfiguration(with(equal(serverConfiguration)));
        allowing(serverConfigurationRepository)
            .updateServerConfiguration(with(aNull(ServerConfiguration.class)));
      }
    });
  }


  private static void mockListServerNames() {
    context.checking(new Expectations() {

      {
        Set<String> serverNames = MockDataProvider.getServerNames();
        allowing(serverConfigurationRepository).listServerNames();
        will(returnValue(serverNames));
      }
    });
  }


  private static void mockGetServerConfiguration() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ServerConfiguration serverConfiguration = MockDataProvider.getServerConfigurationInp();
        allowing(serverConfigurationRepository).getServerConfiguration(with(any(String.class)));
        will(returnValue(serverConfiguration));
      }
    });
  }


  private static void mockSaveServerConfiguration() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        String serverName = "TestServer";
        allowing(serverConfigurationRepository).saveServerConfiguration(with(equal(serverName)));
      }
    });
  }
}
