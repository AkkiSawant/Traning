
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.UserOverrideMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.UserOverrideMapValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockUserOverride {

  private static String serverName = "userOverride";


  public static void mockUserOverrideModelMapper(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws Exception {
    mockFindOverride(context, userOverrideModelMapper);

    mockSaveUserOverride(context, userOverrideModelMapper);
  }


  private static void mockFindOverride(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        UserOverrideMapViewModel userOverrideVm = UserOverrideMockData.getUserOverrideMap();
        allowing(userOverrideModelMapper).findOverrideMapByServerName(with(equal(serverName)));
        will(returnValue(userOverrideVm));
      }
    });
  }


  private static void mockSaveUserOverride(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        UserOverrideMapViewModel userOverrideVm = UserOverrideMockData.getUserOverrideMap();
        UserOverrideMapViewModel userOverrideExceptionVm =
            UserOverrideMockData.getUserOverrideExceptionInp();
        allowing(userOverrideModelMapper)
            .saveUserOverrideMapConfiguration(with(equal(userOverrideVm)), with(equal(serverName)));
        allowing(userOverrideModelMapper).saveUserOverrideMapConfiguration(
            with(equal(userOverrideExceptionVm)), with(equal(serverName)));
        will(throwException(new LdapConfigDataException("LDAPConfigException")));
      }
    });
  }


  public static void mockUserOverrideValidator(Mockery context,
      final UserOverrideMapValidator userOverrideValidator) {
    mockValidate(context, userOverrideValidator);
  }


  private static void mockValidate(Mockery context,
      final UserOverrideMapValidator userOverrideValidator) {
    context.checking(new Expectations() {

      {
        allowing(userOverrideValidator)
            .validate(with(any(UserOverrideMapViewModel.class)), with(any(Errors.class)));
      }
    });
  }
}
