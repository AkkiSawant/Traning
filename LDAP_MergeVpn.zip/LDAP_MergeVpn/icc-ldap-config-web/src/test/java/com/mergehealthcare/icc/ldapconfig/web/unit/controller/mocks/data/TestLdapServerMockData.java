package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.ModelMap;

import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;

import icc.ldap.server.configuration.LdapConfiguration;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.ServiceCredentials;

public class TestLdapServerMockData {

    public static List<ServerDetailsModel> getConfiguredServerList() {
        List<ServerDetailsModel> serverList = new ArrayList<ServerDetailsModel>();
        return serverList;
    }


    // TODO: add mock data
    public static List<ServerConfiguration> getServerConfigurations() {
        List<ServerConfiguration> serverConfigurations = new ArrayList<ServerConfiguration>();
        ServerConfiguration serverConfiguration = getServerConfiguration();
        serverConfigurations.add(serverConfiguration);
        return serverConfigurations;
    }


    public static ServerConfiguration getServerConfiguration() {
        ServerConfiguration serverConfiguration = new ServerConfiguration();
        ServerDetails serverDetails = getServerDetails();
        serverConfiguration.setServerDetails(serverDetails);
        return serverConfiguration;
    }


    private static ServerDetails getServerDetails() {
        ServerDetails serverDetails = new ServerDetails();
        serverDetails.setNetworkDomain("icc");
        serverDetails.setType("AD");
        serverDetails.setEnable(String.valueOf(true));
        serverDetails.setServiceCredentials(getServiceCredentials());
        return serverDetails;
    }


    private static ServiceCredentials getServiceCredentials() {
        ServiceCredentials serviceCredentials = new ServiceCredentials();
        serviceCredentials.setUserName("Administrator");
        return serviceCredentials;
    }


    public static List<LdapTree> getLdapSearchResult() {
        List<LdapTree> searchResult = new ArrayList<LdapTree>();
        searchResult.add(new LdapTree());
        return searchResult;
    }


    // TODO: add mock data
    public static LdapConfiguration getLdapConfiguration() {
        LdapConfiguration ldapConfiguration = new LdapConfiguration();
        return ldapConfiguration;
    }


    public static ModelMap getModelMap() {
        ModelMap modelMap = new ModelMap();
        return modelMap;
    }
}
