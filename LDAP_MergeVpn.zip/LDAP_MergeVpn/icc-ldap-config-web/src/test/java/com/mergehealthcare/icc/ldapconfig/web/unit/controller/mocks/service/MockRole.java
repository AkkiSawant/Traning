
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.RoleMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockRole {

  private static String serverName = "role";


  public static void mockIdentitySearchUtility(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws Exception {
    mockFindIdentity(context, identitySearchUtility);

  }


  public static void mockIdentityObjectCreationUtility(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) throws Exception {

    mockGetNewRole(context, identityObjectCreationUtility);

  }


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    mockSaveIdentity(context, identityModelOptionModelMapper);

  }


  private static void mockFindIdentity(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        RoleIdentitySettingsViewModel roleIdentitySettingsVm = RoleMockData.getIdentitySettings();
        UserIdentitySettingsViewModel userIdentitySettingsVm =
            RoleMockData.getUserIdentitySettings();

        IdentitySettingsMethodVM identitySettingsMethodVM =
            RoleMockData.getIdentitySettingsMethodUserVM();

        IdentitySettingsMethodVM identitySettingsMethodRoleVM =
            RoleMockData.getIdentitySettingsMethodRoleVM();

        IdentitySettingsMethodVM identitySettingsMethodUserExceptionVM =
            RoleMockData.getIdentitySettingsMethodUserExceptionVM();

        IdentitySettingsMethodVM identitySettingsMethodRoleExceptionVM =
            RoleMockData.getIdentitySettingsMethodRoleExceptionVM();

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodRoleVM)));
        will(returnValue(roleIdentitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodRoleExceptionVM)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodVM)));
        will(returnValue(userIdentitySettingsVm));

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodUserExceptionVM)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));

      }
    });
  }


  private static void mockGetNewRole(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) {
    context.checking(new Expectations() {

      {
        RoleIdentitySettingsViewModel identitySettingsVm = RoleMockData.getNewRole();
        allowing(identityObjectCreationUtility)
            .getNewRoleIdentitySettingViewModel(with(any(ServerType.class)));
        will(returnValue(identitySettingsVm));
      }
    });
  }


  private static void mockSaveIdentity(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        RoleIdentitySettingsViewModel roleVm = RoleMockData.getIdentitySettingsInp();
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(roleVm)), with(equal(serverName)));
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(roleVm)), with(equal("LDAPException")));
      }
    });
  }


  public static void mockBasicInformationValidator(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    mockSetIdentity(context, basicInformationValidator);
    mockValidate(context, basicInformationValidator);
  }


  private static void mockSetIdentity(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator).setIdentityName(with(any(String.class)));
      }
    });
  }


  private static void mockValidate(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator)
            .validate(with(any(BasicInfoItemViewModelBase.class)), with(any(Errors.class)));
      }
    });
  }

}
