
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.UserOverrideMockData;

import icc.ldap.server.configuration.ServerConfiguration;

public class MockUserOverride {

  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws Exception {
    mockFetchSaveConfiguration(context, serverDetailsService);
    mockModify(context, serverDetailsService);
  }


  private static void mockFetchSaveConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ServerConfiguration mockServerConfiguration = UserOverrideMockData.getServerConfiguration();
        allowing(serverDetailsService).fetchSaveConfiguration(with(equal("userOverride")));
        will(returnValue(mockServerConfiguration));
      }
    });
  }


  private static void mockModify(Mockery context, final ServerDetailsService serverDetailsService)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        ServerConfiguration mockServerConfiguration = UserOverrideMockData.getServerConfiguration();
        allowing(serverDetailsService).modify(with(equal(mockServerConfiguration)));
      }
    });
  }
}
