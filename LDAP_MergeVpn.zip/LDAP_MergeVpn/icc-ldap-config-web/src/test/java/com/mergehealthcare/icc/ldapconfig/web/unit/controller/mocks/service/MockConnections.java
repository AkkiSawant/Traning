
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ConnectionsMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.ServerConnectionValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

public class MockConnections {

  private static String serverName = "connections";


  public static void mockConnectionModelMapper(Mockery context,
      final ConnectionModelMapper connectionModelMapper) throws Exception {
    mockFindConnection(context, connectionModelMapper);
    mockSaveConnection(context, connectionModelMapper);
  }


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper) throws Exception {
    mockFindModelOptions(context, identityModelOptionModelMapper);
  }


  private static void mockFindConnection(Mockery context,
      final ConnectionModelMapper connectionModelMapper) {
    context.checking(new Expectations() {

      {
        ConnectionDetailsModel connectionDetails = ConnectionsMockData.getConnectionDetails();
        allowing(connectionModelMapper).findConnectionModelByServerName(with(equal(serverName)));
        will(returnValue(connectionDetails));
      }
    });
  }


  private static void mockSaveConnection(Mockery context,
      final ConnectionModelMapper connectionModelMapper) throws Exception {
    context.checking(new Expectations() {

      {
        ConnectionDetailsModel connectionDetails = ConnectionsMockData.getConnectionDetails();
        allowing(connectionModelMapper)
            .saveConnectionDetails(with(equal(connectionDetails)), with(equal(serverName)));
      }
    });
  }


  private static void mockFindModelOptions(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ModelOptionsViewModel modelOptions = ConnectionsMockData.getModelOptions();
        allowing(identityModelOptionModelMapper)
            .findModelOptionByServerName(with(equal(serverName)));
        will(returnValue(modelOptions));
      }
    });
  }


  public static void mockServerConnectionValidator(Mockery context,
      final ServerConnectionValidator serverConnectionValidator) {
    mockValidate(context, serverConnectionValidator);
  }


  private static void mockValidate(Mockery context,
      final ServerConnectionValidator serverConnectionValidator) {
    context.checking(new Expectations() {

      {
        ConnectionDetailsModel connectionDetails = ConnectionsMockData.getConnectionDetailsInp();
        allowing(serverConnectionValidator)
            .validate(with(equal(connectionDetails)), with(any(Errors.class)));
      }
    });
  }
}
