
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper;

import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockConnections;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockIdentity;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockModelOptions;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockRest;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockSaveServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockTestLdapServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service.MockUserOverride;

@Configuration
public class MockServiceProviderTest {

    private static Mockery context = new JUnit4Mockery();

    private ServerDetailsService serverDetailsService;

    private ObjectFactory objectFactory;


    public MockServiceProviderTest() {
        context.setImposteriser(ClassImposteriser.INSTANCE);
    }


    public static Mockery getContext() {
        return context;
    }


    // @Bean
    // public ModelMapperHelper modelMapperHelper() {
    // return new ModelMapperHelper();
    // }

    @Bean
    public ServerDetailsService serverDetailsService() throws Exception {
        serverDetailsService = context.mock(ServerDetailsService.class);
        MockTestLdapServer.mockServerDetailsService(context, serverDetailsService);
        MockSaveServer.mockServerDetailsService(context, serverDetailsService);
        MockConnections.mockServerDetailsService(context, serverDetailsService);
        MockModelOptions.mockServerDetailsService(context, serverDetailsService);
        MockIdentity.mockServerDetailsService(context, serverDetailsService);
        MockUserOverride.mockServerDetailsService(context, serverDetailsService);
        MockRest.mockServerDetailsService(context, serverDetailsService);
        return serverDetailsService;
    }


    @Bean
    public ObjectFactory objectFactory() throws Exception {
        objectFactory = context.mock(ObjectFactory.class);
        MockSaveServer.mockObjectFactory(context, objectFactory);
        MockConnections.mockObjectFactory(context, objectFactory);
        MockModelOptions.mockObjectFactory(context, objectFactory);
        MockIdentity.mockObjectFactory(context, objectFactory);
        return objectFactory;
    }
}
