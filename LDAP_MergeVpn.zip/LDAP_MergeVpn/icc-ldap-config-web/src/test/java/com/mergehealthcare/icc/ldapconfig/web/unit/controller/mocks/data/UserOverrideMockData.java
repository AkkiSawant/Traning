
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapDetailsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;

import icc.ldap.server.configuration.ServerConfiguration;

public class UserOverrideMockData {

  private static UserOverrideMapViewModel userOverrideVm = new UserOverrideMapViewModel();

  private static UserOverrideMapViewModel userOverrideExceptionVm = new UserOverrideMapViewModel();


  // TODO: add mock data
  public static UserOverrideMapViewModel getUserOverrideMap() {
    UserOverrideMapDetailsViewModel userOverrideMapDetailsVm = getUserOverrideDetails();
    List<UserOverrideMapDetailsViewModel> userOverrideDetails =
        new ArrayList<UserOverrideMapDetailsViewModel>();
    userOverrideDetails.add(userOverrideMapDetailsVm);
    userOverrideVm.setUserOverrideMapDetailsViewModel(userOverrideDetails);
    return userOverrideVm;
  }


  private static UserOverrideMapDetailsViewModel getUserOverrideDetails() {
    UserOverrideMapDetailsViewModel userOverrideMapDetailsVm =
        new UserOverrideMapDetailsViewModel();
    return userOverrideMapDetailsVm;
  }


  // TODO: add mock data
  public static UserOverrideMapViewModel getUserOverrideInp() {
    return getUserOverrideMap();
  }


  public static UserOverrideMapViewModel getUserOverrideExceptionInp() {
    return userOverrideExceptionVm;
  }


  // TODO: add mock data
  public static ServerConfiguration getServerConfiguration() {
    return null;
  }


  public static BindingResult getBindingResult(UserOverrideMapViewModel userOverrideVm,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(userOverrideVm, objectName);
    return bindingResult;
  }


  public static BindingResult getBindingResultErrors(UserOverrideMapViewModel userOverrideVm,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(userOverrideVm, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "invalid user override details");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }
}
