
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ConnectionsMockData;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.DomainMockData;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ModelOptionsMockData;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.SaveServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.TestLdapServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.UserOverrideMockData;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.LdapPropertiesDNVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebAppConfiguration
@ContextConfiguration (classes = { LdapConfigApplication.class, MockServiceProviderTest.class })
@RunWith (SpringJUnit4ClassRunner.class)

public class ModelMapperHelperTest {

    private final String serverName = "TestServer";

    @Autowired
    ModelMapperHelper modelMapperHelper;

    @Autowired
    ConnectionModelMapper connectionModelMapper;

    @Autowired
    IdentityModelOptionModelMapper identityModelOptionModelMapper;

    @Autowired
    IdentitySearchUtility identitySearchUtility;

    @Autowired
    UserOverrideModelMapper userOverrideModelMapper;

    @Autowired
    IdentityObjectCreationUtility identityObjectCreationUtility;

    @Autowired
    ReturnAttributeSettings returnAttributeSettings;


    @Test
    public void fetchConfiguredServersListSuccess() {
        List<ServerDetailsModel> mockServerList = TestLdapServerMockData.getConfiguredServerList();
        List<ServerDetailsModel> serverList = modelMapperHelper.fetchConfiguredServersList();
        assertEquals(serverList.toString(), mockServerList.toString());
    }


    @Test
    public void saveServerConfigurationSuccess() throws Exception {
        ServerDetailsModel mockServerDetails = SaveServerMockData.getServerDetailsInp();
        modelMapperHelper.saveServerConfiguration(mockServerDetails);
    }


    @Test
    public void findServerModelByServerNameSuccess() {
        String serverName = "saveServer";
        ServerDetailsModel mockServerDetails = SaveServerMockData.getServerDetailsModel();
        ServerDetailsModel serverDetails = modelMapperHelper.findServerModelByServerName(serverName);
        assertEquals(serverDetails.toString(), mockServerDetails.toString());
    }


    // @Test
    public void findConnectionModelByServerNameSuccess() {
        String serverName = "connections";
        ConnectionDetailsModel mockConnectionDetails = ConnectionsMockData.getConnectionDetails();
        ConnectionDetailsModel connectionDetails = connectionModelMapper.findConnectionModelByServerName(serverName);
        assertEquals(connectionDetails.toString(), mockConnectionDetails.toString());
    }


    // @Test
    public void findModelOptionByServerNameSuccess() throws LdapConfigDataException {
        String serverName = "modelOptions";
        ModelOptionsViewModel mockModelOptions = ModelOptionsMockData.getModelOptions();
        ModelOptionsViewModel modelOptions = identityModelOptionModelMapper.findModelOptionByServerName(serverName);
        assertEquals(modelOptions.toString(), mockModelOptions.toString());
    }


    // @Test
    public void saveConnectionDetailsSuccess() throws Exception {
        String serverName = "connections";
        ConnectionDetailsModel mockConnectionDetails = ConnectionsMockData.getConnectionDetails();
        connectionModelMapper.saveConnectionDetails(mockConnectionDetails, serverName);
    }


    @Test
    public void modifyServerInfoSuccess() throws LdapConfigDataException, IOException {
        ServerDetailsModel mockServerDetails = SaveServerMockData.getServerDetailsInp();
        modelMapperHelper.modifyServerInfo(mockServerDetails);
    }


    @Test
    public void deleteServerSuccess() throws LdapConfigDataException, IOException {
        modelMapperHelper.deleteServer(serverName);
    }


    @Test
    public void enableServerSuccess() throws LdapConfigDataException, IOException {
        modelMapperHelper.enableServer(serverName, true);
    }


    // @Test
    public void saveIdentityConfigurationSuccess() throws LdapConfigDataException, IOException {
        String serverName = "identity";
        IdentitySettingsViewModel mockIdentityVm = DomainMockData.getIdentitySettings();
        identityModelOptionModelMapper.saveIdentityConfiguration(mockIdentityVm, serverName);
    }


    // @Test
    public void findIdentitySettingByServerNameSuccess() throws LdapConfigDataException {
        String serverName = "identity";
        String modelGrouping = "ungrouped";
        IdentitySettingsViewModel mockIdentityVm = DomainMockData.getIdentitySettings();
        IdentitySettingsViewModel identityVm = identitySearchUtility.findIdentitySettingByServerName(
                        new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN, serverName, "AD", modelGrouping));
        assertEquals(identityVm.toString(), mockIdentityVm.toString());
    }


    // @Test
    public void saveModelOptionConfigurationSuccess() throws LdapConfigDataException, IOException {
        String serverName = "modelOptions";
        ModelOptionsViewModel mockModelOptions = ModelOptionsMockData.getModelOptions();
        identityModelOptionModelMapper.saveModelOptionConfiguration(mockModelOptions, serverName, true);
    }


    // @Test
    public void saveUserOverrideMapConfigurationSuccess() throws LdapConfigDataException, IOException {
        String serverName = "userOverride";
        UserOverrideMapViewModel mockUserOverrideMap = UserOverrideMockData.getUserOverrideMap();
        userOverrideModelMapper.saveUserOverrideMapConfiguration(mockUserOverrideMap, serverName);
    }


    // @Test
    public void findOverrideMapByServerName() throws LdapConfigDataException {
        String serverName = "userOverride";
        UserOverrideMapViewModel mockUserOverrideMap = UserOverrideMockData.getUserOverrideMap();
        UserOverrideMapViewModel userOverrideMap = userOverrideModelMapper.findOverrideMapByServerName(serverName);
        assertEquals(userOverrideMap, mockUserOverrideMap);
    }


    @Test
    public void getNewUserIdentitySettingViewModelSuccess() {
        UserIdentitySettingsViewModel userVm = identityObjectCreationUtility.getNewUserIdentitySettingViewModel(ServerType.AD);
        assertNotNull(userVm);
    }


    @Test
    public void getNewGroupIdentitySettingViewModelSuccess() {
        GroupIdentitySettingsViewModel groupVm = identityObjectCreationUtility.getNewGroupIdentitySettingViewModel(ServerType.Apache,
                        "ungrouped");
        assertNotNull(groupVm);
    }


    @Test
    public void getNewRoleIdentitySettingViewModelSuccess() {
        RoleIdentitySettingsViewModel roleVm = identityObjectCreationUtility.getNewRoleIdentitySettingViewModel(ServerType.OpenLdap);
        assertNotNull(roleVm);
    }


    @Test
    public void getNewDomainIdentitySettingViewModelSuccess() {
        DomainIdentitySettingsViewModel domainVm = identityObjectCreationUtility.getNewDomainIdentitySettingViewModel(ServerType.OpenLdap);
        assertNotNull(domainVm);
    }


    @Test
    public void getDefaultNetDataSuccess() {
        AdvancedConnectionOptionsViewModel advancedConnectionVm = connectionModelMapper.getDefaultNetData();
        assertNotNull(advancedConnectionVm);
    }


    @Test
    public void getDefaultJavaDataSuccess() {
        AdvancedConnectionOptionsViewModel advancedConnectionVm = connectionModelMapper.getDefaultJavaData();
        assertNotNull(advancedConnectionVm);
    }


    // @Test
    public void getAllLdapPropertiesByDNSuccess() throws LdapConfigDataException {
        String serverName = "TestServer";
        String dn = "OU=SDomainUngrouped,DC=icc,DC=internal";
        String modelGrouping = "ungrouped";
        String filter = "(objectclass=group)";
        String classType = null;
        Map<String, Map<String, String>> ldapProperties = modelMapperHelper
                        .getAllLdapPropertiesByDN(new LdapPropertiesDNVM(serverName, dn, classType, modelGrouping, filter));
        assertNotNull(ldapProperties);
    }
}
