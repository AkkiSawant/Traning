
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ConnectionsMockData;

import icc.ldap.server.configuration.Attribute;
import icc.ldap.server.configuration.Attributes;
import icc.ldap.server.configuration.OperationCommand;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.SslConnection;

public class MockConnections {

  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws Exception {
    mockFetchSaveConfiguration(context, serverDetailsService);
    mockModify(context, serverDetailsService);
  }


  private static void mockFetchSaveConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ServerConfiguration mockServerConfiguration = ConnectionsMockData.getServerConfiguration();
        allowing(serverDetailsService).fetchSaveConfiguration(with(equal("connections")));
        will(returnValue(mockServerConfiguration));
      }
    });
  }


  private static void mockModify(Mockery context, final ServerDetailsService serverDetailsService)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        ServerConfiguration mockServerConfiguration = ConnectionsMockData.getServerConfiguration();
        allowing(serverDetailsService).modify(with(equal(mockServerConfiguration)));
      }
    });
  }


  public static void mockObjectFactory(Mockery context, final ObjectFactory objectFactory) {
    mockCreateSslConnection(context, objectFactory);
    mockCreateOperationCommand(context, objectFactory);
    mockCreateAttributes(context, objectFactory);
    mockCreateAttribute(context, objectFactory);
  }


  private static void mockCreateSslConnection(Mockery context, final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        SslConnection sslConnection = ConnectionsMockData.getSslConnection();
        allowing(objectFactory).createSslConnection();
        will(returnValue(sslConnection));
      }
    });
  }


  private static void mockCreateOperationCommand(Mockery context,
      final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        OperationCommand operationCommand = ConnectionsMockData.getOperationCommand();
        allowing(objectFactory).createOperationCommand();
        will(returnValue(operationCommand));
      }
    });
  }


  private static void mockCreateAttributes(Mockery context, final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        Attributes attributes = ConnectionsMockData.getAttributes();
        allowing(objectFactory).createAttributes();
        will(returnValue(attributes));
      }
    });
  }


  private static void mockCreateAttribute(Mockery context, final ObjectFactory objectFactory) {
    context.checking(new Expectations() {

      {
        Attribute attribute = ConnectionsMockData.getAttribute();
        allowing(objectFactory).createAttribute();
        will(returnValue(attribute));
      }
    });
  }
}
