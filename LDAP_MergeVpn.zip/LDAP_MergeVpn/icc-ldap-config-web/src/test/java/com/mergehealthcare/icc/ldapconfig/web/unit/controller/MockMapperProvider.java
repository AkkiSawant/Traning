
package com.mergehealthcare.icc.ldapconfig.web.unit.controller;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockConnections;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockDomain;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockGroup;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockModelOptions;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockModifyServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockRole;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockSaveServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockTestLdapServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockTestServer;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockUser;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service.MockUserOverride;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.ModelOptionsValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.ServerConnectionValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.ServerDetailsValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.TestLdapServerValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.UserOverrideMapValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.TestServerHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;
import com.mergehealthcare.icc.ldapconfig.wizard.PropertyReader;
import com.unboundid.ldap.sdk.LDAPException;

import icc.base.exception.IOCException;

import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class MockMapperProvider {

  private Mockery context = new JUnit4Mockery();

  private ModelMapperHelper modelMapperHelper;

  private IdentitySearchUtility identitySearchUtility;

  private IdentityModelOptionModelMapper identityModelOptionModelMapper;

  private IdentityObjectCreationUtility identityObjectCreationUtility;

  private ConnectionModelMapper connectionModelMapper;

  private UserOverrideModelMapper userOverrideModelMapper;

  private ServerDetailsService serverDetailsService;

  private ServerDetailsValidator serverDetailsValidator;

  private PropertyReader propertyReader;

  private ServerConnectionValidator serverConnectionValidator;

  private ModelOptionsValidator modelOptionsValidator;

  private BasicInformationValidator basicInformationValidator;

  private UserOverrideMapValidator userOverrideValidator;

  private TestLdapServerValidator testServerValidator;

  private TestServerHelper testServerHelper;


  public MockMapperProvider() {
    context.setImposteriser(ClassImposteriser.INSTANCE);
  }


  @Bean
  public ConnectionModelMapper connectionModelMapper() throws Exception {
    connectionModelMapper = context.mock(ConnectionModelMapper.class);
    MockSaveServer.mockConnectionModelMapper(context, connectionModelMapper);
    MockConnections.mockConnectionModelMapper(context, connectionModelMapper);
    return connectionModelMapper;
  }


  @Bean
  public IdentityModelOptionModelMapper identityModelOptionModelMapper() throws Exception {
    identityModelOptionModelMapper = context.mock(IdentityModelOptionModelMapper.class);
    MockConnections.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    MockModelOptions.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    MockDomain.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    MockRole.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    MockUser.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    MockGroup.mockIdentityModelOptionModelMapper(context, identityModelOptionModelMapper);
    return identityModelOptionModelMapper;
  }


  @Bean
  public UserOverrideModelMapper userOverrideModelMapper() throws Exception {
    userOverrideModelMapper = context.mock(UserOverrideModelMapper.class);
    MockUserOverride.mockUserOverrideModelMapper(context, userOverrideModelMapper);
    MockUser.mockUserOverrideModelMapper(context, userOverrideModelMapper);
    MockGroup.mockUserOverrideModelMapper(context, userOverrideModelMapper);
    return userOverrideModelMapper;
  }


  @Bean
  public IdentitySearchUtility identitySearchUtility() throws Exception {
    identitySearchUtility = context.mock(IdentitySearchUtility.class);
    MockModelOptions.mockIdentitySearchUtility(context, identitySearchUtility);
    MockDomain.mockIdentitySearchUtility(context, identitySearchUtility);
    MockRole.mockIdentitySearchUtility(context, identitySearchUtility);
    MockUser.mockIdentitySearchUtility(context, identitySearchUtility);
    MockGroup.mockIdentitySearchUtility(context, identitySearchUtility);
    return identitySearchUtility;
  }


  @Bean
  public IdentityObjectCreationUtility identityObjectCreationUtility() throws Exception {
    identityObjectCreationUtility = context.mock(IdentityObjectCreationUtility.class);
    MockDomain.mockIdentityObjectCreationUtility(context, identityObjectCreationUtility);
    MockRole.mockIdentityObjectCreationUtility(context, identityObjectCreationUtility);
    MockUser.mockIdentityObjectCreationUtility(context, identityObjectCreationUtility);
    MockGroup.mockIdentityObjectCreationUtility(context, identityObjectCreationUtility);
    return identityObjectCreationUtility;
  }


  @Bean
  public ModelMapperHelper modelMapperHelper() throws Exception {
    modelMapperHelper = context.mock(ModelMapperHelper.class);
    MockSaveServer.mockMapperHelper(context, modelMapperHelper);
    MockModifyServer.mockMapperHelper(context, modelMapperHelper);
    MockTestServer.mockMapperHelper(context, modelMapperHelper);
    MockTestLdapServer.mockMapperHelper(context, modelMapperHelper);
    return modelMapperHelper;
  }


  @Bean
  public PropertyReader propertyReader() {
    propertyReader = context.mock(PropertyReader.class);
    MockSaveServer.mockPropertyReader(context, propertyReader);
    return propertyReader;
  }


  @Bean
  public ServerDetailsService serverDetailsService() throws LdapConfigDataException, IOException {
    serverDetailsService = context.mock(ServerDetailsService.class);
    MockSaveServer.mockServerDetailsService(context, serverDetailsService);
    MockTestLdapServer.mockServerDetailsService(context, serverDetailsService);
    MockTestServer.mockServerDetailsService(context, serverDetailsService);
    return serverDetailsService;
  }


  @Bean
  public ServerDetailsValidator serverDetailsValidator() {
    serverDetailsValidator = context.mock(ServerDetailsValidator.class);
    MockSaveServer.mockServerDetailsValidator(context, serverDetailsValidator);
    return serverDetailsValidator;
  }


  @Bean
  public ServerConnectionValidator serverConnectionValidator() {
    serverConnectionValidator = context.mock(ServerConnectionValidator.class);
    MockConnections.mockServerConnectionValidator(context, serverConnectionValidator);
    return serverConnectionValidator;
  }


  @Bean
  public ModelOptionsValidator modelOptionsValidator() {
    modelOptionsValidator = context.mock(ModelOptionsValidator.class);
    MockModelOptions.mockModelOptionsValidator(context, modelOptionsValidator);
    return modelOptionsValidator;
  }


  @Bean
  public BasicInformationValidator basicInformationValidator() {
    basicInformationValidator = context.mock(BasicInformationValidator.class);
    MockDomain.mockBasicInformationValidator(context, basicInformationValidator);
    MockRole.mockBasicInformationValidator(context, basicInformationValidator);
    MockUser.mockBasicInformationValidator(context, basicInformationValidator);
    MockGroup.mockBasicInformationValidator(context, basicInformationValidator);
    return basicInformationValidator;
  }


  @Bean
  public UserOverrideMapValidator userOverrideMapValidator() {
    userOverrideValidator = context.mock(UserOverrideMapValidator.class);
    MockUserOverride.mockUserOverrideValidator(context, userOverrideValidator);
    return userOverrideValidator;
  }


  @Bean
  public TestLdapServerValidator testLdapServerValidator() {
    testServerValidator = context.mock(TestLdapServerValidator.class);
    MockTestServer.mockTestValidator(context, testServerValidator);
    return testServerValidator;
  }


  @Bean
  public TestServerHelper testServerHelper()
      throws IOCException,
        LDAPException,
        LdapConfigDataException {
    testServerHelper = context.mock(TestServerHelper.class);
    MockTestServer.mockTestServerHelper(context, testServerHelper);
    MockTestLdapServer.mockTestServerHelper(context, testServerHelper);
    return testServerHelper;
  }
}
