
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.GroupMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockGroup {

  private static String serverName = "group";


  public static void mockIdentitySearchUtility(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws Exception {
    mockFindIdentity(context, identitySearchUtility);

  }


  public static void mockIdentityObjectCreationUtility(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) throws Exception {
    mockGetNewGroup(context, identityObjectCreationUtility);
  }


  public static void mockUserOverrideModelMapper(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws Exception {
    mockFindOverride(context, userOverrideModelMapper);
  }


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    mockSaveIdentity(context, identityModelOptionModelMapper);

  }


  private static void mockFindIdentity(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        GroupIdentitySettingsViewModel groupIdentitySettingsVm =
            GroupMockData.getIdentitySettings();

        IdentitySettingsMethodVM identitySettingsMethodGroupVM =
            GroupMockData.getIdentitySettingsMethodGroupVM();

        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodGroupVM)));

        will(returnValue(groupIdentitySettingsVm));
      }
    });
  }


  private static void mockGetNewGroup(Mockery context,
      final IdentityObjectCreationUtility identityObjectCreationUtility) {
    context.checking(new Expectations() {

      {
        GroupIdentitySettingsViewModel identitySettingsVm = GroupMockData.getNewGroup();
        allowing(identityObjectCreationUtility).getNewGroupIdentitySettingViewModel(
            with(any(ServerType.class)), with(any(String.class)));
        will(returnValue(identitySettingsVm));
      }
    });
  }


  private static void mockSaveIdentity(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        GroupIdentitySettingsViewModel groupVm = GroupMockData.getIdentitySettings();
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(groupVm)), with(equal(serverName)));
        allowing(identityModelOptionModelMapper)
            .saveIdentityConfiguration(with(equal(groupVm)), with(equal("LDAPException")));
      }
    });
  }


  private static void mockFindOverride(Mockery context,
      final UserOverrideModelMapper userOverrideModelMapper) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        UserOverrideMapViewModel userOverrideVm = GroupMockData.getUserOverrideMap();
        allowing(userOverrideModelMapper).findOverrideMapByServerName(with(equal(serverName)));
        will(returnValue(userOverrideVm));
        allowing(userOverrideModelMapper).findOverrideMapByServerName(with(equal("LDAPException")));
        will(throwException(new LdapConfigDataException("LDAPConfigException")));
      }
    });
  }


  public static void mockBasicInformationValidator(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    mockSetIdentity(context, basicInformationValidator);
    mockValidate(context, basicInformationValidator);
  }


  private static void mockSetIdentity(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator).setIdentityName(with(any(String.class)));
      }
    });
  }


  private static void mockValidate(Mockery context,
      final BasicInformationValidator basicInformationValidator) {
    context.checking(new Expectations() {

      {
        allowing(basicInformationValidator)
            .validate(with(any(BasicInfoItemViewModelBase.class)), with(any(Errors.class)));
      }
    });
  }

}
