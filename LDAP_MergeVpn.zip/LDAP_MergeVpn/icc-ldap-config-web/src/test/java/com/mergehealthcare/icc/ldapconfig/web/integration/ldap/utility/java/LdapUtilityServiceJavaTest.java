
package com.mergehealthcare.icc.ldapconfig.web.integration.ldap.utility.java;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.ILdapService;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.java.LdapServiceImplJava;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.base.exception.IOCException;
import icc.ldap.testtool.utils.ContextInitializer;
import org.springframework.test.context.ContextConfiguration;

@WebAppConfiguration
@ContextConfiguration (classes = LdapConfigApplication.class)
@RunWith (SpringJUnit4ClassRunner.class)
public class LdapUtilityServiceJavaTest {

    private static final Logger logger = LogService.getLogger(LdapServiceImplJava.class);

    @Autowired
    @Qualifier (value = "ldapServiceImplJava")
    private ILdapService ldapService;

    private static String configFile = "ldapConfig_AP-SDomainHG.xml";


    @BeforeClass
    public static void setup() throws Exception {
        try {
            ContextInitializer.loadLdapEngine(configFile);
        } catch (IOCException ex) {
            logger.error("setup Error ", ex);
        }
    }


    @Test
    public void testAuthenticateUser() {
        assertNotNull(this.ldapService);
        try {
            ldapService.checkLdapConnection("AP-SDomainHG");
        } catch (Exception ex) {
            logger.error("Authentication Error ", ex);
        }

    }


    @Test
    public void testGetServerIdentity() {
        assertNotNull(this.ldapService);
        try {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put(LdapConfigConstant.CURRENT_SERVER, "AP-SDomainHG");
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20389");
            connectionDetails.put("connectionType", ServerType.Apache.toString());
            String serverIden = ldapService.getServerIdentity(connectionDetails);
            logger.info("Server Identity = " + serverIden);
        } catch (Exception ex) {
            logger.error("testGetServerIdentity Error ", ex);
        }

    }


    @Test
    public void testGetServerCertificate() {
        assertNotNull(this.ldapService);
        try {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put(LdapConfigConstant.CURRENT_SERVER, "AP-SDomainHG");
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20389");
            connectionDetails.put("storeLocation", "");
            connectionDetails.put("storePassword", "");
            String serverCerificate = ldapService.getServerCertificate(connectionDetails);
            logger.info("Return values for testGetServerCertificate = " + serverCerificate);
        } catch (Exception ex) {
            logger.error("testGetServerIdentity Error ", ex);
        }

    }


    @Test
    public void testGetUserDomainRoles() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserDomainRoles("apuser2", "APSDomainHG");
            logger.info("Return values for testGetUserDomainRoles = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserDomainRoles Error ", ex);
        }
    }


    @Test
    public void testGetUserGroupRoles() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserGroupRoles("apuser3", "Group1", "APSDomainHG");
            logger.info("Return values for testGetUserGroupRoles = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserGroupRoles Error ", ex);
        }
    }


    @Test
    public void testGetUserManagedGroups() {
        assertNotNull(this.ldapService);
        try {
            List<String> data = ldapService.getUserManagedGroups("apuser2", "APSDomainHG");
            logger.info("Return values for testGetUserManagedGroups = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserManagedGroups Error ", ex);
        }
    }


    @Test
    public void testGetUserSystemAdminLevel() {
        assertNotNull(this.ldapService);
        try {
            String data = ldapService.getUserSystemAdminLevel("apuser7");
            logger.info("Return values for testGetUserSystemAdminLevel = " + data);
        } catch (Exception ex) {
            logger.error("testGetUserSystemAdminLevel Error ", ex);
        }
    }

}
