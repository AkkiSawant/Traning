
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import java.io.IOException;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.TestLdapServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.TestServerHelper;
import com.unboundid.ldap.sdk.LDAPException;

import icc.base.exception.IOCException;

public class MockTestLdapServer {

  private static String serverName = "TestServer";


  public static void mockMapperHelper(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws Exception {
    mockFetchConfiguredServerList(context, modelMapperHelper);
  }


  private static void mockFetchConfiguredServerList(Mockery context,
      final ModelMapperHelper modelMapperHelper) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        List<ServerDetailsModel> configuredServerList =
            TestLdapServerMockData.getConfiguredServerList();
        allowing(modelMapperHelper).fetchConfiguredServersList();
        will(returnValue(configuredServerList));
      }
    });
  }


  public static void mockTestServerHelper(Mockery context, final TestServerHelper testServerHelper)
      throws IOCException,
        LDAPException,
        LdapConfigDataException {
    mockCheckLdapConnection(context, testServerHelper);
  }


  private static void mockCheckLdapConnection(Mockery context,
      final TestServerHelper testServerHelper) throws LdapConfigDataException  {
    context.checking(new Expectations() {

      {
        allowing(testServerHelper).checkLdapConnection(with(equal(serverName)));
        will(returnValue(true));
        allowing(testServerHelper).checkLdapConnection(with(equal("LADPException")));
        will(throwException(new LDAPException(null, "LDAPException")));
        allowing(testServerHelper).checkLdapConnection(with(aNull(String.class)));
        will(returnValue(false));
      }
    });
  }


  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    mockSaveSelectedConfiguration(context, serverDetailsService);
  }


  private static void mockSaveSelectedConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).saveSelectedConfiguration(with(equal(serverName)));
        allowing(serverDetailsService).saveSelectedConfiguration(with(equal("LADPException")));
        will(throwException(new LdapConfigDataException("LADPConfigException")));
      }
    });
  }
}
