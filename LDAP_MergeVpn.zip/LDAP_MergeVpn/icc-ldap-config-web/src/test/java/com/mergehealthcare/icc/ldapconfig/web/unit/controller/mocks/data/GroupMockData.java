
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapDetailsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.List;

public class GroupMockData {

  private static GroupIdentitySettingsViewModel identitySettingsVm =
      new GroupIdentitySettingsViewModel();

  private static IdentitySettingsMethodVM identitySettingsMethodGroupVM =
      new IdentitySettingsMethodVM(
          LdapConfigConstant.GROUP, "group", "AD", "singleDomainUngrouped");


  public static GroupIdentitySettingsViewModel getIdentitySettings() {
    identitySettingsVm.setBasicInfoVm(getBasicInfo());
    identitySettingsVm.setAttributeMapVm(getAttributeMap());
    identitySettingsVm.setReturnedAttributesVm(getReturnedAttributes());
    identitySettingsVm.setValueMapVm(getValueMap());
    return identitySettingsVm;
  }


  // TODO: add mock data
  private static BasicInfoItemViewModelBase getBasicInfo() {
    BasicInfoItemViewModelBase basicInfoVm = new BasicInfoItemViewModelBase();
    basicInfoVm.setAttributeMapEnabled(true);
    return basicInfoVm;
  }


  // TODO: add mock data
  private static AttributeMapItemViewModel getAttributeMap() {
    AttributeMapItemViewModel attributeMapVm = new AttributeMapItemViewModel();
    return attributeMapVm;
  }


  // TODO: add mock data
  private static ReturnedAttributesItemViewModel getReturnedAttributes() {
    ReturnedAttributesItemViewModel returnedAttributesVm = new ReturnedAttributesItemViewModel();
    return returnedAttributesVm;
  }


  // TODO: add mock data
  private static ValueMapItemViewModel getValueMap() {
    ValueMapItemViewModel valueMapVm = new ValueMapItemViewModel();
    return valueMapVm;
  }


  public static GroupIdentitySettingsViewModel getIdentitySettingsInp() {
    return getIdentitySettings();
  }


  public static GroupIdentitySettingsViewModel getNewGroup() {
    return getIdentitySettings();
  }


  // TODO: add mock data
  public static UserOverrideMapViewModel getUserOverrideMap() {
    UserOverrideMapViewModel userOverrideVm = new UserOverrideMapViewModel();
    UserOverrideMapDetailsViewModel userOverrideMapDetailsVm = getUserOverrideDetails();
    List<UserOverrideMapDetailsViewModel> userOverrideDetails =
        new ArrayList<UserOverrideMapDetailsViewModel>();
    userOverrideDetails.add(userOverrideMapDetailsVm);
    userOverrideVm.setUserOverrideMapDetailsViewModel(userOverrideDetails);
    return userOverrideVm;
  }


  private static UserOverrideMapDetailsViewModel getUserOverrideDetails() {
    UserOverrideMapDetailsViewModel userOverrideMapDetailsVm =
        new UserOverrideMapDetailsViewModel();
    return userOverrideMapDetailsVm;
  }


  public static BindingResult getBindingResult(GroupIdentitySettingsViewModel identitySettingsVm,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(identitySettingsVm, objectName);
    return bindingResult;
  }


  public static BindingResult
      getBindingResultErrors(GroupIdentitySettingsViewModel identitySettingsVm, String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(identitySettingsVm, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "invalid group details");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }


  public static IdentitySettingsMethodVM getIdentitySettingsMethodGroupVM() {
    return identitySettingsMethodGroupVM;
  }
}
