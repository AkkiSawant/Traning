
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.rest;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.LdapServiceManager;
import com.mergehealthcare.icc.ldapconfig.web.validator.ModelOptionsValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.SearchScope;

import icc.base.exception.IOCException;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Configuration
public class MockRestServiceProviderTest {

  private Mockery context = new JUnit4Mockery();

  private LdapServiceManager ldapServiceManager;

  private ModelMapperHelper modelMapperHelper;

  private IdentitySearchUtility identitySearchUtility;

  private ModelOptionsValidator modelOptionsValidator;

  private ServerDetailsService serverDetailsService;


  public MockRestServiceProviderTest() {
    context.setImposteriser(ClassImposteriser.INSTANCE);
  }


  @Bean
  public LdapServiceManager ldapServiceManager() throws LdapConfigDataException {
    ldapServiceManager = context.mock(LdapServiceManager.class);
    mockSearch();
    mockGetLdapTree();
    mockGetServerCertificates();
    mockGetServerIdentity();
    return ldapServiceManager;
  }


  @SuppressWarnings ("unchecked")
  private void mockSearch() throws LdapConfigDataException   {
    context.checking(new Expectations() {

      {
        final List<String> attributeList = MockRestDataProvider.getLdapProperties();
        final List<LdapTree> ldapTreeNodes = MockRestDataProvider.getLdapTreeNodes();
        allowing(ldapServiceManager).search(
            with(any(String.class)), with(equal("(objectclass=group)")), with(any(String.class)),
            with(any(SearchScope.class)), with(any(attributeList.getClass())));
        will(returnValue(ldapTreeNodes));
        allowing(ldapServiceManager).search(
            with(any(String.class)), with(equal("filter")), with(any(String.class)),
            with(any(SearchScope.class)), with(any(attributeList.getClass())));
        will(throwException(new IOCException("IOCException")));
        allowing(ldapServiceManager).search(
            with(any(String.class)), with(equal("")), with(any(String.class)),
            with(any(SearchScope.class)), with(any(attributeList.getClass())));
        will(throwException(new LDAPException(null, "LDAPException")));
      }
    });
  }


  private void mockGetLdapTree() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        LdapTree ldapTree = MockRestDataProvider.getLdapTree();
        allowing(ldapServiceManager).getLdapTree(with(any(String.class)), with(equal("Success")));
        will(returnValue(ldapTree));
        allowing(ldapServiceManager)
            .getLdapTree(with(any(String.class)), with(equal("IOCException")));
        will(throwException(new IOCException("IOCException")));
        allowing(ldapServiceManager)
            .getLdapTree(with(any(String.class)), with(equal("LDAPException")));
        will(throwException(new LDAPException(null, "LDAPException")));
      }
    });
  }


  private void mockGetServerCertificates() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        Map<String, Object> connectionDetails = MockRestDataProvider.getServerCertsInp();
        Map<String, Object> connectionDetailsErrorInp =
            MockRestDataProvider.getServerCertsErrorInp();
        String serverCerts = MockRestDataProvider.getServerCerts();
        allowing(ldapServiceManager).getServerCertificates(with(equal(connectionDetails)));
        will(returnValue(serverCerts));
        allowing(ldapServiceManager).getServerCertificates(with(equal(connectionDetailsErrorInp)));
        will(throwException(new IOCException("IOCException")));
      }
    });
  }


  private void mockGetServerIdentity() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        Map<String, Object> connectionDetails = MockRestDataProvider.getServerIdentityInp();
        Map<String, Object> connectionDetailsErrorInp =
            MockRestDataProvider.getServerIdentityErrorInp();
        String serverIdentity = MockRestDataProvider.getServerIdentity();
        allowing(ldapServiceManager).getServerIdentity(with(equal(connectionDetails)));
        will(returnValue(serverIdentity));
        allowing(ldapServiceManager).getServerIdentity(with(equal(connectionDetailsErrorInp)));
        will(throwException(new IOCException("IOCException")));
      }
    });
  }


  @Bean
  public ModelMapperHelper modelMapperHelper()
      throws IOCException,
        LDAPException,
        LdapConfigDataException,
        IOException {
    modelMapperHelper = context.mock(ModelMapperHelper.class);
    mockFindIdentity();
    mockEnableServer();
    mockDeleteServer();
    mockGetAllLdapPropertiesByDN();
    return modelMapperHelper;
  }


  @Bean
  public IdentitySearchUtility identitySearchUtility() {
    identitySearchUtility = context.mock(IdentitySearchUtility.class);
    return identitySearchUtility;
  }


  private void mockFindIdentity() throws IOCException, LDAPException, LdapConfigDataException {
    context.checking(new Expectations() {

      {
        IdentitySettingsViewModel identitySettingsVm = MockRestDataProvider.getIdentitySettingsVm();
        IdentitySettingsViewModel identitySettingsNullVm =
            MockRestDataProvider.getIdentitySettingsNullVm();

        allowing(identitySearchUtility).findIdentitySettingByServerName(
            with(equal(MockRestDataProvider.identitySettingsMethodDomainVM)));
        will(returnValue(identitySettingsVm));

        allowing(identitySearchUtility).findIdentitySettingByServerName(
            with(equal(MockRestDataProvider.identitySettingsMethodRoleVM)));
        will(returnValue(identitySettingsNullVm));

        allowing(identitySearchUtility).findIdentitySettingByServerName(
            with(equal(MockRestDataProvider.identitySettingsMethodUserVM)));
        will(returnValue(identitySettingsNullVm));

        allowing(identitySearchUtility).findIdentitySettingByServerName(
            with(equal(MockRestDataProvider.identitySettingsMethodGroupVM)));
        will(returnValue(identitySettingsNullVm));
      }
    });
  }


  private void mockEnableServer() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(modelMapperHelper).enableServer(with(equal("Success")), with(any(Boolean.class)));
        allowing(modelMapperHelper)
            .enableServer(with(equal("LdapConfigDataException")), with(any(Boolean.class)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));
        allowing(modelMapperHelper)
            .enableServer(with(equal("IOException")), with(any(Boolean.class)));
        will(throwException(new IOException("IOException")));
      }
    });
  }


  private void mockDeleteServer() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(modelMapperHelper).deleteServer(with(equal("Success")));
        allowing(modelMapperHelper).deleteServer(with(equal("LdapConfigDataException")));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));
        allowing(modelMapperHelper).deleteServer(with(equal("IOException")));
        will(throwException(new IOException("IOException")));
      }
    });
  }


  private void mockGetAllLdapPropertiesByDN() throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        // Map<String, Object> obj = MockRestDataProvider.getAttributeMapInp();
        Map<String, Map<String, String>> attributeMapData = null;

        allowing(modelMapperHelper)
            .getAllLdapPropertiesByDN(with(equal(MockRestDataProvider.ldapPropertiesDNVM)));

        // obj = MockRestDataProvider.getAttributeMapErrorInp();

        allowing(modelMapperHelper).getAllLdapPropertiesByDN(
            with(equal(MockRestDataProvider.ldapPropertiesExceptionDNVM)));
        will(throwException(new LdapConfigDataException("LdapConfigDataException")));

        allowing(modelMapperHelper)
            .getAllLdapPropertiesByDN(with(equal(MockRestDataProvider.ldapPropertiesDnNullDNVM)));
        will(returnValue(attributeMapData));

      }
    });
  }


  @Bean
  public ModelOptionsValidator modelOptionsValidator() {
    modelOptionsValidator = context.mock(ModelOptionsValidator.class);
    mockValidateTree();
    return modelOptionsValidator;
  }


  private void mockValidateTree() {
    context.checking(new Expectations() {

      {
        allowing(modelOptionsValidator)
            .validateTree(with(any(Object.class)), with(any(Errors.class)));
      }
    });
  }


  @Bean
  public ServerDetailsService serverDetailsService() throws LdapConfigDataException, IOException {
    serverDetailsService = context.mock(ServerDetailsService.class);
    mockSaveSelectedConfiguration();
    return serverDetailsService;
  }


  private void mockSaveSelectedConfiguration() throws LdapConfigDataException, IOException {
    context.checking(new Expectations() {

      {
        allowing(serverDetailsService).saveSelectedConfiguration(with(any(String.class)));
      }
    });
  }
}
