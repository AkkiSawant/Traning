
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.rest;

import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.LdapPropertiesDNVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase.MapOption;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class MockRestDataProvider {

  public static IdentitySettingsMethodVM identitySettingsMethodDomainVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN, null, "AD", "");

  public static IdentitySettingsMethodVM identitySettingsMethodRoleVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.ROLE, null, "AD", "");

  public static IdentitySettingsMethodVM identitySettingsMethodUserVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.USER, null, "AD", "");

  public static IdentitySettingsMethodVM identitySettingsMethodGroupVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.GROUP, null, "Apache", "");

  public static LdapPropertiesDNVM ldapPropertiesDNVM = new LdapPropertiesDNVM(
      "internal", "OU=SDomainUngrouped,DC=icc,DC=internal", null, "SDomainUngrouped",
      "(objectclass=group)");

  public static LdapPropertiesDNVM ldapPropertiesExceptionDNVM = new LdapPropertiesDNVM(
      "internal", "OU=SDomainUngrouped,DC=icc,DC=internal", null, "SDomainUngrouped",
      "(objectclass=groupOfNames)");

  public static LdapPropertiesDNVM ldapPropertiesDnNullDNVM = new LdapPropertiesDNVM(
      "internal", null, null, "SDomainUngrouped", "(objectclass=groupOfNames)");


  public static List<String> getLdapProperties() {
    List<String> ldapProperties = new ArrayList<String>();
    ldapProperties.add("cn");
    ldapProperties.add("name");
    ldapProperties.add("member");
    return ldapProperties;
  }


  public static List<LdapTree> getLdapTreeNodes() {
    List<LdapTree> ldapTreeNodes = new ArrayList<LdapTree>();
    LdapTree ldapTree = new LdapTree();
    ldapTree.setTitle("title");
    ldapTreeNodes.add(ldapTree);
    return ldapTreeNodes;
  }


  public static Map<String, Object> getSearchQueryInp(boolean noMap) {
    Map<String, Object> obj = new HashMap<String, Object>();
    List<String> ldapProperties = getLdapProperties();
    obj.put("userTargetDn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("filter", "(objectclass=group)");
    obj.put("classType", null);
    obj.put("noMap", noMap);
    obj.put("ldapProperties", ldapProperties);
    return obj;
  }


  public static Map<String, Object> getSearchQueryInp(boolean noMap, String classType) {
    Map<String, Object> obj = new HashMap<String, Object>();
    List<String> ldapProperties = getLdapProperties();
    obj.put("userTargetDn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("filter", "(objectclass=group)");
    obj.put("classType", classType);
    obj.put("noMap", noMap);
    obj.put("ldapProperties", ldapProperties);
    return obj;
  }


  public static Map<String, Object> getSearchQueryIOCExceptionInp(boolean noMap) {
    Map<String, Object> obj = new HashMap<String, Object>();
    List<String> ldapProperties = getLdapProperties();
    obj.put("userTargetDn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("filter", "filter");
    obj.put("classType", "Domain");
    obj.put("noMap", noMap);
    obj.put("ldapProperties", ldapProperties);
    return obj;
  }


  public static Map<String, Object> getSearchQueryLDAPExceptionInp(boolean noMap) {
    Map<String, Object> obj = new HashMap<String, Object>();
    List<String> ldapProperties = getLdapProperties();
    obj.put("userTargetDn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("filter", "");
    obj.put("classType", null);
    obj.put("noMap", noMap);
    obj.put("ldapProperties", ldapProperties);
    return obj;
  }


  public static IdentitySettingsViewModel getIdentitySettingsVm() {
    IdentitySettingsViewModel identitySettingsVm = new IdentitySettingsViewModel();
    AttributeMapItemViewModel attributeMapVm = getAttributeMapVm();

    List<AttributeMapNode> attributes = getAttributes();
    attributeMapVm.setAttributes(attributes);
    identitySettingsVm.setAttributeMapVm(attributeMapVm);
    return identitySettingsVm;
  }


  public static IdentitySettingsViewModel getIdentitySettingsNullVm() {
    IdentitySettingsViewModel identitySettingsVm = new IdentitySettingsViewModel();
    AttributeMapItemViewModel attributeMapVm = getAttributeMapVm();
    attributeMapVm.setAttributes(null);
    identitySettingsVm.setAttributeMapVm(attributeMapVm);
    return identitySettingsVm;
  }


  private static List<AttributeMapNode> getAttributes() {
    List<AttributeMapNode> attributes = new ArrayList<AttributeMapNode>();
    AttributeMapNode attributeMapNode = new AttributeMapNode();
    attributeMapNode.setIdentityProperty("identity");
    attributeMapNode.setLdapProperty("ldap");
    attributeMapNode.setIgnore(false);
    attributes.add(attributeMapNode);
    return attributes;
  }


  private static AttributeMapItemViewModel getAttributeMapVm() {
    AttributeMapItemViewModel attributeMapVm = new AttributeMapItemViewModel();
    attributeMapVm.setMapOption(MapOption.DICTIONARY);
    return attributeMapVm;
  }


  public static Map<String, Object> getEnableServerObject(String serverName, boolean enable) {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("ServerName", serverName);
    obj.put("Enable", enable);
    return obj;
  }


  public static LdapTree getLdapTree() {
    LdapTree ldapTree = new LdapTree();
    ldapTree.setTitle("ldapTree");
    return ldapTree;
  }


  public static ModelOptionsViewModel getModelOptions(String rootDN) {
    ModelOptionsViewModel modelOptionsViewModel = new ModelOptionsViewModel();
    modelOptionsViewModel.setRootDistinguishedName(rootDN);
    return modelOptionsViewModel;
  }


  public static String getServerCerts() {
    return "server certificates";
  }


  public static Map<String, Object> getServerCertsInp() {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("cert", "certificate");
    obj.put(LdapConfigConstant.CURRENT_SERVER, "internal");
    return obj;
  }


  public static Map<String, Object> getServerCertsErrorInp() {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("cert", "invalidCertificate");
    obj.put(LdapConfigConstant.CURRENT_SERVER, "internal");
    return obj;
  }


  public static String getServerIdentity() {
    return "server identity";
  }


  public static Map<String, Object> getServerIdentityInp() {
    return getServerCertsInp();
  }


  public static Map<String, Object> getServerIdentityErrorInp() {
    return getServerCertsErrorInp();
  }


  public static Map<String, Object> getAttributeMapInp() {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("dn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("classType", null);
    obj.put("filter", "(objectclass=group)");
    return obj;
  }


  public static Map<String, Object> getAttributeMapDNError() {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("classType", null);
    obj.put("filter", "(objectclass=group)");
    return obj;
  }


  public static Map<String, Object> getAttributeMapErrorInp() {
    Map<String, Object> obj = new HashMap<String, Object>();
    obj.put("dn", "OU=SDomainUngrouped,DC=icc,DC=internal");
    obj.put("classType", null);
    obj.put("filter", "(objectclass=groupOfNames)");
    return obj;
  }


  public static Map<String, Map<String, String>> getAttributeMapData() {
    return null;
  }


  public static BindingResult getBindingResult(Object object, String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(object, objectName);
    return bindingResult;
  }


  public static BindingResult getBindingResultErrors(Object object, String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(object, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "validation error");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }
}
