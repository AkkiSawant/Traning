
package com.mergehealthcare.icc.ldapconfig.web.integration.viewmodel.mapper.test.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase.MapOption;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserDomainDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserGroupDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapDetailsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The Class ModelMapperHelperTest.
 */
@WebAppConfiguration
@ContextConfiguration (classes = LdapConfigApplication.class)
@RunWith (SpringJUnit4ClassRunner.class)
public class ModelMapperHelperTest {

    private static final Logger logger = LogService.getLogger(ModelMapperHelperTest.class);

    @Autowired
    private ModelMapperHelper modelMapperHelper;

    @Autowired
    private ConnectionModelMapper connectionModelMapper;

    @Autowired
    private IdentityModelOptionModelMapper domainRoleUserGroupMapper;

    @Autowired
    private IdentityObjectCreationUtility identityObjectCreationUtility;

    @Autowired
    private UserOverrideModelMapper userOverrideModelMapper;

    @Autowired
    private IdentitySearchUtility identitySearchUtility;

    private ServerDetailsModel serverInformationModel;

    private ConnectionDetailsModel connectionDetailsModel;

    private DomainIdentitySettingsViewModel domainIdentitySettingsViewModel;

    private UserIdentitySettingsViewModel userIdentirySettingViewModel;

    @Autowired
    ReturnAttributeSettings returnAttributeSettings;

    private static final boolean isDelete = true;


    /**
     * Sets the up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {

        this.serverInformationModel = new ServerDetailsModel();
        this.serverInformationModel.setNetworkDomain("NETWORK");
        this.serverInformationModel.setPassword("Cedara102");
        this.serverInformationModel.setServerName("internal");
        this.serverInformationModel.setServerType(ServerType.AD.toString());
        this.serverInformationModel.setUserName("uid=admin,ou=system");
        logger.debug("this.serverInformationModel = " + this.serverInformationModel);

        BasicInfoItemViewModelBase basicInfoItemViewModelBase = new BasicInfoItemViewModelBase();
        basicInfoItemViewModelBase.setTargetDn("OU=SDomain");

        Set<String> defaultReturnAttribute = new HashSet<String>();
        defaultReturnAttribute.add("OU");
        defaultReturnAttribute.add("Description");

        ReturnedAttributesItemViewModel returnedAttributesItemViewModel = new ReturnedAttributesItemViewModel();
        returnedAttributesItemViewModel.setDefaultAttributes(defaultReturnAttribute);

        AttributeMapNode attributeMapNode = new AttributeMapNode();
        attributeMapNode.setIdentityProperty("DomainId");
        attributeMapNode.setLdapProperty("OU");
        AttributeMapItemViewModel attributeMapItemViewModel = new AttributeMapItemViewModel();
        attributeMapItemViewModel.setMapOption(MapOption.DICTIONARY);
        List<AttributeMapNode> attributes = new ArrayList<>();
        attributes.add(attributeMapNode);
        attributeMapItemViewModel.setAttributes(attributes);

        ValueMapItemViewModel viewModel = new ValueMapItemViewModel();
        viewModel.setMapOption(MapOption.DICTIONARY);
        ValueMapNode valueMapNode = new ValueMapNode();
        valueMapNode.setLdapValue("ldapKey");
        valueMapNode.setApplicationValue("ldapApplication");

        viewModel.getValueMap().add(valueMapNode);
        domainIdentitySettingsViewModel = new DomainIdentitySettingsViewModel(basicInfoItemViewModelBase, returnedAttributesItemViewModel,
                        attributeMapItemViewModel, viewModel);

        ServerType serverType = ServerType.AD;
        userIdentirySettingViewModel = identityObjectCreationUtility.getNewUserIdentitySettingViewModel(serverType);

        testAddServer();
    }


    /**
     * Test add server.
     *
     * @throws Exception the exception
     */
    public void testAddServer() throws Exception {
        assertNotNull(this.modelMapperHelper);
        logger.info("testAddServer = " + this.serverInformationModel);
        this.modelMapperHelper.saveServerConfiguration(this.serverInformationModel);
    }


    /**
     * Test list server.
     *
     * @throws Exception the exception
     */
    @Test
    public void testListServer() throws Exception {
        assertNotNull(this.modelMapperHelper);
        logger.info("testListServer = " + this.serverInformationModel);
        this.modelMapperHelper.findServerModelByServerName(serverInformationModel.getServerName());
    }


    /**
     * Test modify server.
     *
     * @throws Exception the exception
     */
    @Test
    public void testModifyServer() throws Exception {
        assertNotNull(this.modelMapperHelper);
        logger.info("testAddServer = " + this.serverInformationModel);
        connectionDetailsModel = new ConnectionDetailsModel();
        connectionDetailsModel.setDomainHost("icc-ldap.products.network.internal");
        connectionDetailsModel.setDefaultPort(20389);
        connectionDetailsModel.setConnectionType("Basic");
        connectionDetailsModel.setAdvancedConnectionVm(connectionModelMapper.getDefaultJavaData());
        this.connectionModelMapper.saveConnectionDetails(connectionDetailsModel, serverInformationModel.getServerName());

        ServerDetailsModel servInfoModel = this.modelMapperHelper.findServerModelByServerName(this.serverInformationModel.getServerName());
        assertEquals(servInfoModel.toString(), this.serverInformationModel.toString());
    }


    /**
     * Test save domain identity config success.
     *
     * @throws Exception the exception
     */
    @Test
    public void testSaveDomainIdentityConfigSuccess() throws Exception {
        try {
            domainRoleUserGroupMapper.saveIdentityConfiguration(domainIdentitySettingsViewModel, "internal");
        } catch (LdapConfigDataException lde) {
            logger.error("Server name could not found");
        }
    }


    /**
     * Test save user identity config success.
     *
     * @throws Exception the exception
     */
    @Test
    public void testSaveUserIdentityConfigSuccess() throws Exception {
        try {
            userIdentirySettingViewModel.getAttributeMapVm().setMapOption(MapOption.DICTIONARY);
            userIdentirySettingViewModel.getValueMapVm().setMapOption(MapOption.DICTIONARY);
            userIdentirySettingViewModel.getReturnedAttributesVm().setSelectedDefaultAttribute("ou,test");
            domainRoleUserGroupMapper.saveIdentityConfiguration(userIdentirySettingViewModel, this.serverInformationModel.getServerName());
        } catch (LdapConfigDataException lde) {
            logger.error("Server name could not found");
        }
    }


    /**
     * Test find identity settings view model success.
     *
     * @throws Exception the exception
     */
    @Test
    public void testFindIdentitySettingsViewModelSuccess() throws Exception {

        String serverName = this.serverInformationModel.getServerName();
        IdentitySettingsViewModel identitySettingsViewMode = identitySearchUtility.findIdentitySettingByServerName(
                        new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN, serverName, ServerType.AD.toString(), null));
        logger.debug(identitySettingsViewMode.toString());
        logger.debug(this.domainIdentitySettingsViewModel.toString());

    }


    /**
     * Test save user override map configuration success.
     *
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Test
    public void testSaveUserOverrideMapConfigurationSuccess() throws LdapConfigDataException, IOException {

        UserOverrideMapDetailsViewModel detailsViewModel = new UserOverrideMapDetailsViewModel();

        detailsViewModel.setUserId("SdnhUser2");
        detailsViewModel.setSystemAdminLevel("SYSTEMADMIN");

        UserGroupDetailViewModel ug1 = new UserGroupDetailViewModel();

        ug1.setDomainId("SDomainNHG");
        ug1.setGroupAdminLevel("ADMIN");
        ug1.setGroupId("Group1");
        ug1.setRole("SdnhRole1");

        UserGroupDetailViewModel ug3 = new UserGroupDetailViewModel();
        ug3.setDomainId("SDomainNHG");
        ug3.setGroupAdminLevel("ADMIN");
        ug3.setGroupId("Group1");
        ug3.setRole("SdnhRole2");

        UserGroupDetailViewModel ug2 = new UserGroupDetailViewModel();
        ug2.setDomainId("SDomainNH");
        ug2.setGroupAdminLevel("MEMBER");
        ug2.setGroupId("Group2");
        ug2.setRole("SdnhRole2");

        List<UserGroupDetailViewModel> ugl = new ArrayList<UserGroupDetailViewModel>();
        ugl.add(ug1);
        ugl.add(ug2);
        ugl.add(ug3);

        UserDomainDetailViewModel ud1 = new UserDomainDetailViewModel();

        ud1.setDomainId("SDomainNHG");
        ud1.setDomainAdminLevel("MEMBER");
        ud1.setRole("Cardiologist");

        UserDomainDetailViewModel ud3 = new UserDomainDetailViewModel();
        ud3.setDomainId("SDomainNHG");
        ud3.setDomainAdminLevel("MEMBER");
        ud3.setRole("Cardiologist1");

        UserDomainDetailViewModel ud2 = new UserDomainDetailViewModel();
        ud2.setDomainId("SDomainNH");
        ud2.setDomainAdminLevel("MEMBER");
        ud2.setRole("Cardiologist 2");

        List<UserDomainDetailViewModel> udl = new ArrayList<UserDomainDetailViewModel>();
        udl.add(ud1);
        udl.add(ud2);
        udl.add(ud3);

        detailsViewModel.setGroupDetails(ugl);
        detailsViewModel.setDomainDetails(udl);

        List<UserOverrideMapDetailsViewModel> detailViewList = new ArrayList<UserOverrideMapDetailsViewModel>();
        detailViewList.add(detailsViewModel);
        UserOverrideMapViewModel viewModel = new UserOverrideMapViewModel();
        viewModel.setUserOverrideMapDetailsViewModel(detailViewList);

        userOverrideModelMapper.saveUserOverrideMapConfiguration(viewModel, serverInformationModel.getServerName());

    }


    /**
     * Test find override map by server name success.
     *
     * @throws LdapConfigDataException the ldap config data exception
     */
    @Test
    public void testFindOverrideMapByServerNameSuccess() throws LdapConfigDataException {

        UserOverrideMapDetailsViewModel detailsViewModel = new UserOverrideMapDetailsViewModel();

        detailsViewModel.setUserId("SdnhUser2");
        detailsViewModel.setSystemAdminLevel("SYSTEMADMIN");

        UserGroupDetailViewModel ug1 = new UserGroupDetailViewModel();

        ug1.setDomainId("SDomainNHG");
        ug1.setGroupAdminLevel("ADMIN");
        ug1.setGroupId("Group1");
        ug1.setRole("SdnhRole1");

        UserGroupDetailViewModel ug3 = new UserGroupDetailViewModel();
        ug3.setDomainId("SDomainNHG");
        ug3.setGroupAdminLevel("ADMIN");
        ug3.setGroupId("Group1");
        ug3.setRole("SdnhRole2");

        UserGroupDetailViewModel ug2 = new UserGroupDetailViewModel();
        ug2.setDomainId("SDomainNH");
        ug2.setGroupAdminLevel("MEMBER");
        ug2.setGroupId("Group2");
        ug2.setRole("SdnhRole2");

        List<UserGroupDetailViewModel> ugl = new ArrayList<UserGroupDetailViewModel>();
        ugl.add(ug1);
        ugl.add(ug2);
        ugl.add(ug3);

        UserDomainDetailViewModel ud1 = new UserDomainDetailViewModel();

        ud1.setDomainId("SDomainNHG");
        ud1.setDomainAdminLevel("MEMBER");
        ud1.setRole("Cardiologist");

        UserDomainDetailViewModel ud3 = new UserDomainDetailViewModel();
        ud3.setDomainId("SDomainNHG");
        ud3.setDomainAdminLevel("MEMBER");
        ud3.setRole("Cardiologist1");

        UserDomainDetailViewModel ud2 = new UserDomainDetailViewModel();
        ud2.setDomainId("SDomainNH");
        ud2.setDomainAdminLevel("MEMBER");
        ud2.setRole("Cardiologist 2");

        List<UserDomainDetailViewModel> udl = new ArrayList<UserDomainDetailViewModel>();
        udl.add(ud1);
        udl.add(ud2);
        udl.add(ud3);

        detailsViewModel.setGroupDetails(ugl);
        detailsViewModel.setDomainDetails(udl);

        List<UserOverrideMapDetailsViewModel> detailViewList = new ArrayList<UserOverrideMapDetailsViewModel>();
        UserOverrideMapViewModel viewModel = new UserOverrideMapViewModel();
        detailViewList.add(detailsViewModel);
        viewModel.setUserOverrideMapDetailsViewModel(detailViewList);
        UserOverrideMapViewModel viewModel1 = userOverrideModelMapper.findOverrideMapByServerName(serverInformationModel.getServerName());
        assertNotNull(viewModel1);
    }


    /**
     * Test save user override map configuration exception.
     *
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Test (expected = LdapConfigDataException.class)
    public void testSaveUserOverrideMapConfigurationException() throws LdapConfigDataException, IOException {
        userOverrideModelMapper.saveUserOverrideMapConfiguration(null, serverInformationModel.getServerName());
    }


    /**
     * Test find override map by server name exception.
     *
     * @throws LdapConfigDataException the ldap config data exception
     */
    @Test (expected = LdapConfigDataException.class)
    public void testFindOverrideMapByServerNameException() throws LdapConfigDataException {
        userOverrideModelMapper.findOverrideMapByServerName("Test server");
    }


    /**
     * Test delete server.
     *
     * @throws Exception the exception
     */
    public void testDeleteServer() throws Exception {
        assertNotNull(this.modelMapperHelper);
        logger.info("testAddServer = " + this.serverInformationModel);
        this.modelMapperHelper.deleteServer(this.serverInformationModel.getServerName());

    }


    /**
     * Tear.
     *
     * @throws Exception the exception
     */
    @After
    public void tear() throws Exception {
        testDeleteServer();
    }


    /**
     * Tear down.
     */
    @AfterClass
    public static void tearDown() {
        String dir = "src/test/resources/";
        String[] fileNames = { "ApacheSingleHierarchicalConfiguration.xml" };
        if (isDelete) {
            for (String fileName : fileNames) {
                File file = new File(dir + fileName);
                if (file.exists()) {
                    file.delete();
                }
            }
        }
    }

}
