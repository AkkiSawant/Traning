package com.mergehealthcare.icc.ldapconfig.web.integration.controller.rest;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.assertNotNull;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ConnectionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The Class LdapConfigurationRestControllerTest.
 */
@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = { LdapConfigApplication.class })
@WebAppConfiguration
public class LdapConfigurationRestControllerTest {

    private static final int DEFAULT_PORT = 20389;

    private static final Logger logger = LogService.getLogger(LdapConfigurationRestControllerTest.class);

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;

    @Autowired
    private ConnectionModelMapper connectionModelMapper;

    @Autowired
    private MockHttpSession session;

    @Autowired
    private MockHttpServletRequest request;

    @Autowired
    private ModelMapperHelper modelMapperHelper;

    private ServerDetailsModel serverInformationModel;

    private LdapTree ldapTree;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;


    /**
     * Setup.
     *
     * @throws Exception the exception
     */
    @Before
    public void setup() throws Exception {
        mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();

        serverInformationModel = new ServerDetailsModel();
        serverInformationModel.setNetworkDomain("NETWORK");
        serverInformationModel.setPassword("Cedara102");

        serverInformationModel.setServerName("internal");
        serverInformationModel.setServerType(ServerType.Apache.toString());
        serverInformationModel.setUserName("uid=admin,ou=system");

        modelMapperHelper.saveServerConfiguration(serverInformationModel);

        ConnectionDetailsModel connectionDetailsModel = new ConnectionDetailsModel();
        connectionDetailsModel.setDomainHost("icc-ldap.products.network.internal");
        connectionDetailsModel.setDefaultPort(DEFAULT_PORT);
        connectionDetailsModel.setConnectionType("basic");
        connectionDetailsModel.setAdvancedConnectionVm(connectionModelMapper.getDefaultJavaData());
        connectionModelMapper.saveConnectionDetails(connectionDetailsModel, serverInformationModel.getServerName());

        logger.debug("serverInformationModel = " + serverInformationModel);

    }


    /**
     * Gets the ldap tree success.
     *
     * @return the ldap tree success
     * @throws Exception the exception
     */
    // @Test
    public void getLdapTreeSuccess() throws Exception {

        ldapTree = new LdapTree();
        ldapTree.setTitle("testnode");

        session.setAttribute("ldapTree", ldapTree);
        request.setSession(session);

        ServletRequestAttributes requestAttributes = new ServletRequestAttributes(request);
        RequestContextHolder.setRequestAttributes(requestAttributes);

        mockMvc.perform(MockMvcRequestBuilders.get("/rest/session-ldap-data").accept(MediaType.APPLICATION_JSON).session(session))
                        .andExpect(MockMvcResultMatchers.status().isOk())
        .andExpect(MockMvcResultMatchers
                        .content()
                        .string("{\"title\":\"testnode\",\"attributeMap\":null,\"nodes\":null,\"value\":null,\"fullyQualifiedName\":null}"));
    }


    /**
     * Gets the ldap tree failure.
     *
     * @return the ldap tree failure
     * @throws Exception the exception
     */
    @Test
    public void getLdapTreeFailure() throws Exception {
        ServletRequestAttributes requestAttributes = new ServletRequestAttributes(request);
        RequestContextHolder.setRequestAttributes(requestAttributes);

        mockMvc.perform(MockMvcRequestBuilders.get("/rest/session-ldap-data").accept(MediaType.APPLICATION_JSON).session(session)).andExpect(
                        MockMvcResultMatchers.status().isBadRequest());
    }


    /**
     * Gets the tree by root distinguished name success.
     *
     * @return the tree by root distinguished name success
     * @throws Exception the exception
     */
    @Test
    public void getTreeByRootDistinguishedNameSuccess() throws Exception {
        String dn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        final String serverName = "internal";
        ModelOptionsViewModel modelOption = new ModelOptionsViewModel();
        modelOption.setDomainModel("");
        modelOption.setModelGrouping("");
        modelOption.setOrganizationalUnitDomain("");
        modelOption.setRootDistinguishedName(dn);
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldap-data").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(modelOption))).andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE));
    }


    @Test
    public void getTreeByRootDistinguishedNameFailure() throws Exception {
        final String serverName = "internal";
        ModelOptionsViewModel modelOption = new ModelOptionsViewModel();
        modelOption.setDomainModel("");
        modelOption.setModelGrouping("");
        modelOption.setOrganizationalUnitDomain("");
        modelOption.setRootDistinguishedName(null);
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldap-data").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(modelOption))).andExpect(MockMvcResultMatchers.status().isBadRequest())
                        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE));
    }


    @Test
    public void getTreeByRootDistinguishedNameWrongServerFailure() throws Exception {
        final String serverName = "wrongserver";
        ModelOptionsViewModel modelOption = new ModelOptionsViewModel();
        modelOption.setDomainModel("");
        modelOption.setModelGrouping("");
        modelOption.setOrganizationalUnitDomain("");
        modelOption.setRootDistinguishedName("ou=APSDomainUngrouped,dc=icc,dc=internal");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldap-data").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(modelOption)))
                        .andExpect(MockMvcResultMatchers.status().isInternalServerError())
                        .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_VALUE));
    }


    @Test
    public void getLdapSearchSuccess() throws Exception {
        Map<String, Object> obj = new HashMap<>();
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        String serverName = "internal";
        String userTargetDn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";
        boolean noMap = false;
        List<String> ldapProperties = new ArrayList<>();
        obj.put("userTargetDn", userTargetDn);
        obj.put("filter", filter);
        obj.put("classType", classType);
        obj.put("noMap", noMap);
        obj.put("ldapProperties", ldapProperties);
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldapSearch").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());
    }


    // @Test
    public void getLdapSearchNoMapSuccess() throws Exception {
        Map<String, Object> obj = new HashMap<>();
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        String serverName = "internal";
        String userTargetDn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";
        boolean noMap = true;
        List<String> ldapProperties = new ArrayList<>();
        obj.put("userTargetDn", userTargetDn);
        obj.put("filter", filter);
        obj.put("classType", classType);
        obj.put("noMap", noMap);
        obj.put("ldapProperties", ldapProperties);
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldapSearch").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());
    }


    @Test
    public void getLdapSearchNoMapFailure() throws Exception {
        Map<String, Object> obj = new HashMap<>();
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        String serverName = "internal";
        String userTargetDn = "ou=asasas,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";
        boolean noMap = true;
        List<String> ldapProperties = new ArrayList<>();
        obj.put("userTargetDn", userTargetDn);
        obj.put("filter", filter);
        obj.put("classType", classType);
        obj.put("noMap", noMap);
        obj.put("ldapProperties", ldapProperties);
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        mockMvc.perform(MockMvcRequestBuilders.post("/rest/ldapSearch").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isBadRequest());
    }


    @SuppressWarnings ("unchecked")
    @Test
    public void getAttributeMapDataEmptyTargetDnFailure() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> obj = new HashMap<>();

        String dn = "";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isBadRequest())
                        .andExpect(MockMvcResultMatchers.content().string(allOf(containsString("Please provide valid target DN"))));
    }


    @Test
    public void getAttributeMapDataForDomainSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForDomainStaticPropSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=wrong,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Domain";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForRoleSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Role";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForUserSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=APSDomainUngrouped,dc=icc,dc=internal";
        String filter = "(objectclass=InetOrgPerson)";
        String classType = "User";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForGroupSDHSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        wac.getServletContext().setAttribute(LdapConfigConstant.MODEL_GROUPING, LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED);
        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=Roles,OU=APSDomainNHG,dc=icc,dc=internal";
        String filter = "(objectclass=group)";
        String classType = "Group";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForGroupStaticSDHSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        wac.getServletContext().setAttribute(LdapConfigConstant.MODEL_GROUPING, LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED);
        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=Roles,OU=wrong,dc=icc,dc=internal";
        String filter = "(objectclass=group)";
        String classType = "Group";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    @Test
    public void getAttributeMapDataForGroupSuccess() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
        Map<String, Object> obj = new HashMap<>();

        String dn = "ou=Roles,OU=APSDomainNHG,dc=icc,dc=internal";
        String filter = "(objectclass=groupOfNames)";
        String classType = "Group";

        obj.put("dn", dn);
        obj.put("filter", filter);
        obj.put("classType", classType);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/attributeMap").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(obj))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    /**
     * Enable server success.
     *
     * @throws Exception the exception
     */
    @Test
    public void enableServerSuccess() throws Exception {

        String serverName = "internal";
        boolean flag = true;

        Map<String, Object> serverMap = new HashMap<>();
        serverMap.put("ServerName", serverName);
        serverMap.put("Enable", flag);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/enableServer").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(serverMap))).andExpect(MockMvcResultMatchers.status().isOk());

    }


    /**
     * Enable server failure.
     *
     * @throws Exception the exception
     */
    @Test
    public void enableServerFailure() throws Exception {

        String serverName = "";
        boolean flag = true;

        Map<String, Object> serverMap = new HashMap<>();
        serverMap.put("ServerName", serverName);
        serverMap.put("Enable", flag);

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/enableServer").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(serverMap))).andExpect(MockMvcResultMatchers.status().isBadRequest());

    }


    /**
     * Test delete server.
     *
     * @throws Exception the exception
     */
    public void testDeleteServer() throws Exception {
        assertNotNull(modelMapperHelper);
        logger.info("testAddServer = " + serverInformationModel);
        modelMapperHelper.deleteServer(serverInformationModel.getServerName());

    }


    /**
     * Tear.
     *
     * @throws Exception the exception
     */
    @After
    public void tear() throws Exception {
        testDeleteServer();
    }


    /**
     * Gets the server identity success.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws Exception the exception
     */
    @Test
    public void getServerIdentitySuccess() throws IOException, Exception {
        Map<String, Object> connectionDetails = new HashMap<String, Object>();
        connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
        connectionDetails.put("port", "20639");
        connectionDetails.put("connectionType", "SSL");

        if (iCCEnvironmentConfig.getPlatform().equals(Platform.Java.toString())) {
            mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverIdentity").contentType(TestUtil.APPLICATION_JSON_UTF8)
                            .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(MockMvcResultMatchers.status().isOk())
                            .andExpect(MockMvcResultMatchers.content().string("\"icc-ICC-LDAP-CA\""));
        }

    }


    @Test
    public void getServerIdentityFailure() throws Exception {

        String serverName = "internal";
        wac.getServletContext().setAttribute(LdapConfigConstant.SERVER_TYPE, "Apache");
        wac.getServletContext().setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);

        Map<String, Object> connectionDetails = new HashMap<String, Object>();
        connectionDetails.put("domainHost", "");
        connectionDetails.put("port", "22");
        connectionDetails.put("connectionType", "SSL");

        mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverIdentity").contentType(TestUtil.APPLICATION_JSON_UTF8)
                        .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(
                                        MockMvcResultMatchers.status().isInternalServerError());

    }


    @Test
    public void getServerCertificateSSLSuccessJava() throws IOException, Exception {

        if (iCCEnvironmentConfig.getPlatform().equals(Platform.Java.toString())) {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20639");
            connectionDetails.put("connectionType", "SSL");
            File certificateFile = new File("c:\\configuration\\path\\certificate.jks");
            certificateFile.createNewFile();
            connectionDetails.put("storeLocation", "c:\\configuration\\path\\certificate.jks");
            connectionDetails.put("storePassword", "changeit");
            mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverCerts").contentType(TestUtil.APPLICATION_JSON_UTF8)
                            .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(MockMvcResultMatchers.status().isOk())
                            .andExpect(MockMvcResultMatchers.content().string("\"Certificate retrieved successfully\""));
            certificateFile.delete();
        }

    }


    // @Test
    public void getServerCertificateSSLSuccessNet() throws IOException, Exception {

        if (iCCEnvironmentConfig.getPlatform().equals(Platform.Net.toString())) {
            Map<String, Object> connectionDetails = new HashMap<String, Object>();
            connectionDetails.put("domainHost", "icc-ldap.products.network.internal");
            connectionDetails.put("port", "20639");
            connectionDetails.put("connectionType", "SSL");
            File certificateFile = new File("c:\\configuration\\path\\certificate.crt");
            certificateFile.createNewFile();
            connectionDetails.put("storeLocation", "c:\\configuration\\path\\certificate.crt");
            connectionDetails.put("storePassword", "changeit");
            mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverCerts").contentType(TestUtil.APPLICATION_JSON_UTF8)
                            .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(MockMvcResultMatchers.status().isOk())
                            .andExpect(MockMvcResultMatchers.content().string("\"Certificate retrieved successfully\""));
            certificateFile.delete();
        }

    }


    @Test
    public void getServerCertificateFailure() throws IOException, Exception {
        Map<String, Object> connectionDetails = new HashMap<String, Object>();
        connectionDetails.put("domainHost", "");
        connectionDetails.put("port", "20639");
        connectionDetails.put("connectionType", "TLS");
        File certificateFile = new File("c:\\configuration\\path\\certificate.txt");
        certificateFile.createNewFile();
        connectionDetails.put("storeLocation", "c:\\configuration\\path\\certificate.txt");
        connectionDetails.put("storePassword", "");
        if (iCCEnvironmentConfig.getPlatform().equals(Platform.Java.toString())) {
            mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverCerts").contentType(TestUtil.APPLICATION_JSON_UTF8)
                            .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(
                                            MockMvcResultMatchers.content().string("\"Enter valid details\""));
        } else {
            mockMvc.perform(MockMvcRequestBuilders.post("/rest/serverCerts").contentType(TestUtil.APPLICATION_JSON_UTF8)
                            .content(TestUtil.convertObjectToJsonBytes(connectionDetails))).andExpect(
                                            MockMvcResultMatchers.content().string("\"Enter valid details\""));
        }

        certificateFile.delete();
    }
}
