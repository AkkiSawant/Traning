
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ModifyServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.ModelMapperHelper;

public class MockModifyServer {

  private static String serverName = "modifyServer";


  public static void mockMapperHelper(Mockery context, final ModelMapperHelper modelMapperHelper)
      throws Exception {
    mockFindServerModel(context, modelMapperHelper);
  }


  private static void mockFindServerModel(Mockery context,
      final ModelMapperHelper modelMapperHelper) {
    context.checking(new Expectations() {

      {
        ServerDetailsModel serverDetailsModel = ModifyServerMockData.getServerDetails();
        allowing(modelMapperHelper).findServerModelByServerName(with(equal(serverName)));
        will(returnValue(serverDetailsModel));
      }
    });
  }
}
