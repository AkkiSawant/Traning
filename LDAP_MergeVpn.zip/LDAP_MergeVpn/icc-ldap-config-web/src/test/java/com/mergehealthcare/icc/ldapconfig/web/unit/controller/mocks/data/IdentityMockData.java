
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.ServerConfiguration;

public class IdentityMockData {

  // TODO: add mock data
  public static ServerConfiguration getServerConfiguration() {
    return null;
  }


  // TODO: add mock data
  public static Locators getLocators() {
    return null;
  }


  // TODO: add mock data
  public static Mappers getMappers() {
    return null;
  }

}
