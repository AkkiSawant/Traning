
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;

import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.ServiceCredentials;

public class SaveServerMockData {

  private static ServerDetailsModel serverDetails = new ServerDetailsModel();

  private static ConnectionDetailsModel connectionDetails = new ConnectionDetailsModel();


  public static ServerDetailsModel getServerDetailsModel() {
    serverDetails.setServerName("saveServer");
    serverDetails.setServerType("AD");
    serverDetails.setNetworkDomain("icc");
    serverDetails.setUserName("Administrator");
    serverDetails.setPassword("password");
    return serverDetails;
  }


  public static ServerDetailsModel getServerDetailsInp() {
    return getServerDetailsModel();
  }


  public static ServerDetailsModel getServerDetailsExceptionInp() {
    return null;
  }


  public static BindingResult getBindingResult(ServerDetailsModel serverDetails,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(serverDetails, objectName);
    return bindingResult;
  }


  public static BindingResult getBindingResultErrors(ServerDetailsModel serverDetails,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(serverDetails, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "invalid server details");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }


  public static ConnectionDetailsModel getConnectionDetails() {
    connectionDetails.setDomainHost("icc-ldap.products.network.internal");
    connectionDetails.setDefaultPort(389);
    connectionDetails.setFullyQualifiedDomainName(true);
    connectionDetails.setConnectionType("basic");
    return connectionDetails;
  }


  public static AdvancedConnectionOptionsViewModel getAdvancedConnectionsJava() {
    AdvancedConnectionOptionsViewModel advancedConnectionVm =
        new AdvancedConnectionOptionsViewModel();
    advancedConnectionVm.setAutoReconnect(true);
    advancedConnectionVm.setReferralHopLimit(32);
    advancedConnectionVm.setConnectionTimeOut("00:00:30");
    advancedConnectionVm.setSizeLimit(700);
    advancedConnectionVm.setTimeLimit("00:00:00");
    advancedConnectionVm.setPageSize(699);
    return advancedConnectionVm;
  }


  public static AdvancedConnectionOptionsViewModel getAdvancedConnectionsNet() {
    AdvancedConnectionOptionsViewModel advancedConnectionVm =
        new AdvancedConnectionOptionsViewModel();
    advancedConnectionVm.setProtocolVersion(3);
    advancedConnectionVm.setAutoReconnect(true);
    advancedConnectionVm.setReferralHopLimit(32);
    advancedConnectionVm.setPingKeepAliveTimeout("00:02:00");
    advancedConnectionVm.setPingWaitTimeout("00:00:02");
    advancedConnectionVm.setPingLimit(4);
    advancedConnectionVm.setConnectionTimeOut("00:00:30");
    advancedConnectionVm.setSizeLimit(700);
    advancedConnectionVm.setTimeLimit("00:00:00");
    advancedConnectionVm.setPageSize(699);
    return advancedConnectionVm;
  }


  // TODO: add mock data
  public static ServerConfiguration getServerConfiguration() {
    ServerConfiguration serverConfiguration = new ServerConfiguration();
    return serverConfiguration;
  }


  // TODO: add mock data
  public static ServerDetails getServerDetails() {
    ServerDetails serverDetails = new ServerDetails();
    return serverDetails;
  }


  // TODO: add mock data
  public static ServiceCredentials getServerCredentials() {
    ServiceCredentials serviceCredentials = new ServiceCredentials();
    return serviceCredentials;
  }
}
