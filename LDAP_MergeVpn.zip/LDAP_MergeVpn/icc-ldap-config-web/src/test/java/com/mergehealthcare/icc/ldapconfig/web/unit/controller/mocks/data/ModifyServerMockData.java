
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;

public class ModifyServerMockData {

  public static ServerDetailsModel getServerDetails() {
    ServerDetailsModel serverDetails = new ServerDetailsModel();
    serverDetails.setServerName("saveServer");
    serverDetails.setServerType("AD");
    serverDetails.setNetworkDomain("icc");
    serverDetails.setUserName("Administrator");
    serverDetails.setPassword("password");
    return serverDetails;
  }
}
