
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.LdapServiceManager;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.TestLdapServerMockData;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.SearchScope;

import icc.base.exception.IOCException;
import icc.ldap.server.configuration.ServerConfiguration;

public class MockTestLdapServer {

  public static void mockServerDetailsService(Mockery context,
      final ServerDetailsService serverDetailsService) throws Exception {
    mockLoadAllServerNames(context, serverDetailsService);
    mockFetchSaveConfiguration(context, serverDetailsService);
  }


  private static void mockLoadAllServerNames(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        List<ServerDetailsModel> configuredServerList =
            TestLdapServerMockData.getConfiguredServerList();
        allowing(serverDetailsService).loadAllServerNames();
        will(returnValue(configuredServerList));
      }
    });
  }


  private static void mockFetchSaveConfiguration(Mockery context,
      final ServerDetailsService serverDetailsService) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ServerConfiguration serverConfiguration = TestLdapServerMockData.getServerConfiguration();
        allowing(serverDetailsService).fetchSaveConfiguration(with(equal("TestServer")));
        will(returnValue(serverConfiguration));
      }
    });
  }


  public static void mockLdapUtilityService(Mockery context,
      final LdapServiceManager ldapUtilityService) throws Exception {
    mockSearch(context, ldapUtilityService);
  }


  @SuppressWarnings ("unchecked")
  private static void mockSearch(Mockery context, final LdapServiceManager ldapUtilityService)
      throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        List<String> mockList = new ArrayList<String>();
        List<LdapTree> ldapSearchResult = TestLdapServerMockData.getLdapSearchResult();
        allowing(ldapUtilityService).search(
            with(any(String.class)), with(any(String.class)), with(any(String.class)),
            with(any(SearchScope.class)), with(any(mockList.getClass())));
        will(returnValue(ldapSearchResult));
      }
    });
  }
}
