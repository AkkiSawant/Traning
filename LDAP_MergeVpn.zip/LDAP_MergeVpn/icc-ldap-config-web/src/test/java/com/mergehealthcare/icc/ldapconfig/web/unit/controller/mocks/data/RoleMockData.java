
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

public class RoleMockData {

  private static RoleIdentitySettingsViewModel identitySettingsVm =
      new RoleIdentitySettingsViewModel();

  private static IdentitySettingsMethodVM identitySettingsMethodRoleVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.ROLE, "role", "AD", null);

  private static IdentitySettingsMethodVM identitySettingsMethodUserVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.USER, "role", "AD", null);

  private static IdentitySettingsMethodVM identitySettingsMethodExceptionUserVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.USER, "LDAPException", "AD", null);

  private static IdentitySettingsMethodVM identitySettingsMethodRoleExceptionVM =
      new IdentitySettingsMethodVM(LdapConfigConstant.ROLE, "LDAPException", "AD", null);


  public static RoleIdentitySettingsViewModel getIdentitySettings() {
    identitySettingsVm.setBasicInfoVm(getBasicInfo());
    identitySettingsVm.setAttributeMapVm(getAttributeMap());
    identitySettingsVm.setReturnedAttributesVm(getReturnedAttributes());
    identitySettingsVm.setValueMapVm(getValueMap());
    return identitySettingsVm;
  }


  // TODO: add mock data
  private static BasicInfoItemViewModelBase getBasicInfo() {
    BasicInfoItemViewModelBase basicInfoVm = new BasicInfoItemViewModelBase();
    basicInfoVm.setAttributeMapEnabled(true);
    return basicInfoVm;
  }


  // TODO: add mock data
  private static AttributeMapItemViewModel getAttributeMap() {
    AttributeMapItemViewModel attributeMapVm = new AttributeMapItemViewModel();
    return attributeMapVm;
  }


  // TODO: add mock data
  private static ReturnedAttributesItemViewModel getReturnedAttributes() {
    ReturnedAttributesItemViewModel returnedAttributesVm = new ReturnedAttributesItemViewModel();
    return returnedAttributesVm;
  }


  // TODO: add mock data
  private static ValueMapItemViewModel getValueMap() {
    ValueMapItemViewModel valueMapVm = new ValueMapItemViewModel();
    return valueMapVm;
  }


  public static RoleIdentitySettingsViewModel getIdentitySettingsInp() {
    return getIdentitySettings();
  }


  public static RoleIdentitySettingsViewModel getNewRole() {
    return getIdentitySettings();
  }


  // TODO: add mock data
  public static UserIdentitySettingsViewModel getUserIdentitySettings() {
    return new UserIdentitySettingsViewModel();
  }


  public static BindingResult getBindingResult(RoleIdentitySettingsViewModel identitySettingsVm,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(identitySettingsVm, objectName);
    return bindingResult;
  }


  public static BindingResult
      getBindingResultErrors(RoleIdentitySettingsViewModel identitySettingsVm, String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(identitySettingsVm, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "invalid role details");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }


  public static IdentitySettingsMethodVM getIdentitySettingsMethodRoleVM() {
    return identitySettingsMethodRoleVM;
  }


  public static IdentitySettingsMethodVM getIdentitySettingsMethodUserVM() {
    return identitySettingsMethodUserVM;
  }


  public static IdentitySettingsMethodVM getIdentitySettingsMethodUserExceptionVM() {
    return identitySettingsMethodExceptionUserVM;
  }


  public static IdentitySettingsMethodVM getIdentitySettingsMethodRoleExceptionVM() {
    return identitySettingsMethodRoleExceptionVM;
  }

}
