
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import org.springframework.ui.ModelMap;

public class FinishMockData {

  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }
}
