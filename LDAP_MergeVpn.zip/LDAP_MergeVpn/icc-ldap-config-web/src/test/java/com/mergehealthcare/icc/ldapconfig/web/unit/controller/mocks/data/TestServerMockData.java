
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.TestServerConfigurationViewModel;

public class TestServerMockData {

  // TODO: add mock data
  public static TestServerConfigurationViewModel getTestServerInp() {
    return getTestServerVm();
  }


  public static TestServerConfigurationViewModel getTestServerErrorInp() {
    TestServerConfigurationViewModel testServerVm = new TestServerConfigurationViewModel();
    testServerVm.setUserName("Test");
    testServerVm.setPassword("password");
    return testServerVm;
  }


  public static TestServerConfigurationViewModel getTestServerExceptionInp() {
    TestServerConfigurationViewModel testServerVm = new TestServerConfigurationViewModel();
    testServerVm.setUserName("LDAPException");
    testServerVm.setPassword("password");
    return testServerVm;
  }


  // TODO: add mock data
  public static TestServerConfigurationViewModel getTestServerVm() {
    TestServerConfigurationViewModel testServerVm = new TestServerConfigurationViewModel();
    testServerVm.setUserName("Administrator");
    testServerVm.setPassword("password");
    return testServerVm;
  }


  public static BindingResult getBindingResult(TestServerConfigurationViewModel testViewModel,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(testViewModel, objectName);
    return bindingResult;
  }


  public static BindingResult getBindingResultErrors(TestServerConfigurationViewModel testViewModel,
      String objectName) {
    BindingResult bindingResult = new DirectFieldBindingResult(testViewModel, objectName);
    ObjectError error = getError();
    bindingResult.addError(error);
    return bindingResult;
  }


  private static ObjectError getError() {
    ObjectError error = new ObjectError("error", "invalid test server details");
    return error;
  }


  public static ModelMap getModelMap() {
    ModelMap modelMap = new ModelMap();
    return modelMap;
  }
}
