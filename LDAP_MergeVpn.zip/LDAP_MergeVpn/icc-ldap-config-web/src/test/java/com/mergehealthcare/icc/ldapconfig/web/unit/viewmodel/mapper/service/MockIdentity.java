
package com.mergehealthcare.icc.ldapconfig.web.unit.viewmodel.mapper.service;

import java.io.IOException;

import org.jmock.Expectations;
import org.jmock.Mockery;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.IdentityMockData;

import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.ServerConfiguration;

public class MockIdentity {

    public static void mockServerDetailsService(Mockery context, final ServerDetailsService serverDetailsService) throws Exception {
        mockModify(context, serverDetailsService);
        mockFetchSaveConfiguration(context, serverDetailsService);
    }


    private static void mockModify(Mockery context, final ServerDetailsService serverDetailsService)
                    throws LdapConfigDataException, IOException {
        context.checking(new Expectations() {

            {
                ServerConfiguration mockServerConfiguration = IdentityMockData.getServerConfiguration();
                allowing(serverDetailsService).modify(with(equal(mockServerConfiguration)));
            }
        });
    }


    private static void mockFetchSaveConfiguration(Mockery context, final ServerDetailsService serverDetailsService)
                    throws LdapConfigDataException {
        context.checking(new Expectations() {

            {
                ServerConfiguration mockServerConfiguration = IdentityMockData.getServerConfiguration();
                allowing(serverDetailsService).fetchSaveConfiguration(with(equal("identity")));
                will(returnValue(mockServerConfiguration));
            }
        });
    }


    public static void mockObjectFactory(Mockery context, final ObjectFactory objectFactory) throws Exception {
        mockCreateLocators(context, objectFactory);
        mockCreateMappers(context, objectFactory);
        mockCreateEmptySiteDomains(context, objectFactory);
    }


    private static void mockCreateLocators(Mockery context, final ObjectFactory objectFactory) {
        context.checking(new Expectations() {

            {
                Locators mockLocators = IdentityMockData.getLocators();
                allowing(objectFactory).createLocators();
                will(returnValue(mockLocators));
            }
        });
    }


    private static void mockCreateMappers(Mockery context, final ObjectFactory objectFactory) {
        context.checking(new Expectations() {

            {
                Mappers mockMappers = IdentityMockData.getMappers();
                allowing(objectFactory).createMappers();
                will(returnValue(mockMappers));
            }
        });
    }


    private static void mockCreateEmptySiteDomains(Mockery context, final ObjectFactory objectFactory) {
        context.checking(new Expectations() {

            {
                allowing(objectFactory).createEmptySiteDomains();
            }
        });
    }
}
