
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.service;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data.ModelOptionsMockData;
import com.mergehealthcare.icc.ldapconfig.web.validator.ModelOptionsValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.springframework.validation.Errors;

import java.io.IOException;

public class MockModelOptions {

  private static String serverName = "modelOptions";


  public static void mockIdentityModelOptionModelMapper(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper) throws Exception {
    mockFindModelOptions(context, identityModelOptionModelMapper);
    mockSaveModelOptions(context, identityModelOptionModelMapper);

  }


  public static void mockIdentitySearchUtility(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws Exception {
    mockFindIdentity(context, identitySearchUtility);
  }


  private static void mockFindModelOptions(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        ModelOptionsViewModel modelOptions = ModelOptionsMockData.getModelOptions();
        allowing(identityModelOptionModelMapper)
            .findModelOptionByServerName(with(equal(serverName)));
        will(returnValue(modelOptions));
      }
    });
  }


  private static void mockSaveModelOptions(Mockery context,
      final IdentityModelOptionModelMapper identityModelOptionModelMapper)
      throws LdapConfigDataException,
        IOException {
    context.checking(new Expectations() {

      {
        ModelOptionsViewModel modelOptions = ModelOptionsMockData.getModelOptionsInp();
        ModelOptionsViewModel modelOptionsUngrouped =
            ModelOptionsMockData.getModelOptionsUngroupedInp();
        allowing(identityModelOptionModelMapper).saveModelOptionConfiguration(
            with(equal(modelOptions)), with(equal(serverName)), with(any(Boolean.class)));
        allowing(identityModelOptionModelMapper).saveModelOptionConfiguration(
            with(equal(modelOptionsUngrouped)), with(equal(serverName)), with(any(Boolean.class)));
      }
    });
  }


  private static void mockFindIdentity(Mockery context,
      final IdentitySearchUtility identitySearchUtility) throws LdapConfigDataException {
    context.checking(new Expectations() {

      {
        DomainIdentitySettingsViewModel identitySettingsVm =
            ModelOptionsMockData.getIdentitySettings();
        IdentitySettingsMethodVM identitySettingsMethodVM =
            ModelOptionsMockData.getIdentitySettingsMethodModelOptionsVM();
        allowing(identitySearchUtility)
            .findIdentitySettingByServerName(with(equal(identitySettingsMethodVM)));
        will(returnValue(identitySettingsVm));
      }
    });
  }


  public static void mockModelOptionsValidator(Mockery context,
      final ModelOptionsValidator modelOptionsValidator) {
    mockValidate(context, modelOptionsValidator);
  }


  private static void mockValidate(Mockery context,
      final ModelOptionsValidator modelOptionsValidator) {
    context.checking(new Expectations() {

      {
        ModelOptionsViewModel modelOptions = ModelOptionsMockData.getModelOptionsInp();
        ModelOptionsViewModel modelOptionsUngrouped =
            ModelOptionsMockData.getModelOptionsUngroupedInp();
        allowing(modelOptionsValidator)
            .validate(with(equal(modelOptions)), with(any(Errors.class)));
        allowing(modelOptionsValidator)
            .validate(with(equal(modelOptionsUngrouped)), with(any(Errors.class)));
      }
    });
  }
}
