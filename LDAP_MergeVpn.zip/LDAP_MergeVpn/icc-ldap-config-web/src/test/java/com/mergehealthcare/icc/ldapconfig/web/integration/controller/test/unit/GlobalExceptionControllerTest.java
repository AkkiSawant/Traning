
package com.mergehealthcare.icc.ldapconfig.web.integration.controller.test.unit;

import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import com.mergehealthcare.icc.ldapconfig.LdapConfigApplication;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;

@WebAppConfiguration
@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = LdapConfigApplication.class)
public class GlobalExceptionControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;


    @Before
    public void before() {
        this.mockMvc = webAppContextSetup(this.webApplicationContext).build();
    }


    @Test
    public void shouldReturnErrorView() throws Exception {

        mockMvc.perform(MockMvcRequestBuilders.get("/nopagefound").contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().isNotFound());
    }
}
