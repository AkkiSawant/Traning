
package com.mergehealthcare.icc.ldapconfig.web.unit.controller.mocks.data;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.SiteDomain;
import icc.ldap.server.configuration.SiteDomains;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.ObjectError;

public class ModelOptionsMockData {

    private static ModelOptionsViewModel modelOptions = new ModelOptionsViewModel();

    private static ModelOptionsViewModel modelOptionsUngrouped = new ModelOptionsViewModel();

    private static DomainIdentitySettingsViewModel identitySettingsVm = new DomainIdentitySettingsViewModel();

    private static IdentitySettingsMethodVM identitySettingsMethodModelOptionsVM = new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN,
                    "modelOptions", "AD", null);


    public static ModelOptionsViewModel getModelOptions() {
        modelOptions.setDomainModel("Single Domain");
        modelOptions.setModelGrouping("ungrouped");
        modelOptions.setRootDistinguishedName("OU=SDomainUngrouped,DC=icc,DC=internal");
        modelOptions.setOrganizationalUnitDomain("SDomainUngrouped");
        modelOptions.setFetchNewTree(false);
        return modelOptions;
    }


    public static IdentitySettingsMethodVM getIdentitySettingsMethodModelOptionsVM() {
        return identitySettingsMethodModelOptionsVM;
    }


    public static ModelOptionsViewModel getModelOptionsInp() {
        return getModelOptions();
    }


    public static ModelOptionsViewModel getModelOptionsUngroupedInp() {
        modelOptionsUngrouped.setDomainModel("Single Domain");
        modelOptionsUngrouped.setModelGrouping(LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED);
        modelOptionsUngrouped.setRootDistinguishedName("OU=SDomainUngrouped,DC=icc,DC=internal");
        modelOptionsUngrouped.setOrganizationalUnitDomain("SDomainUngrouped");
        modelOptionsUngrouped.setFetchNewTree(false);
        return modelOptionsUngrouped;
    }


    public static BindingResult getBindingResult(ModelOptionsViewModel modelOptions, String objectName) {
        BindingResult bindingResult = new DirectFieldBindingResult(modelOptions, objectName);
        return bindingResult;
    }


    public static BindingResult getBindingResultErrors(ModelOptionsViewModel modelOptions, String objectName) {
        BindingResult bindingResult = new DirectFieldBindingResult(modelOptions, objectName);
        ObjectError error = getError();
        bindingResult.addError(error);
        return bindingResult;
    }


    private static ObjectError getError() {
        ObjectError error = new ObjectError("error", "invalid model options");
        return error;
    }


    public static ModelMap getModelMap() {
        ModelMap modelMap = new ModelMap();
        return modelMap;
    }


    public static DomainIdentitySettingsViewModel getIdentitySettings() {
        identitySettingsVm.setBasicInfoVm(getBasicInfo());
        identitySettingsVm.setAttributeMapVm(getAttributeMap());
        identitySettingsVm.setReturnedAttributesVm(getReturnedAttributes());
        identitySettingsVm.setValueMapVm(getValueMap());
        return identitySettingsVm;
    }


    // TODO: add mock data
    private static BasicInfoItemViewModelBase getBasicInfo() {
        BasicInfoItemViewModelBase basicInfoVm = new BasicInfoItemViewModelBase();
        basicInfoVm.setAttributeMapEnabled(true);
        return basicInfoVm;
    }


    // TODO: add mock data
    private static AttributeMapItemViewModel getAttributeMap() {
        AttributeMapItemViewModel attributeMapVm = new AttributeMapItemViewModel();
        return attributeMapVm;
    }


    // TODO: add mock data
    private static ReturnedAttributesItemViewModel getReturnedAttributes() {
        ReturnedAttributesItemViewModel returnedAttributesVm = new ReturnedAttributesItemViewModel();
        return returnedAttributesVm;
    }


    // TODO: add mock data
    private static ValueMapItemViewModel getValueMap() {
        ValueMapItemViewModel valueMapVm = new ValueMapItemViewModel();
        return valueMapVm;
    }


    public static ServerConfiguration getServerConfiguration() {
        ServerConfiguration serverConfiguration = new ServerConfiguration();
        Model model = getModel();
        serverConfiguration.setModel(model);
        serverConfiguration.setServerDetails(getServerDetails());
        return serverConfiguration;
    }


    private static Model getModel() {
        Model model = new Model();
        model.setType("ungrouped");
        model.setRootDistinguishedName("OU=SDomainUngrouped,DC=icc,DC=internal");
        return model;
    }


    private static ServerDetails getServerDetails() {
        ServerDetails serverDetails = new ServerDetails();
        serverDetails.setSiteDomains(getSiteDomains());
        return serverDetails;
    }


    private static SiteDomains getSiteDomains() {
        SiteDomains siteDomains = new SiteDomains();
        siteDomains.getSiteDomain().put("ou", getSiteDomain());
        return siteDomains;
    }


    public static SiteDomain getSiteDomain() {
        SiteDomain siteDomain = new SiteDomain();
        siteDomain.setDomainName("SDomainUngrouped");
        return siteDomain;
    }
}
