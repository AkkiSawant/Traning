$(document).ready(function(){
	
	//This variable saves currently selected value of UserSystemAdminLevelTable row
	var selectedUniqueRowValue = "";
	
	function getSelectedUserSystemValue() {
		return selectedUniqueRowValue;
	}
	
	function setSelectedUserSystemValue(uniqueVal) {
		selectedUniqueRowValue = uniqueVal;
	}
	
	var selectedUniqueDomainRoleRowValue = null;
	
	function getSelectedUniqueDomainRoleRowValue() {
		return selectedUniqueDomainRoleRowValue;
	}
	
	function setSelectedUniqueDomainRoleRowValue(uniqueVal) {
		selectedUniqueDomainRoleRowValue = uniqueVal;
	}
	
	var selectedUniqueDomainGroupRoleRowValue = null;
	
	function getSelectedUniqueDomainGroupRoleRowValue() {
		return selectedUniqueDomainGroupRoleRowValue;
	}
	
	function setSelectedUniqueDomainGroupRoleRowValue(uniqueVal) {
		selectedUniqueDomainGroupRoleRowValue = uniqueVal;
	}
	
	/*START :: Code for UserSystemAdminLevelTable binding row click event*/
	
	function initializeUserOverrideMap() {
   
		var tableRow = bindTableRowClickHandler("userSystemAdminLevelTable", userSystemAdminLevelTableRow_ClickHandler);
	    bindTableRowClickHandler("domainRoleMappingTable", domainRoleMappingTableRow_ClickHandler);
	    bindTableRowClickHandler("domainGroupRoleMappingTable", domainGroupRoleMappingTableRow_ClickHandler);
  
	    //This is for firing click event on first row of the userSystemAdminLevelTable
	    if(tableRow && tableRow.length > 0){
	    	$("#"+tableRow[0].id).trigger('click');
		}
	}
	
	function bindTableRowClickHandler(tableId, functionName){
		var tableRow = $("#" + tableId + " > tbody > tr");
		tableRow.click(functionName);
		return tableRow;
	}
	
	function domainRoleMappingTableRow_ClickHandler() {
		$(this).addClass('selected').siblings().removeClass('selected');
		setSelectedUniqueDomainRoleRowValue($(this)[0]);
	}
	
	function domainGroupRoleMappingTableRow_ClickHandler() {
		$(this).addClass('selected').siblings().removeClass('selected');
		setSelectedUniqueDomainGroupRoleRowValue($(this)[0]);
	}
	
	function userSystemAdminLevelTableRow_ClickHandler() {
		var rowId = $(this)[0].id + "";
		var uniqueArr = rowId.split("___");
		setSelectedUserSystemValue(uniqueArr[1]);
		
		var domainRoleMappingRowClass = "domain-role-mapping-row___"+ getSelectedUserSystemValue();
		var domainGroupRoleMappingRowClass = "domain-group-role-mapping-row___" + getSelectedUserSystemValue();
		
		$("#domainRoleMappingTable > tbody > tr").css("display","none");
		$("#domainGroupRoleMappingTable > tbody > tr").css("display","none");
		
		$("."+domainRoleMappingRowClass).css("display","table-row");
		$("."+domainGroupRoleMappingRowClass).css("display","table-row");
		
		//This is for highlighting selected row in userSystemAdminLevelTable.
		$(this).addClass('selected').siblings().removeClass('selected');
    };
    
    /*END :: Code for UserSystemAdminLevelTable binding row click event*/
    
    /*START :: Utility function*/
    
    function getDropDownList(name, optionList, id) {
	    var combo = $("<select></select>");
		combo.attr("name", name);
		if(id && id !== "" && id !== null) {
			combo.attr("id", id);
		}
				
	    $.each(optionList, function (index, element) {
	        combo.append("<option>" + element + "</option>");
	    });

	    return combo;
	}
    
    function getDropDownTd(name, optionList, id, cssClass) {
    	var combo = getDropDownList(name, optionList, id);
    	combo.attr("class", cssClass);
    	var td = $("<td></td>");
		td.append(combo);
		return td;
    }
    
    function getInputBoxTd(name, cssClass){
    	var input = $("<input></input>");
    	input.attr("name", name);
    	input.attr("class", cssClass);
		var td = $("<td></td>");
		td.append(input);
		return td;
		
    }
    
    /*END :: Utility function*/
    
    /*START :: UserSystemAdminLevelTable UI DOM creation*/
    
	function getUserSystemAdminLevelTableRow() {
		var rowIndex = $("#userSystemAdminLevelTable > tbody > tr").length;
		var userSystemAdminLevelTableRow = $("<tr></tr>");
		userSystemAdminLevelTableRow.attr("id", "userSystemAdminLevelRow___" + rowIndex);
		var userIdTd = getUserIdTd(rowIndex);
		var systemAdminTd = getSystemAdminTd(rowIndex);
		
		userSystemAdminLevelTableRow.append(userIdTd);
		userSystemAdminLevelTableRow.append(systemAdminTd);
		userSystemAdminLevelTableRow.click(userSystemAdminLevelTableRow_ClickHandler);
		return userSystemAdminLevelTableRow;
	}
	
	function getUserIdTd(rowIndex) {
		var name = "userOverrideMapDetailsViewModel[" + rowIndex + "].userId";
		return getInputBoxTd(name, "user-id form-control height-33");
	}
	
	function getSystemAdminTd(rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+rowIndex+"].systemAdminLevel";
		var optionList = ["User","SuperAdmin"];
		return getDropDownTd(name, optionList, "", "admin-level form-control height-33");
	}
	
	/*END :: UserSystemAdminLevelTable UI DOM creation*/
	
	/*START :: UserSystemAdminLevelTable UI DOM manipulation*/

	$("#userSystemAdminLevelTableRowRemove").click(function() {
		var index = getSelectedUserSystemValue();
		if(index === null || index === "") {
			alert("Please select any row.");
		} else {
			var deleteConfirmation = confirm("Are you sure you want to delete?");
			if(deleteConfirmation) {
				var row = $("#userSystemAdminLevelRow___"+index);
				var success = deleteUserOverrideMapDetail(row, index);
				if(success) {
					setSelectedUserSystemValue(null);
				}
			}
		}
	});
	
	function deleteUserSystemAdminLevelRow(row) {
		row.remove();
	}
	
	function deleteDomainRoleMappingRows(index) {
		var rowSelector = "domain-role-mapping-row___" + index;
		$("#domainRoleMappingTable > tbody > tr." + rowSelector).remove();
	}
	
	function deleteDomainGroupRoleMappingRows(index) {
		var rowSelector = "domain-group-role-mapping-row___" + index;
		$("#domainGroupRoleMappingTable > tbody > tr." + rowSelector).remove();
	}
	
	function deleteUserOverrideMapDetail(row,index) {
		try {
			deleteUserSystemAdminLevelRow(row);
			deleteDomainRoleMappingRows(index);
			deleteDomainGroupRoleMappingRows(index);
			reassignUserSystemAdminRowIds();
			return true;
		} catch(ex) {
			return false;
		}
	}
	
	$("#userSystemAdminLevelTableRowAdd").click(function(){
		var userSystemAdminLevelTable = $("#userSystemAdminLevelTable");
		var rowDom = getUserSystemAdminLevelTableRow();
		userSystemAdminLevelTable.append(rowDom);
	});
	
	function reassignUserSystemAdminRowIds(){
		var index = 0;
		$("#userSystemAdminLevelTable > tbody > tr").each(function() {
			var oldIndex = $(this).attr("id").split("___")[1];
			$(this).attr("id", "userSystemAdminLevelRow___" + index);
			var userId = "userOverrideMapDetailsViewModel[" + index + "].userId";
			var userIdElement = $(this).find("input.user-id");
			userIdElement.attr("name", userId);
			
			var systemAdminLevelId = "userOverrideMapDetailsViewModel[" + index + "].systemAdminLevel";
			var systemAdminLevelElement = $(this).find("input.admin-level");
			systemAdminLevelElement.attr("name", systemAdminLevelId);
					
			updateDomainRoleTable(oldIndex, index);
			updateDomainGroupRoleTable(oldIndex, index);
			index++;
		});
	}
	
	function updateDomainRoleTable(oldIndex, newIndex) {
		var oldClass = "domain-role-mapping-row___" + oldIndex;
		var newClass = "domain-role-mapping-row___" + newIndex;
		var index = 0;
		$("#domainRoleMappingTable ." + oldClass).each(function() {
			$(this).attr("class", newClass);
			$(this).find(".domain-id").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].domainDetails[" + index + "].domainId");
			$(this).find(".admin-level").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].domainDetails[" + index + "].domainAdminLevel");
			$(this).find(".role").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].domainDetails[" + index + "].role");
			index++;
		});
	}
	
	function updateDomainGroupRoleTable(oldIndex, newIndex) {
		var oldClass = "domain-group-role-mapping-row___" + oldIndex;
		var newClass = "domain-group-role-mapping-row___" + newIndex;
		var index = 0;
		$("#domainGroupRoleMappingTable ." + oldClass).each(function() {
			$(this).attr("class", newClass);
			$(this).find(".domain-id").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].groupDetails[" + index + "].domainId");
			$(this).find(".group-id").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].groupDetails[" + index + "].groupId");
			$(this).find(".admin-level").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].groupDetails[" + index + "].groupAdminLevel");
			$(this).find(".role").attr("name", "userOverrideMapDetailsViewModel[" + newIndex + "].groupDetails[" + index + "].role");
			index++;
		});
	}
	
	/*END :: UserSystemAdminLevelTable UI DOM manipulation*/
	
	/*START :: DomainRoleMappingTable UI DOM creation*/
	
	function getDomainIdTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].domainDetails["+rowIndex+"].domainId";
		return getInputBoxTd(name, "domain-id form-control height-33");
	}
	
	function getDomainAdminLevelTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].domainDetails["+rowIndex+"].domainAdminLevel";
		var optionList = ["Admin","Member"];
		return getDropDownTd(name, optionList, "", "admin-level form-control height-33");
	}
	
	function getRoleTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].domainDetails["+rowIndex+"].role";
		return getInputBoxTd(name, "role form-control height-33");
	}
	
	function getDomainRoleMappingTableRow() {		
		var domainRoleMapping = $("<tr></tr>");
		var selectedUserSystemTableRowVal = getSelectedUserSystemValue();
		if(selectedUserSystemTableRowVal === null || selectedUserSystemTableRowVal === "") {
			alert("Please select a row from System admin table");
			return;
		}
		var rowIndex = $(".domain-role-mapping-row___"+ selectedUserSystemTableRowVal).length;
		
		domainRoleMapping.attr("class", "domain-role-mapping-row___" + selectedUserSystemTableRowVal);
		domainRoleMapping.click(domainRoleMappingTableRow_ClickHandler);
		
		var domainIdTd = getDomainIdTd(selectedUserSystemTableRowVal, rowIndex);
		var systemAdminTd = getDomainAdminLevelTd(selectedUserSystemTableRowVal, rowIndex);
		var roleTd = getRoleTd(selectedUserSystemTableRowVal, rowIndex);
		
		domainRoleMapping.append(domainIdTd);
		domainRoleMapping.append(systemAdminTd);
		domainRoleMapping.append(roleTd);
		return domainRoleMapping;
	}
	
	/* END :: DomainRoleMappingTable UI DOM creation*/
	
	/* START :: DomainRoleMappingTable UI DOM manipulation*/
	
	$("#domainRoleMappingTableRowRemove").click(function(){
		deleteDomainRoleMappingRow();
	});
	
	function deleteDomainRoleMappingRow() {
		var index = getSelectedUniqueDomainRoleRowValue();
		if(index === null || index === "") {
			alert("Please select any row in Domain Role table.");
		} else {
			var deleteConfirmation = confirm("Are you sure you want to delete?");
			if(deleteConfirmation) {
				getSelectedUniqueDomainRoleRowValue().remove();
				reassignDomainRoleMappingRowIds();
				setSelectedUniqueDomainRoleRowValue(null);
			}
		}
	}
		
	$("#domainRoleMappingTableRowAdd").click(function(){
		var domainRoleMappingTable = $("#domainRoleMappingTable");
		var rowDom = getDomainRoleMappingTableRow();
		domainRoleMappingTable.append(rowDom);
	});
	
	function reassignDomainRoleMappingRowIds(){
		var selectedIndex = getSelectedUserSystemValue();
		var index2 = 0;
		$("#domainRoleMappingTable > tbody > tr.domain-role-mapping-row___" + selectedIndex).each(function() {
			var domainId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].domainDetails[" + index2 + "].domainId";
			var domainIdElement = $(this).find("input.domain-id");
			domainIdElement.attr("name", domainId);
		
			var domainAdminLevelId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].domainDetails[" + index2 + "].domainAdminLevel";
			var domainAdminLevelElement = $(this).find("input.admin-level");
			domainAdminLevelElement.attr("name", domainAdminLevelId);
	
			var roleId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].domainDetails[" + index2 + "].role";
			var roleElement = $(this).find("input.role");
			roleElement.attr("name", roleId);
			index2++;
		});
	}
	
	/* END :: DomainRoleMappingTable UI DOM manipulation*/
	
	/* START :: DomainGroupRoleMappingTable UI DOM creation*/
	
	function getDomainGroupIdTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].groupDetails["+rowIndex+"].domainId";
		return getInputBoxTd(name, "domain-id form-control height-33");
	}
	
	function getGroupId(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].groupDetails["+rowIndex+"].groupId";
		return getInputBoxTd(name, "group-id form-control height-33");
	}
	
	function getDomainGroupAdminLevelTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].groupDetails["+rowIndex+"].groupAdminLevel";
		var optionList = ["Admin","Member"];
		return getDropDownTd(name, optionList, "", "admin-level form-control height-33");
	}
	
	function getGroupRoleTd(selectedUserSystemTableRowVal, rowIndex) {
		var name = "userOverrideMapDetailsViewModel["+selectedUserSystemTableRowVal+"].groupDetails["+rowIndex+"].role";
		return getInputBoxTd(name, "role form-control height-33");
	}
	
	function getDomainGroupRoleMappingTableRowAddRow() {
		var domainGroupRoleMapping = $("<tr></tr>");
		var selectedUserSystemTableRowVal = getSelectedUserSystemValue();
		if(selectedUserSystemTableRowVal === null || selectedUserSystemTableRowVal === "") {
			alert("Please select a row from System admin table");
			return;
		}
		var rowIndex = $(".domain-group-role-mapping-row___"+ selectedUserSystemTableRowVal).length;
		domainGroupRoleMapping.attr("class", "domain-group-role-mapping-row___" + selectedUserSystemTableRowVal);
		domainGroupRoleMapping.click(domainGroupRoleMappingTableRow_ClickHandler);
		
		var domainIdTd = getDomainGroupIdTd(selectedUserSystemTableRowVal, rowIndex);
		var groupIdTd = getGroupId(selectedUserSystemTableRowVal, rowIndex);
		var systemAdminTd = getDomainGroupAdminLevelTd(selectedUserSystemTableRowVal, rowIndex);
		var roleTd = getGroupRoleTd(selectedUserSystemTableRowVal, rowIndex);
		
		domainGroupRoleMapping.append(domainIdTd);
		domainGroupRoleMapping.append(groupIdTd);
		domainGroupRoleMapping.append(systemAdminTd);
		domainGroupRoleMapping.append(roleTd);
		return domainGroupRoleMapping;
	}
	
	/* END :: DomainGroupRoleMappingTable UI DOM creation*/
	
	/* START :: DomainGroupRoleMappingTable UI DOM manipulation*/
	
	$("#domainGroupRoleMappingTableRowRemove").click(function(){
		deleteDomainGroupRoleMappingRow();
	});
	
	function deleteDomainGroupRoleMappingRow() {
		var index = getSelectedUniqueDomainGroupRoleRowValue();
		if(index === null || index === "") {
			alert("Please select any row in Domain Group Role table.");
		} else {
			var deleteConfirmation = confirm("Are you sure you want to delete?");
			if(deleteConfirmation) {
				getSelectedUniqueDomainGroupRoleRowValue().remove();
				reassignDomainGroupRoleMappingRowIds();
				setSelectedUniqueDomainGroupRoleRowValue(null);
			}
		}
	}
	
	$("#domainGroupRoleMappingTableRowAdd").click(function(){
		var domainGroupRoleMappingTable = $("#domainGroupRoleMappingTable");
		var rowDom = getDomainGroupRoleMappingTableRowAddRow();
		domainGroupRoleMappingTable.append(rowDom);
	});
	
	function reassignDomainGroupRoleMappingRowIds(){	
		var selectedIndex = getSelectedUserSystemValue();
		var index2 = 0;
		$("#domainGroupRoleMappingTable > tbody > tr.domain-group-role-mapping-row___" + selectedIndex).each(function() {
			var domainId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].groupDetails[" + index2 + "].domainId";
			var domainIdElement = $(this).find("input.domain-id");
			domainIdElement.attr("name", domainId);
			
			var groupId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].groupDetails[" + index2 + "].groupId";
			var groupIdElement = $(this).find("input.group-id");
			groupIdElement.attr("name", groupId);
			
			var groupAdminLevelId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].groupDetails[" + index2 + "].groupAdminLevel";
			var groupAdminLevelElement = $(this).find("input.admin-level");
			groupAdminLevelElement.attr("name", groupAdminLevelId);
		
			var roleId = "userOverrideMapDetailsViewModel[" + selectedIndex + "].groupDetails[" + index2 + "].role";
			var roleElement = $(this).find("input.role");
			roleElement.attr("name", roleId);
			index2++;
		});	
	}
	
	/* END :: DomainGroupRoleMappingTable UI DOM manipulation*/
	
	initializeUserOverrideMap();
});