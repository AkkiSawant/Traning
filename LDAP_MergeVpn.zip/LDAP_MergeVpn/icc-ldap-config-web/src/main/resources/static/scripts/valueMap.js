$(document).ready(function(){
	
	//This variable saves currently selected value of UserSystemAdminLevelTable row
	var selectedUniqueRowValue = null;
	
	function getSelectedValueMapValue() {
		return selectedUniqueRowValue;
	}
	
	function setSelectedValueMapValue(uniqueVal) {
		selectedUniqueRowValue = uniqueVal;
	}
	
	/*START :: Code for ValueMapTable binding row click event*/
	
	function initializeValueMap() {
		bindTableRowClickHandler("valueMapTable", valueMapTableRow_ClickHandler);
	}
	
	function bindTableRowClickHandler(tableId, functionName){
		var tableRow = $("#" + tableId + " > tbody > tr");
		tableRow.click(functionName);
		return tableRow;
	}
	
	function valueMapTableRow_ClickHandler() {
		$(this).addClass('selected').siblings().removeClass('selected');
		setSelectedValueMapValue($(this)[0]);
    };
    
    /*END :: Code for ValueMapTable binding row click event*/
    
    /*START :: Utility function*/
          
    function getInputBoxTd(name, cssClass){
    	var input = $("<input></input>");
    	input.attr("name", name);
    	input.attr("class", cssClass);
		var td = $("<td></td>");
		td.append(input);
		return td;		
    }
    
    /*END :: Utility function*/
    
    /*START :: ValueMapTable UI DOM creation*/
    
	function getValueMapTableRow() {		
		var rowIndex = $("#valueMapTable > tbody > tr").length;
		var previousRowValid = false;
		if(rowIndex !== 0) {
			previousRowValid = validateValueMapRow(rowIndex - 1);
		}
		if(previousRowValid || rowIndex === 0) {	
			var valueMapRow = $("<tr></tr>");
			valueMapRow.attr("id", "valueMapRow_" + rowIndex);
			var ldapValueTd = getLdapValueTd(rowIndex);
			var applicationValueTd = getApplicationValueTd(rowIndex);
		
			valueMapRow.append(ldapValueTd);
			valueMapRow.append(applicationValueTd);
			valueMapRow.click(valueMapTableRow_ClickHandler);
			return valueMapRow;
		}
	}
	
	function getLdapValueTd(rowIndex) {
		var name = "valueMapVm.valueMap[" + rowIndex + "].ldapValue";
		return getInputBoxTd(name, "form-control height-33 ldap-value");
	}
	
	function getApplicationValueTd(rowIndex) {
		var name = "valueMapVm.valueMap[" + rowIndex + "].applicationValue";
		return getInputBoxTd(name, "form-control height-33 application-value");
	}
	
	/*END :: ValueMapTable UI DOM creation*/
	
	/* START :: ValueMapTable UI DOM manipulation*/
	
	function validateValueMapRow(rowNum) {
		var ldapValue = $("#valueMapRow_" + rowNum).find("input.ldap-value").val();
		var applicationValue = $("#valueMapRow_" + rowNum).find("input.application-value").val();
		
		if(ldapValue && applicationValue) {
			return true;
		}
		return false;
	}
	
	function deleteValueMapRow() {
		var index = getSelectedValueMapValue();
		if(index === null) {
			alert("Please select any row in Value Map table.");
		} else {
			var deleteConfirmation = confirm("Are you sure you want to delete?");
			if(deleteConfirmation) {
				getSelectedValueMapValue().remove();
				reassignValueMapRowIds();
				setSelectedValueMapValue(null);
			}
		}
	}
	
	function reassignValueMapRowIds(){
		var index = 0;
		$("#valueMapTable > tbody > tr").each(function() {
			$(this).attr("id", "valueMapRow_" + index);
			var ldapValueId = "valueMapVm.valueMap[" + index + "].ldapValue";
			var ldapValueElement = $(this).find("input.ldap-value");
			ldapValueElement.attr("name", ldapValueId);
		
			var applicationValueId = "valueMapVm.valueMap[" + index + "].applicationValue";
			var applicationValueElement = $(this).find("input.application-value");
			applicationValueElement.attr("name", applicationValueId);
			index++;
		});
	}
	
	$("#removeValueMapRow").click(function(){
		deleteValueMapRow();
	});
	
	$("#addValueMapRow").click(function(){
		var valueMapTable = $("#valueMapTable");
		var rowDom = getValueMapTableRow();
		valueMapTable.append(rowDom);
	});
		
	/* END :: ValueMapTable UI DOM manipulation*/
	
	initializeValueMap();
});