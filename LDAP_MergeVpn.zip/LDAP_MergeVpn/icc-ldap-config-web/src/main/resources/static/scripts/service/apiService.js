(function() {
	angular.module('TreeApp', [ 'ui.tree'])
    	.factory('apiService', ['$http', '$q', function($http, $q) {
	        var self = this;
	        self.callApi = function(apiConfig) {
	            var deferred = $q.defer();
	            var httpRequest = {};
	
	            httpRequest.method = apiConfig.method;
	            httpRequest.url = apiConfig.url;
	            httpRequest.contentType = apiConfig.contentType;
	            if(apiConfig.hasOwnProperty("data")) {
	            	httpRequest.data = apiConfig.data;
	            }
	            httpRequest.headers = {};
	
	            $http(httpRequest)
	                .success(function(data) {
	                    deferred.resolve(data);
	                }).error(function(err) {
	                    deferred.resolve(err);
	                });
	            return deferred.promise;
	        };
	        return self;
	    }]);
})();