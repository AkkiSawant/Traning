(function() {
	angular.module('TreeApp').controller('TreeViewController',
			[ "$scope", "$timeout", "apiService", TreeViewController ]);

	function TreeViewController($scope, $timeout, apiService) {
		$scope.list = [];
		$scope.loading = false;
		$scope.toggling = function(scope, node) {
			if (node.nodes === null || (node.nodes.length === 1 && node.nodes[0].hasOwnProperty("title") !== "")) {

				var request = {};
				request.domainModel = $('#domainmodel:checked').val();
				request.rootDistinguishedName = node.attributeMap.distinguishedname.attributes[0];
				request.modelGrouping = $("input[type='radio'][name='modelGrouping']:checked").val();
				request.fetchNewTree = false;
				
				$scope.loading = true;
				var treeApiConfig = {
					url : "rest/ldap-data",
					method : 'POST',
					contentType : 'application/json',
					data : JSON.stringify(request)
				};

				apiService.callApi(treeApiConfig).then(function(res) {
					if (res && res.title === node.title) {
						var count = res.nodes.length;
						for (var i = 0; i < count; i++) {
							node.nodes.push(res.nodes[i]);
						}
						$scope.hideEmptyNodes();
						
						if(count === 1 && res.nodes[0].title === "") {
							scope.collapse();
						} else {
							scope.toggle();
							scope.expand();
						}
					}
					
				}, function(err) {
					console.error("Error in fetching treedata:");
					console.error(err);
				}).finally(function () {
				      // Hide loading spinner whether our call succeeded or failed.
				      $scope.loading = false;
				    });
			} else {
				scope.toggle();
			}
		}

		$scope.hideEmptyNodes = function() {
			$timeout(function() {
				$('.tree-node').each(function() {
					if ($(this).children().length !== 0) {
						$(this).show();
						$(this).parent().show();
					} else {
						$(this).parent().hide();
					}
				});
			}, 200);
		}

		var apiConfig = {
			url : "rest/session-ldap-data",
			method : 'get',
			contentType : 'application/json'
		};

		apiService.callApi(apiConfig).then(function(res) {
			if (res) {
				$scope.list = [ res ];
				$scope.hideEmptyNodes();
			}
		}, function(err) {
			console.error("Error in fetching treedata:");
			console.error(err);
		});
	}
})();
