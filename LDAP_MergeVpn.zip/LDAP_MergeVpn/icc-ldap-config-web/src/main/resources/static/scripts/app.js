$(document).ready(function() {
/*
 * start of script for handling ui on connection details page
 */
	
	function bindCheckboxChangeEvents() {
		var checkboxViewMap = Object.create(null);
		
		checkboxViewMap["clientCertificateCheck"] = "clientCertificate";
		checkboxViewMap["serverIdentityCheck"] = "serverIdentityDiv";
		checkboxViewMap["serverCertificateCheck"] = "serverCertificate";
		
		for(var checkbox in checkboxViewMap) {
			var checkboxSelector = "#" + checkbox;
			$(checkboxSelector).on("change", toggleViewOnCheckboxChange);		
		}
		
		function toggleViewOnCheckboxChange() {
			var checkboxId =  $(this).attr("id");
			toggleView(checkboxId);
		}

		function toggleView(checkboxId){
			var view = checkboxViewMap[checkboxId];
			var viewSelector = "#" + view;
			var checkboxSelector = "#" + checkboxId;
			if ($(checkboxSelector).is(":checked")) {
				$(viewSelector).show();
			} else {
				$(viewSelector).hide();
			}
		}
		
		function invokeToggleView() {
			for(var checkbox in checkboxViewMap) {
				toggleView(checkbox);
			}
		}
		
		invokeToggleView();
	}
	
	bindCheckboxChangeEvents();
	
	function onConnectionTypeChange() {
		if ($('#connectionType') && $('#connectionType').val() && $('#connectionType').val().toLowerCase() === "basic") {
			$("#additionalDetails").addClass("lcw-hidden");
		} else {
			$("#additionalDetails").removeClass("lcw-hidden");
		}
	}

	$('#connectionType').on('change', onConnectionTypeChange);
	onConnectionTypeChange();

	function onClientCertificateStoreChange() {
		if ($("#clientCertificateStore1").is(":checked")) {
			$("#clientCertificateStore").show();
			$("#clientCertificateDirectoryPath").hide();
		} else {
			$("#clientCertificateStore").hide();
			$("#clientCertificateDirectoryPath").show();
		}
	}
	$("#clientCertificateStore1").change(onClientCertificateStoreChange);
	$("#clientCertificateStore2").change(onClientCertificateStoreChange);
	onClientCertificateStoreChange();
	
	function onServerCertificateStoreChange() {
		if ($("#serverCertificateStore1").is(":checked")) {
			$("#serverCertificateDirectoryPath").hide();
		} else {
			$("#serverCertificateDirectoryPath").show();
		}
	}
	$("#serverCertificateStore1").change(onServerCertificateStoreChange);
	$("#serverCertificateStore2").change(onServerCertificateStoreChange);
	onServerCertificateStoreChange();
		
	function onServerKeystoreChange() {
		if ($("#serverKeystore1").is(":checked")) {
			$("#serverCertificateDirectoryPath").hide();
		} else {
			$("#serverCertificateDirectoryPath").show();
		}
	}
	$("#serverKeystore1").change(onServerKeystoreChange);
	$("#serverKeystore2").change(onServerKeystoreChange);
	onServerKeystoreChange();
	
	/*
	 * end of script for handling ui on connection details page
	 */
	/*
	 * start of script for making ajax call and creation of tree on frontend
	 */
	$('#showTree').click(showLDAPTree);
	
	function setLdapError() {
		$('#ldapError').hide();
	}
	
	setLdapError();
		
	function showLDAPTree() {
		setLdapError();
		$('.text-danger').empty();
		var data = {};
	    data["domainModel"] = $('#domainmodel:checked').val();
	    data["rootDistinguishedName"] = $('#distinguishedname').val();
	    data["modelGrouping"] = $("input[type='radio'][name='modelGrouping']:checked").val();
	    data['fetchNewTree'] = true;
	    
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : "rest/ldap-data",
			data : JSON.stringify(data),
			success : function(data) {
				console.log("SUCCESS: " + data);
				setTreeData([data]);
			},
			error : function(e,data) {
				console.log("ERROR: " + e);
				console.log("data " + data);
				/*
				 * start of script for binding validation messages on the page
				 */
				if(e.status===400){
					for (var i = 0; i < e.responseJSON.length; i++) {
						var item = e.responseJSON[i];
						var field=item.field;
						var $formField = $('#' + field);
						$formField.find('.text-danger').html(item.defaultMessage);
					}
				}
				
				if(e.status===500){
					$('#ldapErrorSpan')[0].innerText = e.responseText;
					$('#ldapError').show();
					setTreeData([]);
				}else{
					$('#ldapError').hide();
				}
				/*
				 * end of validation binding script
				 */
			}
		});
	}
	
	function setTreeData(data) {
		var appElement = document.querySelector('[data-ng-app=TreeApp]');
        var appScope = angular.element(appElement).scope();
        var controllerScope = appScope.$$childHead;
        controllerScope.$apply(function() {
        	controllerScope.list = data;
        	controllerScope.treeload = true;
        	controllerScope.hideEmptyNodes();
        }); 
	}
	/*
	 * end of ajax call script
	 */
	
	$("#serverIdentity").click(getServerIdentity);
	
	function getServerIdentity(){
		var data = {};
	    data["domainHost"] = $("input[type='text'][name='domainHost']").val();
	    data["port"] = $("#defaultPort").val();
	    data["connectionType"]=$("#connectionType").val();
		$.ajax({
			type : "POST",
			contentType : "application/json",
			url : "rest/serverIdentity",
			data : JSON.stringify(data),
			success : function(data) {
				console.log("SUCCESS: " + data);
				$("#serverIdentityPath").val(data);
			},
			error : function(e,data) {
				console.log("ERROR: " + e);
				console.log("data " + data);
				$("#serverIdentityPath").val("");
				if(e.status===500){
					$('#ldapErrorSpan')[0].innerText = e.responseJSON;
					$('#ldapError').show();
				}else{
					$('#ldapError').hide();
				}
			}
		});
	}
	
	$("#serverCertificateButton").click(validateServerCert);
	
	function validateServerCert() {
		$('#ldapError').hide();
		$('#ldapSuccess').hide();  
        var retrivedPath = $("#serverCertificatePath").val();
        
        var empty = rejectEmptyPath(retrivedPath);
        if(!empty) {
        	validatePath(retrivedPath);
        }
        
        
        function rejectEmptyPath(retrivedPath) {
        	var empty = (!retrivedPath);
        	if(empty) {
            	displayError("Please provide server cerificate path");	
            }
        	return empty;
        }
        
        function validatePath(retrivedPath) {
        	var pattern = new RegExp("([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+\\\\?(.jks|.crt)");
        	var retrivedPathValid = pattern.test(retrivedPath);
        	if(retrivedPathValid) {     		
            	getServerCert();
            }
            else {
            	displayError("Invalid server cerificate path");	
            }
        }
        
        
		function getServerCert(){
			var data = getConnectionData();
			$.ajax({
				type : "POST",
				contentType : "application/json",
				url : "rest/serverCerts",
				data : JSON.stringify(data),
				success : getServerCertSuccess,
				error : getServerCertError
			});
				
			function getConnectionData(){
				var data = Object.create(null);
			    data["domainHost"] = $("input[type='text'][name='domainHost']").val();
			    data["port"] = $("#defaultPort").val();
			    data["connectionType"]=$("#connectionType").val();
			    data["storeLocation"]=$("#serverCertificatePath").val();
			    data["storePassword"]=$("#serverCertificatePassword").val();
			    return data;
			}
			
			function getServerCertSuccess(message) {
				displaySuccess(message);
				console.log("SUCCESS: " + message);
			}
	
			
			function getServerCertError(e,result) {
				console.log("ERROR: " + e);
				console.log("result " + result);
				if(e.status===500){
					displayError(e.responseText);
				}
			}
		}
			
			
		function displaySuccess(successMessage) {
			$('#ldapSuccessSpan').text(successMessage);
			$('#ldapSuccess').show();
		}

		function displayError(errorMessage) {
			$('#ldapErrorSpan').text(errorMessage);
        	$('#ldapError').show();
		}	
	}
});

$(window).bind("load", function() {
	repositionMainContents();

	function repositionMainContents() {
		var windowHeight = $(window).height(); 
		$(".lcw-main-scrollable-area").height(windowHeight - 200);
	}
	$(window).scroll(repositionMainContents).resize(repositionMainContents);
});


function serverChecked(value, serverName) {

	var sendInfo = JSON.stringify({
			'Enable': value.checked,
			'ServerName': serverName
	});

	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "rest/enableServer",
		data : sendInfo,
			success : function(data) {
				console.log("SUCCESS: "+ data);
			},
			error : function(e,data) {
				console.log("ERROR: "+ e);
				console.log("data " + data);
			}
	}); 
}


$(function() {
    //This function will drag a particular element from tree node.
    $(".draggable div").draggable({
        appendTo: "body",
        helper: "clone",
        addClasses: false,
        cursor: "select",
        cursorAt: {
            bottom: 0
        }
    });

    //This function will treat as a droppable for tree element.
    //Add this class="droppable" for droppable events
    $(".droppable").droppable({
        hoverClass: 'active',
        drop: function(event, ui) {
            //Get custom element : 
            this.value = ui.draggable.parent()[0].getAttribute("data-custom");
            try {
            	setTabStates();
            } catch(err) {
            	console.error(err);
            }
        },
        accept: function(element) {
            //This method is for validation.
            //if($(d).text().trim() === "User 3")
            if (element) {
                return true;
            }
        }
    });

    //This function will treat as a droppable for tree element.
    //Add this class="droppable" for droppable events
    $(".droppable-org-domain").droppable({
        hoverClass: 'active',
        drop: function(event, ui) {
            //Get custom element : 
            if (this.value === "" || this.value === null) {
                this.value = ui.draggable.parent()[0].getAttribute("data-value");
            } else {
                this.value += "," + ui.draggable.parent()[0].getAttribute("data-value");
            }
        }
    });



    var $body = $("body");
    $(document).on({
        ajaxStart: function() {
            $body.addClass("loading");
        },
        ajaxStop: function() {
            $body.removeClass("loading");
        }
    });

    refreshSelectedList();

    $("#addAttribute").click(function() {
        $("#totalAttributeList > option:selected").each(function() {
            $(this).remove().appendTo("#selectedAttributeList");
            $(this).prop("selected", false);
            refreshSelectedList();
        });
    });

    $("#removeAttribute").click(function() {
        $("#selectedAttributeList > option:selected").each(function() {
            $(this).remove().appendTo("#totalAttributeList");
            $(this).prop("selected", false);
            refreshSelectedList();
        });
    });

    function refreshSelectedList() {
        var selectedAttr = "";
        $("#selectedAttributeList option").each(function() {
            selectedAttr += $(this).val() + ",";
        });
        selectedAttr = selectedAttr.substring(0, selectedAttr.length - 1);
        $("#selectedReturnedAttributes").val(selectedAttr);
    }

    setAttributeMapTableState("initial");

    $("#hideAttributeMap, #showAttributeMap").change(setAttributeMapTableState);

    function setAttributeMapTableState(event) {
        if ($("#hideAttributeMap") && $("#hideAttributeMap")[0]) {
            if ($("#hideAttributeMap")[0].checked) {
                $("#attributeMapView").hide();
            } else {
                $("#attributeMapView").show();
                if (event !== "initial") {
                    fetchLdapProperties();
                }
            }
        }
    }

    var checkboxTabIdMap = {
        "enableReturnedAttributes": {
            "Link": "#returnedAttributesLink",
            "Anchor": "#returnedAttributesAnchor"
        },
        "enableAttributeMap": {
            "Link": "#attributeMapLink",
            "Anchor": "#attributeMapAnchor"
        },
        "enableValueMap": {
            "Link": "#valueMapLink",
            "Anchor": "#valueMapAnchor"
        }
    };

    function attributeMapTab_Click() {
    	if($("#hideAttributeMap") && $("#hideAttributeMap")[0] && (!$("#hideAttributeMap")[0].checked)) {
    		var newDn = $("#basicInfoVmTargetDn").val();
    		var oldDn = $("#oldTargetDn").text();
    		var classType=$("#classType").val();
    		
    		if(classType.toLowerCase() !== "domain") {
    			var newFilter = $("#basicInfoVmfilter").val();
    			var oldFilter = $("#oldFilter").text();
    		}
    		
    		if(oldDn !== newDn || (classType.toLowerCase() !== "domain" && oldFilter !== newFilter)) {
    			fetchLdapProperties();
    		}
    	}
    }

    function fetchLdapProperties() {

        var classType = $("#classType").val();
        var newDn = $("#basicInfoVmTargetDn").val();

        var sendInfo = {};
        sendInfo.dn = newDn;
        sendInfo.classType = classType;

        if (classType.toLowerCase() === "domain") {
            sendInfo.filter = $("#oldFilter").text();
        } else {
            var newFilter = $("#basicInfoVmfilter").val();
            sendInfo.filter = newFilter;
        }
        var sendInfoStr = JSON.stringify(sendInfo);

        $.ajax({
            type: "POST",
            contentType: "application/json",
            url: "rest/attributeMap",
            data: sendInfoStr,
            success: function(data) {
                if (data.hasOwnProperty("ldapAttribute")) {
                    var optionList = generateOptionListFromMap(data.ldapAttribute);
                    
                    $(".ldap-properties").each(function() {
                        var selectBox = $(this);
                        var selectedVal = selectBox.val();
                        selectBox.empty().append(optionList);
                        selectBox.val(selectedVal);
                        var tr = selectBox.closest("tr");
                        var ignoreInput = tr.find("td.ignore-flag input");
                        if(!data.ldapAttribute.hasOwnProperty(selectedVal)){
                        	ignoreInput.attr("checked", true);
                        }
                    });
                }
                if (data.hasOwnProperty("staticAttribute")) {
                    var identityLdapPropertyMap = data.staticAttribute;

                    $(".ldap-properties").each(function() {
                        var selectBox = $(this);
                        var tr = selectBox.closest("tr");
                        var identityInput = tr.find("td.identity-property input");
                        var ignoreInput = tr.find("td.ignore-flag input");
                        var identityVal = identityInput.val();
                        
                        if (identityLdapPropertyMap.hasOwnProperty(identityVal)) {
                            var option = generateOptionListFromArr([identityLdapPropertyMap[identityVal]]);
                            selectBox.empty().append(option);
                            selectBox.val(identityLdapPropertyMap[identityVal]);
                            if(!data.staticAttribute.hasOwnProperty(identityVal)){
                            	ignoreInput.attr("checked", true);
                            }
                        }
                    });
                }
                $("#oldTargetDn").html($("#basicInfoVmTargetDn").val());
                if ($("#classType").val().toLowerCase() !== "domain") {
                    $("#oldFilter").html($("#basicInfoVmfilter").val());
                }
            },
            error: function(err, data) {
                console.error(err);
                console.error(data);
            }
        });
    }

    function generateOptionListFromMap(attributeMap) {
        var optionList = "";
        for (var attribute in attributeMap) {
            if (attributeMap.hasOwnProperty(attribute)) {
                optionList += "<option value='" + attribute + "'>" + attribute + "</option>";
            }
        }
        return optionList;
    }

    function generateOptionListFromArr(attributes) {
        var optionList = "";
        for (var attributeIndex = 0; attributeIndex < attributes.length; attributeIndex++) {
            optionList += "<option value='" + attributes[attributeIndex] + "'>" + attributes[attributeIndex] + "</option>";
        }
        return optionList;
    }

    function setInitialTabStates() {
        setInitialTabState("enableReturnedAttributes");
        setInitialTabState("enableAttributeMap");
        setInitialTabState("enableValueMap");
    }
    setInitialTabStates();

    $("#enableReturnedAttributes").change(onCheckboxChange);
    $("#enableAttributeMap").change(onCheckboxChange);
    $("#enableValueMap").change(onCheckboxChange);
    $("#basicInfoVmTargetDn").on("input", onTargetDnChange);
    $("#basicInfoVmTargetDn").on("change", onTargetDnChange);

    function onCheckboxChange(eventObj) {
        setTabState(eventObj.target.id, eventObj);
    }

    function onTargetDnChange(event) {
        setTabStates();
    }

    function setInitialTabState(id) {
        var targetDnValid = testTargetDn();
        toggleTabState(id, targetDnValid);
    }

    function testTargetDn() {
        var pattern = new RegExp("^(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*(?:,(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*)*$");
        var targetDn = $("#basicInfoVmTargetDn").val();
        return pattern.test(targetDn);
    }

    function setTabState(id, event) {
        var targetDnValid = checkTargetDn(event);
        toggleTabState(id, targetDnValid);
    }

    function setTabStates() {
        for (var tab in checkboxTabIdMap) {
            setTabState(tab);
        }
    }

    function toggleTabState(id, targetDnValid) {
        if ($("#" + id)[0] && $("#" + id)[0].checked && targetDnValid) {
            enableTab(id);
        } else {
            disableTab(id);
        }
    }

    function enableTab(id) {
        $(checkboxTabIdMap[id].Link).removeClass("disabled");
        $(checkboxTabIdMap[id].Anchor).attr("data-toggle", "tab");
        if ("#attributeMapAnchor" === checkboxTabIdMap[id].Anchor) {
            var events = $._data(document.getElementById('attributeMapAnchor'), "events");
            if (!events || events === null || (!events.hasOwnProperty("click"))) {
                $(checkboxTabIdMap[id].Anchor).on("click", attributeMapTab_Click);
            }
        }
    }

    function disableTab(id) {
        $(checkboxTabIdMap[id].Link).addClass("disabled");
        $(checkboxTabIdMap[id].Anchor).removeAttr("data-toggle");
        if ("#attributeMapAnchor" === checkboxTabIdMap[id].Anchor) {
            $(checkboxTabIdMap[id].Anchor).off("click");
        }
    }

    function setSecurityGroupState() {
        
        if($("#ldapGroupRepresentation2") && $("#ldapGroupRepresentation2")[0] && $("#ldapGroupRepresentation2")[0].checked) {
            $('#securityGroup').show();
        } else {
            $('#securityGroup').hide();
        }
        
        if($("#enableNamePattern").is(":checked")) {
            $("#namePatternView").show();
        } else {
            $("#namePatternView").hide();
        }

        $('input[type="radio"]').change(function() {
            if ($("input[name='basicInfoVm.ldapGroupRepresentation']:checked").attr("id") === "ldapGroupRepresentation2") {
                $('#securityGroup').show();
            } else if ($("input[name='basicInfoVm.ldapGroupRepresentation']:checked").attr("id") === "ldapGroupRepresentation1")
                $('#securityGroup').hide();
        });
    }

    setSecurityGroupState();
});


//show/hide attribute map
$(document).ready(function() {
	
	setValueMapTableState();
	
	$("#hideValueMap, #showValueMap").change(setValueMapTableState);
	
	function setValueMapTableState() {
		if($("#hideValueMap") && $("#hideValueMap")[0] && $("#hideValueMap")[0].checked) {
			$("#valueMapView").hide();
		}
		else {
			$("#valueMapView").show();
		}
	}
	
});

$(document).ready(function() {
	function showLdapList() {
	    var targetDn = $("#basicInfoVmTargetDn").val();
	    var filter = $("#basicInfoVmfilter").val();
	    var classType = $("#classType").val();
	    var noMap = $("#hideAttributeMap").is(":checked");
	    var ldapProperties = getLdapProperties();

	    var sendInfo = JSON.stringify({
	        "userTargetDn": targetDn,
	        "filter": filter,
	        "classType": classType,
	        "noMap": noMap,
	        "ldapProperties": ldapProperties
	    });

	    $.ajax({
	        type: "POST",
	        contentType: "application/json",
	        url: "rest/ldapSearch",
	        data: sendInfo,
	        success: getLdapRolesSuccess,
	        error: getLdapRolesError
	    });
	}

	function getLdapRolesSuccess(data) {

	    if (data !== null && data.length > 0) {
	        createSearchResultTable(data);
	    } else {
	        setError();
	    }
	}

	function getLdapRolesError(e, data) {
	    setError();
	}

	function setError() {
	    $("#searchResultTable > tbody > tr").remove();

	    var error = $("<div id='errorMsg'></div>");
	    error.html("No results returned. Please check Target Dn and Identity filter.");
	    $("#errorMsg >").remove();
	    $("#searchResultModal").html(error);
	    $("#searchResult").modal("show");
	}

	$("#showLdapList").click(showLdapListListener);

	function showLdapListListener(event) {
	    if (checkTargetDn(event)) {
	        showLdapList();
	    }
	}

	function getLdapProperties() {
	    var properties = [];
	    $(".ignore-attribute").each(optionallyAddProperty);
	    return properties;

	    function optionallyAddProperty() {
	        var ignoreNode = $(this);
	        var attributeMapNode = ignoreNode.closest("tr");
	        var ldapProperty = attributeMapNode.find(".ldap-properties");
	        var ignored = ignoreNode[0].checked;
	        if (!ignored) {
	            properties.push(ldapProperty.val());
	        }
	    }
	}	

	 
	function createSearchResultTable(data) {
		if($("#searchResultTable").length === 0) {
			$("#searchResultModal").prepend('<table id="searchResultTable" class="table table-striped table-hover table-bordered"><thead></thead></table>');
			$("#errorMsg").empty();
		} 
		$("#searchResultTable > thead > tr").remove();
		$("#searchResultTable > tbody > tr").remove();
		
		var attributeMap = Object.create(null);
		var attributeList = getAttributeList(data, attributeMap);
		$("#searchResultTable thead").append(getHeader(attributeList, attributeMap));
		
		var rows = [];
		for(var i = 0; i < data.length; i++) {
			var row = createSearchResultRow(attributeList, data[i].attributeMap);
			rows.push(row);
		}
		$("#searchResultTable").append(rows);
		$("#searchResult").modal("show");
	}
	 
	function createSearchResultRow(attributeList, data) {
		var searchResultRow = createRow(attributeList, data);
		return searchResultRow;
	}

	function createRow(attributeList, data) {
		var searchResultRow = $("<tr></tr>");
		for(var i=0; i<attributeList.length; i++) {
			var attribute = attributeList[i];
			var searchResultRowTd = $("<td></td>");
			var searchResultRowTdValue = data[attribute] && data[attribute].attributes[0];
			searchResultRowTd.attr("title", searchResultRowTdValue);
			searchResultRowTd.html(searchResultRowTdValue);
			searchResultRow.append(searchResultRowTd);
		}
		return searchResultRow;
	}
	
	function updateAttributeList(attributes, attributeList, attributeMap) {
		for(var attribute in attributes) {
			if(attributeMap[attribute] == null) {
				attributeList.push(attribute);
				attributeMap[attribute] = attributes[attribute].ldapKey;
			}
		}
	}
	
	function getAttributeList(data, attributeMap) {
		var attributeList = [];
		for(var i = 0; i < data.length; i++) {
			var attributeMapData = data[i].attributeMap;
			updateAttributeList(attributeMapData, attributeList, attributeMap);
		}
		return attributeList;
	}
	
	function getHeader(attributeList, attributeMap) {
		var searchResultRow = $("<tr></tr>");
		for(var i=0; i<attributeList.length; i++){
			var SearchResultRowTh = $("<th></th>");
			var attribute = attributeList[i];
			var ldapKey = attributeMap[attribute];
			SearchResultRowTh.attr("title", ldapKey);
			SearchResultRowTh.html(ldapKey);
			searchResultRow.append(SearchResultRowTh);
		}
		return searchResultRow;
	}
});

//show/hide returned attributes view
$(document).ready(function() {
	
	setReturnedAttributesViewState();
	
	$("#configureReturnedAttributes").change(setReturnedAttributesViewState);
	
	function setReturnedAttributesViewState(){
		if($("#configureReturnedAttributes") && $("#configureReturnedAttributes")[0] && $("#configureReturnedAttributes")[0].checked) {
			$("#returnedAttributesView").show();
		}
		else {
			$("#returnedAttributesView").hide();
		}
	}
});

//show/hide name pattern view 
$(document).ready(function() {
	
	setNamePatternViewState();
	
	$("#enableNamePattern").change(setNamePatternViewState);
	
	function setNamePatternViewState(){
            
		if($("#enableNamePattern") && $("#enableNamePattern")[0] && $("#enableNamePattern")[0].checked) {
			$("#namePatternView").hide();
		}
		else {
			$("#namePatternView").show();
		}
	}
        
    setNameGroupPatternViewState();
	
	$("#enableGroupHierarchyPattern").change(setNameGroupPatternViewState);
	
	function setNameGroupPatternViewState(){
		if($("#enableGroupHierarchyPattern") && $("#enableGroupHierarchyPattern")[0] && $("#enableGroupHierarchyPattern")[0].checked) {
			$("#nameGroupPatternView").show();
		}
		else {
			$("#nameGroupPatternView").hide();
		}
	}
        
});


$(document).ready(function() {
	
	showAdvanceConnectionOptions();
	
	$("#advancedConnectionOption").change(showAdvanceConnectionOptions);
	
	function showAdvanceConnectionOptions(){
		if( $("#advancedConnectionOption") && $("#advancedConnectionOption")[0] && $("#advancedConnectionOption")[0].checked){
			$("#advanceConnectionOptionsPage").show();
		}else{
			$("#advanceConnectionOptionsPage").hide();
		}
	}
	
	showAdvanceConnectionOptions();
});


$(document).ready(function() {
	
	$( "#target" ).submit(function( event ) {
		
		if($( "#target" )[0] && $( "#target" )[0]["action"]) {
			var action = $( "#target" )[0]["action"];
			
			if(action.match) {
				if(action.match("domainIdentitySettings")) {
					validateDomainSetting(event);
				}  else if(action.match("userIdentitySettings")) {
					validateUserSetting(event);
				} else if(action.match("roleIdentitySettings")) {
					validateRoleSetting(event);
				} else if (action.match("groupIdentitySettings")) {
		                	validateGroupSetting(event);
			        } else if (action.match("connections")) {
		                	validateDefaultPort(event);
					validateTimeInput(event);
		            }
			}
			if(action.length === 2 && action[0].getAttribute("id") === "userAuthenticated") {
				$("body").addClass("loading");
			}
		} 
	});
	
	function checkFilterBox(event) {
		var filter = $("#basicInfoVmfilter").val();
		validateEmptyFilter(filter, event);
		validateImproperFilter(filter, event);	
	}
	
	function validateEmptyFilter(filter, event) {
		if(!filter) {
			$("#basicInfoVmfilterError").text("Please provide filter");
			prevent(event);
		} else {
			$("#basicInfoVmfilterError").text("");
		}
	}
	
	function validateImproperFilter(filter, event) {
		var valid = true;
		var stack = [];
		for(var i=0; i<filter.length; i++) {
			if(filter[i] == "(") {
				stack.push(filter[i]);
			}
			if(filter[i] == ")") {
				var topOfStack = stack.pop();
				if(topOfStack != "(") {
					valid = false;
				}
			}
		}
		valid = valid && (stack.length === 0);
		setImproperFilterError(valid, event);
	}
	
	function setImproperFilterError(valid, event) {
		if(!valid) {
			$("#basicInfoVmfilterError").text("Invalid filter");
			prevent(event);
		}
		else {
			$("#basicInfoVmfilterError").text("");
		}
	}
	
	function validateDefaultPort(event) {
		var defaultPort = $("#defaultPort").val();
		if(defaultPort <= 0 || defaultPort >= 2147483648) {
			$("#domainPortError").html("Port should be valid positive integer");
			event.preventDefault();
		} else {
			$("#domainPortError").html("");
		}
	}
	
	function validateDomainSetting(event) {
		 checkTargetDn(event);
		 validateValueMap(event);
	}
	
	function validateUserSetting(event) {
		checkFilterBox(event);
		checkTargetDn(event); 
		validateValueMap(event);
	}
	
	function validateRoleSetting(event) {
		checkFilterBox(event); 
		checkTargetDn(event);
		checkRolePattern(event);
		validateValueMap(event);
	}
        
    function validateGroupSetting(event) {
		checkFilterBox(event);
		checkTargetDn(event);
		checkGroupPattern(event);
		validateValueMap(event);
    }
    
    function validateValueMap(event) {
    	var valueMapEnabled = $("#enableValueMap").is(":checked") && $("#showValueMap").is(":checked");
    	if(valueMapEnabled) {
    		validateValueMapTable(event);
    	}
    }
    
    function validateValueMapTable(event) {
    	var requiredFields = Object.create(null);
    	var empty = validateEmpty(requiredFields);
    	var duplicate = validateDuplicate();
    	if(empty || duplicate) {
    		setDuplicateError(duplicate);
        	setEmptyError(empty, requiredFields);
        	$("#valueMapErrors").show();
    		prevent(event);
    	}
    	else {
    		$("#valueMapErrors").hide();
    	}
    }
        
    function setDuplicateError(duplicate) {
    	if(duplicate) {
    		$("#duplicateLdapValue").text("Duplicate ldap value");
    	}
		else {
			$("#duplicateLdapValue").text("");
		}
    }
    
    function setEmptyError(empty, requiredFields) {
    	if(empty) {
    		setEmptyLdapError(requiredFields);
    		setEmptyApplicationError(requiredFields);	
    	}	
    }
    
    function setEmptyLdapError(requiredFields) {
    	if(requiredFields["ldapValue"]) {
    		$("#emptyLdapValue").text("Ldap value is required");
    	}
    	else {
    		$("#emptyLdapValue").text("");
		}
    }
    
    function setEmptyApplicationError(requiredFields) {
    	if(requiredFields["applicationValue"]) {
    		$("#emptyApplicationValue").text("Application value is required");
    	}
    	else {
    		$("#emptyApplicationValue").text("");
		}
    }
    
    function validateDuplicate() {
    	var duplicate = false;
    	var ldapValueMap = Object.create(null);
    	$("#valueMapTable > tbody > tr").each(addToMap);
    	return duplicate;
    	
    	function addToMap() {
    		var row = $(this);
    		var ldapValue = row.find("input.ldap-value").val();
    		if(ldapValueMap[ldapValue]) {
    			duplicate = true;
    		}
    		ldapValueMap[ldapValue] = true;
    	}
    }
    
    function validateEmpty(requiredFields) {
    	var empty = false;
    	$("#valueMapTable > tbody > tr").each(validate);
    	return empty;
    	
    	function validate() {
    		var row = $(this);
    		var ldapValueValid =validateLdapValue();
    		var applicationValueValid = validateApplicationValue();
    		var valid = (ldapValueValid && applicationValueValid);
    		if(!valid) {
    			empty = true;
    		}
    		
    		function validateLdapValue() {
    			var ldapValue = row.find("input.ldap-value").val();
    			if(!ldapValue) {
        			requiredFields["ldapValue"] = true;
        		}	
    			return ldapValue;
    		}
    		
    		function validateApplicationValue() {
    			var applicationValue = row.find("input.application-value").val();	
        		if(!applicationValue) {
        			requiredFields["applicationValue"] = true;
        		}
        		return applicationValue;
    		}
    	}  	
    }
       
    function validateTimeInput(event) {
		 optionallyCheckTimeInputs(event);
	}
    
	function checkRolePattern(event) {
		if($("#enableNamePattern") && $("#enableNamePattern")[0] && !$("#enableNamePattern")[0].checked) {
			
			var rolePattern = new RegExp("^(\\{[RGD\\]})(-\\{[RGD\\]})?(-\\{RGD\\]})?{1,100000}(-[a-zA-Z0-9]{1,})?$");
			var roleFilterInput = $("input[id='basicInfoVm.pattern']").val();
			
			if(rolePattern.test(roleFilterInput)){
				$("input[id='basicInfoVm.pattern']").css({"border-style":"solid", "border-color": "green"});
			} else {
				$("input[id='basicInfoVm.pattern']").css({"border-style":"solid", "border-color": "red"});
				prevent(event);
				
			}
		}
	}
        
    function checkGroupPattern(event) {
        if ($("#enableNamePattern") && $("#enableNamePattern")[0] && !$("#enableNamePattern")[0].checked && $("#ldapGroupRepresentation2").is(':checked')) {

            var groupPattern = new RegExp("^(\\{R\\})(-\\{G\\})?(-[a-zA-Z0-9]{1,})?$");
            var groupFilterInput = $("input[id='basicInfoVm.pattern']").val();

            if (groupPattern.test(groupFilterInput)) {
                $("input[id='basicInfoVm.pattern']").css({"border-style": "solid", "border-color": "green"});
            } else {
                $("input[id='basicInfoVm.pattern']").css({"border-style": "solid", "border-color": "red"});
                prevent(event);

            }
            
            if($("#enableGroupHierarchyPattern") && $("#enableGroupHierarchyPattern")[0] && $("#enableGroupHierarchyPattern")[0].checked) {
                var basicInfoVmGroupHierarchy = $("#basicInfoVmGroupHierarchy").val();
                if(!basicInfoVmGroupHierarchy){
                    $("input[id='basicInfoVmGroupHierarchy']").css({"border-style": "solid", "border-color": "red"});
                    prevent(event);
                }
            }
        }
    }
});

function checkTargetDn(event) {
	var pattern =  new RegExp("^(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*(?:,(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*)*$");
    var targetDn = $("#basicInfoVmTargetDn").val();
    var targetDnErrorField = $("#basicInfoVmTargetDnError"); 
    var targetDnField = $("#basicInfoVmTargetDn");
    var retValue = false;
    	if(targetDn) {
    		validateTargetDn();
        } else {
        	setTargetDnError("Please provide target Dn");
        }
        return retValue;   
        
        function validateTargetDn() {
        	if(pattern.test(targetDn)){
        		targetDnField.removeClass("lcw-dn-error");
        		targetDnField.addClass("lcw-dn-valid");
        		targetDnErrorField[0].innerText= "";
                retValue = true;
        	} 
        	else	{
        		setTargetDnError("The provided target DN not matches the rules");
            }
        }
        
        function setTargetDnError(message) {
    		if(targetDnErrorField && targetDnErrorField[0]) {
    			targetDnErrorField[0].innerText= message;
    		}
    		targetDnField.removeClass("lcw-dn-valid");
    		targetDnField.addClass("lcw-dn-error");
    		targetDnField.focus();
    		prevent(event);
        }
}

function prevent(event) {
   if (event) {
	   event.preventDefault();
   }

}

function formSubmit(action,hiddenValue){
	if(action === 'deleteServer') {
		var deleteConfirmation = confirm("Are you sure you want to delete?");
		if(!deleteConfirmation) {
			return;
		}
	}
    $("#target").attr("action", action);
    $("#hiddenField").attr("value",hiddenValue);
    $("#target").submit();
}



$(function() {

	// We can attach the `fileselect` event to all file inputs on the page
	$(document).on('change', ':file', function() {
		var input = $(this);
		var label = input.val();
		input.trigger('fileselect', [ label ]);
	});

	// We can watch for our custom `fileselect` event like this
	$(document).ready(function() {
		$(':file').on('fileselect',function(event, label) {
			var input = $(this).parents('.input-group').find(':text'); 
			input.val(label);
			input.attr("title", label);
		});
		
	});
});


$(document).ready(function() {
	
	$('#path').change(validateFileUpload);
	function validateFileUpload(event){
		$("#filePathError").text("");
		var path = $('#path').val()
		if(path !== null && path !== ""){
			processFileUpload(event);
		}
	};

	function processFileUpload(event){
		var files = event.target.files;
	    var oMyForm = new FormData();
	    oMyForm.append("file", files[0]);
	    oMyForm.append("alias",$("#identity").val());
	   $.ajax({
		   	  dataType : 'json',
	          url : "uploadFile",
	          data : oMyForm,
	          type : "POST",
	          enctype: 'multipart/form-data',
	          processData: false,
	          contentType:false,
	          success : function(result) {
	        	  $("#filePathError").removeClass("text-danger");
		          $("#filePathError").addClass("text-info");
		          $("#filePathError").text(result);
	          },
	          error : function(result){
	        	 $('#path').val("");
	        	 $("#pathText").val("");
	        	 $("#filePathError").removeClass("text-info");
	        	 $("#filePathError").addClass("text-danger");
	             $("#filePathError").text(result.responseJSON);
	          }
	      });
		}
});


$(document).ready(function() {
	setAuthorizeState();
	$(".authorize-checkbox").change(setAuthorizeState);
	function setAuthorizeState(){
		var authenticationStatus = $("#authenticationStatus") && $("#authenticationStatus").html();
		if(authenticationStatus === 'true' &&  authoriceCheckBoxStatus()){
			$("#userAuthrization").prop('disabled', false);
		}else{
			$("#userAuthrization").prop('disabled', true);
		}
	}
	function authoriceCheckBoxStatus(){
		var checked = false;
		$(".authorize-checkbox").each(function(){
			checked = $(this)[0].checked || checked;
		});
		return checked;
	}
});
function optionallyCheckTimeInputs(event) {
	var advancedConnectionEnabled = $("#advancedConnectionOption").is(":checked");
	if(advancedConnectionEnabled) {
		checkTimeInputs(event);
	}
}
function checkTimeInputs(event){
	var timePickerMap = Object.create(null);
	
	initializeTimePickerMap();
	
	for(var timePicker in timePickerMap){
		var inputFieldId = timePicker;
		var errorFieldId = timePickerMap[timePicker];
		checkTimeInput(event, inputFieldId, errorFieldId);
	}
	function initializeTimePickerMap() {
		timePickerMap["pingKeepAliveTimeout"]= "pingKeepAliveTimeoutError";
		timePickerMap["pingWaitTimeout"]= "pingWaitTimeoutError";
		timePickerMap["connectionTimeOut"]= "connectionTimeOutError";
		timePickerMap["timeLimit"]= "timeLimitError";
	}
}
function checkTimeInput(event, inputFieldId, errorFieldId) {	
		
    var errorField = $("#" + errorFieldId); 
    var inputField = $("#" + inputFieldId );
    var inputFieldValue = inputField.val();
    
    if(inputField.length > 0) {
    	if(inputFieldValue) {
    		validateTimeInput(inputField, errorField, event);
        } else {
        	setTimeErrorField("Please enter time in 'hh:mm:ss' format", errorField, inputField, event);
        }  
    }
}
function validateTimeInput(inputField, errorField, event) {
	var pattern =  new RegExp("^(?:2[0-3]|[01]?[0-9]):[0-5][0-9]:[0-5][0-9]$");
	var inputFieldValue = inputField.val();
	if(pattern.test(inputFieldValue)){
		inputField.removeClass("lcw-dn-error");
		inputField.addClass("lcw-dn-valid");
		errorField[0].innerText= "";
	} 
	else	{
		setTimeErrorField("Please enter time in the 'hh:mm:ss' format", errorField, inputField, event);
    }
}
function setTimeErrorField(message, errorField, inputField, event) {
	if(errorField && errorField[0]) {
		errorField[0].innerText= message;
	}
	inputField.removeClass("lcw-dn-valid");
	inputField.addClass("lcw-dn-error");
	prevent(event);
}