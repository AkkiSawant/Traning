(function() {
	var app = angular.module('TreeApp');
	app.directive('draggable', DraggableFunction);
	
	function DraggableFunction() {
		return {
			restrict: 'CE',
			link: function (scope, element) {
				element.find("div").draggable({
			    	appendTo: "body",
			        helper: "clone",
			        addClasses: false,
			        cursor: "select",
			        cursorAt: { bottom: 0 }
				});
			}
		}
	}
})();