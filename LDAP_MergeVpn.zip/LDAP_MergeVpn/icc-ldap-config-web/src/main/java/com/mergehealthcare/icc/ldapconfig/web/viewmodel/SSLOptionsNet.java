
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class SSLOptionsNet.
 */
@Component
public class SSLOptionsNet extends SSLOptions {

  private boolean clientCertificateStoreEnabled;

  private String cn;

  private String storeName;

  private String storeLocation;

  private String clientCertificatePath;

  private String clientCertificatePassword;

  private boolean serverCertificateStoreEnabled;

  private String serverCertificatePath;

  private String serverCertificatePassword;


  public boolean isClientCertificateStoreEnabled() {
    return clientCertificateStoreEnabled;
  }


  public void setClientCertificateStoreEnabled(boolean clientCertificateStoreEnabled) {
    this.clientCertificateStoreEnabled = clientCertificateStoreEnabled;
  }


  public String getCn() {
    return cn;
  }


  public void setCn(String cn) {
    this.cn = cn;
  }


  public String getStoreName() {
    return storeName;
  }


  public void setStoreName(String storeName) {
    this.storeName = storeName;
  }


  public String getStoreLocation() {
    return storeLocation;
  }


  public void setStoreLocation(String storeLocation) {
    this.storeLocation = storeLocation;
  }


  public String getClientCertificatePath() {
    return clientCertificatePath;
  }


  public void setClientCertificatePath(String clientCertificatePath) {
    this.clientCertificatePath = clientCertificatePath;
  }


  public String getClientCertificatePassword() {
    return clientCertificatePassword;
  }


  public void setClientCertificatePassword(String clientCertificatePassword) {
    this.clientCertificatePassword = clientCertificatePassword;
  }


  public boolean isServerCertificateStoreEnabled() {
    return serverCertificateStoreEnabled;
  }


  public void setServerCertificateStoreEnabled(boolean serverCertificateStoreEnabled) {
    this.serverCertificateStoreEnabled = serverCertificateStoreEnabled;
  }


  public String getServerCertificatePath() {
    return serverCertificatePath;
  }


  public void setServerCertificatePath(String serverCertificatePath) {
    this.serverCertificatePath = serverCertificatePath;
  }


  public String getServerCertificatePassword() {
    return serverCertificatePassword;
  }


  public void setServerCertificatePassword(String serverCertificatePassword) {
    this.serverCertificatePassword = serverCertificatePassword;
  }


  /*
   * (non-Javadoc)
   * @see com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptions#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("SSLOptionsNet [clientCertificateStoreEnabled=");
    builder.append(clientCertificateStoreEnabled);
    builder.append(", cn=");
    builder.append(cn);
    builder.append(", storeName=");
    builder.append(storeName);
    builder.append(", storeLocation=");
    builder.append(storeLocation);
    builder.append(", clientCertificatePath=");
    builder.append(clientCertificatePath);
    builder.append(", clientCertificatePassword=");
    builder.append(clientCertificatePassword);
    builder.append(", serverCertificateStoreEnabled=");
    builder.append(serverCertificateStoreEnabled);
    builder.append(", serverCertificatePath=");
    builder.append(serverCertificatePath);
    builder.append(", serverCertificatePassword=");
    builder.append(serverCertificatePassword);
    builder.append("]");
    return builder.toString();
  }

}
