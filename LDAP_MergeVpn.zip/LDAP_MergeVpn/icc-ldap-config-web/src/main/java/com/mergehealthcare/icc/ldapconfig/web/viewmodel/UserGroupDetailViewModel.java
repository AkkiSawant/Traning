
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class UserGroupDetailViewModel.
 */
public class UserGroupDetailViewModel {

  private String domainId;

  private String groupId;

  private String groupAdminLevel;

  private String role;


  /*
   * @return the domainId
   */
  public String getDomainId() {
    return domainId;
  }


  /*
   * @param domainId the domainId to set
   */
  public void setDomainId(String domainId) {
    this.domainId = domainId;
  }


  /*
   * @return the groupId
   */
  public String getGroupId() {
    return groupId;
  }


  /*
   * @param groupId the groupId to set
   */
  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }


  /*
   * @return the groupAdminLevel
   */
  public String getGroupAdminLevel() {
    return groupAdminLevel;
  }


  /*
   * @param groupAdminLevel the groupAdminLevel to set
   */
  public void setGroupAdminLevel(String groupAdminLevel) {
    this.groupAdminLevel = groupAdminLevel;
  }


  /*
   * @return the roles
   */
  public String getRole() {
    return role;
  }


  /*
   * @param role the roles to set
   */
  public void setRole(String role) {
    this.role = role;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("UserGroupDetailViewModel [domainId=");
    builder.append(domainId);
    builder.append(", groupId=");
    builder.append(groupId);
    builder.append(", groupAdminLevel=");
    builder.append(groupAdminLevel);
    builder.append(", role=");
    builder.append(role);
    builder.append("]");
    return builder.toString();
  }

}
