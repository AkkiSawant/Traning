/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

/*
 * The Class IdentitySettingsViewModelComposite.
 * Helper class to ease creating similar ID Settings View Model instances
 */
public class IdentitySettingsViewModelComposite {

  private final BasicInfoItemViewModelBase basicInfo;

  private final ReturnedAttributesItemViewModel returnAttributes;

  private final AttributeMapItemViewModel attributeMap;

  private final ValueMapItemViewModel valueMap;


  /**
   * Instantiates a new identity settings view model composite.
   *
   * @param serverType the server type
   * @param settingsMap the settings map
   * @param defaultSettingsMap the default settings map
   * @param attributeSettings the attribute settings
   */
  // @formatter:off
        public IdentitySettingsViewModelComposite(ServerType serverType,
                        Map<ServerType, List<String>> settingsMap,
                        Map<ServerType, List<String>> defaultSettingsMap,
                        Map<ServerType, List<AttributeMapNode>> attributeSettings) {
            // @formatter:on
    basicInfo = new BasicInfoItemViewModelBase();
    returnAttributes = new ReturnedAttributesItemViewModel();
    attributeMap = new AttributeMapItemViewModel();
    valueMap = new ValueMapItemViewModel();

    returnAttributes.setDefaultAttributes(new HashSet<>(defaultSettingsMap.get(serverType)));
    returnAttributes.setAttributes(new HashSet<>(settingsMap.get(serverType)));

    List<AttributeMapNode> attributeMapList = attributeSettings.get(serverType);
    attributeMap.setAttributes(attributeMapList);
    attributeMap.setMapOption(MapItemViewModelBase.MapOption.DICTIONARY);

    valueMap.setMapOption(MapItemViewModelBase.MapOption.NO_MAP);
  }


  public BasicInfoItemViewModelBase getBasicInfo() {
    return basicInfo;
  }


  public ReturnedAttributesItemViewModel getReturnAttributes() {
    return returnAttributes;
  }


  public AttributeMapItemViewModel getAttributeMap() {
    return attributeMap;
  }


  public ValueMapItemViewModel getValueMap() {
    return valueMap;
  }
}
