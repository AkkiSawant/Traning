package com.mergehealthcare.icc.ldapconfig.web.validator;

class DomainGroupNode {

    private String groupId;
    
    private String domainId;

    public DomainGroupNode() {}

    public DomainGroupNode(String groupId2 , String domainId2) {
        groupId = groupId2;
        domainId = domainId2;
    }


    public String getDomainID() {
        return domainId;
    }


    public void setDomainID(String domainId) {
        this.domainId = domainId;
    }


    public String getGroupId() {
        return groupId;
    }


    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DomainGroupNode [domainId=");
        builder.append(domainId);
        builder.append(", groupId=");
        builder.append(groupId);
        builder.append("]");
        return builder.toString();
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((domainId == null) ? 0 : domainId.hashCode());
        result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
        return result;
    }


    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DomainGroupNode other = (DomainGroupNode) obj;
        if (domainId == null) {
            if (other.domainId != null)
                return false;
        } else if (!domainId.equals(other.domainId))
            return false;
        if (groupId == null) {
            if (other.groupId != null)
                return false;
        } else if (!groupId.equals(other.groupId))
            return false;
        return true;
    }  
}
