
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class SSLOptionsJava.
 */
@Component
public class SSLOptionsJava extends SSLOptions {

  private String clientCertificatePath;

  private String clientCertificatePassword;

  private boolean serverKeystoreEnabled;

  private String serverCertificatePath;

  private String serverCertificatePassword;


  public String getClientCertificatePath() {
    return clientCertificatePath;
  }


  public void setClientCertificatePath(String clientCertificatePath) {
    this.clientCertificatePath = clientCertificatePath;
  }


  public String getClientCertificatePassword() {
    return clientCertificatePassword;
  }


  public void setClientCertificatePassword(String clientCertificatePassword) {
    this.clientCertificatePassword = clientCertificatePassword;
  }


  public boolean isServerKeystoreEnabled() {
    return serverKeystoreEnabled;
  }


  public void setServerKeystoreEnabled(boolean serverKeystoreEnabled) {
    this.serverKeystoreEnabled = serverKeystoreEnabled;
  }


  public String getServerCertificatePath() {
    return serverCertificatePath;
  }


  public void setServerCertificatePath(String serverCertificatePath) {
    this.serverCertificatePath = serverCertificatePath;
  }


  public String getServerCertificatePassword() {
    return serverCertificatePassword;
  }


  public void setServerCertificatePassword(String serverCertificatePassword) {
    this.serverCertificatePassword = serverCertificatePassword;
  }


  /*
   * (non-Javadoc)
   * @see
   * com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptions#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("SSLOptionsJava [clientCertificatePath=");
    builder.append(clientCertificatePath);
    builder.append(", clientCertificatePassword=");
    builder.append(clientCertificatePassword);
    builder.append(", serverKeystoreEnabled=");
    builder.append(serverKeystoreEnabled);
    builder.append(", serverCertificatePath=");
    builder.append(serverCertificatePath);
    builder.append(", serverCertificatePassword=");
    builder.append(serverCertificatePassword);
    builder.append("]");
    return builder.toString();
  }

}
