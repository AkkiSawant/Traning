
package com.mergehealthcare.icc.ldapconfig.web.controller;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdminLevels;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AuthenticationMethod;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.OperationCommandType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReferralChasing;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SystemAdminLevels;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;
import com.mergehealthcare.icc.ldapconfig.wizard.PropertyReader;
import com.mergehealthcare.icc.ldapconfig.wizard.WizardStateCommand;

import icc.base.exception.IOCException;
import icc.ldap.testtool.utils.ContextInitializer;
import org.apache.commons.io.FileUtils;

/**
 * The Class BaseController.
 */
@SuppressWarnings ("PMD.AbstractClassWithoutAbstractMethod")
public abstract class BaseController {

    private static final Logger logger = LogService.getLogger(BaseController.class);

    protected static final String DASHBOARD = "dashboard";

    protected static final String ERROR_MESSAGE = "OOPs something went wrong";

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    protected PropertyReader propertyReader;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;

    @Autowired
    private ServerDetailsService serverDetailsService;

    private final Map<String, IdentitySettingsViewModel> identitySettingsVmMap = new ConcurrentHashMap<String, IdentitySettingsViewModel>();


    /**
     * Sets the attribute in session.
     *
     * @param key the key
     * @param value the value
     */
    protected void setAttributeInSession(String key, String value) {
        this.webApplicationContext.getServletContext().setAttribute(key, value);
    }


    /**
     * Gets the attribute from session.
     *
     * @param key the key
     * @return the attribute from session
     */
    protected Object getAttributeFromSession(String key) {
        return this.webApplicationContext.getServletContext().getAttribute(key);
    }


    /**
     * Read currently active server from session.
     *
     * @return the string
     */
    protected String readCurrentlyActiveServerFromSession() {
        ServletContext servletContext = this.webApplicationContext.getServletContext();

        return (String) servletContext.getAttribute(LdapConfigConstant.CURRENT_SERVER);
    }


    /**
     * Read modified server flag from session.
     *
     * @return the string
     */
    protected String readModifiedServerFlagFromSession() {
        ServletContext servletContext = this.webApplicationContext.getServletContext();

        return (String) servletContext.getAttribute(LdapConfigConstant.MODIFY_MODE);
    }


    /**
     * Write currently active server name to session.
     *
     * @param serverName the server name
     */
    protected void writeCurrentlyActiveServerNameToSession(String serverName) {
        ServletContext servletContext = this.webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.CURRENT_SERVER, serverName);
    }


    /**
     * Write model grouping to session.
     *
     * @param modelGrouping the model grouping
     */
    protected void writeModelGroupingToSession(String modelGrouping) {
        ServletContext servletContext = this.webApplicationContext.getServletContext();
        servletContext.setAttribute(LdapConfigConstant.MODEL_GROUPING, modelGrouping);
    }


    /**
     * Read model grouping from session.
     *
     * @return the string
     */
    protected String readModelGroupingFromSession() {
        ServletContext servletContext = this.webApplicationContext.getServletContext();

        return (String) servletContext.getAttribute(LdapConfigConstant.MODEL_GROUPING);
    }


    /**
     * Link model to command.
     *
     * @param modelMap the model map
     * @param currentCommand the current command
     */
    protected void linkModelToCommand(ModelMap modelMap, WizardStateCommand currentCommand) {
        logger.debug("Current Command: " + currentCommand);
        modelMap.addAttribute("modelGrouping", readModelGroupingFromSession());
        modelMap.addAttribute("wizardState", currentCommand);
        modelMap.addAttribute("currentPage", currentCommand.getViewName());
    }


    /**
     * Gets the platform.
     *
     * @return the platform
     */
    public Platform getPlatform() {
        String platform = iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform");
        return Platform.valueOf(platform);
    }


    /**
     * Gets the connection type list.
     *
     * @return the connection type list
     */
    public List<String> getConnectionTypeList() {
        List<String> serverTypeList = new ArrayList<String>();
        serverTypeList.add("basic");
        serverTypeList.add("ssl");
        serverTypeList.add("tls");

        return serverTypeList;
    }


    /**
     * Gets the server type list.
     *
     * @return the server type list
     */
    public List<ServerType> getServerTypeList() {
        List<ServerType> serverTypeList = new ArrayList<ServerType>();
        serverTypeList.add(ServerType.AD);
        serverTypeList.add(ServerType.OpenLdap);
        serverTypeList.add(ServerType.Apache);
        return serverTypeList;
    }


    /**
     * Gets the model grouping list.
     *
     * @return the model grouping list
     */
    public List<String> getModelGroupingList() {
        List<String> groupingList = new ArrayList<String>();
        groupingList.add("Ungrouped");
        groupingList.add("Grouped Hierarchicaly Structured");
        groupingList.add("Grouped Non Hierarchicaly Structured");

        return groupingList;
    }


    /**
     * Gets the operation command types.
     *
     * @return the operation command types
     */
    public Object getOperationCommandTypes() {
        List<OperationCommandType> operationCommandTypes = new ArrayList<OperationCommandType>();
        for (OperationCommandType operationCommandType : OperationCommandType.values()) {
            operationCommandTypes.add(operationCommandType);
        }
        return operationCommandTypes;
    }


    /**
     * Gets the authentication methods.
     *
     * @return the authentication methods
     */
    public Object getAuthenticationMethods() {
        List<AuthenticationMethod> authenticationMethods = new ArrayList<AuthenticationMethod>();
        for (AuthenticationMethod authenticationMethod : AuthenticationMethod.values()) {
            authenticationMethods.add(authenticationMethod);
        }
        return authenticationMethods;
    }


    /**
     * Gets the referral chasing options list.
     *
     * @return the referral chasing options list
     */
    public Object getReferralChasingOptionsList() {
        List<ReferralChasing> referralChasingOptions = new ArrayList<ReferralChasing>();
        for (ReferralChasing referralChasing : ReferralChasing.values()) {
            referralChasingOptions.add(referralChasing);
        }
        return referralChasingOptions;
    }


    /**
     * Gets the admin levels.
     *
     * @return the admin levels
     */
    public List<String> getAdminLevels() {
        List<String> adminLevels = new ArrayList<String>();
        for (AdminLevels adminLevel : AdminLevels.values()) {
            adminLevels.add(adminLevel.getLevel());
        }
        return adminLevels;
    }


    /**
     * Gets the system admin levels.
     *
     * @return the system admin levels
     */
    public List<String> getSystemAdminLevels() {
        List<String> systemAdminLevels = new ArrayList<String>();
        for (SystemAdminLevels systemAdminLevel : SystemAdminLevels.values()) {
            systemAdminLevels.add(systemAdminLevel.getLevel());
        }
        return systemAdminLevels;
    }


    /**
     * Gets the store name.
     *
     * @return the store name
     */
    public String[] getStoreName() {

        String storeName = iCCEnvironmentConfig.environment.getProperty("icc.configuration.net.storename");
        return StringUtils.delimitedListToStringArray(storeName, ",");
    }


    /**
     * Gets the store location.
     *
     * @return the store location
     */
    public String[] getStoreLocation() {

        String storeName = iCCEnvironmentConfig.environment.getProperty("icc.configuration.net.storelocation");
        return StringUtils.delimitedListToStringArray(storeName, ",");
    }


    /**
     * Link vm to command.
     *
     * @param modelMap the model map
     * @param currentCommand the current command
     * @param identitySettingsVm the identity settings vm
     */
    public void linkVmToCommand(ModelMap modelMap, WizardStateCommand currentCommand, IdentitySettingsViewModel identitySettingsVm) {
        identitySettingsVmMap.put(currentCommand.getViewName(), identitySettingsVm);
        modelMap.addAttribute("identitySettingsVmMap", identitySettingsVmMap);
    }


    /**
     * Load current server configuration.
     *
     * @param serverName the server name
     * @throws IOCException the IOC exception
     */
    public void loadCurrentServerConfiguration(String serverName) throws IOCException {
        try {
            serverDetailsService.saveSelectedConfiguration(serverName);
        } catch (LdapConfigDataException | IOException ex) {
            logger.error("Error while writing serverConfiguration into temp file Name");
            logger.error("stacktrace :: ", ex);
        }
        intializeContext(getTempFileName(serverName));
    }


    /**
     * Intialize context.
     *
     * @param configFile the config file
     * @throws IOCException the IOC exception
     */
    public static void intializeContext(String configFile) throws IOCException {
        try {
            ContextInitializer.loadLdapEngine(configFile);
        } catch (Exception ex) {
            logger.error("Unable to load ldap engine", ex);
            throw ex;
        }
    }


    /**
     * Gets the temp file name.
     *
     * @param serverName the server name
     * @return the temp file name
     */
    private String getTempFileName(String serverName) {
        String filePath = getTempFolderPath();
        String fileExt = iCCEnvironmentConfig.environment.getProperty("icc.configuration.temp.filext");
        StringBuilder returnValue = new StringBuilder(filePath);
        returnValue.append(serverName).append(fileExt);
        return returnValue.toString();
    }


    /**
     * Gets the temp folder path.
     *
     * @return the temp folder path
     */
    public String getTempFolderPath() {
        return iCCEnvironmentConfig.environment.getProperty("icc.configuration.temp.path");
    }


    /**
     * Delete temp config files.
     */
    public void deleteTempConfigFiles() {

        File folder = new File(getTempFolderPath());
        if (folder.exists()) {
            try {
                FileUtils.cleanDirectory(folder);
            } catch (IOException ex) {
                logger.error("Error", ex);
            }
        }

    }

}
