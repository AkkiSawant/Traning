/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.cache.AttributeMapSettings;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.LdapPropertiesDNVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapperIdentitySettingsVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapNode;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.ldap.server.configuration.Locator;
import icc.ldap.server.configuration.LocatorProperty;
import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mapper;
import icc.ldap.server.configuration.MapperConverterProperties;
import icc.ldap.server.configuration.MapperConverterProperty;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.ReturnedDefaultAttribute;
import icc.ldap.server.configuration.ServerConfiguration;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author sarikam2
 */
@Component
public class IdentitySearchUtility {

    private static final String LDAP_ATTRIBUTES = "ldapAttribute";

    private static final String STATIC_ATTRIBUTES = "staticAttribute";

    private static ObjectFactory objectFactory = new ObjectFactory();

    private static final Logger logger = LogService.getLogger(IdentitySearchUtility.class);

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private IdentityObjectCreationUtility identityObjectCreationUtility;

    @Autowired
    private ModelMapperHelper modelMapperHelper;

    @Autowired
    private ReturnAttributeSettings returnAttributeSettings;


    // Below Two methods cannot moved to MapperLocatorUtility.Giving God class
    // error.

    /**
     * Find pattern.
     *
     * @param locator the locator
     * @return the string
     * @throws LdapConfigDataException the ldap config data exception
     */
    public static String findPattern(Locator locator) throws LdapConfigDataException {
        String finalPattern = null;
        try {
            if (locator != null && locator.getLocatorProperties() != null) {
                StringBuilder sb = new StringBuilder();
                StringBuilder patternSep = new StringBuilder();
                for (Map.Entry<String, LocatorProperty> addLocatorProperties : locator.getLocatorProperties().getLocatorProperty().entrySet()) {
                    LocatorProperty locatorProperty = addLocatorProperties.getValue();
                    String name = locatorProperty.getName();
                    String value = locatorProperty.getValue();
                    switch (name) {
                    case "pattern":
                        sb.append(value);
                        break;
                    case "patternSeparator":
                        patternSep.append(value);
                        break;
                    case "appValue":
                        sb.append(patternSep);
                        sb.append(value);
                        break;
                    default:
                        break;
                    }
                }
                finalPattern = sb.toString().replace("-{A}", "");
                finalPattern = ObjectUtils.removeEnd(finalPattern, "-");
            }
        } catch (Exception ex) {
            logger.error("Exception occured while finding Pattern for " + locator.getIdentityName() + ", String form " + finalPattern, ex);
            throw new LdapConfigDataException(
                            "Exception occured while finding Pattern for " + locator.getIdentityName() + " String form " + finalPattern, ex);
        }
        return finalPattern;
    }


    /**
     * Find mapper object.
     *
     * @param classType the class type
     * @param mappers the mappers
     * @return the mapper
     */
    public static Mapper findMapperObject(String classType, Mappers mappers) {
        return mappers.getMapper(classType);
    }


    /**
     * Mapper to identity settings view model mapping.
     *
     * @param mapperIdentitySettingsVM the mapper identity settings VM
     * @return the identity settings view model
     * @throws LdapConfigDataException the ldap config data exception
     */
    private IdentitySettingsViewModel mapperToIdentitySettingsViewModelMapping(MapperIdentitySettingsVM mapperIdentitySettingsVM)
                    throws LdapConfigDataException {
        IdentitySettingsViewModel identitySettings = mapperIdentitySettingsVM.getIdentitySettings();
        List<AttributeMapNode> xmlAttributeMapNodes = identitySettings.getAttributeMapVm().getAttributes();
        List<AttributeMapNode> attributeMapList;
        Set<String> returnedDefaultAttributes = identitySettings.getReturnedAttributesVm().getDefaultAttributes();
        Set<String> returnAttributes = identitySettings.getReturnedAttributesVm().getAttributes();
        Set<String> returnDefaultStaticAttributes = new HashSet<>();
        List<ValueMapNode> valueMapNodes = identitySettings.getValueMapVm().getValueMap();
        ServerType serverTypeEnum = ServerType.valueOf(mapperIdentitySettingsVM.getServerType());
        switch (mapperIdentitySettingsVM.getClassType()) {
        case LdapConfigConstant.DOMAIN:
            returnAttributes.addAll(new HashSet<>(returnAttributeSettings.getDomainSettings().get(serverTypeEnum)));
            returnDefaultStaticAttributes.addAll(new HashSet<>(returnAttributeSettings.getDefalutDomainSettings().get(serverTypeEnum)));
            attributeMapList = AttributeMapSettings.DOMAINSETTINGS.get(serverTypeEnum);
            break;
        case LdapConfigConstant.ROLE:
            returnAttributes.addAll(new HashSet<>(returnAttributeSettings.getRoleSettings().get(serverTypeEnum)));
            returnDefaultStaticAttributes.addAll(new HashSet<>(returnAttributeSettings.getDefalutRoleSettings().get(serverTypeEnum)));
            attributeMapList = AttributeMapSettings.ROLESETTINGS.get(serverTypeEnum);
            break;
        case LdapConfigConstant.USER:
            returnAttributes.addAll(new HashSet<>(returnAttributeSettings.getUserSettings().get(serverTypeEnum)));
            returnDefaultStaticAttributes.addAll(new HashSet<>(returnAttributeSettings.getDefalutUserSettings().get(serverTypeEnum)));
            attributeMapList = AttributeMapSettings.USERSETTINGS.get(serverTypeEnum);
            break;
        case LdapConfigConstant.GROUP:
            attributeMapList = getGrpIdentityAttributes(mapperIdentitySettingsVM, returnAttributes, returnDefaultStaticAttributes,
                            serverTypeEnum, returnAttributeSettings);
            break;
        default:
            throw new LdapConfigDataException("AttributeMapeNode cannot be null");
        }

        if (mapperIdentitySettingsVM.isExistingModel()) {
            MapperConverterProperties mapperConverterProperties = mapperIdentitySettingsVM.getMapper().getAttributeMap()
                            .getMapperConverterProperties();
            if (mapperConverterProperties.getMapperConverterProperty().isEmpty()) {
                xmlAttributeMapNodes.addAll(attributeMapList);
            } else {
                String ou = identitySettings.getBasicInfoVm().getTargetDn();
                String filter = identitySettings.getBasicInfoVm().getFilter();
                @SuppressWarnings (value = "PMD.UseConcurrentHashMap")
                Map<String, Map<String, String>> returnObject = modelMapperHelper
                                .getAllLdapPropertiesByDN(new LdapPropertiesDNVM(mapperIdentitySettingsVM.getServerName(), ou,
                                                mapperIdentitySettingsVM.getClassType(), mapperIdentitySettingsVM.getModelGrouping(), filter));
                for (Map.Entry<String, MapperConverterProperty> entry : mapperConverterProperties.getMapperConverterProperty().entrySet()) {
                    MapperConverterProperty mapperConverterProperty = entry.getValue();
                    AttributeMapNode attributeMapNode = new AttributeMapNode();
                    attributeMapNode.setIdentityProperty(mapperConverterProperty.getKey());
                    if (!serverTypeEnum.equals(ServerType.AD) && mapperConverterProperty.getKey().equalsIgnoreCase("MemberOf")) {
                        attributeMapNode.setLdapProperty("member");
                    } else {
                        attributeMapNode.setLdapProperty(mapperConverterProperty.getValue());
                    }

                    if (returnObject.containsKey(LDAP_ATTRIBUTES)) {
                        Map<String, String> identityLdapPropertyMap = returnObject.get(LDAP_ATTRIBUTES);
                        Set<String> attributeMap = identityLdapPropertyMap.keySet();
                        attributeMapNode.setLdapProperties(attributeMap);
                        boolean ignoreFlag = !attributeMap.contains(attributeMapNode.getLdapProperty()) || mapperConverterProperty.isIgnore();
                        attributeMapNode.setIgnore(ignoreFlag);
                    } else if (returnObject.containsKey(STATIC_ATTRIBUTES)) {
                        Map<String, String> identityLdapPropertyMap = returnObject.get(STATIC_ATTRIBUTES);
                        Set<String> attributeMap = new HashSet<>();
                        if (identityLdapPropertyMap.containsKey(mapperConverterProperty.getKey())) {
                            attributeMap.add(identityLdapPropertyMap.get(mapperConverterProperty.getKey()));
                        }
                        Set<String> ldapPropertiesSet = new HashSet<String>();
                        for (String key : identityLdapPropertyMap.keySet()) {
                            if (!identityLdapPropertyMap.get(key).isEmpty()) {
                                ldapPropertiesSet.add(identityLdapPropertyMap.get(key));
                            }
                        }

                        attributeMapNode.setLdapProperties(attributeMap);
                        boolean ignoreFlag = !ldapPropertiesSet.contains(attributeMapNode.getLdapProperty())
                                        || mapperConverterProperty.isIgnore();
                        attributeMapNode.setIgnore(ignoreFlag);
                    }
                    xmlAttributeMapNodes.add(attributeMapNode);
                }
            }
            for (Map.Entry<String, ReturnedDefaultAttribute> entry : mapperIdentitySettingsVM.getMapper().getReturnedDefaultAttributes()
                            .getReturnedDefaultAttribute().entrySet()) {
                ReturnedDefaultAttribute returnedDefaultAttribute = entry.getValue();
                returnedDefaultAttributes.add(returnedDefaultAttribute.getAttributeName());
            }
            for (Map.Entry<String, MapperConverterProperty> entry : mapperIdentitySettingsVM.getMapper().getValueMap()
                            .getMapperConverterProperties().getMapperConverterProperty().entrySet()) {
                MapperConverterProperty mapperConverterProperty = entry.getValue();
                ValueMapNode valueMapNode = new ValueMapNode();
                valueMapNode.setLdapValue(mapperConverterProperty.getKey());
                valueMapNode.setApplicationValue(mapperConverterProperty.getValue());
                valueMapNodes.add(valueMapNode);
            }
            boolean isAttributeMapEnabled = MapItemViewModelBase.MapOption.DICTIONARY.toString()
                            .equalsIgnoreCase(mapperIdentitySettingsVM.getMapper().getAttributeMap().getType()) ? false : true;
            boolean isReturnedAttributesEnabled = returnDefaultStaticAttributes.equals(returnedDefaultAttributes);
            boolean isValueMapEnabled = MapItemViewModelBase.MapOption.DICTIONARY.toString()
                            .equalsIgnoreCase(mapperIdentitySettingsVM.getMapper().getValueMap().getType()) ? true : false;
            identitySettings.getBasicInfoVm().setAttributeMapEnabled(isAttributeMapEnabled);
            identitySettings.getBasicInfoVm().setReturnedAttributesEnabled(!isReturnedAttributesEnabled);
            identitySettings.getBasicInfoVm().setValueMapEnabled(isValueMapEnabled);
            identitySettings.getAttributeMapVm().setMapOption(
                            isAttributeMapEnabled ? MapItemViewModelBase.MapOption.NO_MAP : MapItemViewModelBase.MapOption.DICTIONARY);
            identitySettings.getValueMapVm().setMapOption(
                            isValueMapEnabled ? MapItemViewModelBase.MapOption.DICTIONARY : MapItemViewModelBase.MapOption.NO_MAP);
        } else {
            identitySettings = identityObjectCreationUtility.createNewIdentitySettings(mapperIdentitySettingsVM, serverTypeEnum);
        }
        return identitySettings;
    }


    private List<AttributeMapNode> getGrpIdentityAttributes(MapperIdentitySettingsVM mapperIdentitySettingsVM, Set<String> returnAttributes,
                    Set<String> returnDefaultStaticAttributes, ServerType serverTypeEnum, ReturnAttributeSettings returnAttributeSettings) {
        List<AttributeMapNode> attributeMapList;
        if (mapperIdentitySettingsVM.getModelGrouping().equals(LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED)) {
            returnAttributes.addAll(new HashSet<>(returnAttributeSettings.getOuGroupSettings().get(serverTypeEnum)));
            returnDefaultStaticAttributes.addAll(new HashSet<>(returnAttributeSettings.getDefalutOuGroupSettings().get(serverTypeEnum)));
            attributeMapList = AttributeMapSettings.OU_GROUPSETTINGS.get(serverTypeEnum);
        } else {
            returnAttributes.addAll(new HashSet<>(returnAttributeSettings.getSgGroupSettings().get(serverTypeEnum)));
            returnDefaultStaticAttributes.addAll(new HashSet<>(returnAttributeSettings.getDefalutSgGroupSettings().get(serverTypeEnum)));
            attributeMapList = AttributeMapSettings.SG_GROUPSETTINGS.get(serverTypeEnum);
        }
        return attributeMapList;
    }


    /**
     * Find identity setting by server name.
     *
     * @param <T> the generic type
     * @param identityMethodVM the identity method VM
     * @return the t
     * @throws LdapConfigDataException the ldap config data exception
     */
    @SuppressWarnings (value = "unchecked")
    public <T extends IdentitySettingsViewModel> T findIdentitySettingByServerName(IdentitySettingsMethodVM identityMethodVM)
                    throws LdapConfigDataException {
        IdentitySettingsViewModel identitySettings = null;
        switch (identityMethodVM.getClassType()) {
        case LdapConfigConstant.DOMAIN:
            identitySettings = BeanUtils.instantiateClass(DomainIdentitySettingsViewModel.class);
            break;
        case LdapConfigConstant.ROLE:
            identitySettings = BeanUtils.instantiateClass(RoleIdentitySettingsViewModel.class);
            break;
        case LdapConfigConstant.USER:
            identitySettings = BeanUtils.instantiateClass(UserIdentitySettingsViewModel.class);
            break;
        case LdapConfigConstant.GROUP:
            identitySettings = BeanUtils.instantiateClass(GroupIdentitySettingsViewModel.class);
            break;
        default:
            throw new LdapConfigDataException("IdentityMethodVM classtype is wrong.It must be between Domain/User/Role/Group");
        }
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(identityMethodVM.getServerName());
        Model model = serverConfiguration.getModel();
        Locators locators;
        Mappers mappers;
        if (ObjectUtils.isNull(model)) {
            locators = objectFactory.createLocators();
            mappers = objectFactory.createMappers();
        } else {
            locators = model.getLocators();
            mappers = model.getMappers();
        }
        String pattern = null;
        Locator locator = null;
        Mapper mapper = null;
        if (!ObjectUtils.isNull(locators)) {
            locator = MapperLocatorUtility.findLocatorObject(identityMethodVM.getClassType(), locators);
            if (!identityMethodVM.getClassType().equalsIgnoreCase(LdapConfigConstant.GROUP)) {
                pattern = findPattern(locator);
            }
        }
        if (!ObjectUtils.isNull(mappers)) {
            mapper = findMapperObject(identityMethodVM.getClassType(), mappers);
        }
        if (ObjectUtils.isNull(locator)) {
            identitySettings = mapperToIdentitySettingsViewModelMapping(
                            new MapperIdentitySettingsVM(identityMethodVM.getServerName(), false, identityMethodVM.getClassType(),
                                            identityMethodVM.getServerType(), identitySettings, mapper, identityMethodVM.getModelGrouping()));
        } else {
            identitySettings = loadExistingIdentitySettings(identitySettings, locator, pattern, identityMethodVM);
            identitySettings = mapperToIdentitySettingsViewModelMapping(
                            new MapperIdentitySettingsVM(identityMethodVM.getServerName(), true, identityMethodVM.getClassType(),
                                            identityMethodVM.getServerType(), identitySettings, mapper, identityMethodVM.getModelGrouping()));
        }
        logger.info("Retrieved IdentitySettingModel = " + identitySettings);
        return (T) identitySettings;
    }


    private IdentitySettingsViewModel loadExistingIdentitySettings(IdentitySettingsViewModel identitySettings, Locator locator, String pattern,
                    IdentitySettingsMethodVM identityMethodVM) throws LdapConfigDataException {
        identitySettings.getBasicInfoVm().setTargetDn(locator.getTargetDistinguishedName());
        identitySettings.getBasicInfoVm().setFilter(locator.getIdentityFilterPattern());
        if (pattern == null || pattern.isEmpty()) {
            identitySettings.getBasicInfoVm().setEnableNamePattern(true);
        } else {
            identitySettings.getBasicInfoVm().setPattern(pattern);
            identitySettings.getBasicInfoVm().setEnableNamePattern(false);
        }
        if (identityMethodVM.getClassType().equalsIgnoreCase(LdapConfigConstant.GROUP)) {
            if (locator.getType().equalsIgnoreCase(LdapConfigConstant.ORG_UNIT_GROUP_TYPE)) {
                identitySettings.getBasicInfoVm().setLdapGroupRepresentation(LdapConfigConstant.ORG_UNIT_GROUP_TYPE);
            } else if (locator.getType().equalsIgnoreCase(LdapConfigConstant.SECURITY_GROUP_TYPE)) {
                identitySettings.getBasicInfoVm().setLdapGroupRepresentation(LdapConfigConstant.SECURITY_GROUP_TYPE);
                identitySettings.getBasicInfoVm().setEnableNamePattern(false);
                identitySettings.getBasicInfoVm().setEnableGroupHierarchyPattern(true);
                MapperLocatorUtility.findPattern(identitySettings, locator);
            }
        } else {
            identitySettings.getBasicInfoVm().setLocatorType(locator.getType());
        }
        return identitySettings;
    }

}
