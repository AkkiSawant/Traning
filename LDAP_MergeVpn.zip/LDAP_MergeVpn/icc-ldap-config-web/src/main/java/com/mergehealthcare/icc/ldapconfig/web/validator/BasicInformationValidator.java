
package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class BasicInformationValidator implements Validator {

  private static final String DOMAIN_TARGETDN_REGEX =
      "^(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*(?:,(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*)*$";

  private String identityName = "";


  @Override
  public boolean supports(Class<?> clazz) {
    return BasicInfoItemViewModelBase.class.equals(clazz);
  }


  @Override
  public void validate(Object target, Errors errors) {

    BasicInfoItemViewModelBase basicInfoVm = (BasicInfoItemViewModelBase) target;
    ValidationUtils.rejectIfEmpty(errors, "basicInfoVm.targetDn", "error.basicInfoVm.targetDn");
    if (!identityName.equals(LdapConfigConstant.DOMAIN)) {
      ValidationUtils.rejectIfEmpty(errors, "basicInfoVm.filter", "error.basicInfoVm.filter");
    }

    if (!StringUtils.isEmpty(basicInfoVm.getTargetDn())) {
      if (!basicInfoVm.getTargetDn().matches(DOMAIN_TARGETDN_REGEX)) {
        errors.rejectValue("basicInfoVm.targetDn", "error.basicInfoVm.targetDn.improper");
      }
    }

  }


  public void setIdentityName(String identityName) {
    this.identityName = identityName;
  }

}
