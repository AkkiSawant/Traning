
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

/**
 * The Class SSLOptions.
 */
@Component
public class SSLOptions {

  private boolean clientCertificateEnabled;

  private boolean serverIdentityEnabled;

  private String serverCertificateIdentity;

  private boolean serverCertificateEnabled;

  private MultipartFile uploadCertificate;


  public boolean isClientCertificateEnabled() {
    return clientCertificateEnabled;
  }


  public void setClientCertificateEnabled(boolean clientCertificateEnabled) {
    this.clientCertificateEnabled = clientCertificateEnabled;
  }


  public boolean isServerIdentityEnabled() {
    return serverIdentityEnabled;
  }


  public void setServerIdentityEnabled(boolean serverIdentityEnabled) {
    this.serverIdentityEnabled = serverIdentityEnabled;
  }


  public String getServerCertificateIdentity() {
    return serverCertificateIdentity;
  }


  public void setServerCertificateIdentity(String serverCertificateIdentity) {
    this.serverCertificateIdentity = serverCertificateIdentity;
  }


  public boolean isServerCertificateEnabled() {
    return serverCertificateEnabled;
  }


  public void setServerCertificateEnabled(boolean serverCertificateEnabled) {
    this.serverCertificateEnabled = serverCertificateEnabled;
  }


  /*
   * @return the uploadCertificate
   */
  public MultipartFile getUploadCertificate() {
    return uploadCertificate;
  }


  /*
   * @param uploadCertificate the uploadCertificate to set
   */
  public void setUploadCertificate(MultipartFile uploadCertificate) {
    this.uploadCertificate = uploadCertificate;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("SSLOptions [clientCertificateEnabled=");
    builder.append(clientCertificateEnabled);
    builder.append(", serverIdentityEnabled=");
    builder.append(serverIdentityEnabled);
    builder.append(", serverCertificateIdentity=");
    builder.append(serverCertificateIdentity);
    builder.append(", serverCertificateEnabled=");
    builder.append(serverCertificateEnabled);
    builder.append("]");
    return builder.toString();
  }

}
