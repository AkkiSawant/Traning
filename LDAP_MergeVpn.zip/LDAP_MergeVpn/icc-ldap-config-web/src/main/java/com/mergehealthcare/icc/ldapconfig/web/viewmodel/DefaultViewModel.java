
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class DefaultViewModel.
 */
@Component
public class DefaultViewModel {

  private String pageTitle;


  public String getPageTitle() {
    return this.pageTitle;
  }


  public void setPageTitle(String pageTitle) {
    this.pageTitle = pageTitle;
  }
}
