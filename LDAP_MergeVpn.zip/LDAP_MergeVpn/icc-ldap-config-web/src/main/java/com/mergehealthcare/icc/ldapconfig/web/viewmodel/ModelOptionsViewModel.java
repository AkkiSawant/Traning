
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class ModelOptionsViewModel.
 */
public class ModelOptionsViewModel {

    private String domainModel;

    private String modelGrouping;

    private String rootDistinguishedName;

    private String organizationalUnitDomain;

    private boolean fetchNewTree;


    /*
     * @return the domainModel
     */
    public String getDomainModel() {
        return domainModel;
    }


    /*
     * @param domainModel the domainModel to set
     */
    public void setDomainModel(String domainModel) {
        this.domainModel = domainModel;
    }


    /*
     * @return the modelGrouping
     */
    public String getModelGrouping() {
        return modelGrouping;
    }


    /*
     * @param modelGrouping the modelGrouping to set
     */
    public void setModelGrouping(String modelGrouping) {
        this.modelGrouping = modelGrouping;
    }


    /*
     * @return the rootDistinguishedName
     */
    public String getRootDistinguishedName() {
        return rootDistinguishedName;
    }


    /*
     * @param rootDistinguishedName the rootDistinguishedName to set
     */
    public void setRootDistinguishedName(String rootDistinguishedName) {
        this.rootDistinguishedName = rootDistinguishedName;
    }


    /*
     * @return the organizationalUnitDomain
     */
    public String getOrganizationalUnitDomain() {
        return organizationalUnitDomain;
    }


    /*
     * @param organizationalUnitDomain the organizationalUnitDomain to set
     */
    public void setOrganizationalUnitDomain(String organizationalUnitDomain) {
        this.organizationalUnitDomain = organizationalUnitDomain;
    }


    /*
     * @return the fetchNewTree
     */
    public boolean isFetchNewTree() {
        return fetchNewTree;
    }


    /*
     * @param fetchNewTree the fetchNewTree to set
     */
    public void setFetchNewTree(boolean fetchNewTree) {
        this.fetchNewTree = fetchNewTree;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ModelOptionsViewModel [domainModel=").append(domainModel).append(", modelGrouping=").append(modelGrouping)
                        .append(", rootDistinguishedName=").append(rootDistinguishedName).append(", organizationalUnitDomain=")
                        .append(organizationalUnitDomain).append("]");
        return builder.toString();
    }
}
