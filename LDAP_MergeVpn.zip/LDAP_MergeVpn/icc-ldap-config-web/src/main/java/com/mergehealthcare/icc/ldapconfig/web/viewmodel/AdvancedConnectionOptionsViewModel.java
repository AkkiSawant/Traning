package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class AdvancedConnectionOptionsViewModel.
 */
@Component
public class AdvancedConnectionOptionsViewModel {

    private boolean autoBind;

    private Integer protocolVersion;

    private boolean autoReconnect;

    private String referralChasingOptions;

    private Integer referralHopLimit;

    private String pingKeepAliveTimeout;

    private String pingWaitTimeout;

    private Integer pingLimit;

    private boolean tcpKeepAlive;

    private String connectionTimeOut;

    private String authenticationMethod;

    private String type;

    private Integer sizeLimit;

    private String timeLimit;

    private Integer pageSize;


    public boolean isAutoBind() {
        return autoBind;
    }


    public void setAutoBind(boolean autoBind) {
        this.autoBind = autoBind;
    }


    public Integer getProtocolVersion() {
        return protocolVersion;
    }


    public void setProtocolVersion(Integer protocolVersion) {
        this.protocolVersion = protocolVersion;
    }


    public boolean isAutoReconnect() {
        return autoReconnect;
    }


    public void setAutoReconnect(boolean autoReconnect) {
        this.autoReconnect = autoReconnect;
    }


    public String getReferralChasingOptions() {
        return referralChasingOptions;
    }


    public void setReferralChasingOptions(String referralChasingOptions) {
        this.referralChasingOptions = referralChasingOptions;
    }


    public Integer getReferralHopLimit() {
        return referralHopLimit;
    }


    public void setReferralHopLimit(Integer referralHopLimit) {
        this.referralHopLimit = referralHopLimit;
    }


    public String getPingKeepAliveTimeout() {
        return pingKeepAliveTimeout;
    }


    public void setPingKeepAliveTimeout(String pingKeepAliveTimeout) {
        this.pingKeepAliveTimeout = pingKeepAliveTimeout;
    }


    public String getPingWaitTimeout() {
        return pingWaitTimeout;
    }


    public void setPingWaitTimeout(String pingWaitTimeout) {
        this.pingWaitTimeout = pingWaitTimeout;
    }


    public Integer getPingLimit() {
        return pingLimit;
    }


    public void setPingLimit(Integer pingLimit) {
        this.pingLimit = pingLimit;
    }


    public boolean isTcpKeepAlive() {
        return tcpKeepAlive;
    }


    public void setTcpKeepAlive(boolean tcpKeepAlive) {
        this.tcpKeepAlive = tcpKeepAlive;
    }


    public String getConnectionTimeOut() {
        return connectionTimeOut;
    }


    public void setConnectionTimeOut(String connectionTimeOut) {
        this.connectionTimeOut = connectionTimeOut;
    }


    public String getAuthenticationMethod() {
        return authenticationMethod;
    }


    public void setAuthenticationMethod(String authenticationMethod) {
        this.authenticationMethod = authenticationMethod;
    }


    public String getType() {
        return type;
    }


    public void setType(String type) {
        this.type = type;
    }


    public String getTimeLimit() {
        return timeLimit;
    }


    public void setTimeLimit(String timeLimit) {
        this.timeLimit = timeLimit;
    }


    public Integer getPageSize() {
        return pageSize;
    }


    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }


    public Integer getSizeLimit() {
        return sizeLimit;
    }


    public void setSizeLimit(Integer sizeLimit) {
        this.sizeLimit = sizeLimit;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AdvancedConnectionOptionsViewModel [autoBind=");
        builder.append(autoBind);
        builder.append(", protocolVersion=");
        builder.append(protocolVersion);
        builder.append(", autoReconnect=");
        builder.append(autoReconnect);
        builder.append(", referralChasingOptions=");
        builder.append(referralChasingOptions);
        builder.append(", referralHopLimit=");
        builder.append(referralHopLimit);
        builder.append(", pingKeepAliveTimeout=");
        builder.append(pingKeepAliveTimeout);
        builder.append(", pingWaitTimeout=");
        builder.append(pingWaitTimeout);
        builder.append(", pingLimit=");
        builder.append(pingLimit);
        builder.append(", tcpKeepAlive=");
        builder.append(tcpKeepAlive);
        builder.append(", connectionTimeOut=");
        builder.append(connectionTimeOut);
        builder.append(", authenticationMethod=");
        builder.append(authenticationMethod);
        builder.append(", type=");
        builder.append(type);
        builder.append(", sizeLimit=");
        builder.append(sizeLimit);
        builder.append(", timeLimit=");
        builder.append(timeLimit);
        builder.append(", pageSize=");
        builder.append(pageSize);
        builder.append("]");
        return builder.toString();
    }

}
