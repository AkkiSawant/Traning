
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class SearchResultViewModel.
 */
public class SearchResultViewModel {

}
