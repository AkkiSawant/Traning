
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum SystemAdminLevels.
 */
public enum SystemAdminLevels {

  SUPERADMIN("SuperAdmin"), USER("User");

  private String level;


  /**
   * Instantiates a new system admin levels.
   *
   * @param name the name
   */
  private SystemAdminLevels(String name) {
    this.level = name;
  }


  public String getLevel() {
    return this.level;
  }


  public void setLevel(String level) {
    this.level = level;
  }
}
