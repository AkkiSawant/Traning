
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.HashSet;
import java.util.Set;

/**
 * The Class ReturnedAttributesItemViewModel.
 */
public class ReturnedAttributesItemViewModel {

  private boolean configureEnabled = true;

  private Set<String> attributes = new HashSet<>();

  private Set<String> defaultAttributes = new HashSet<>();

  private String selectedDefaultAttribute = "";

  private String selectedAttribute = "";


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ReturnedAttributesItemViewModel [configureEnabled=");
    builder.append(configureEnabled);
    builder.append(", attributes=");
    builder.append(attributes);
    builder.append(", defaultAttributes=");
    builder.append(defaultAttributes);
    builder.append(", selectedDefaultAttribute=");
    builder.append(selectedDefaultAttribute);
    builder.append(", selectedAttribute=");
    builder.append(selectedAttribute);
    builder.append("]");
    return builder.toString();
  }


  public boolean isConfigureEnabled() {
    return configureEnabled;
  }


  public void setConfigureEnabled(boolean configureEnabled) {
    this.configureEnabled = configureEnabled;
  }


  public Set<String> getAttributes() {
    return attributes;
  }


  public void setAttributes(Set<String> attributes) {
    this.attributes = attributes;
  }


  public Set<String> getDefaultAttributes() {
    return defaultAttributes;
  }


  public void setDefaultAttributes(Set<String> defaultAttributes) {
    this.defaultAttributes = defaultAttributes;
  }


  public String getSelectedDefaultAttribute() {
    return selectedDefaultAttribute;
  }


  public void setSelectedDefaultAttribute(String selectedDefaultAttribute) {
    this.selectedDefaultAttribute = selectedDefaultAttribute;
  }


  public String getSelectedAttribute() {
    return selectedAttribute;
  }


  public void setSelectedAttribute(String selectedAttribute) {
    this.selectedAttribute = selectedAttribute;
  }

}
