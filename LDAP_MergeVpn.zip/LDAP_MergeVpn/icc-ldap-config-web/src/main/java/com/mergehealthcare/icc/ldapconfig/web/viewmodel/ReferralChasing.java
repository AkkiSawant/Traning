
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum ReferralChasing.
 */
public enum ReferralChasing {
  None, Subordinate, External, All

}
