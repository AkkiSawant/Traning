
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum AdminLevels.
 */
public enum AdminLevels {
  ADMIN("Admin"), MEMBER("Member");

  private String level;


  /**
   * Instantiates a new admin levels.
   *
   * @param name the name
   */
  private AdminLevels(String name) {
    this.level = name;
  }


  public String getLevel() {
    return this.level;
  }


  public void setLevel(String level) {
    this.level = level;
  }
}
