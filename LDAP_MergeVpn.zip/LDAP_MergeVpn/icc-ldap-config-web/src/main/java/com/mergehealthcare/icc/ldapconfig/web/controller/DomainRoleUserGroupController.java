package com.mergehealthcare.icc.ldapconfig.web.controller;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.validator.BasicInformationValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.ModelOptionsValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsMethodVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityModelOptionModelMapper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentityObjectCreationUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.UserOverrideModelMapper;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;
import com.mergehealthcare.icc.ldapconfig.wizard.WizardStateCommand;
import com.mergehealthcare.icc.ldapconfig.wizard.WizardStateConfig;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.IOException;
import java.util.List;

@Controller
public class DomainRoleUserGroupController extends BaseController {

    private static final Logger logger = Logger.getLogger(DomainRoleUserGroupController.class);

    @Autowired
    private IdentityModelOptionModelMapper identityModelOptionModelMapper;

    @Autowired
    private UserOverrideModelMapper userOverrideModelMapper;

    @Autowired
    private ModelOptionsValidator modelOptionValidator;

    @Autowired
    private IdentityObjectCreationUtility identityObjectCreationUtility;

    @Autowired
    private BasicInformationValidator basicInformationValidator;

    @Autowired
    private IdentitySearchUtility identitySearchUtility;


    @RequestMapping (value = "/groupIdentitySettings", method = { RequestMethod.POST })
    public String saveGroupIdentitySettings(
                    @ModelAttribute (value = "groupIdentity") GroupIdentitySettingsViewModel groupIdentitySettingViewModel,
                    BindingResult result, ModelMap modelMap) {
        try {
            logger.debug("Updating GroupIdentity Setting........." + groupIdentitySettingViewModel);
            basicInformationValidator.setIdentityName(LdapConfigConstant.GROUP);
            /*
             * @formatter:off
             * Note: Client side validations are enabled so in case of user
             * bypassed it then only server side validations will be executed.
             * @formatter:on
             */
            basicInformationValidator.validate(groupIdentitySettingViewModel.getBasicInfoVm(), result);
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            String modelGrouping = readModelGroupingFromSession();
            if (result.hasErrors()) {
                WizardStateCommand groupIdentityCommand = WizardStateConfig.WIZARD_MAP.get("groupIdentitySettings");
                GroupIdentitySettingsViewModel groupIdentitySettingsViewModel = identityObjectCreationUtility
                                .getNewGroupIdentitySettingViewModel(ServerType.valueOf(serverType), modelGrouping);
                groupIdentitySettingsViewModel.setValueMapVm(groupIdentitySettingViewModel.getValueMapVm());
                modelMap.put(BindingResult.class.getName() + ".groupIdentitySettingsViewModel", result);
                modelMap.addAttribute("groupIdentitySettingsViewModel", groupIdentitySettingsViewModel);
                linkVmToCommand(modelMap, groupIdentityCommand, groupIdentitySettingsViewModel);
                linkModelToCommand(modelMap, groupIdentityCommand);
            } else {
                String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
                logger.debug("Server name: " + serverName);
                if (serverName != null) {
                    identityModelOptionModelMapper.saveIdentityConfiguration(groupIdentitySettingViewModel, serverName);
                }
                WizardStateCommand userOverrideMapCommand = WizardStateConfig.WIZARD_MAP.get(LdapConfigConstant.USER_OVERRIDE_MAP);
                UserOverrideMapViewModel userOverrideMapViewModel = userOverrideModelMapper.findOverrideMapByServerName(serverName);
                List<String> systemAdminLevelsEnum = getSystemAdminLevels();
                List<String> adminLevelsEnum = getAdminLevels();
                modelMap.addAttribute("SystemAdminLevelsEnum", systemAdminLevelsEnum);
                modelMap.addAttribute("AdminLevelsEnum", adminLevelsEnum);
                modelMap.addAttribute(LdapConfigConstant.USER_OVERRIDE_MAP, userOverrideMapViewModel);
                linkModelToCommand(modelMap, userOverrideMapCommand);
                logger.debug("Updating GroupIdentity Setting updated successfully");
            }
        } catch (LdapConfigDataException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.error("Updating GroupIdentity Setting failed ", ex);
        } catch (IOException ex) {
            logger.error("Updating GroupIdentity Setting failed ", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/domainIdentitySettings", method = RequestMethod.POST)
    public String saveDomainIdentitySettings(@ModelAttribute (value = "domainIdentity") DomainIdentitySettingsViewModel domainViewModel,
                    BindingResult result, ModelMap modelMap) {
        try {
            logger.info("Saving Domain Identity Object");
            String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
            BasicInfoItemViewModelBase base = domainViewModel.getBasicInfoVm();
            basicInformationValidator.setIdentityName(LdapConfigConstant.DOMAIN);
            basicInformationValidator.validate(base, result);
            logger.debug("Server name: " + serverName);
            if (result.hasErrors()) {
                logger.debug("Validations Errors: " + result.getFieldErrors());
                WizardStateCommand domainIdentityCommand = WizardStateConfig.WIZARD_MAP.get("domainIdentitySettings");
                String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
                DomainIdentitySettingsViewModel domainIdentitySettingsViewModel = identityObjectCreationUtility
                                .getNewDomainIdentitySettingViewModel(ServerType.valueOf(serverType));
                domainIdentitySettingsViewModel.getBasicInfoVm().setLocatorType(domainViewModel.getBasicInfoVm().getLocatorType());
                domainIdentitySettingsViewModel.setValueMapVm(domainViewModel.getValueMapVm());
                modelMap.put(BindingResult.class.getName() + ".domainIdentitySettingsViewModel", result);
                modelMap.addAttribute("domainIdentitySettingsViewModel", domainIdentitySettingsViewModel);
                linkVmToCommand(modelMap, domainIdentityCommand, domainIdentitySettingsViewModel);
                linkModelToCommand(modelMap, domainIdentityCommand);
            } else {
                domainViewModel.getBasicInfoVm().setFilter(LdapConfigConstant.OU_UNIT);
                if (serverName != null) {
                    identityModelOptionModelMapper.saveIdentityConfiguration(domainViewModel, serverName);
                }
                String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
                WizardStateCommand roleIdentityCommand = WizardStateConfig.WIZARD_MAP.get("roleIdentitySettings");
                RoleIdentitySettingsViewModel roleIdentitySettingsViewModel = identitySearchUtility
                                .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.ROLE, serverName, serverType,
                                                null));
                modelMap.addAttribute("roleIdentitySettingsViewModel", roleIdentitySettingsViewModel);
                modelMap.addAttribute("classType", LdapConfigConstant.ROLE);
                modelMap.addAttribute("modelGrouping", readModelGroupingFromSession());
                linkVmToCommand(modelMap, roleIdentityCommand, roleIdentitySettingsViewModel);
                linkModelToCommand(modelMap, roleIdentityCommand);
            }
        } catch (LdapConfigDataException | IOException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.error("Errors encountered while saving a domain identity object", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/userIdentitySettings", method = { RequestMethod.POST })
    public String saveUserIdentitySettings(@ModelAttribute (value = "userIdentity") UserIdentitySettingsViewModel userIdentitySettingViewModel,
                    BindingResult result, ModelMap modelMap) {
        try {
            logger.debug("Updating UserIdentity Setting........." + userIdentitySettingViewModel);
            basicInformationValidator.setIdentityName(LdapConfigConstant.USER);
            basicInformationValidator.validate(userIdentitySettingViewModel.getBasicInfoVm(), result);
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            if (result.hasErrors()) {
                WizardStateCommand userIdentityCommand = WizardStateConfig.WIZARD_MAP.get("userIdentitySettings");
                UserIdentitySettingsViewModel userIdentitySettingsViewModel = identityObjectCreationUtility
                                .getNewUserIdentitySettingViewModel(ServerType.valueOf(serverType));
                userIdentitySettingsViewModel.setValueMapVm(userIdentitySettingViewModel.getValueMapVm());
                modelMap.put(BindingResult.class.getName() + ".userIdentitySettingsViewModel", result);
                modelMap.addAttribute("userIdentitySettingsViewModel", userIdentitySettingsViewModel);

                linkVmToCommand(modelMap, userIdentityCommand, userIdentitySettingsViewModel);
                linkModelToCommand(modelMap, userIdentityCommand);
            } else {
                String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
                logger.debug("Server name: " + serverName);
                if (serverName != null) {
                    identityModelOptionModelMapper.saveIdentityConfiguration(userIdentitySettingViewModel, serverName);
                }
                String modelGrouping = String.valueOf(readModelGroupingFromSession());
                if (modelGrouping.equalsIgnoreCase(LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED)) {
                    WizardStateCommand userOverrideMapCommand = WizardStateConfig.WIZARD_MAP.get(LdapConfigConstant.USER_OVERRIDE_MAP);
                    UserOverrideMapViewModel userOverrideMapViewModel = userOverrideModelMapper.findOverrideMapByServerName(serverName);
                    List<String> systemAdminLevelsEnum = getSystemAdminLevels();
                    List<String> adminLevelsEnum = getAdminLevels();
                    modelMap.addAttribute("SystemAdminLevelsEnum", systemAdminLevelsEnum);
                    modelMap.addAttribute("AdminLevelsEnum", adminLevelsEnum);
                    modelMap.addAttribute(LdapConfigConstant.USER_OVERRIDE_MAP, userOverrideMapViewModel);
                    linkModelToCommand(modelMap, userOverrideMapCommand);
                } else {
                    WizardStateCommand groupIdentitySettings = WizardStateConfig.WIZARD_MAP.get(LdapConfigConstant.GROUP_IDENTITY_SETTINGS);
                    GroupIdentitySettingsViewModel groupIdentitySettingsViewModel = identitySearchUtility
                                    .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.GROUP, serverName,
                                                    serverType, modelGrouping));
                    modelMap.addAttribute("groupIdentitySettingsViewModel", groupIdentitySettingsViewModel);
                    modelMap.addAttribute("classType", LdapConfigConstant.GROUP);

                    linkVmToCommand(modelMap, groupIdentitySettings, groupIdentitySettingsViewModel);
                    linkModelToCommand(modelMap, groupIdentitySettings);
                }
                logger.debug("Updating UserIdentity Setting updated successfully");
            }
        } catch (LdapConfigDataException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.error("Updating UserIdentity Setting failed ", ex);
        } catch (IOException ex) {
            logger.error("Updating UserIdentity Setting failed ", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/roleIdentitySettings", method = RequestMethod.POST)
    public String saveRoleIdentitySettings(@ModelAttribute (value = "roleIdentity") RoleIdentitySettingsViewModel roleViewModel,
                    BindingResult result, ModelMap modelMap) {
        try {
            logger.debug("Saving Role Identity Setting: " + roleViewModel);
            basicInformationValidator.setIdentityName(LdapConfigConstant.ROLE);
            basicInformationValidator.validate(roleViewModel.getBasicInfoVm(), result);
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            if (result.hasErrors()) {
                WizardStateCommand roleIdentityCommand = WizardStateConfig.WIZARD_MAP.get("roleIdentitySettings");
                RoleIdentitySettingsViewModel roleIdentitySettingsViewModel = identityObjectCreationUtility
                                .getNewRoleIdentitySettingViewModel(ServerType.valueOf(serverType));
                roleIdentitySettingsViewModel.setValueMapVm(roleViewModel.getValueMapVm());
                modelMap.addAttribute("roleIdentitySettingsViewModel", roleIdentitySettingsViewModel);

                linkVmToCommand(modelMap, roleIdentityCommand, roleIdentitySettingsViewModel);
                linkModelToCommand(modelMap, roleIdentityCommand);
            } else {
                String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
                logger.debug("Server name: " + serverName);
                if (serverName != null) {
                    identityModelOptionModelMapper.saveIdentityConfiguration(roleViewModel, serverName);
                }
                WizardStateCommand userIdentityCommand = WizardStateConfig.WIZARD_MAP.get("userIdentitySettings");
                UserIdentitySettingsViewModel userIdentitySettingsViewModel = identitySearchUtility
                                .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.USER, serverName, serverType,
                                                null));
                modelMap.addAttribute("userIdentitySettingsViewModel", userIdentitySettingsViewModel);
                modelMap.addAttribute("classType", LdapConfigConstant.USER);

                linkVmToCommand(modelMap, userIdentityCommand, userIdentitySettingsViewModel);
                linkModelToCommand(modelMap, userIdentityCommand);
                logger.debug("Updating RoleIdentity Setting updated successfully");
            }
        } catch (LdapConfigDataException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.warn("Errors encountered while saving a role identity object", ex);
        } catch (IOException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.warn("Errors encountered while saving a role identity object", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/modelOptions", method = RequestMethod.POST)
    public String saveModelOptions(@ModelAttribute (value = "modelOption") ModelOptionsViewModel modelOption, BindingResult result,
                    ModelMap modelMap) throws LdapConfigDataException, IOException {
        // @formatter:on
        logger.debug("modelOption : " + modelOption);
        modelOptionValidator.validate(modelOption, result);
        logger.debug("result : " + result.getFieldErrors());
        if (result.hasErrors()) {
            WizardStateCommand modelOptionCommand = WizardStateConfig.WIZARD_MAP.get("modelOption");
            linkModelToCommand(modelMap, modelOptionCommand);
            modelMap.addAttribute("modelOption", new ModelOptionsViewModel());
            modelMap.put(BindingResult.class.getName() + ".modelOption", result);
        } else {
            String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
            Boolean modifyMode = Boolean.valueOf(readModifiedServerFlagFromSession());
            logger.debug("modelOption serverName = " + serverName);
            identityModelOptionModelMapper.saveModelOptionConfiguration(modelOption, serverName, modifyMode);
            WizardStateCommand domainIdentityCommand = WizardStateConfig.WIZARD_MAP.get("domainIdentitySettings");
            linkModelToCommand(modelMap, domainIdentityCommand);
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            DomainIdentitySettingsViewModel domainIdentitySettingsViewModel = identitySearchUtility
                            .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN, serverName, serverType,
                                            null));
            domainIdentitySettingsViewModel.getBasicInfoVm().setLocatorType(modelOption.getDomainModel());
            modelMap.addAttribute("domainIdentitySettingsViewModel", domainIdentitySettingsViewModel);
            modelMap.addAttribute("classType", LdapConfigConstant.DOMAIN);
            linkVmToCommand(modelMap, domainIdentityCommand, domainIdentitySettingsViewModel);
            writeModelGroupingToSession(modelOption.getModelGrouping());
            String modelGrouping = modelOption.getModelGrouping();
            if (modelGrouping.equalsIgnoreCase(LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED)) {
                WizardStateConfig.removeGroupIdentityNode();
            } else {
                WizardStateConfig.addGroupIdentityNode();
            }
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/domainIdentitySettings", method = { RequestMethod.GET })
    public String getDomainIdentitySettings(ModelMap modelMap) {
        try {
            String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
            logger.debug("Server name: " + serverName);
            WizardStateCommand domainIdentityCommand = WizardStateConfig.WIZARD_MAP.get("domainIdentitySettings");
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            DomainIdentitySettingsViewModel domainIdentitySettingsViewModel = identitySearchUtility
                            .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.DOMAIN, serverName, serverType,
                                            null));
            modelMap.addAttribute("domainIdentitySettingsViewModel", domainIdentitySettingsViewModel);
            modelMap.addAttribute("classType", LdapConfigConstant.DOMAIN);
            linkVmToCommand(modelMap, domainIdentityCommand, domainIdentitySettingsViewModel);
            linkModelToCommand(modelMap, domainIdentityCommand);
        } catch (LdapConfigDataException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.error("Errors encountered while retrieving a domain identity object", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/modelOptions", method = RequestMethod.GET)
    public String getModelOptions(ModelMap modelMap) throws LdapConfigDataException {
        String activeServerFromSession = readCurrentlyActiveServerFromSession();
        ModelOptionsViewModel currentModelOption = identityModelOptionModelMapper.findModelOptionByServerName(activeServerFromSession);
        WizardStateCommand modelOptionCommand = WizardStateConfig.WIZARD_MAP.get("modelOption");
        modelMap.addAttribute("modelOption", currentModelOption);
        modelMap.addAttribute("modelGroups", getModelGroupingList());
        linkModelToCommand(modelMap, modelOptionCommand);
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/roleIdentitySettings", method = RequestMethod.GET)
    public String getRoleIdentitySettings(ModelMap modelMap) throws LdapConfigDataException {
        try {
            String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
            WizardStateCommand roleIdentityCommand = WizardStateConfig.WIZARD_MAP.get("roleIdentitySettings");
            String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
            RoleIdentitySettingsViewModel roleIdentitySettingsViewModel = identitySearchUtility
                            .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.ROLE, serverName, serverType, null));
            modelMap.addAttribute("roleIdentitySettingsViewModel", roleIdentitySettingsViewModel);
            modelMap.addAttribute("classType", LdapConfigConstant.ROLE);

            linkVmToCommand(modelMap, roleIdentityCommand, roleIdentitySettingsViewModel);
            linkModelToCommand(modelMap, roleIdentityCommand);
        } catch (LdapConfigDataException ex) {
            modelMap.addAttribute("error", BaseController.ERROR_MESSAGE);
            logger.error("Errors encountered while retrieving a domain identity object", ex);
        }
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/groupIdentitySettings", method = { RequestMethod.GET })
    public String getGroupIdentitySettings(ModelMap modelMap) throws LdapConfigDataException {
        String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
        String modelGrouping = readModelGroupingFromSession();
        WizardStateCommand groupIdentityCommand = WizardStateConfig.WIZARD_MAP.get("groupIdentitySettings");
        String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
        GroupIdentitySettingsViewModel groupIdentitySettingsViewModel = identitySearchUtility
                        .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.GROUP, serverName, serverType,
                                        modelGrouping));
        modelMap.addAttribute("groupIdentitySettingsViewModel", groupIdentitySettingsViewModel);
        modelMap.addAttribute("classType", LdapConfigConstant.GROUP);

        linkVmToCommand(modelMap, groupIdentityCommand, groupIdentitySettingsViewModel);
        linkModelToCommand(modelMap, groupIdentityCommand);
        return BaseController.DASHBOARD;
    }


    @RequestMapping (value = "/userIdentitySettings", method = { RequestMethod.GET })
    public String getUserIdentitySettings(ModelMap modelMap) throws LdapConfigDataException {
        String serverType = (String) getAttributeFromSession(LdapConfigConstant.SERVER_TYPE);
        WizardStateCommand userIdentityCommand = WizardStateConfig.WIZARD_MAP.get("userIdentitySettings");
        String serverName = String.valueOf(readCurrentlyActiveServerFromSession());
        UserIdentitySettingsViewModel userIdentitySettingsViewModel = identitySearchUtility
                        .findIdentitySettingByServerName(new IdentitySettingsMethodVM(LdapConfigConstant.USER, serverName, serverType, null));
        modelMap.addAttribute("userIdentitySettingsViewModel", userIdentitySettingsViewModel);
        modelMap.addAttribute("classType", LdapConfigConstant.USER);

        linkVmToCommand(modelMap, userIdentityCommand, userIdentitySettingsViewModel);
        linkModelToCommand(modelMap, userIdentityCommand);
        return BaseController.DASHBOARD;
    }

}
