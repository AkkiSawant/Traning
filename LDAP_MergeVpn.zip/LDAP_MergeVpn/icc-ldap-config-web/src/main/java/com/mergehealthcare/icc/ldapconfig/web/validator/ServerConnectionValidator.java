package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection.JavaAdvancedConnectionValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection.JavaSSLValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection.NetAdvancedConnectionValidator;
import com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection.NetSSLValidator;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsJava;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsNet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.Map;
import java.util.regex.Pattern;

@Component
public class ServerConnectionValidator implements Validator {

    private static final String BASIC = "basic";

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;


    @Override
    public boolean supports(Class<?> clazz) {
        return ConnectionDetailsModel.class.equals(clazz);
    }


    @Override
    public void validate(Object target, Errors errors) {
        ConnectionDetailsModel connectionModel = (ConnectionDetailsModel) target;

        if (StringUtils.isEmpty(connectionModel.getDomainHost())) {
            errors.rejectValue("domainHost", "Size");
        }

        boolean isNet = getPlatform().equals(Platform.Net);
        if (isNet) {
            validateNetVm(connectionModel, errors);
        } else {
            validateJavaVm(connectionModel, errors);
        }
    }


    private void validateJavaVm(ConnectionDetailsModel connectionModel, Errors errors) {
        boolean basicConnection = BASIC.equals(connectionModel.getConnectionType());
        boolean advancedConnectionEnabled = connectionModel.isAdvancedConnectionOption();
        if (!basicConnection) {
            SSLOptionsJava sslOptionsJavaVm = connectionModel.getSslOptionsJavaVm();
            JavaSSLValidator.validateJavaSSL(sslOptionsJavaVm, errors);
        }
        if (advancedConnectionEnabled) {
            AdvancedConnectionOptionsViewModel advancedConnectionVm = connectionModel.getAdvancedConnectionVm();
            JavaAdvancedConnectionValidator.validateJavaAdvancedConnectionOptions(advancedConnectionVm, errors);
        }
    }


    private void validateNetVm(ConnectionDetailsModel connectionModel, Errors errors) {
        boolean basicConnection = BASIC.equalsIgnoreCase(connectionModel.getConnectionType());
        boolean advancedConnectionEnabled = connectionModel.isAdvancedConnectionOption();
        if (!basicConnection) {
            SSLOptionsNet sslOptionsNetVm = connectionModel.getSslOptionsNetVm();
            NetSSLValidator.validateNetSSL(sslOptionsNetVm, errors);
        }
        if (advancedConnectionEnabled) {
            AdvancedConnectionOptionsViewModel advancedConnectionVm = connectionModel.getAdvancedConnectionVm();
            NetAdvancedConnectionValidator.validateNetAdvancedConnectionOptions(advancedConnectionVm, errors);
        }
    }


    public Platform getPlatform() {
        String platform = iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform");
        return Platform.valueOf(platform);
    }


    public void validateRetrieveCert(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        String domainHost = (String) connectionDetails.get("domainHost");
        Integer port = Integer.parseInt((String) connectionDetails.get("port"));
        String storeLocation = (String) connectionDetails.get("storeLocation");
        String message;
        // String serverName = (String)
        // connectionDetails.get(LdapConfigConstant.CURRENT_SERVER);
        String pathRegex;

        if (getPlatform().equals(Platform.Java)) {
            pathRegex = "([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+\\\\?.jks";
        } else {
            pathRegex = "([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+\\\\?.crt";
        }
        Pattern pattern = Pattern.compile(pathRegex);

        if (StringUtils.isEmpty(storeLocation) || StringUtils.isEmpty(domainHost) || StringUtils.isEmpty(port)) {
            message = "Enter valid details";
            throw new LdapConfigDataException(message);
        } else if (!pattern.matcher(storeLocation).matches()) {
            message = "Enter valid file path";
            throw new LdapConfigDataException(message);
        }
    }
}
