
package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * The Class ModelOptionsValidator.
 */
@Component
public class ModelOptionsValidator implements Validator {

  private static final String ROOT_TARGETDISTINCT_REGEX =
      "^(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*(?:,(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\")(?:\\+(?:[A-Za-z][\\w-]*|\\d+(?:\\.\\d+)*)=(?:#(?:[\\dA-Fa-f]{2})+|(?:[^,=\\+<>#;\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*|\"(?:[^\\\\\"]|\\\\[,=\\+<>#;\\\\\"]|\\\\[\\dA-Fa-f]{2})*\"))*)*$";


  /*
   * (non-Javadoc)
   * @see org.springframework.validation.Validator#supports(java.lang.Class)
   */
  @Override
  public boolean supports(Class<?> clazz) {
    return ModelOptionsViewModel.class.equals(clazz);
  }


  /*
   * (non-Javadoc)
   * @see org.springframework.validation.Validator#validate(java.lang.Object,
   * org.springframework.validation.Errors)
   */
  @Override
  public void validate(Object target, Errors errors) {

    String siteDomainRegex = "^([0-9A-Za-z=()]+)((,|,\\r\\n)[0-9A-Za-z=()]+)*$";

    ModelOptionsViewModel modelOptions = (ModelOptionsViewModel) target;
    ValidationUtils.rejectIfEmpty(errors, "rootDistinguishedName", "error.rootDistinguishedName");
    ValidationUtils
        .rejectIfEmpty(errors, "organizationalUnitDomain", "error.organizationalUnitDomain.null");

    if (!StringUtils.isEmpty(modelOptions.getRootDistinguishedName())) {
      if (!modelOptions.getRootDistinguishedName().matches(ROOT_TARGETDISTINCT_REGEX)) {
        errors.rejectValue("rootDistinguishedName", "error.rootDistinguishedName.improper");
      }
    }

    if (!StringUtils.isEmpty(modelOptions.getOrganizationalUnitDomain())) {
      if (!modelOptions.getOrganizationalUnitDomain().matches(siteDomainRegex)) {
        errors.rejectValue("organizationalUnitDomain", "error.organizationalUnitDomain.improper");
      }
    }
  }


  /**
   * Validate tree.
   *
   * @param target the target
   * @param errors the errors
   */
  public void validateTree(Object target, Errors errors) {

    ModelOptionsViewModel modelOptions = (ModelOptionsViewModel) target;

    ValidationUtils.rejectIfEmpty(
        errors, "rootDistinguishedName", "error.rootDistinguishedName",
        "Root distinguished name required");

    if (!StringUtils.isEmpty(modelOptions.getRootDistinguishedName())) {
      if (!modelOptions.getRootDistinguishedName().matches(ROOT_TARGETDISTINCT_REGEX)) {
        errors.rejectValue(
            "rootDistinguishedName", "error.rootDistinguishedName", "Enter proper RDN");
      }
    }
  }

}
