
package com.mergehealthcare.icc.ldapconfig.web.ldap.utility;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.java.LdapServiceImplJava;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.net.LdapServiceImplNet;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * A factory for creating LdapService objects.
 */
@Component
public class LdapServiceFactory {

    @Autowired
    private LdapServiceImplJava ldapServiceImplJava;

    @Autowired
    private LdapServiceImplNet ldapServiceImplNet;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;


    /**
     * Gets the single instance of LdapServiceFactory.
     *
     * @return single instance of LdapServiceFactory
     */
    public ILdapService getInstance() {

        Platform platform = Platform.valueOf(iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform"));

        ILdapService ldapUtilityService = null;
        if (platform == Platform.Java) {
            ldapUtilityService = ldapServiceImplJava;
        } else if (platform == Platform.Net) {
            ldapUtilityService = ldapServiceImplNet;
        }
        return ldapUtilityService;
    }

}
