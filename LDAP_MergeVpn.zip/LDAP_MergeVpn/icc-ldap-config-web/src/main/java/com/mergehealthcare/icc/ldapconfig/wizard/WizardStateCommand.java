
package com.mergehealthcare.icc.ldapconfig.wizard;

import org.springframework.stereotype.Component;

/**
 * The Class WizardStateCommand.
 *
 * @author monilg
 *         This class will maintain the state of the wizard
 */
@Component
public class WizardStateCommand {

  private String commandUrl;

  private String pageHeader;

  private WizardStateCommand previousCommand;

  private WizardStateCommand nextCommand;

  private String viewName;

  private String buttonTitle;

  private boolean submitable;

  private String modelVariable;

  private boolean showNavbar = true;

  private boolean showTreeViewer = true;


  public String getCommandUrl() {
    return this.commandUrl;
  }


  public void setCommandUrl(String url) {
    this.commandUrl = url;
  }


  public String getPageHeader() {
    return this.pageHeader;
  }


  public void setPageHeader(String title) {
    this.pageHeader = title;
  }


  public WizardStateCommand getPreviousCommand() {
    return this.previousCommand;
  }


  public void setPreviousCommand(WizardStateCommand prev) {
    this.previousCommand = prev;
  }


  public WizardStateCommand getNextCommand() {
    return this.nextCommand;
  }


  public void setNextCommand(WizardStateCommand next) {
    this.nextCommand = next;
  }


  public String getViewName() {
    return this.viewName;
  }


  public void setViewName(String jspPage) {
    this.viewName = jspPage;
  }


  public String getButtonTitle() {
    return this.buttonTitle;
  }


  public void setButtonTitle(String btnName) {
    this.buttonTitle = btnName;
  }


  public boolean isSubmitable() {
    return this.submitable;
  }


  public void setSubmitable(boolean isPost) {
    this.submitable = isPost;
  }


  public String getModelVariable() {
    return this.modelVariable;
  }


  public void setModelVariable(String modelVariable) {
    this.modelVariable = modelVariable;
  }


  public boolean isShowNavbar() {
    return showNavbar;
  }


  public void setShowNavbar(boolean showNavbar) {
    this.showNavbar = showNavbar;
  }


  public boolean isShowTreeViewer() {
    return showTreeViewer;
  }


  public void setShowTreeViewer(boolean showTreeViewer) {
    this.showTreeViewer = showTreeViewer;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("WizardStateCommand [commandUrl=");
    builder.append(commandUrl);
    builder.append(", pageHeader=");
    builder.append(pageHeader);
    builder.append(", viewName=");
    builder.append(viewName);
    builder.append(", buttonTitle=");
    builder.append(buttonTitle);
    builder.append(", submitable=");
    builder.append(submitable);
    builder.append(", modelVariable=");
    builder.append(modelVariable);
    builder.append(", showNavbar=");
    builder.append(showNavbar);
    builder.append(", showTreeViewer=");
    builder.append(showTreeViewer);
    builder.append("]");
    return builder.toString();
  }

}
