
package com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.validator.ValidationHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;

import org.springframework.validation.Errors;

/**
 * The Class JavaAdvancedConnectionValidator.
 */
public final class JavaAdvancedConnectionValidator {

  /**
   * Instantiates a new java advanced connection validator.
   */
  private JavaAdvancedConnectionValidator() {
  }


  /**
   * Validate java advanced connection options.
   *
   * @param advancedConnectionVm the advanced connection vm
   * @param errors the errors
   */
  public static void validateJavaAdvancedConnectionOptions(
      AdvancedConnectionOptionsViewModel advancedConnectionVm, Errors errors) {
    validatePageSize(
        advancedConnectionVm.getPageSize(), advancedConnectionVm.getSizeLimit().intValue(), errors);
    validateSizeLimit(advancedConnectionVm.getSizeLimit(), errors);
    validateReferralHopLimit(advancedConnectionVm.getReferralHopLimit(), errors);
  }


  /**
   * Validate page size.
   *
   * @param pageSize the page size
   * @param sizeLimit the size limit
   * @param errors the errors
   */
  private static void validatePageSize(Integer pageSize, Integer sizeLimit, Errors errors) {
    boolean isPageSizeNull = ValidationHelper.rejectNull(
        pageSize, "advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize.required",
        errors);
    boolean isSizeLimitNull = ObjectUtils.isNull(sizeLimit);
    if (!isPageSizeNull) {
      int pageSizeValue = pageSize.intValue();
      int sizeLimitValue = isSizeLimitNull ? 0 : sizeLimit.intValue();
      if (pageSizeValue > sizeLimitValue) {
        errors.rejectValue("advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize");
      }
      ValidationHelper.rejectNegative(
          pageSize, "advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize.positive",
          errors);
    }
  }


  /**
   * Validate size limit.
   *
   * @param sizeLimit the size limit
   * @param errors the errors
   */
  private static void validateSizeLimit(Integer sizeLimit, Errors errors) {
    boolean isSizeLimitNull = ValidationHelper.rejectNull(
        sizeLimit, "advancedConnectionVm.sizeLimit",
        "error.advancedConnectionVm.sizeLimit.required", errors);
    if (!isSizeLimitNull) {
      ValidationHelper.rejectNegative(
          sizeLimit, "advancedConnectionVm.sizeLimit",
          "error.advancedConnectionVm.sizeLimit.positive", errors);
    }
  }


  /**
   * Validate referral hop limit.
   *
   * @param referralHopLimit the referral hop limit
   * @param errors the errors
   */
  private static void validateReferralHopLimit(Integer referralHopLimit, Errors errors) {
    ValidationHelper.rejectNegative(
        referralHopLimit, "advancedConnectionVm.referralHopLimit",
        "error.advancedConnectionVm.referralHopLimit.positive", errors);
  }

}
