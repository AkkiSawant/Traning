
package com.mergehealthcare.icc.ldapconfig.wizard;

/**
 * The Interface LdapConfigConstant.
 */
public final class LdapConfigConstant {

  public static final String CURRENT_SERVER = "serverDetails";

  public static final String MODIFY_MODE = "modifyMode";

  public static final String DOMAIN = "Domain";

  public static final String USER = "User";

  public static final String USER_SMALL = "user";

  public static final String GROUP = "Group";

  public static final String IDENTITY = "identity";

  public static final String BLANK = "";

  public static final String SERVER_TYPE = "serverType";

  public static final String PATTERN = "pattern";

  public static final String PATTERN_SEPERATOR = "patternSeparator";

  public static final String APP_VALUE = "appValue";

  public static final String ROLE = "Role";

  public static final String DICTIONARY = "dictionary";

  public static final String HIERARCHICAL_ROLE = "hierarchicalRole";

  public static final String NON_HIERARCHICAL_ROLE = "nonHierarchicalRole";

  public static final String OU_UNIT = "(objectclass=organizationalUnit)";

  public static final String USER_OVERRIDE_MAP = "userOverrideMap";

  public static final String GROUP_IDENTITY_SETTINGS = "groupIdentitySettings";

  public static final String MODEL_GROUPING = "modelGrouping";

  public static final String SINGLE_DOMAIN_UNGROUPED = "singleDomainUngrouped";

  public static final String SINGLE_DOMAIN_HIERARCHICAL_GROUPED = "singleDomainHierarchicalGrouped";

  public static final String SINGLE_DOMAIN_NONHIERARCHICAL_GROUPED =
      "singleDomainNonHierarchicalGrouped";

  public static final String HIERACHICAL_GROUPED = "hierarchicalgrouped";

  public static final String GROUP_HIERARCHY_SEPARATOR = "hierarchyPatternSeparator";

  public static final String GROUP_HIERARCHY_ORDER = "topToBottomOrder";

  public static final String GROUP_OF_NAMES_FILTER = "(objectclass=groupOfNames)";

  public static final String GROUP_FILTER = "(objectclass=group)";

  public static final String INETORG_PERSON_FILTER = "(objectclass=InetOrgPerson)";

  public static final String USER_AND_PERSON_FILTER =
      "(&(objectclass=user)(objectcategory=person))";

  public static final String SECURITY_GROUP_TYPE = "hPatternSecurityGroup";

  public static final String ORG_UNIT_GROUP_TYPE = "orgUnitGroup";

  public static final String UNGROUPED_TYPE = "ungrouped";

  public static final String PATTERN_ROLE = "patternRole";

  public static final String PAGE_SIZE = "pageSize";

  public static final String SSL = "SSL";

}
