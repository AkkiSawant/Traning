/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.ldap.server.configuration.Locator;
import icc.ldap.server.configuration.LocatorProperties;
import icc.ldap.server.configuration.LocatorProperty;
import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mapper;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.Model;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 *
 * @author sarikam2
 */
@Component
@SuppressWarnings ("PMD.UseUtilityClass")
// cannot make this class final since
// Spring subclass this.
public class MapperLocatorUtility {

    private static ObjectFactory objectFactory = new ObjectFactory();

    private static final Logger logger = LogService.getLogger(MapperLocatorUtility.class);


    /**
     * Prepare add locator properties.
     *
     * @param attributeName
     *            the attribute name
     * @param value
     *            the value
     * @return the locator property
     */
    private static LocatorProperty prepareAddLocatorProperties(String attributeName, String value) {
        LocatorProperty locatorProperty = objectFactory.createLocatorProperty();
        locatorProperty.setName(attributeName);
        locatorProperty.setValue(value);
        return locatorProperty;
    }


    /**
     * Prepare locator properties.
     *
     * @param locatorProperties
     *            the locator properties
     * @param locatorPattern
     *            the locator pattern
     */
    private static void prepareLocatorProperties(LocatorProperties locatorProperties, String locatorPattern) {
        String finalLocatorPattern = "";
        String appValue = "";
        String[] patternArr = locatorPattern.split("-");
        if (patternArr[patternArr.length - 1].indexOf("{") == -1) {
            finalLocatorPattern = locatorPattern.substring(0, locatorPattern.lastIndexOf("-"));
            finalLocatorPattern += "-{A}";
            appValue = patternArr[patternArr.length - 1];
        } else {
            finalLocatorPattern = locatorPattern;
        }
        locatorProperties.getLocatorProperty().put(LdapConfigConstant.PATTERN,
                        prepareAddLocatorProperties(LdapConfigConstant.PATTERN, finalLocatorPattern));
        locatorProperties.getLocatorProperty().put(LdapConfigConstant.PATTERN_SEPERATOR,
                        prepareAddLocatorProperties(LdapConfigConstant.PATTERN_SEPERATOR, "-"));
        if (!ObjectUtils.isNullOrEmpty(appValue)) {
            locatorProperties.getLocatorProperty().put(LdapConfigConstant.APP_VALUE,
                            prepareAddLocatorProperties(LdapConfigConstant.APP_VALUE, appValue));
        }
    }


    /**
     * Prepare locator object.
     *
     * @param model
     *            the model
     * @param identityViewModel
     *            the identity view model
     * @return
     * @throws LdapConfigDataException
     *             the ldap config data exception
     */
    public static Model prepareLocatorObject(Model model, IdentitySettingsViewModel identityViewModel) throws LdapConfigDataException {
        Locators locators = model.getLocators();
        if (ObjectUtils.isNull(locators)) {
            locators = objectFactory.createLocators();
            model.setLocators(locators);
        }
        Map<String, Locator> locatorList = locators.getLocator();
        boolean isNewLocator = false;
        Locator locator = locatorList.get(identityViewModel.getIdentityName());
        if (ObjectUtils.isNull(locator)) {
            locator = objectFactory.createLocator();
        } else {
            isNewLocator = true;
        }
        locator.setIdentityName(identityViewModel.getIdentityName());
        locator.setType(MapperLocatorUtility.getLocatorType(model, identityViewModel));
        locator.setTargetDistinguishedName(identityViewModel.getBasicInfoVm().getTargetDn());
        if (LdapConfigConstant.DOMAIN.equals(identityViewModel.getIdentityName())) {
            locator.setIdentityFilterPattern(LdapConfigConstant.OU_UNIT);
        }
        locator.setIdentityFilterPattern(identityViewModel.getBasicInfoVm().getFilter());
        LocatorProperties locatorProperties = objectFactory.createLocatorProperties();
        locator.setLocatorProperties(locatorProperties);
        String locatorPattern = identityViewModel.getBasicInfoVm().getPattern();
        if ((identityViewModel.getBasicInfoVm().getLdapGroupRepresentation() != null
                        && identityViewModel.getBasicInfoVm().getLdapGroupRepresentation().equals(LdapConfigConstant.SECURITY_GROUP_TYPE))
                        || LdapConfigConstant.ROLE.equals(identityViewModel.getIdentityName())) {
            if (!identityViewModel.getBasicInfoVm().isEnableNamePattern()) {
                if (locatorPattern != null && !locatorPattern.equals("")) {
                    prepareLocatorProperties(locatorProperties, locatorPattern);
                }
                if (identityViewModel.getBasicInfoVm().isEnableGroupHierarchyPattern()) {
                    locatorProperties.getLocatorProperty().put(LdapConfigConstant.GROUP_HIERARCHY_SEPARATOR,
                                    prepareAddLocatorProperties(LdapConfigConstant.GROUP_HIERARCHY_SEPARATOR,
                                                    identityViewModel.getBasicInfoVm().getGroupHierarchySeperator()));
                    locatorProperties.getLocatorProperty().put(LdapConfigConstant.GROUP_HIERARCHY_ORDER, prepareAddLocatorProperties(
                                    LdapConfigConstant.GROUP_HIERARCHY_ORDER, identityViewModel.getBasicInfoVm().getGroupHierarchy()));
                }
            }
        }
        if (!isNewLocator) {
            locators.getLocator().put(locator.getIdentityName(), locator);
        }
        return model;
    }


    /**
     * Gets the locator type.
     *
     * @param model
     *            the model
     * @param identityViewModel
     *            the identity view model
     * @return the locator type
     * @throws LdapConfigDataException
     *             the ldap config data exception
     */
    private static String getLocatorType(Model model, IdentitySettingsViewModel identityViewModel) throws LdapConfigDataException {
        String modelType = model.getType();
        String returnValue = null;
        if (null != identityViewModel.getIdentityName()) {
            switch (identityViewModel.getIdentityName()) {
            case LdapConfigConstant.DOMAIN:
                returnValue = identityViewModel.getBasicInfoVm().getLocatorType();
                break;
            case LdapConfigConstant.USER:
                returnValue = LdapConfigConstant.USER_SMALL;
                break;
            case LdapConfigConstant.ROLE:
                if (LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED.equals(modelType)) {
                    returnValue = LdapConfigConstant.HIERARCHICAL_ROLE;
                } else if (LdapConfigConstant.SINGLE_DOMAIN_NONHIERARCHICAL_GROUPED.equals(modelType)
                                && !identityViewModel.getBasicInfoVm().isEnableNamePattern()) {
                    // if
                    // (!identityViewModel.getBasicInfoVm().isEnableNamePattern())
                    // {
                    returnValue = LdapConfigConstant.PATTERN_ROLE;
                    // } else {
                    // returnValue = LdapConfigConstant.NON_HIERARCHICAL_ROLE;
                    // }
                } else {
                    returnValue = LdapConfigConstant.NON_HIERARCHICAL_ROLE;
                }
                break;
            case LdapConfigConstant.GROUP:
                if (ObjectUtils.assignEmptyIfNull(modelType).toString().indexOf(LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED) != -1) {
                    returnValue = LdapConfigConstant.ORG_UNIT_GROUP_TYPE;
                } else if (ObjectUtils.assignEmptyIfNull(modelType).toString()
                                .indexOf(LdapConfigConstant.SINGLE_DOMAIN_NONHIERARCHICAL_GROUPED) != -1) {
                    if (identityViewModel.getBasicInfoVm().getLdapGroupRepresentation().equals(LdapConfigConstant.SECURITY_GROUP_TYPE)) {
                        returnValue = LdapConfigConstant.SECURITY_GROUP_TYPE;
                    } else {
                        returnValue = LdapConfigConstant.ORG_UNIT_GROUP_TYPE;
                    }
                } else {
                    returnValue = LdapConfigConstant.UNGROUPED_TYPE;
                }
                break;
            default:
                throw new LdapConfigDataException("IdentityMethodVM classtype is wrong.It must be between Domain/User/Role/Group");
            }
        }
        return returnValue;
    }


    /**
     * Find locator object.
     *
     * @param classType
     *            the class type
     * @param locators
     *            the locators
     * @return the locator
     */
    public static Locator findLocatorObject(String classType, Locators locators) {
        Locator locator = null;
        Locator locatorClass = locators.getLocator(classType);
        // if (StringUtils.isBlank(locator.getType())) {
        // return null;
        // } else {
        // return locator;
        // }
        if (ObjectUtils.isNotNullOrEmpty(locatorClass.getType())) {
            locator = locatorClass;
        }
        return locator;
    }


    /**
     * Find pattern.
     *
     * @param viewModel
     *            the view model
     * @param locator
     *            the locator
     * @return the identity settings view model
     * @throws LdapConfigDataException
     *             the ldap config data exception
     */
    public static void findPattern(IdentitySettingsViewModel viewModel, Locator locator) throws LdapConfigDataException {
        String finalPattern = null;
        try {
            if (locator != null && locator.getLocatorProperties() != null) {
                StringBuilder sb = new StringBuilder();
                StringBuilder patternSep = new StringBuilder();
                boolean enableGroupPattern = false;
                for (Map.Entry<String, LocatorProperty> addLocatorProperties : locator.getLocatorProperties().getLocatorProperty().entrySet()) {
                    LocatorProperty locatorProperty = addLocatorProperties.getValue();
                    String name = locatorProperty.getName();
                    String value = locatorProperty.getValue();
                    switch (name) {
                    case LdapConfigConstant.GROUP_HIERARCHY_SEPARATOR:
                        viewModel.getBasicInfoVm().setGroupHierarchySeperator(value);
                        enableGroupPattern = true;
                        break;
                    case LdapConfigConstant.GROUP_HIERARCHY_ORDER:
                        viewModel.getBasicInfoVm().setGroupHierarchy(value);
                        enableGroupPattern = true;
                        break;
                    case LdapConfigConstant.PATTERN:
                        sb.append(value);
                        break;
                    case LdapConfigConstant.PATTERN_SEPERATOR:
                        patternSep.append(value);
                        break;
                    case LdapConfigConstant.APP_VALUE:
                        sb.append(patternSep);
                        sb.append(value);
                        break;
                    default:
                        break;
                    }
                }
                finalPattern = sb.toString().replace("-{A}", "");
                finalPattern = ObjectUtils.removeEnd(finalPattern.toString(), "-");
                viewModel.getBasicInfoVm().setPattern(finalPattern);
                viewModel.getBasicInfoVm().setEnableGroupHierarchyPattern(enableGroupPattern);
            }
        } catch (Exception ex) {
            logger.error("Exception occured while finding Pattern for " + locator.getIdentityName() + ", String form " + finalPattern, ex);
            throw new LdapConfigDataException(
                            "Exception occured while finding Pattern for " + locator.getIdentityName() + " String form " + finalPattern, ex);
        }

    }


    /**
     * Prepare mapper object.
     *
     * @param model the model
     * @param identitySettingsViewModel the identity settings view model
     * @return model
     */
    public static Model prepareMapperObject(Model model, IdentitySettingsViewModel identitySettingsViewModel, String serverType) {
        Mappers mappers = model.getMappers();
        if (ObjectUtils.isNull(mappers)) {
            mappers = objectFactory.createMappers();
            model.setMappers(mappers);
        }
        Map<String, Mapper> mapperList = mappers.getMapper();
        boolean isNewMapper = false;
        Mapper mapper = mapperList.get(identitySettingsViewModel.getIdentityName());
        if (ObjectUtils.isNull(mapper)) {
            mapper = objectFactory.createMapper();
        } else {
            isNewMapper = true;
        }
        mapper.setIdentityName(identitySettingsViewModel.getIdentityName());
        mapper.setAttributeMap(AttributeValueMapUtility.prepareAttributeMap(identitySettingsViewModel.getAttributeMapVm(), serverType));
        mapper.setReturnedDefaultAttributes(
                        AttributeValueMapUtility.prepareReturnedDefaultProp(identitySettingsViewModel.getReturnedAttributesVm()));
        mapper.setValueMap(AttributeValueMapUtility.prepareValueMap(identitySettingsViewModel.getValueMapVm()));
        if (!isNewMapper) {
            mappers.getMapper().put(mapper.getIdentityName(), mapper);
        }
        return model;
    }

}
