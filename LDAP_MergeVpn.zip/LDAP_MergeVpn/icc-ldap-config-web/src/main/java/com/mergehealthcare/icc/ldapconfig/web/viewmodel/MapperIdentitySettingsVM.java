
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import icc.ldap.server.configuration.Mapper;

/**
 * The Class MapperIdentitySettingsVM.
 */
public class MapperIdentitySettingsVM {

  private String serverName;

  private boolean isExistingModel;

  private String classType;

  private String serverType;

  private IdentitySettingsViewModel identitySettings;

  private Mapper mapper;

  private String modelGrouping;


  /**
   * @return the serverName
   */
  public String getServerName() {
    return serverName;
  }


  /**
   * @param serverName the serverName to set
   */
  public void setServerName(String serverName) {
    this.serverName = serverName;
  }


  /**
   * @return the isExistingModel
   */
  public boolean isExistingModel() {
    return isExistingModel;
  }


  /**
   * @param isExistingModel the isExistingModel to set
   */
  public void setExistingModel(boolean isExistingModel) {
    this.isExistingModel = isExistingModel;
  }


  /**
   * @return the classType
   */
  public String getClassType() {
    return classType;
  }


  /**
   * @param classType the classType to set
   */
  public void setClassType(String classType) {
    this.classType = classType;
  }


  /**
   * @return the serverType
   */
  public String getServerType() {
    return serverType;
  }


  /**
   * @param serverType the serverType to set
   */
  public void setServerType(String serverType) {
    this.serverType = serverType;
  }


  /**
   * @return the identitySettings
   */
  public IdentitySettingsViewModel getIdentitySettings() {
    return identitySettings;
  }


  /**
   * @param identitySettings the identitySettings to set
   */
  public void setIdentitySettings(IdentitySettingsViewModel identitySettings) {
    this.identitySettings = identitySettings;
  }


  /**
   * @return the mapper
   */
  public Mapper getMapper() {
    return mapper;
  }


  /**
   * @param mapper the mapper to set
   */
  public void setMapper(Mapper mapper) {
    this.mapper = mapper;
  }


  /**
   * @return the modelGrouping
   */
  public String getModelGrouping() {
    return modelGrouping;
  }


  /**
   * @param modelGrouping the modelGrouping to set
   */
  public void setModelGrouping(String modelGrouping) {
    this.modelGrouping = modelGrouping;
  }


  /**
   * Instantiates a new mapper identity settings VM.
   *
   * @param serverName the server name
   * @param isExistingModel the is existing model
   * @param classType the class type
   * @param serverType the server type
   * @param identitySettings the identity settings
   * @param mapper the mapper
   * @param modelGrouping the model grouping
   */
  public MapperIdentitySettingsVM(String serverName, boolean isExistingModel, String classType,
      String serverType, IdentitySettingsViewModel identitySettings, Mapper mapper,
      String modelGrouping) {
    this.serverName = serverName;
    this.isExistingModel = isExistingModel;
    this.classType = classType;
    this.serverType = serverType;
    this.identitySettings = identitySettings;
    this.mapper = mapper;
    this.modelGrouping = modelGrouping;
  }
}
