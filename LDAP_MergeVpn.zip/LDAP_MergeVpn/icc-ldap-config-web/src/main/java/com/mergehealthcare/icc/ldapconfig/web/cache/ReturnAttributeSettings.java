
package com.mergehealthcare.icc.ldapconfig.web.cache;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@SuppressWarnings ("PMD.UseConcurrentHashMap")
public class ReturnAttributeSettings {

    private Map<ServerType, List<String>> domainSettings;

    private Map<ServerType, List<String>> domainDefaultSettings;

    private Map<ServerType, List<String>> userSettings;

    private Map<ServerType, List<String>> userDefaultSettings;

    private Map<ServerType, List<String>> roleSettings;

    private Map<ServerType, List<String>> roleDefaultSettings;

    private Map<ServerType, List<String>> sgGroupSettings;

    private Map<ServerType, List<String>> sgGroupDefaultSettings;

    private Map<ServerType, List<String>> ouGroupSettings;

    private Map<ServerType, List<String>> ouGroupDefaultSettings;

    @Autowired
    public Environment environment;


    public Map<ServerType, List<String>> getDomainSettings() {
        if (ObjectUtils.isNull(domainSettings)) {
            domainSettings = new HashMap<>();
            domainSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("domain.ad").split(",")));
            domainSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("domain.apache").split(",")));
            domainSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("domain.open").split(",")));
        }
        return domainSettings;
    }


    public Map<ServerType, List<String>> getDefalutDomainSettings() {
        if (ObjectUtils.isNull(domainDefaultSettings)) {
            domainDefaultSettings = new HashMap<>();
            domainDefaultSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("domain.default.ad").split(",")));
            domainDefaultSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("domain.default.apache").split(",")));
            domainDefaultSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("domain.default.open").split(",")));
        }
        return domainDefaultSettings;
    }


    public Map<ServerType, List<String>> getUserSettings() {
        if (ObjectUtils.isNull(userSettings)) {
            userSettings = new HashMap<>();
            userSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("user.ad").split(",")));
            userSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("user.apache").split(",")));
            userSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("user.open").split(",")));
        }
        return userSettings;
    }


    public Map<ServerType, List<String>> getDefalutUserSettings() {
        if (ObjectUtils.isNull(userDefaultSettings)) {
            userDefaultSettings = new HashMap<>();
            userDefaultSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("user.default.ad").split(",")));
            userDefaultSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("user.default.apache").split(",")));
            userDefaultSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("user.default.open").split(",")));
        }
        return userDefaultSettings;
    }


    public Map<ServerType, List<String>> getRoleSettings() {
        if (ObjectUtils.isNull(roleSettings)) {
            roleSettings = new HashMap<>();
            roleSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("role.ad").split(",")));
            roleSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("role.apache").split(",")));
            roleSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("role.open").split(",")));
        }
        return roleSettings;

    }


    public Map<ServerType, List<String>> getDefalutRoleSettings() {
        if (ObjectUtils.isNull(roleDefaultSettings)) {
            roleDefaultSettings = new HashMap<>();
            roleDefaultSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("role.default.ad").split(",")));
            roleDefaultSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("role.default.apache").split(",")));
            roleDefaultSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("role.default.open").split(",")));
        }
        return roleDefaultSettings;

    }


    public Map<ServerType, List<String>> getSgGroupSettings() {
        if (ObjectUtils.isNull(sgGroupSettings)) {
            sgGroupSettings = new HashMap<>();
            sgGroupSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("sggroup.ad").split(",")));
            sgGroupSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("sggroup.apache").split(",")));
            sgGroupSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("sggroup.open").split(",")));
        }
        return sgGroupSettings;
    }


    public Map<ServerType, List<String>> getDefalutSgGroupSettings() {
        if (ObjectUtils.isNull(sgGroupDefaultSettings)) {
            sgGroupDefaultSettings = new HashMap<>();
            sgGroupDefaultSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("sggroup.default.ad").split(",")));
            sgGroupDefaultSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("sggroup.default.apache").split(",")));
            sgGroupDefaultSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("sggroup.default.open").split(",")));
        }
        return sgGroupDefaultSettings;
    }


    public Map<ServerType, List<String>> getOuGroupSettings() {
        if (ObjectUtils.isNull(ouGroupSettings)) {
            ouGroupSettings = new HashMap<>();
            ouGroupSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("ougroup.ad").split(",")));
            ouGroupSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("ougroup.apache").split(",")));
            ouGroupSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("ougroup.open").split(",")));
        }
        return ouGroupSettings;

    }


    public Map<ServerType, List<String>> getDefalutOuGroupSettings() {
        if (ObjectUtils.isNull(ouGroupDefaultSettings)) {
            ouGroupDefaultSettings = new HashMap<>();
            ouGroupDefaultSettings.put(ServerType.AD, Arrays.asList(environment.getProperty("ougroup.default.ad").split(",")));
            ouGroupDefaultSettings.put(ServerType.Apache, Arrays.asList(environment.getProperty("ougroup.default.apache").split(",")));
            ouGroupDefaultSettings.put(ServerType.OpenLdap, Arrays.asList(environment.getProperty("ougroup.default.open").split(",")));
        }
        return ouGroupDefaultSettings;
    }

}
