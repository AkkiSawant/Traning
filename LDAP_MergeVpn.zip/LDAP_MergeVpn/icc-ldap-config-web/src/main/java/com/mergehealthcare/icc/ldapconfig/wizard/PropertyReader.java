/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.wizard;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * The Class PropertyReader.
 *
 * @author sarikam2
 */
@Configuration
@PropertySource ("classpath:messages.properties")
public class PropertyReader {

  @Value ("${ADD_SERVER_SUCCESS}")
  private String addServerSuccess;

  @Value ("${ADD_SERVER_ERROR}")
  private String addServerError;

  @Value ("${UPDATE_SERVER_SUCCESS}")
  private String updateServerMessage;

  @Value ("${DELETE_SERVER_SUCCESS}")
  private String deleteServerMessage;

  @Value ("${CONNECTION_SUCCESSFUL}")
  private String connectionSuccessfulMessage;


  @Bean
  public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
    return new PropertySourcesPlaceholderConfigurer();
  }


  public String getAddServerSuccess() {
    return this.addServerSuccess;
  }


  public void setAddServerSuccess(String addServerSuccess) {
    this.addServerSuccess = addServerSuccess;
  }


  public String getAddServerError() {
    return this.addServerError;
  }


  public void setAddServerError(String addServerError) {
    this.addServerError = addServerError;
  }


  public String getUpdateServerMessage() {
    return this.updateServerMessage;
  }


  public void setUpdateServerMessage(String updateServerError) {
    this.updateServerMessage = updateServerError;
  }


  public String getDeleteServerMessage() {
    return deleteServerMessage;
  }


  public void setDeleteServerMessage(String deleteServerMessage) {
    this.deleteServerMessage = deleteServerMessage;
  }


  public String getConnectionSuccessfulMessage() {
    return connectionSuccessfulMessage;
  }


  public void setConnectionSuccessfulMessage(String connectionSuccessfulMessage) {
    this.connectionSuccessfulMessage = connectionSuccessfulMessage;
  }
}
