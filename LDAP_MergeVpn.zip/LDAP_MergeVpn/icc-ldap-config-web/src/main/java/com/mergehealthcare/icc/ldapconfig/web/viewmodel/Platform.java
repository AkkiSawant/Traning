
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;
/**
 * The Enum Platform.
 */
public enum Platform {

  Java, Net;
  
  public static Platform getPlatform(String value){
      return Platform.valueOf(value);
  }

}
