package com.mergehealthcare.icc.ldapconfig.web.viewmodel;


/**
 * The Class BasicInfoItemViewModelBase.
 */
public class BasicInfoItemViewModelBase {

    private boolean returnedAttributesEnabled;

    private boolean attributeMapEnabled;

    private boolean valueMapEnabled;

    private String filter;

    private String targetDn;

    private boolean enableNamePattern;

    private String pattern;

    private String locatorType;

    private String ldapGroupRepresentation;

    private boolean enableGroupHierarchyPattern;

    private String groupHierarchySeperator;

    private String groupHierarchy;


    public boolean isReturnedAttributesEnabled() {
        return returnedAttributesEnabled;
    }


    public void setReturnedAttributesEnabled(boolean returnedAttributesEnabled) {
        this.returnedAttributesEnabled = returnedAttributesEnabled;
    }


    public boolean isAttributeMapEnabled() {
        return attributeMapEnabled;
    }


    public void setAttributeMapEnabled(boolean attributeMapEnabled) {
        this.attributeMapEnabled = attributeMapEnabled;
    }


    public boolean isValueMapEnabled() {
        return valueMapEnabled;
    }


    public void setValueMapEnabled(boolean valueMapEnabled) {
        this.valueMapEnabled = valueMapEnabled;
    }


    public String getFilter() {
        return filter;
    }


    public void setFilter(String filter) {
        this.filter = filter;
    }


    public String getTargetDn() {
        return targetDn;
    }


    public void setTargetDn(String targetDn) {
        this.targetDn = targetDn;
    }


    public String getLocatorType() {
        return locatorType;
    }


    public void setLocatorType(String locatorType) {
        this.locatorType = locatorType;
    }


    public String getLdapGroupRepresentation() {
        return ldapGroupRepresentation;
    }


    public void setLdapGroupRepresentation(String ldapGroupRepresentation) {
        this.ldapGroupRepresentation = ldapGroupRepresentation;
    }


    public boolean isEnableGroupHierarchyPattern() {
        return enableGroupHierarchyPattern;
    }


    public void setEnableGroupHierarchyPattern(boolean enableGroupHierarchyPattern) {
        this.enableGroupHierarchyPattern = enableGroupHierarchyPattern;
    }


    public String getGroupHierarchySeperator() {
        return groupHierarchySeperator;
    }


    public void setGroupHierarchySeperator(String groupHierarchySeperator) {
        this.groupHierarchySeperator = groupHierarchySeperator;
    }


    public String getGroupHierarchy() {
        return groupHierarchy;
    }


    public void setGroupHierarchy(String groupHierarchy) {
        this.groupHierarchy = groupHierarchy;
    }


    public String getPattern() {
        return pattern;
    }


    public void setPattern(String pattern) {
        this.pattern = pattern;
    }


    public boolean isEnableNamePattern() {
        return enableNamePattern;
    }


    public void setEnableNamePattern(boolean enableNamePattern) {
        this.enableNamePattern = enableNamePattern;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder toStringBuilder;
        toStringBuilder = new StringBuilder("BasicInfoItemViewModelBase{");
        toStringBuilder.append("returnedAttributesEnabled=").append(this.returnedAttributesEnabled);
        toStringBuilder.append(",attributeMapEnabled=").append(this.attributeMapEnabled);
        toStringBuilder.append(",valueMapEnabled=").append(this.valueMapEnabled);
        toStringBuilder.append(",filter=").append(this.filter);
        toStringBuilder.append(",targetDn=").append(this.targetDn);
        toStringBuilder.append(",enableNamePattern=").append(this.enableNamePattern);
        toStringBuilder.append(",pattern=").append(this.pattern);
        toStringBuilder.append(",locatorType=").append(this.locatorType);
        toStringBuilder.append(",ldapGroupRepresentation=").append(this.ldapGroupRepresentation);
        toStringBuilder.append(",enableGroupHierarchyPattern=").append(this.enableGroupHierarchyPattern);
        toStringBuilder.append(",groupHierarchySeperator=").append(this.groupHierarchySeperator);
        toStringBuilder.append(",groupHierarchy=").append(this.groupHierarchy);
        toStringBuilder.append('}');
        return toStringBuilder.toString();
    }

}
