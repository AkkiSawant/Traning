/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.cache.AttributeMapSettings;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ModelOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapNode;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.ldap.server.configuration.AttributeMap;
import icc.ldap.server.configuration.Locator;
import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mapper;
import icc.ldap.server.configuration.MapperConverterProperties;
import icc.ldap.server.configuration.MapperConverterProperty;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.ReturnedDefaultAttribute;
import icc.ldap.server.configuration.ReturnedDefaultAttributes;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.SiteDomain;
import icc.ldap.server.configuration.SiteDomains;
import icc.ldap.server.configuration.ValueMap;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author sarikam2
 */
@Component
public class IdentityModelOptionModelMapper {

    @Autowired
    private ObjectFactory objectFactory;

    private static final Logger logger = LogService.getLogger(IdentityModelOptionModelMapper.class);

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private ReturnAttributeSettings returnAttributeSettings;


    /**
     * Convert model to identity setting configuration.
     *
     * @param serverConfiguration
     *            the server configuration
     * @param identityViewModel
     *            the identity view model
     * @return the server configuration
     * @throws LdapConfigDataException
     *             the ldap config data exception
     */
    private ServerConfiguration convertModelToIdentitySettingConfiguration(ServerConfiguration serverConfiguration,
                    IdentitySettingsViewModel identityViewModel) throws LdapConfigDataException {
        Model model = serverConfiguration.getModel();
        if (ObjectUtils.isNull(model)) {
            model = objectFactory.createModel();
        }
        String serverType = serverConfiguration.getServerDetails().getType();
        model = MapperLocatorUtility.prepareLocatorObject(model, identityViewModel);
        model = MapperLocatorUtility.prepareMapperObject(model, identityViewModel, serverType);
        serverConfiguration.setModel(model);
        return serverConfiguration;
    }


    /**
     * Find model option by server name.
     *
     * @param serverName
     *            the server name
     * @return the model options view model
     * @throws LdapConfigDataException
     *             the ldap config data exception
     */
    public ModelOptionsViewModel findModelOptionByServerName(String serverName) throws LdapConfigDataException {
        int count = 0;
        ModelOptionsViewModel modelOptionModel = BeanUtils.instantiateClass(ModelOptionsViewModel.class);
        if (ObjectUtils.isNull(serverName)) {
            throw new LdapConfigDataException("ServerName parameter is null");
        }
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
        Model model = serverConfiguration.getModel();
        if (!ObjectUtils.isNull(model)) {
            modelOptionModel.setModelGrouping(model.getType());
            modelOptionModel.setRootDistinguishedName(model.getRootDistinguishedName());
        }
        SiteDomains siteDomainsMain = serverConfiguration.getServerDetails().getSiteDomains();
        Map<String, SiteDomain> siteDomainData = null;
        if (!ObjectUtils.isNull(siteDomainsMain)) {
            siteDomainData = siteDomainsMain.getSiteDomain();
        }

        if (!ObjectUtils.isNull(siteDomainsMain) && !ObjectUtils.isNull(siteDomainData) && !siteDomainData.isEmpty()) {

            StringBuilder siteDomains = new StringBuilder();
            for (Map.Entry<String, SiteDomain> entry : siteDomainData.entrySet()) {
                SiteDomain domainValue = entry.getValue();
                if (domainValue != null && (domainValue.getDomainName() != null)) {
                    SiteDomain siteDomain = domainValue;
                    siteDomains.append(siteDomain.getDomainName()).append(",");
                }
            }
            if (siteDomains.length() > count) {
                modelOptionModel.setOrganizationalUnitDomain(siteDomains.substring(0, siteDomains.length() - 1));
            }

        }
        logger.info("Retrieved ModelOption: " + modelOptionModel);
        return modelOptionModel;
    }


    /**
     * Save model option configuration.
     *
     * @param modelOption
     *            the model option
     * @param serverName
     *            the server name
     * @param modifyMode
     *            the modify mode
     * @throws LdapConfigDataException
     *             the ldap config data exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void saveModelOptionConfiguration(ModelOptionsViewModel modelOption, String serverName, Boolean modifyMode)
                    throws LdapConfigDataException, IOException {
        logger.info("Saving model option configuration from model...");
        if (ObjectUtils.isNull(modelOption)) {
            throw new LdapConfigDataException("Model data cannot be null");
        }
        if (ObjectUtils.isNull(serverName)) {
            throw new LdapConfigDataException("Server name cannot be null");
        }
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
        ServerConfiguration serverConfig = convertModelToModelOptionConfiguration(serverConfiguration, modelOption, modifyMode);
        serverDetailsService.modify(serverConfig);
        logger.info("Server configuration saved!");
    }


    /**
     * Convert model to model option configuration.
     *
     * @param serverConfiguration
     *            the server configuration
     * @param modelOption
     *            the model option
     * @param modifyMode
     *            the modify mode
     * @return the server configuration
     */
    private ServerConfiguration convertModelToModelOptionConfiguration(ServerConfiguration serverConfiguration,
                    ModelOptionsViewModel modelOption, Boolean modifyMode) {

        String server = serverConfiguration.getServerDetails().getType();
        ServerType serverType = ServerType.valueOf(server);
        Model model = serverConfiguration.getModel();
        if (ObjectUtils.isNull(model)) {
            model = objectFactory.createModel();
        }
        model.setType(modelOption.getModelGrouping());
        model.setRootDistinguishedName(modelOption.getRootDistinguishedName());
        String[] siteDomain = modelOption.getOrganizationalUnitDomain().split(",");
        String[] uniqueSiteDomains = new HashSet<String>(Arrays.asList(siteDomain)).toArray(new String[0]);
        if (uniqueSiteDomains != null && uniqueSiteDomains.length > 0) {
            SiteDomains siteDomains = objectFactory.createEmptySiteDomains();
            serverConfiguration.getServerDetails().setSiteDomains(siteDomains);
            for (int domain = 0; domain < uniqueSiteDomains.length; domain++) {
                SiteDomain siteDomainData = objectFactory.createSiteDomain();
                siteDomainData.setDomainName(uniqueSiteDomains[domain]);
                serverConfiguration.getServerDetails().getSiteDomains().getSiteDomain().put(uniqueSiteDomains[domain], siteDomainData);
            }
        } else {
            if (ObjectUtils.isNull(serverConfiguration.getServerDetails().getSiteDomains())) {
                SiteDomains siteDomains = objectFactory.createSiteDomains();
                serverConfiguration.getServerDetails().setSiteDomains(siteDomains);
            }
        }
        Locators locators = model.getLocators();
        Locator locator = locators.getLocator(LdapConfigConstant.GROUP);
        if (modelOption.getModelGrouping().equals(LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED)) {
            locator.setTargetDistinguishedName(modelOption.getRootDistinguishedName());
            locator.setType(LdapConfigConstant.UNGROUPED_TYPE);
            locator.setIdentityFilterPattern(LdapConfigConstant.OU_UNIT);
            model.getLocators().getLocator().put(LdapConfigConstant.GROUP, locator);
        } else {
            if (!modifyMode) {
                if (ObjectUtils.isNotNullOrEmpty(locator.getTargetDistinguishedName())) {
                    model.getLocators().getLocator().remove(LdapConfigConstant.GROUP);
                    Locator group = objectFactory.createLocator();
                    group.setIdentityName(LdapConfigConstant.GROUP);
                    model.getLocators().getLocator().put(LdapConfigConstant.GROUP, group);
                }
            }
        }

        Mappers mappers = model.getMappers();
        Mapper mapper = mappers.getMapper(LdapConfigConstant.GROUP);
        if (modelOption.getModelGrouping().equals(LdapConfigConstant.SINGLE_DOMAIN_UNGROUPED)) {
            mapper.setIdentityName(LdapConfigConstant.GROUP);

            ValueMap valMap = objectFactory.createValueMap();
            valMap.setType(LdapConfigConstant.IDENTITY);

            AttributeMap attrMap = objectFactory.createAttributeMap();
            attrMap.setType(LdapConfigConstant.DICTIONARY);

            MapperConverterProperties mapperConvertorProp = attrMap.getMapperConverterProperties();

            List<AttributeMapNode> attributeMapNodes = AttributeMapSettings.OU_GROUPSETTINGS.get(serverType);

            for (AttributeMapNode attributeMapNode : attributeMapNodes) {
                MapperConverterProperty mapperConverterProperty = objectFactory.createMapperConverterProperty();
                mapperConverterProperty.setKey(attributeMapNode.getIdentityProperty());
                String ldapAttributeValue = attributeMapNode.getLdapProperty() == null ? "" : attributeMapNode.getLdapProperty();
                mapperConverterProperty.setValue(ldapAttributeValue);
                mapperConverterProperty.setIgnore(attributeMapNode.isIgnore());
                mapperConvertorProp.getMapperConverterProperty().put(attributeMapNode.getIdentityProperty(), mapperConverterProperty);
            }

            ReturnedDefaultAttributes returnedDefaultAttributes = objectFactory.createReturnedDefaultAttributes();
            Map<String, ReturnedDefaultAttribute> returnedDefaultAttributeMap = returnedDefaultAttributes.getReturnedDefaultAttribute();
            List<String> defaultAttributes = returnAttributeSettings.getDefalutOuGroupSettings().get(serverType);
            Iterator<String> itr = defaultAttributes.iterator();
            while (itr.hasNext()) {
                String attributeName = itr.next();
                ReturnedDefaultAttribute returnedDefaultAttribute = objectFactory.createReturnedDefaultAttribute();
                returnedDefaultAttribute.setAttributeName(attributeName);
                returnedDefaultAttributeMap.put(attributeName, returnedDefaultAttribute);
            }

            mapper.setValueMap(valMap);
            mapper.setAttributeMap(attrMap);
            mapper.setReturnedDefaultAttributes(returnedDefaultAttributes);

        } else {
            if (!modifyMode) {
                if (ObjectUtils.isNotNullOrEmpty(mapper.getIdentityName())) {
                    model.getMappers().getMapper().remove(LdapConfigConstant.GROUP);
                    Mapper map = objectFactory.createMapper();
                    map.setIdentityName(LdapConfigConstant.GROUP);
                    model.getMappers().getMapper().put(LdapConfigConstant.GROUP, map);
                }
            }
        }

        serverConfiguration.setModel(model);
        return serverConfiguration;
    }


    /**
     * Save identity configuration.
     *
     * @param identityViewModel
     *            the identity view model
     * @param serverName
     *            the server name
     * @throws LdapConfigDataException
     *             the ldap config data exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public void saveIdentityConfiguration(Object identityViewModel, String serverName) throws LdapConfigDataException, IOException {
        if (identityViewModel instanceof IdentitySettingsViewModel) {
            IdentitySettingsViewModel identitySettingsViewModel = (IdentitySettingsViewModel) identityViewModel;
            String selectedAttrs = identitySettingsViewModel.getReturnedAttributesVm().getSelectedDefaultAttribute();
            List<String> selected = Arrays.asList(selectedAttrs.split(","));
            identitySettingsViewModel.getReturnedAttributesVm().setDefaultAttributes(new HashSet<>(selected));
            MapItemViewModelBase.MapOption mapOptionAttr = identitySettingsViewModel.getAttributeMapVm().getMapOption();
            MapItemViewModelBase.MapOption mapOptionValueMap = identitySettingsViewModel.getValueMapVm().getMapOption();
            logger.info("No Map option for AttributeMap = " + mapOptionAttr);
            logger.info("No Map option for ValueMap = " + mapOptionValueMap);
            if (mapOptionAttr == MapItemViewModelBase.MapOption.NO_MAP) {
                identitySettingsViewModel.getAttributeMapVm().setAttributes(new ArrayList<AttributeMapNode>());
            }
            if (mapOptionValueMap == MapItemViewModelBase.MapOption.NO_MAP) {
                identitySettingsViewModel.getValueMapVm().setValueMap(new ArrayList<ValueMapNode>());
            }
            saveIdentityConfiguration(identitySettingsViewModel, serverName);
            logger.info(String.format("Identity Configuration of %s is saved", serverName));
        } else {
            throw new LdapConfigDataException("Wrong Parameter of IdentityViewModel");
        }
    }


    /**
     * Save identity configuration.
     *
     * @param identityViewModel
     *            the identity view model
     * @param serverName
     *            the server name
     * @throws LdapConfigDataException
     *             the ldap config data exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    private void saveIdentityConfiguration(IdentitySettingsViewModel identityViewModel, String serverName)
                    throws LdapConfigDataException, IOException {
        logger.info("Saving domain identity configuration from model...");
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
        ServerConfiguration serverConfig = this.convertModelToIdentitySettingConfiguration(serverConfiguration, identityViewModel);
        serverDetailsService.modify(serverConfig);
        logger.info("Server configuration saved!");
    }

}
