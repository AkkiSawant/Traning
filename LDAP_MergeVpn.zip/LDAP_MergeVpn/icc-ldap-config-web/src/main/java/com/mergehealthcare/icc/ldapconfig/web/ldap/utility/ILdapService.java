
package com.mergehealthcare.icc.ldapconfig.web.ldap.utility;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.SearchScope;

import icc.base.exception.IOCException;

import java.util.List;
import java.util.Map;

/**
 * The Interface ILdapService.
 */
public interface ILdapService {

  /**
   * Authenticate user.
   *
   * @param userName the user name
   * @param password the password
   * @return true, if successful
   * @throws IOCException the IOC exception
   */
  boolean authenticateUser(String userName, String password) throws LdapConfigDataException;


  /**
   * Search.
   *
   * @param targetDn the target dn
   * @param filter the filter
   * @param serverName the server name
   * @param searchScope the search scope
   * @param attributeList the attribute list
   * @return the list
   * @throws IOCException the IOC exception
   * @throws LDAPException the LDAP exception
   */
  List<LdapTree> search(String targetDn, String filter, String serverName, SearchScope searchScope,
      List<String> attributeList) throws LdapConfigDataException;


  /**
   * Gets the ldap tree.
   *
   * @param serverName the server name
   * @param targetDn the target dn
   * @return the ldap tree
   * @throws LDAPException the LDAP exception
   * @throws IOCException the IOC exception
   */
  LdapTree getLdapTree(String serverName, String targetDn) throws LdapConfigDataException;


  /**
   * Check ldap connection.
   *
   * @param serverName the server name
   * @return true, if successful
   * @throws IOCException the IOC exception
   */
  boolean checkLdapConnection(String serverName) throws LdapConfigDataException;


  /**
   * Gets the server identity.
   *
   * @param connectionDetails the connection details
   * @return the server identity
   * @throws IOCException the IOC exception
   */
  String getServerIdentity(Map<String, Object> connectionDetails) throws LdapConfigDataException;


  /**
   * Gets the server certificate.
   *
   * @param connectionDetails the connection details
   * @return the server certificate
   * @throws IOCException the IOC exception
   */
  String getServerCertificate(Map<String, Object> connectionDetails) throws LdapConfigDataException;


  /**
   * Gets the user system admin level.
   *
   * @param userId the user id
   * @return the user system admin level
   * @throws IOCException the IOC exception
   */
  String getUserSystemAdminLevel(String userId) throws LdapConfigDataException;


  /**
   * Gets the user group roles.
   *
   * @param userId the user id
   * @param groupId the group id
   * @param domainId the domain id
   * @return the user group roles
   * @throws IOCException the IOC exception
   */
  List<String> getUserGroupRoles(String userId, String groupId, String domainId)
      throws LdapConfigDataException;


  /**
   * Gets the user domain roles.
   *
   * @param userId the user id
   * @param domainId the domain id
   * @return the user domain roles
   * @throws IOCException the IOC exception
   */
  List<String> getUserDomainRoles(String userId, String domainId) throws LdapConfigDataException;


  /**
   * Gets the user managed domains.
   *
   * @param userId the user id
   * @return the user managed domains
   * @throws IOCException the IOC exception
   */
  List<String> getUserManagedDomains(String userId) throws LdapConfigDataException;


  /**
   * Gets the user managed groups.
   *
   * @param userId the user id
   * @param domainId the domain id
   * @return the user managed groups
   * @throws IOCException the IOC exception
   */
  List<String> getUserManagedGroups(String userId, String domainId) throws LdapConfigDataException;


  void setCurrentServer(String currentServer);
}
