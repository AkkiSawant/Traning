
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class LdapPropertiesDNVM.
 */
public class LdapPropertiesDNVM {

  private String serverName;

  private String dn;

  private String classType;

  private String modelGrouping;

  private String filter;


  /**
   * @return the serverName
   */
  public String getServerName() {
    return serverName;
  }


  /**
   * @param serverName the serverName to set
   */
  public void setServerName(String serverName) {
    this.serverName = serverName;
  }


  /**
   * @return the dn
   */
  public String getDn() {
    return dn;
  }


  /**
   * @param dn the dn to set
   */
  public void setDn(String dn) {
    this.dn = dn;
  }


  /**
   * @return the classType
   */
  public String getClassType() {
    return classType;
  }


  /**
   * @param classType the classType to set
   */
  public void setClassType(String classType) {
    this.classType = classType;
  }


  /**
   * @return the modelGrouping
   */
  public String getModelGrouping() {
    return modelGrouping;
  }


  /**
   * @param modelGrouping the modelGrouping to set
   */
  public void setModelGrouping(String modelGrouping) {
    this.modelGrouping = modelGrouping;
  }


  /**
   * @return the filter
   */
  public String getFilter() {
    return filter;
  }


  /**
   * @param filter the filter to set
   */
  public void setFilter(String filter) {
    this.filter = filter;
  }


  /**
   * Instantiates a new ldap properties DNVM.
   *
   * @param serverName the server name
   * @param dn the dn
   * @param classType the class type
   * @param modelGrouping the model grouping
   * @param filter the filter
   */
  public LdapPropertiesDNVM(String serverName, String dn, String classType, String modelGrouping,
      String filter) {
    this.serverName = serverName;
    this.dn = dn;
    this.classType = classType;
    this.modelGrouping = modelGrouping;
    this.filter = filter;
  }


  @Override
  public int hashCode() {
    int prime = 31;
    int result = 1;
    result = prime * result + ((classType == null) ? 0 : classType.hashCode());
    result = prime * result + ((dn == null) ? 0 : dn.hashCode());
    result = prime * result + ((filter == null) ? 0 : filter.hashCode());
    result = prime * result + ((modelGrouping == null) ? 0 : modelGrouping.hashCode());
    result = prime * result + ((serverName == null) ? 0 : serverName.hashCode());
    return result;
  }


  @Override
  public boolean equals(Object obj) {
    boolean result = true;
    if (this == obj) {
      result = true;
    }
    if (obj == null) {
      result = false;
    }
    if (getClass() != obj.getClass()) {
      result = false;
    }
    LdapPropertiesDNVM other = (LdapPropertiesDNVM) obj;
    if (classType == null) {
      if (other.classType != null) {
        result = false;
      }
    } else if (!classType.equals(other.classType)) {
      result = false;
    }
    if (dn == null) {
      if (other.dn != null) {
        result = false;
      }
    } else if (!dn.equals(other.dn)) {
      result = false;
    }
    if (filter == null) {
      if (other.filter != null) {
        result = false;
      }
    } else if (!filter.equals(other.filter)) {
      result = false;
    }
    if (modelGrouping == null) {
      if (other.modelGrouping != null) {
        result = false;
      }
    } else if (!modelGrouping.equals(other.modelGrouping)) {
      result = false;
    }
    if (serverName == null) {
      if (other.serverName != null) {
        result = false;
      }
    } else if (!serverName.equals(other.serverName)) {
      result = false;
    }
    return result;
  }
}
