
package com.mergehealthcare.icc.ldapconfig.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;

/**
 * The Class GlobalExceptionController.
 */
@ControllerAdvice
public class GlobalExceptionController {

    private static final Logger logger = LogService.getLogger(GlobalExceptionController.class);


    /**
     * Handler exception.
     *
     * @param request the request
     * @param ex the ex
     * @return the model and view
     */
    @ExceptionHandler (Exception.class)
    public ModelAndView handlerException(HttpServletRequest request, Exception ex) {
        logger.error("Requested URL=" + request.getRequestURL());
        logger.error("Exception Raised=", ex);
        ex.printStackTrace();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("exception", ex);
        modelAndView.addObject("url", request.getRequestURL());
        modelAndView.setViewName("error");
        logger.error("Exception Raised=", ex);
        return modelAndView;
    }

}
