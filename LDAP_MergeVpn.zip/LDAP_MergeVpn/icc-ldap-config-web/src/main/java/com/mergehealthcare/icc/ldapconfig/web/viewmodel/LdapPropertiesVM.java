/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 *
 * @author sarikam2
 */
public class LdapPropertiesVM {

  private String serverName;

  private String dn;

  private String classType;

  private ServerType serverTypeEnum;

  private String modelGrouping;

  private String filter;


  /**
   * @return the serverName
   */
  public String getServerName() {
    return serverName;
  }


  /**
   * @param serverName the serverName to set
   */
  public void setServerName(String serverName) {
    this.serverName = serverName;
  }


  /**
   * @return the dn
   */
  public String getDn() {
    return dn;
  }


  /**
   * @param dn the dn to set
   */
  public void setDn(String dn) {
    this.dn = dn;
  }


  /**
   * @return the classType
   */
  public String getClassType() {
    return classType;
  }


  /**
   * @param classType the classType to set
   */
  public void setClassType(String classType) {
    this.classType = classType;
  }


  /**
   * @return the serverTypeEnum
   */
  public ServerType getServerTypeEnum() {
    return serverTypeEnum;
  }


  /**
   * @param serverTypeEnum the serverTypeEnum to set
   */
  public void setServerTypeEnum(ServerType serverTypeEnum) {
    this.serverTypeEnum = serverTypeEnum;
  }


  /**
   * @return the modelGrouping
   */
  public String getModelGrouping() {
    return modelGrouping;
  }


  /**
   * @param modelGrouping the modelGrouping to set
   */
  public void setModelGrouping(String modelGrouping) {
    this.modelGrouping = modelGrouping;
  }


  /**
   * @return the filter
   */
  public String getFilter() {
    return filter;
  }


  /**
   * @param filter the filter to set
   */
  public void setFilter(String filter) {
    this.filter = filter;
  }


  /**
   * Instantiates a new ldap properties VM.
   *
   * @param serverName the server name
   * @param dn the dn
   * @param classType the class type
   * @param serverTypeEnum the server type enum
   * @param modelGrouping the model grouping
   * @param filter the filter
   */
  public LdapPropertiesVM(String serverName, String dn, String classType, ServerType serverTypeEnum,
      String modelGrouping, String filter) {
    this.serverName = serverName;
    this.dn = dn;
    this.classType = classType;
    this.serverTypeEnum = serverTypeEnum;
    this.modelGrouping = modelGrouping;
    this.filter = filter;
  }
}
