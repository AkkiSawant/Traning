package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.LdapServiceManager;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.TestServerConfigurationViewModel;
import com.unboundid.ldap.sdk.LDAPException;

import icc.base.exception.IOCException;
import icc.ldap.testtool.utils.StreamUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

/**
 * The Class TestServerHelper.
 */
@Component
public class TestServerHelper {

    @Autowired
    private LdapServiceManager ldapServiceManager;

    private static final String DELIMITER = ",";

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private ICCEnvironmentConfig iccEnvironmentConfig;


    /**
     * Gets the authorization result.
     *
     * @param testServerModel the test server model
     * @param serverName the server name
     * @param userId the user id
     * @return the authorization result
     * @throws LDAPException the LDAP exception
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOCException the IOC exception
     */
    public String getAuthorizationResult(TestServerConfigurationViewModel testServerModel, String serverName, String userId)
                    throws LDAPException, LdapConfigDataException, IOCException {
        LdapServiceManager newLdapServiceManager = ldapServiceManager.getPltformSpecificServiceManager();

        String authorizeResult = "";
        if (testServerModel.isUserAdminLevelTestEnabled()) {
            String systemAdminLevel = newLdapServiceManager.getUserSystemAdminLevel(userId);
            authorizeResult += "The user " + testServerModel.getUserName() + " has " + systemAdminLevel + " system admin level.\n";
        }

        if (testServerModel.isDomainsAdministratorTestEnabled()) {
            String domainAdminList = convertListToString(newLdapServiceManager.getUserManagedDomains(userId));
            if (ObjectUtils.isNullOrEmpty(domainAdminList)) {
                authorizeResult += "There are no domains where the user " + testServerModel.getUserName() + " is administrator.\n";
            } else {
                authorizeResult += "The domain/s where the user " + testServerModel.getUserName() + " is administrator is/are "
                                + domainAdminList + ".\n";

            }
        }

        if (testServerModel.isGroupsAdministratorTestEnabled()) {
            String groupAdminList = convertListToString(newLdapServiceManager
                            .getUserManagedGroups(userId, testServerModel.getGroupDomainText()));
            if (ObjectUtils.isNullOrEmpty(groupAdminList)) {
                authorizeResult += "There are no groups where the user " + testServerModel.getUserName() + " is administrator in domain "
                                + testServerModel.getGroupDomainText() + ".\n";
            } else {
                authorizeResult += "The group/s where the user " + testServerModel.getUserName() + " is administrator in "
                                + testServerModel.getGroupDomainText() + " domain is/are " + groupAdminList + ".\n";

            }
        }

        if (testServerModel.isRolesInDomainTestEnabled()) {
            String rolesOfUserInDomain = convertListToString(newLdapServiceManager.getUserDomainRoles(userId,
                            testServerModel.getRoleDomainText()));
            if (ObjectUtils.isNullOrEmpty(rolesOfUserInDomain)) {
                authorizeResult += "The user " + testServerModel.getUserName() + " does not have roles in "
                                + testServerModel.getRoleDomainText() + " domain.";
            } else {
                authorizeResult += "The role/s of the user " + testServerModel.getUserName() + " in " + testServerModel.getRoleDomainText()
                                + " domain is/are " + rolesOfUserInDomain + ".\n";
            }
        }
        if (testServerModel.isGroupRolesInDomainTestEnabled()) {
            String rolesOfUserInGrp = convertListToString(newLdapServiceManager.getUserGroupRoles(userId,
                            testServerModel.getGroupRoleGroupText(), testServerModel.getGroupRoleDomainText()));
            if (ObjectUtils.isNullOrEmpty(rolesOfUserInGrp)) {
                authorizeResult += "The user " + testServerModel.getUserName() + " does not have roles in "
                                + testServerModel.getGroupRoleGroupText() + " group of the " + testServerModel.getGroupRoleDomainText()
                                + " domain.";

            } else {
                authorizeResult += "The role/s of the user in group " + testServerModel.getGroupRoleGroupText() + " group of the "
                                + testServerModel.getGroupRoleDomainText() + " is/are " + rolesOfUserInGrp + ".\n";
            }
        }
        return authorizeResult;

    }


    /**
     * Convert list to string.
     *
     * @param list the list
     * @return the string
     * @throws IOCException the IOC exception
     */
    private String convertListToString(List<String> list) throws IOCException {
        return StreamUtil.strJoin(list, DELIMITER);
    }


    /**
     * Authenticate user.
     *
     * @param userName the user name
     * @param password the password
     * @return true, if successful
     * @throws IOCException the IOC exception
     * @throws LdapConfigDataException
     */
    public boolean authenticateUser(String userName, String password) throws LdapConfigDataException {
        return ldapServiceManager.getPltformSpecificServiceManager().authenticateUser(userName, password);
    }


    /**
     * Check ldap connection.
     *
     * @param serverName the server name
     * @return true, if successful
     * @throws IOCException the IOC exception
     * @throws LdapConfigDataException
     */
    public boolean checkLdapConnection(String serverName) throws LdapConfigDataException {
        this.setCurrentServer(serverName);
        try {
            String tempVal = iccEnvironmentConfig.getPlatform();
            Platform platform = Platform.valueOf(tempVal);
            if (Platform.Net == platform) {
                serverDetailsService.saveTestConnectionConfig(serverName);
            }
        } catch (IOException e) {
            throw new LdapConfigDataException(e);
        }
        return ldapServiceManager.getPltformSpecificServiceManager().checkLdapConnection(serverName);

    }


    public void setCurrentServer(String currentServer) {

        ldapServiceManager.setCurrentServer(currentServer);

    }

}
