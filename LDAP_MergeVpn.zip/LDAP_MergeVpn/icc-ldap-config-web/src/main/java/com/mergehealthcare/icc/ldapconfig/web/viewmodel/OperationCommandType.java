
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum OperationCommandType.
 */
public enum OperationCommandType {
  simple, paged

}
