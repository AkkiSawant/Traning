
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class AttributeMapItemViewModel.
 */
public class AttributeMapItemViewModel extends MapItemViewModelBase {

  private List<AttributeMapNode> attributes = new ArrayList<>();


  public List<AttributeMapNode> getAttributes() {
    return attributes;
  }


  public void setAttributes(List<AttributeMapNode> attributes) {
    this.attributes = attributes;
  }


  /*
   * (non-Javadoc)
   * @see com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AttributeMapItemViewModel [attributes=");
    builder.append(attributes);
    builder.append("]");
    return builder.toString();
  }

}
