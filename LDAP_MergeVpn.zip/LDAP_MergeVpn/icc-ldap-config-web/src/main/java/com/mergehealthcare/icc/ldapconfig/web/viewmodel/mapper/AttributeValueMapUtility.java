/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapNode;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import icc.ldap.server.configuration.AttributeMap;
import icc.ldap.server.configuration.MapperConverterProperties;
import icc.ldap.server.configuration.MapperConverterProperty;
import icc.ldap.server.configuration.ReturnedDefaultAttribute;
import icc.ldap.server.configuration.ReturnedDefaultAttributes;
import icc.ldap.server.configuration.ValueMap;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author sarikam2
 */
@Component
@SuppressWarnings ("PMD.UseUtilityClass")
// cannot make this class final since
// Spring subclass this.
public class AttributeValueMapUtility {

    private static final Logger logger = LogService.getLogger(AttributeValueMapUtility.class);

    private static ObjectFactory objectFactory = new ObjectFactory();


    /**
     * Prepare returned default prop.
     *
     * @param returnedAttributesVm the returned attributes vm
     * @return the returned default attributes
     */
    public static ReturnedDefaultAttributes prepareReturnedDefaultProp(ReturnedAttributesItemViewModel returnedAttributesVm) {
        ReturnedDefaultAttributes returnedDefaultAttributes = objectFactory.createReturnedDefaultAttributes();
        Map<String, ReturnedDefaultAttribute> returnedDefaultAttributeMap = returnedDefaultAttributes.getReturnedDefaultAttribute();
        Set<String> defaultAttributes = returnedAttributesVm.getDefaultAttributes();
        Iterator<String> itr = defaultAttributes.iterator();
        while (itr.hasNext()) {
            String attributeName = itr.next();
            ReturnedDefaultAttribute returnedDefaultAttribute = objectFactory.createReturnedDefaultAttribute();
            returnedDefaultAttribute.setAttributeName(attributeName);
            returnedDefaultAttributeMap.put(attributeName, returnedDefaultAttribute);
        }
        return returnedDefaultAttributes;
    }


    /**
     * Prepare value map.
     *
     * @param valueMapVm the value map vm
     * @return the value map
     */
    public static ValueMap prepareValueMap(ValueMapItemViewModel valueMapVm) {
        ValueMap valueMap = objectFactory.createValueMap();
        if (valueMapVm.getMapOption() == MapItemViewModelBase.MapOption.DICTIONARY) {
            valueMap.setType(valueMapVm.getMapOption().name().toLowerCase());
        } else {
            valueMap.setType(LdapConfigConstant.IDENTITY);
        }
        valueMap.setMapperConverterProperties(prepareMapperConverterProp(valueMapVm.getValueMap()));
        return valueMap;
    }


    /**
     * Prepare attribute map.
     *
     * @param attributeMapItemViewModel the attribute map item view model
     * @return the attribute map
     */
    public static AttributeMap prepareAttributeMap(AttributeMapItemViewModel attributeMapItemViewModel, String serverType) {
        AttributeMap attributeMap = objectFactory.createAttributeMap();
        if (attributeMapItemViewModel.getMapOption() == MapItemViewModelBase.MapOption.DICTIONARY) {
            attributeMap.setType(attributeMapItemViewModel.getMapOption().name().toLowerCase());
        } else {
            attributeMap.setType(LdapConfigConstant.IDENTITY);
        }
        attributeMap.setMapperConverterProperties(prepareMapperConverterProp(attributeMapItemViewModel, serverType));
        return attributeMap;
    }


    /**
     * Prepare mapper converter prop.
     *
     * @param valueMap the value map
     * @return the mapper converter properties
     */
    private static MapperConverterProperties prepareMapperConverterProp(List<ValueMapNode> valueMap) {
        MapperConverterProperties mapperConverterProperties = objectFactory.createMapperConverterProperties();
        Iterator<ValueMapNode> itr = valueMap.iterator();
        while (itr.hasNext()) {
            ValueMapNode valueMapNode = itr.next();
            MapperConverterProperty mapperConverterProperty = objectFactory.createMapperConverterProperty();
            mapperConverterProperty.setKey(valueMapNode.getLdapValue());
            mapperConverterProperty.setValue(valueMapNode.getApplicationValue());
            mapperConverterProperties.getMapperConverterProperty().put(valueMapNode.getLdapValue(), mapperConverterProperty);
        }
        return mapperConverterProperties;
    }


    /**
     * Prepare mapper converter prop.
     *
     * @param attributeMapItemViewModel the attribute map item view model
     * @return the mapper converter properties
     */
    private static MapperConverterProperties prepareMapperConverterProp(AttributeMapItemViewModel attributeMapItemViewModel,
                    String serverType) {
        MapperConverterProperties mapperConverterProperties = objectFactory.createMapperConverterProperties();
        List<AttributeMapNode> attributeMapNodes = attributeMapItemViewModel.getAttributes();
        if (attributeMapNodes != null) {
            for (AttributeMapNode attributeMapNode : attributeMapNodes) {
                MapperConverterProperty mapperConverterProperty = objectFactory.createMapperConverterProperty();
                mapperConverterProperty.setKey(attributeMapNode.getIdentityProperty());
                String ldapAttributeValue = attributeMapNode.getLdapProperty() == null ? "" : attributeMapNode.getLdapProperty();
                if (!serverType.equals(ServerType.AD) && attributeMapNode.getIdentityProperty().equalsIgnoreCase("MemberOf")) {
                    mapperConverterProperty.setValue("");
                } else {
                    mapperConverterProperty.setValue(ldapAttributeValue);
                }
                mapperConverterProperty.setIgnore(attributeMapNode.isIgnore());
                mapperConverterProperties.getMapperConverterProperty().put(attributeMapNode.getIdentityProperty(), mapperConverterProperty);
            }
        }
        return mapperConverterProperties;
    }

}
