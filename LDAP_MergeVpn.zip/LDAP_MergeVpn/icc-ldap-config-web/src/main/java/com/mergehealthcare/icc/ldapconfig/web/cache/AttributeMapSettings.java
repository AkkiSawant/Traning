package com.mergehealthcare.icc.ldapconfig.web.cache;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings ("PMD.UseConcurrentHashMap")
public class AttributeMapSettings {

    public static final Map<ServerType, List<AttributeMapNode>> USERSETTINGS = new HashMap<>();

    public static final Map<ServerType, List<AttributeMapNode>> ROLESETTINGS = new HashMap<>();

    public static final Map<ServerType, List<AttributeMapNode>> SG_GROUPSETTINGS = new HashMap<>();

    public static final Map<ServerType, List<AttributeMapNode>> OU_GROUPSETTINGS = new HashMap<>();

    public static final Map<ServerType, List<AttributeMapNode>> DOMAINSETTINGS = new HashMap<>();


    private static Map<ServerType, List<AttributeMapNode>> setUserSettings() {

        List<AttributeMapNode> lstAttributeMapNodAD = new ArrayList<>();
        lstAttributeMapNodAD.add(new AttributeMapNode("UserId", "sAMAccountName"));
        lstAttributeMapNodAD.add(new AttributeMapNode("Email", "mail"));
        lstAttributeMapNodAD.add(new AttributeMapNode("UserName", "cn"));
        lstAttributeMapNodAD.add(new AttributeMapNode("FirstName", "givenName"));
        lstAttributeMapNodAD.add(new AttributeMapNode("LastName", "sn"));
        lstAttributeMapNodAD.add(new AttributeMapNode("MiddleName", "middleName", true));
        lstAttributeMapNodAD.add(new AttributeMapNode("NamePrefix", "", true));
        lstAttributeMapNodAD.add(new AttributeMapNode("NameSuffix", "", true));
        lstAttributeMapNodAD.add(new AttributeMapNode("PwdChanged", "pwdLastSet"));
        lstAttributeMapNodAD.add(new AttributeMapNode("PwdCreationDate", "whenCreated"));
        lstAttributeMapNodAD.add(new AttributeMapNode("PwdFailAttempt", "badPwdCount"));
        lstAttributeMapNodAD.add(new AttributeMapNode("LastLogonDate", "lastLogonTimestamp"));
        lstAttributeMapNodAD.add(new AttributeMapNode("IPAddress", "networkAddress"));
        lstAttributeMapNodAD.add(new AttributeMapNode("Active", "userAccountControl"));
        lstAttributeMapNodAD.add(new AttributeMapNode("MemberOf", "memberOf"));

        USERSETTINGS.put(ServerType.AD, lstAttributeMapNodAD);

        List<AttributeMapNode> lstAttributeMapNodApache = new ArrayList<>();

        lstAttributeMapNodApache.add(new AttributeMapNode("UserId", "uid"));
        lstAttributeMapNodApache.add(new AttributeMapNode("Email", "mail"));
        lstAttributeMapNodApache.add(new AttributeMapNode("UserName", "cn"));
        lstAttributeMapNodApache.add(new AttributeMapNode("FirstName", "givenname"));
        lstAttributeMapNodApache.add(new AttributeMapNode("LastName", "sn"));
        lstAttributeMapNodApache.add(new AttributeMapNode("MiddleName", "initials", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("NamePrefix", "title", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("NameSuffix", "title", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("PwdChanged", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("PwdCreationDate", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("PwdFailAttempt", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("LastLogonDate ", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("IPAddress", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("Active", "", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("MemberOf", "member", true));

        USERSETTINGS.put(ServerType.Apache, lstAttributeMapNodApache);

        List<AttributeMapNode> lstAttributeMapNodOpenLdap = new ArrayList<>();

        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("UserId", "uid"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("Email", "mail"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("UserName", "cn"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("FirstName", "givenname"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("LastName", "sn"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("MiddleName", "initials", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("NamePrefix", "title", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("NameSuffix", "title", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("PwdChanged", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("PwdCreationDate", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("PwdFailAttempt", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("LastLogonDate ", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("IPAddress", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("Active", "", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("MemberOf", "members", true));

        USERSETTINGS.put(ServerType.OpenLdap, lstAttributeMapNodOpenLdap);
        return USERSETTINGS;

    }


    private static Map<ServerType, List<AttributeMapNode>> setRoleSettings() {

        List<AttributeMapNode> lstAttributeMapNodAD = new ArrayList<>();

        lstAttributeMapNodAD.add(new AttributeMapNode("RoleId", "cn"));
        lstAttributeMapNodAD.add(new AttributeMapNode("RoleName", "name"));
        lstAttributeMapNodAD.add(new AttributeMapNode("RoleDescription", "description", true));
        lstAttributeMapNodAD.add(new AttributeMapNode("Members", "member"));

        List<AttributeMapNode> lstAttributeMapNodApache = new ArrayList<>();
        lstAttributeMapNodApache.add(new AttributeMapNode("RoleId", "cn"));
        lstAttributeMapNodApache.add(new AttributeMapNode("RoleName", "name"));
        lstAttributeMapNodApache.add(new AttributeMapNode("RoleDescription", "description", true));
        lstAttributeMapNodApache.add(new AttributeMapNode("Members", "member"));

        List<AttributeMapNode> lstAttributeMapNodOpenLdap = new ArrayList<>();
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("RoleId", "cn"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("RoleName", "name"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("RoleDescription", "description", true));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("Members", "member"));

        ROLESETTINGS.put(ServerType.AD, lstAttributeMapNodAD);
        ROLESETTINGS.put(ServerType.Apache, lstAttributeMapNodApache);
        ROLESETTINGS.put(ServerType.OpenLdap, lstAttributeMapNodOpenLdap);

        return ROLESETTINGS;
    }


    private static Map<ServerType, List<AttributeMapNode>> setSgGroupSettings() {

        List<AttributeMapNode> lstAttributeMapNodAD = new ArrayList<>();
        lstAttributeMapNodAD.add(new AttributeMapNode("GroupId", "cn"));
        lstAttributeMapNodAD.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodAD.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodAD.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        List<AttributeMapNode> lstAttributeMapNodApache = new ArrayList<>();
        lstAttributeMapNodApache.add(new AttributeMapNode("GroupId", "cn"));
        lstAttributeMapNodApache.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodApache.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodApache.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        List<AttributeMapNode> lstAttributeMapNodOpenLdap = new ArrayList<>();
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("GroupId", "cn"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        SG_GROUPSETTINGS.put(ServerType.AD, lstAttributeMapNodAD);
        SG_GROUPSETTINGS.put(ServerType.Apache, lstAttributeMapNodApache);
        SG_GROUPSETTINGS.put(ServerType.OpenLdap, lstAttributeMapNodOpenLdap);
        return SG_GROUPSETTINGS;
    }


    private static Map<ServerType, List<AttributeMapNode>> setOuGroupSettings() {

        List<AttributeMapNode> lstAttributeMapNodAD = new ArrayList<>();
        lstAttributeMapNodAD.add(new AttributeMapNode("GroupId", "ou"));
        lstAttributeMapNodAD.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodAD.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodAD.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        List<AttributeMapNode> lstAttributeMapNodApache = new ArrayList<>();
        lstAttributeMapNodApache.add(new AttributeMapNode("GroupId", "ou"));
        lstAttributeMapNodApache.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodApache.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodApache.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        List<AttributeMapNode> lstAttributeMapNodOpenLdap = new ArrayList<>();

        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("GroupId", "ou"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("GroupName", "name"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("Description", "description"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode(LdapConfigConstant.BLANK, "distinguishedname"));

        OU_GROUPSETTINGS.put(ServerType.AD, lstAttributeMapNodAD);
        OU_GROUPSETTINGS.put(ServerType.Apache, lstAttributeMapNodApache);
        OU_GROUPSETTINGS.put(ServerType.OpenLdap, lstAttributeMapNodOpenLdap);
        return OU_GROUPSETTINGS;

    }


    private static Map<ServerType, List<AttributeMapNode>> setDomainSettings() {

        List<AttributeMapNode> lstAttributeMapNodAD = new ArrayList<>();
        lstAttributeMapNodAD.add(new AttributeMapNode("DomainId", "ou"));
        lstAttributeMapNodAD.add(new AttributeMapNode("DomainDescription", "description"));

        List<AttributeMapNode> lstAttributeMapNodApache = new ArrayList<>();
        lstAttributeMapNodApache.add(new AttributeMapNode("DomainId", "ou"));
        lstAttributeMapNodApache.add(new AttributeMapNode("DomainDescription", "description"));

        List<AttributeMapNode> lstAttributeMapNodOpenLdap = new ArrayList<>();
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("DomainId", "ou"));
        lstAttributeMapNodOpenLdap.add(new AttributeMapNode("DomainDescription", "description"));

        DOMAINSETTINGS.put(ServerType.AD, lstAttributeMapNodAD);
        DOMAINSETTINGS.put(ServerType.Apache, lstAttributeMapNodApache);
        DOMAINSETTINGS.put(ServerType.OpenLdap, lstAttributeMapNodOpenLdap);
        return DOMAINSETTINGS;
    }


    static {
        setDomainSettings();
        setOuGroupSettings();
        setSgGroupSettings();
        setUserSettings();
        setRoleSettings();
    }

}
