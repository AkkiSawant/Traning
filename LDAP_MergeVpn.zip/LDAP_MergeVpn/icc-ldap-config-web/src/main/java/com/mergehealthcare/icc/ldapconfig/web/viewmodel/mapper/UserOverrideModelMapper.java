/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserDomainDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserGroupDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapDetailsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;

import icc.ldap.server.configuration.DomainAdminLevel;
import icc.ldap.server.configuration.DomainsAdminLevel;
import icc.ldap.server.configuration.GroupAdminLevel;
import icc.ldap.server.configuration.GroupsAdminLevel;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.UserDomainRole;
import icc.ldap.server.configuration.UserDomainRoles;
import icc.ldap.server.configuration.UserGroupRole;
import icc.ldap.server.configuration.UserGroupRoles;
import icc.ldap.server.configuration.UserOverrideDetail;
import icc.ldap.server.configuration.UserOverrideMap;

/**
 *
 * @author sarikam2
 */
@Component
public class UserOverrideModelMapper {

    private static final Logger logger = LogService.getLogger(UserOverrideModelMapper.class);

    @Autowired
    private ServerDetailsService serverDetailsService;


    /**
     * This method creates List<UserGroupDetailViewModel> from the list of
     * groupAdmin(Data model) and groupRoles(Data model).
     *
     * @param userGroupList the user group list
     * @param addTypeGroupAdmin the add type group admin
     * @param addTypeGroupRoles the add type group roles
     */
    public void setGroupDetailViewModel(List<UserGroupDetailViewModel> userGroupList, Map<String, GroupAdminLevel> addTypeGroupAdmin,
                    Map<String, UserGroupRole> addTypeGroupRoles) {
        Iterator<String> groupAdminItr = addTypeGroupAdmin.keySet().iterator();
        // Iterator<String> groupRolesItr =
        // addTypeGroupRoles.keySet().iterator();
        while (groupAdminItr.hasNext()) {
            String groupAdminLevelKey = groupAdminItr.next();
            // String userGroupRoleKey = groupRolesItr.next();
            GroupAdminLevel groupAdminAddType = addTypeGroupAdmin.get(groupAdminLevelKey);
            UserGroupRole groupRolesAddType = null;
            if (addTypeGroupRoles.containsKey(groupAdminLevelKey)) {
                groupRolesAddType = addTypeGroupRoles.get(groupAdminLevelKey);
            }
            logger.debug("ModelMapperHelper : setGroupDetailViewModel : groupAdminAddType " + groupAdminAddType);
            logger.debug("ModelMapperHelper : setGroupDetailViewModel : groupRolesAddType " + groupRolesAddType);
            if (ObjectUtils.isNull(groupRolesAddType)) {
                UserGroupDetailViewModel groupViewModel = new UserGroupDetailViewModel();
                groupViewModel.setGroupAdminLevel(groupAdminAddType.getGroupAdminLevel());
                groupViewModel.setDomainId(groupAdminAddType.getDomainId());
                groupViewModel.setGroupId(groupAdminAddType.getGroupId());
                groupViewModel.setRole("");
                logger.debug("ModelMapperHelper : setGroupDetailViewModel : groupViewModel " + groupViewModel);
                userGroupList.add(groupViewModel);
            } else {
                String[] roles = groupRolesAddType.getRoles().split("\\|");
                logger.debug("ModelMapperHelper : setGroupDetailViewModel : roles " + roles);
                for (int role = 0; role < roles.length; role++) {
                    logger.debug("ModelMapperHelper : setGroupDetailViewModel : role " + role);
                    UserGroupDetailViewModel groupViewModel = new UserGroupDetailViewModel();
                    groupViewModel.setGroupAdminLevel(groupAdminAddType.getGroupAdminLevel());
                    groupViewModel.setDomainId(groupAdminAddType.getDomainId());
                    groupViewModel.setGroupId(groupAdminAddType.getGroupId());
                    groupViewModel.setRole(roles[role]);
                    logger.debug("ModelMapperHelper : setGroupDetailViewModel : groupViewModel " + groupViewModel);
                    userGroupList.add(groupViewModel);
                }
            }
        }
        logger.debug("ModelMapperHelper : setGroupDetailViewModel : userGroupList " + userGroupList);
    }


    /**
     * This method is to find the previously saved user override map details
     * data from the XML on the basis of server name provided.
     *
     * @param serverName the server name
     * @return the user override map view model
     * @throws LdapConfigDataException the ldap config data exception
     */
    public UserOverrideMapViewModel findOverrideMapByServerName(String serverName) throws LdapConfigDataException {
        UserOverrideMapViewModel userOverrideMapView = BeanUtils.instantiateClass(UserOverrideMapViewModel.class);
        List<UserOverrideMapDetailsViewModel> userOverrideMapDetailViewList = new ArrayList<>();
        if (!ObjectUtils.isNull(serverName)) {
            ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
            UserOverrideMap userOverrideData = serverConfiguration.getUserOverrideMap();
            logger.debug("ModelMapperHelper : findOverrideMapByServerName : userOverrideData " + userOverrideData);
            if (ObjectUtils.isNull(userOverrideData)) {
                List<UserDomainDetailViewModel> userDomainList = new ArrayList<>();
                List<UserGroupDetailViewModel> userGroupList = new ArrayList<>();
                UserOverrideMapDetailsViewModel userOverrideMapDetailView = BeanUtils.instantiateClass(UserOverrideMapDetailsViewModel.class);
                userOverrideMapDetailView.setDomainDetails(userDomainList);
                userOverrideMapDetailView.setGroupDetails(userGroupList);
                userOverrideMapDetailViewList.add(userOverrideMapDetailView);
            } else {
                Map<String, UserOverrideDetail> userOverideDetail = userOverrideData.getUserOverrideDetail();
                logger.debug("ModelMapperHelper : findOverrideMapByServerName : userOverideDetail " + userOverideDetail);
                Iterator<String> itr = userOverideDetail.keySet().iterator();
                while (itr.hasNext()) {
                    String userOverrideDetailKey = itr.next();
                    UserOverrideDetail detailData = userOverideDetail.get(userOverrideDetailKey);
                    logger.debug("ModelMapperHelper : findOverrideMapByServerName : detailData" + detailData);
                    UserOverrideMapDetailsViewModel userOverrideMapDetailView = BeanUtils
                                    .instantiateClass(UserOverrideMapDetailsViewModel.class);
                    DomainsAdminLevel domainAdmin = detailData.getDomainsAdminLevel();
                    GroupsAdminLevel groupAdmin = detailData.getGroupsAdminLevel();
                    UserDomainRoles domainRoles = detailData.getUserDomainRoles();
                    UserGroupRoles groupRoles = detailData.getUserGroupRoles();
                    List<UserDomainDetailViewModel> userDomainList = new ArrayList<>();
                    // if (!ObjectUtils.isNull(domainAdmin) &&
                    // !ObjectUtils.isNull(domainRoles)) {
                    setUserDomainDetailViewModel(userDomainList, domainAdmin.getDomainAdminLevel(), domainRoles.getUserDomainRole());
                    // }
                    List<UserGroupDetailViewModel> userGroupList = new ArrayList<>();
                    // if (!ObjectUtils.isNull(groupAdmin) &&
                    // !ObjectUtils.isNull(groupRoles)) {
                    setGroupDetailViewModel(userGroupList, groupAdmin.getGroupAdminLevel(), groupRoles.getUserGroupRole());
                    // }
                    userOverrideMapDetailView.setDomainDetails(userDomainList);
                    userOverrideMapDetailView.setGroupDetails(userGroupList);
                    userOverrideMapDetailView.setSystemAdminLevel(detailData.getSystemAdminLevel());
                    userOverrideMapDetailView.setUserId(detailData.getUserId());
                    logger.debug("ModelMapperHelper : findOverrideMapByServerName : userOverrideMapDetailView " + userOverrideMapDetailView);
                    userOverrideMapDetailViewList.add(userOverrideMapDetailView);
                }
            }
            userOverrideMapView.setUserOverrideMapDetailsViewModel(userOverrideMapDetailViewList);
        }
        logger.debug("userOverrideMapView = " + userOverrideMapView);
        return userOverrideMapView;
    }


    /**
     * This method creates List<UserDomainDetailViewModel> from list of
     * domainAdmin(Data model) and domainRoles(Data model) .
     *
     * @param userDomainList the user domain list
     * @param addTypeDomainAdmin the add type domain admin
     * @param addTypeDomainRoles the add type domain roles
     */
    public void setUserDomainDetailViewModel(List<UserDomainDetailViewModel> userDomainList, Map<String, DomainAdminLevel> addTypeDomainAdmin,
                    Map<String, UserDomainRole> addTypeDomainRoles) {
        Iterator<String> domainAdminItr = addTypeDomainAdmin.keySet().iterator();
        // Iterator<String> domainRolesItr =
        // addTypeDomainRoles.keySet().iterator();
        while (domainAdminItr.hasNext()) {
            String domainAdminLevelKey = domainAdminItr.next();
            // String domainRolesItrKey = domainRolesItr.next();
            DomainAdminLevel domainAdminAddtype = addTypeDomainAdmin.get(domainAdminLevelKey);
            UserDomainRole domainRolesAddType = null;
            if (addTypeDomainRoles.containsKey(domainAdminLevelKey)) {
                domainRolesAddType = addTypeDomainRoles.get(domainAdminLevelKey);
            }
            logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : domainAdminAddtype " + domainAdminAddtype);
            logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : domainRolesAddType " + domainRolesAddType);
            if (ObjectUtils.isNull(domainRolesAddType)) {
                UserDomainDetailViewModel domainViewModel = new UserDomainDetailViewModel();
                domainViewModel.setDomainAdminLevel(domainAdminAddtype.getDomainAdminLevel());
                domainViewModel.setDomainId(domainAdminAddtype.getDomainId());
                domainViewModel.setRole("");
                logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : domainViewModel " + domainViewModel);
                userDomainList.add(domainViewModel);
            } else {
                String[] roles = domainRolesAddType.getRoles().split("\\|");
                logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : roles " + roles);
                for (int role = 0; role < roles.length; role++) {
                    logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : role " + role);
                    UserDomainDetailViewModel domainViewModel = new UserDomainDetailViewModel();
                    domainViewModel.setDomainAdminLevel(domainAdminAddtype.getDomainAdminLevel());
                    domainViewModel.setDomainId(domainAdminAddtype.getDomainId());
                    domainViewModel.setRole(roles[role]);
                    logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : domainViewModel " + domainViewModel);
                    userDomainList.add(domainViewModel);
                }
            }
        }
        logger.debug("ModelMapperHelper : setUserDomainDetailViewModel : userDomainList " + userDomainList);
    }


    /**
     * This method is to create UserGroupRolesType(Data model) and
     * GroupsAdminLevelType(Data model) from List<UserGroupDetailViewModel>.
     *
     * @param userGroupViewList the user group view list
     * @param userGroupRole the user group role
     * @param groupAdmin the group admin
     */
    private void setUserGroupDataModel(List<UserGroupDetailViewModel> userGroupViewList, UserGroupRoles userGroupRole,
                    GroupsAdminLevel groupAdmin) {
        logger.debug("ModelMapperHelper : setUserGroupViewModel : userGroupViewList " + userGroupViewList);
        logger.debug("ModelMapperHelper : setUserGroupViewModel : userGroupRole " + userGroupRole);
        logger.debug("ModelMapperHelper : setUserGroupViewModel : groupAdmin " + groupAdmin);
        for (UserGroupDetailViewModel groupData : userGroupViewList) {
            logger.debug("ModelMapperHelper : setUserGroupViewModel : groupData " + groupData);
            GroupAdminLevel groupAdminAdd = new GroupAdminLevel();
            groupAdminAdd.setDomainId(groupData.getDomainId());
            groupAdminAdd.setGroupId(groupData.getGroupId());
            groupAdminAdd.setGroupAdminLevel(groupData.getGroupAdminLevel());
            groupAdmin.getGroupAdminLevel().put(groupData.getGroupId(), groupAdminAdd);
            logger.debug("ModelMapperHelper : setUserGroupViewModel : groupAdminAdd " + groupAdminAdd);
            if (ObjectUtils.isNotNullOrEmpty(groupData.getRole())) {
                UserGroupRole groupRolesAdd = new UserGroupRole();
                groupRolesAdd.setDomainId(groupData.getDomainId());
                groupRolesAdd.setGroupId(groupData.getGroupId());
                groupRolesAdd.setRoles(groupData.getRole());
                userGroupRole.getUserGroupRole().put(groupData.getDomainId(), groupRolesAdd);
                logger.debug("ModelMapperHelper : setUserGroupViewModel : groupRolesAdd " + groupRolesAdd);
            }
        }
    }


    /**
     * This method is to create UserDomainRolesType(Data model) and
     * DomainsAdminLevelType(Data model) from List<UserDomainDetailViewModel>.
     *
     * @param userDomainViewList the user domain view list
     * @param userDomainRole the user domain role
     * @param domainAdmin the domain admin
     */
    private void setUserDomainDataModel(List<UserDomainDetailViewModel> userDomainViewList, UserDomainRoles userDomainRole,
                    DomainsAdminLevel domainAdmin) {
        for (UserDomainDetailViewModel domainData : userDomainViewList) {
            logger.debug("ModelMapperHelper : setUserDomainViewModel : domainData" + domainData);
            DomainAdminLevel domainAdminAdd = new DomainAdminLevel();
            domainAdminAdd.setDomainId(domainData.getDomainId());
            domainAdminAdd.setDomainAdminLevel(domainData.getDomainAdminLevel());
            domainAdmin.getDomainAdminLevel().put(domainData.getDomainId(), domainAdminAdd);
            logger.debug("ModelMapperHelper : setUserDomainViewModel : domainAdmin" + domainAdmin);
            if (ObjectUtils.isNotNullOrEmpty(domainData.getRole())) {
                UserDomainRole domainRolesAdd = new UserDomainRole();
                domainRolesAdd.setDomainId(domainData.getDomainId());
                domainRolesAdd.setRoles(domainData.getRole());
                userDomainRole.getUserDomainRole().put(domainData.getDomainId(), domainRolesAdd);
                logger.debug("ModelMapperHelper : setUserDomainViewModel : userDomainRole" + userDomainRole);
            }
        }
    }


    /**
     * This method converts the the list of roles to a pipe(|) appended string
     * for saving the data into xml.
     *
     * @param userGroupViewList the user group view list
     * @return the list
     */
    @SuppressWarnings (value = "PMD.UseConcurrentHashMap")
    public List<UserGroupDetailViewModel> convertUserGroupViewDetails(List<UserGroupDetailViewModel> userGroupViewList) {
        logger.debug("ModelMapperHelper : convertUserGroupViewDetails :     userGroupViewList" + userGroupViewList);
        Map<String, Set<String>> map = new HashMap<>();
        for (UserGroupDetailViewModel userGroupView : userGroupViewList) {
            logger.debug("ModelMapperHelper : convertUserGroupViewDetails :     userGroupView" + userGroupView);
            String modelKey = userGroupView.getGroupAdminLevel() + "|" + userGroupView.getDomainId() + "|" + userGroupView.getGroupId();
            if (map.containsKey(modelKey)) {
                if (map.get(modelKey).contains("")) {
                    Set<String> roleSet = new HashSet<>();
                    roleSet.add(userGroupView.getRole());
                    map.put(modelKey, roleSet);
                } else if (!ObjectUtils.isNullOrEmpty(userGroupView.getRole())) {
                    Set<String> roleSet = map.get(modelKey);
                    roleSet.add(userGroupView.getRole());
                    map.put(modelKey, roleSet);
                }
            } else {
                Set<String> roleSet = new HashSet<>();
                roleSet.add(userGroupView.getRole());
                map.put(modelKey, roleSet);
            }
        }
        logger.debug("ModelMapperHelper : convertUserGroupViewDetails : map" + map);
        userGroupViewList.clear();
        for (String key : map.keySet()) {
            logger.debug("ModelMapperHelper : convertUserGroupViewDetails : key" + key);
            String[] groupDetails = key.split("\\|");
            UserGroupDetailViewModel viewModel = new UserGroupDetailViewModel();
            viewModel.setGroupAdminLevel(groupDetails[0]);
            viewModel.setDomainId(groupDetails[1]);
            viewModel.setGroupId(groupDetails[2]);
            if (map.get(key).contains("")) {
                viewModel.setRole("");
            } else {
                viewModel.setRole(ObjectUtils.join(map.get(key), "|"));
            }
            userGroupViewList.add(viewModel);
        }
        logger.debug("ModelMapperHelper : convertUserGroupViewDetails :     userGroupViewList" + userGroupViewList);
        return userGroupViewList;
    }


    /**
     * This method is used to convert the UserOverrideMapViewModel into XML
     * specific USerOverrideMap Data model.
     *
     * @param serverConfiguration the server configuration
     * @param userOverrideMap the user override map
     * @return the server configuration
     */
    private ServerConfiguration convertModelToUserOverrideConfiguration(ServerConfiguration serverConfiguration,
                    UserOverrideMapViewModel userOverrideMap) {
        logger.debug("ModelMapperHelper : convertModelToUserOverrideConfiguration : userOverrideMap" + userOverrideMap);
        UserOverrideMap dataUserOverrideMap = new UserOverrideMap();
        if (userOverrideMap != null && userOverrideMap.getUserOverrideMapDetailsViewModel() != null) {
            for (UserOverrideMapDetailsViewModel detailViewModel : userOverrideMap.getUserOverrideMapDetailsViewModel()) {
                logger.debug("ModelMapperHelper : convertModelToUserOverrideConfiguration : detailViewModel" + detailViewModel);
                UserOverrideDetail detailData = new UserOverrideDetail();
                GroupsAdminLevel groupAdmin = new GroupsAdminLevel();
                UserGroupRoles userGroupRole = new UserGroupRoles();
                DomainsAdminLevel domainAdmin = new DomainsAdminLevel();
                UserDomainRoles userDomainRole = new UserDomainRoles();
                List<UserDomainDetailViewModel> userDomainViewList = detailViewModel.getDomainDetails();
                List<UserGroupDetailViewModel> userGroupViewList = detailViewModel.getGroupDetails();
                if (!ObjectUtils.isNull(userGroupViewList)) {
                    setUserGroupDataModel(convertUserGroupViewDetails(userGroupViewList), userGroupRole, groupAdmin);
                }
                if (!ObjectUtils.isNull(userDomainViewList)) {
                    setUserDomainDataModel(convertUserDomainViewDetails(userDomainViewList), userDomainRole, domainAdmin);
                }
                detailData.setDomainsAdminLevel(domainAdmin);
                detailData.setGroupsAdminLevel(groupAdmin);
                detailData.setUserDomainRoles(userDomainRole);
                detailData.setUserGroupRoles(userGroupRole);
                detailData.setSystemAdminLevel(detailViewModel.getSystemAdminLevel());
                detailData.setUserId(detailViewModel.getUserId());
                logger.debug("ModelMapperHelper : convertModelToUserOverrideConfiguration : detailData" + detailData);
                dataUserOverrideMap.getUserOverrideDetail().put(detailViewModel.getUserId(), detailData);
            }
        }
        logger.debug("ModelMapperHelper : convertModelToUserOverrideConfiguration : dataUserOverrideMap" + dataUserOverrideMap);
        serverConfiguration.setUserOverrideMap(dataUserOverrideMap);
        return serverConfiguration;
    }


    /**
     * Save user override map configuration.
     *
     * @param userOverrideMap the user override map
     * @param serverName the server name
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void saveUserOverrideMapConfiguration(UserOverrideMapViewModel userOverrideMap, String serverName)
                    throws LdapConfigDataException {
        logger.info("Saving model option configuration from model...");
        if (ObjectUtils.isNull(userOverrideMap)) {
            throw new LdapConfigDataException("userOverrideMap is null");
        }
        if (ObjectUtils.isNull(serverName)) {
            throw new LdapConfigDataException("Server name is null");
        }
        
        try {
            ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
            ServerConfiguration serverConfig = convertModelToUserOverrideConfiguration(serverConfiguration, userOverrideMap);
            serverDetailsService.modify(serverConfig);
        } catch (IOException ex) {
            throw new LdapConfigDataException(ex.getMessage(), ex);
        }
        logger.info("Server configuration saved!");
    }


    /**
     * This method converts the the list of roles to a pipe(|) appended string
     * for saving the data into XML.
     *
     * @param userDomainViewList the user domain view list
     * @return the list
     */
    @SuppressWarnings (value = "PMD.UseConcurrentHashMap")
    public List<UserDomainDetailViewModel> convertUserDomainViewDetails(List<UserDomainDetailViewModel> userDomainViewList) {
        logger.debug("ModelMapperHelper : convertUserDomainViewDetails :userDomainViewList " + userDomainViewList);
        Map<String, Set<String>> map = new HashMap<>();
        for (UserDomainDetailViewModel userDomainView : userDomainViewList) {
            logger.debug("ModelMapperHelper : convertUserDomainViewDetails :userDomainView " + userDomainView);
            String modelKey = userDomainView.getDomainAdminLevel() + "|" + userDomainView.getDomainId();
            if (map.containsKey(modelKey)) {
                if (map.get(modelKey).contains("")) {
                    Set<String> roleSet = new HashSet<>();
                    roleSet.add(userDomainView.getRole());
                    map.put(modelKey, roleSet);
                } else if (!ObjectUtils.isNullOrEmpty(userDomainView.getRole())) {
                    Set<String> roleSet = map.get(modelKey);
                    roleSet.add(userDomainView.getRole());
                    map.put(modelKey, roleSet);
                }
            } else {
                Set<String> roleSet = new HashSet<>();
                roleSet.add(userDomainView.getRole());
                map.put(modelKey, roleSet);
            }
        }
        logger.debug("ModelMapperHelper : convertUserDomainViewDetails : map " + map);
        userDomainViewList.clear();
        for (String key : map.keySet()) {
            String[] domainDetails = key.split("\\|");
            UserDomainDetailViewModel viewModel = new UserDomainDetailViewModel();
            viewModel.setDomainAdminLevel(domainDetails[0]);
            viewModel.setDomainId(domainDetails[1]);
            if (map.get(key).contains("")) {
                viewModel.setRole("");
            } else {
                viewModel.setRole(ObjectUtils.join(map.get(key), "|"));
            }
            userDomainViewList.add(viewModel);
        }
        logger.debug("ModelMapperHelper : convertUserDomainViewDetails : userDomainViewList " + userDomainViewList);
        return userDomainViewList;
    }

}
