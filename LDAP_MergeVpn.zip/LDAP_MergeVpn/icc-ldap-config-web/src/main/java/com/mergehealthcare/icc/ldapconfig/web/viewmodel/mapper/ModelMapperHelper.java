package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTreeAttributeNode;
import com.mergehealthcare.icc.ldapconfig.web.cache.AttributeMapSettings;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.LdapServiceManager;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapNode;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.LdapPropertiesDNVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.LdapPropertiesVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;
import com.unboundid.ldap.sdk.SearchScope;

import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnection;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.ServiceCredentials;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * The Class ModelMapperHelper.
 */
@Component
public class ModelMapperHelper {

    private static final Logger logger = LogService.getLogger(ModelMapperHelper.class);

    private static final String LDAP_ATTRIBUTES = "ldapAttribute";

    private static final String STATIC_ATTRIBUTES = "staticAttribute";

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private ObjectFactory objectFactory;

    private Platform platform;

    @Autowired
    private LdapServiceManager ldapUtilityService;


    /**
     * Fetch configured servers list.
     *
     * @return the list
     */
    public List<ServerDetailsModel> fetchConfiguredServersList() {
        logger.debug("Fetching configured servers list...");
        List<ServerDetailsModel> serverConfigurationList = new ArrayList<>();

        try {
            List<ServerConfiguration> serverConfigurations = this.serverDetailsService.loadAllServerNames();

            if (serverConfigurations == null) {
                logger.warn("No configured servers found!");
            } else {
                logger.info("Total configured servers: " + serverConfigurations.size());

                for (ServerConfiguration serverConfiguration : serverConfigurations) {
                    ServerDetailsModel serverModel = convertServerConfigToModel(serverConfiguration);
                    serverConfigurationList.add(serverModel);
                    logger.debug("Added server model to configured servers model list: " + serverModel.getServerName());
                }
            }
        } catch (Exception ex) {
            logger.warn("Server list is empty. The Error is: " + ex.getMessage());
        }

        return serverConfigurationList;
    }


    /**
     * Convert server config to model.
     *
     * @param serverConfiguration the server configuration
     * @return the server details model
     * @throws Exception the exception
     */
    public ServerDetailsModel convertServerConfigToModel(ServerConfiguration serverConfiguration) throws Exception {
        logger.info("Converting server configuration to model...");

        ServerDetailsModel serverDetailsModel = new ServerDetailsModel();
        ObjectUtils.checkIsNullAndAssign(serverConfiguration, serverDetailsModel);
        ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails(), serverDetailsModel);
        ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerConnection(), serverDetailsModel);
        ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails().getServiceCredentials(), serverDetailsModel);
        ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails().getSiteDomains(), serverDetailsModel);

        serverDetailsModel.setUserName(serverConfiguration.getServerDetails().getServiceCredentials().getUserName());
        serverDetailsModel.setServerType(serverConfiguration.getServerDetails().getType());
        serverDetailsModel.setServerDetailsEnable(Boolean.valueOf(serverConfiguration.getServerDetails().getEnable()));
        serverDetailsModel.setNetworkDomain(serverConfiguration.getServerDetails().getNetworkDomain());
        logger.debug("Converted server model: " + serverDetailsModel.getServerName());

        return serverDetailsModel;
    }


    /**
     * Save server configuration.
     *
     * @param serverModel the server model
     * @throws Exception the exception
     */
    public void saveServerConfiguration(ServerDetailsModel serverModel) throws Exception {
        logger.info("Saving server configuration from model...");
        ServerConfiguration serverConfig = convertModelToServerConfiguration(serverModel);

        this.serverDetailsService.add(serverConfig);
        logger.info("Server configuration saved!");
    }


    /**
     * Find server model by server name.
     *
     * @param serverName the server name
     * @return the server details model
     */
    public ServerDetailsModel findServerModelByServerName(String serverName) {
        logger.info("Finding server model by server name: " + serverName);
        ServerDetailsModel serverModel = BeanUtils.instantiateClass(ServerDetailsModel.class);

        try {
            ServerConfiguration serverConfiguration = this.serverDetailsService.fetchSaveConfiguration(serverName);

            ObjectUtils.checkIsNullAndAssign(serverConfiguration, serverModel);
            ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails(), serverModel);
            ObjectUtils.checkIsNullAndAssign(serverConfiguration, serverModel);

            ServerConnection serverConnection = serverConfiguration.getServerConnection();
            ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails().getServiceCredentials(), serverModel);
            ObjectUtils.checkIsNullAndAssign(serverConnection, serverModel);
            ObjectUtils.checkIsNullAndAssign(serverConfiguration.getServerDetails(), serverModel);

            serverModel.setServerType(serverConfiguration.getServerDetails().getType());
            serverModel.setUserName(serverConfiguration.getServerDetails().getServiceCredentials().getUserName());
            String decryptedPassword = serverConfiguration.getServerDetails().getServiceCredentials().getDecodedPassword();
            if (decryptedPassword != null) {
                serverModel.setPassword(decryptedPassword);
            }
            logger.debug("serverInfoViewModel = " + serverModel);

        } catch (Exception ex) {
            logger.error("Reversed Mapping Exception occured from LdapConfiguration to ServerDetailsModel", ex);
        }

        return serverModel;
    }


    /**
     * Modify server info.
     *
     * @param model the model
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void modifyServerInfo(ServerDetailsModel model) throws LdapConfigDataException, IOException {
        logger.info("Saving modified server information: " + model);

        ServerConfiguration serverConfig = convertModelToServerConfiguration(model);
        this.serverDetailsService.modify(serverConfig);
    }


    /**
     * Convert model to server configuration.
     *
     * @param serverModel the server model
     * @return the server configuration
     */
    private ServerConfiguration convertModelToServerConfiguration(ServerDetailsModel serverModel) {
        ServerConfiguration serverConfiguration = null;

        try {
            serverConfiguration = this.serverDetailsService.fetchSaveConfiguration(serverModel.getServerName());
        } catch (LdapConfigDataException ex) {
            serverConfiguration = objectFactory.createServerConfiguration();
            logger.error("Creating new object of ServerConfiguration: " + ex);
        }

        serverConfiguration.setServerName(serverModel.getServerName());
        ServerDetails serverDetails = serverConfiguration.getServerDetails();
        if (serverDetails == null) {
            serverDetails = objectFactory.createServerDetails();
            serverDetails.setEnable("true");
        }

        ObjectUtils.checkIsNullAndAssign(serverModel, serverDetails);
        serverDetails.setType(serverModel.getServerType());

        ServiceCredentials credentials = objectFactory.createServiceCredentials();

        credentials.setUserName(serverModel.getUserName());
        credentials.setPassword(serverModel.getPassword());

        if (platform == Platform.Net) {
            credentials.setNetworkDomain("");
        }
        if (serverModel.getPassword() != null) {
            credentials.setEncodedPassword(serverModel.getPassword());
            logger.debug("Encoded password saved in the model = " + credentials.getPassword());
        }

        ServerType serverType = ServerType.valueOf(serverDetails.getType());
        if (serverType == ServerType.AD) {
            credentials.setNetworkDomain(serverDetails.getNetworkDomain());
        }

        serverConfiguration.setServerDetails(serverDetails);
        serverDetails.setServiceCredentials(credentials);

        return serverConfiguration;
    }


    /**
     * Delete server.
     *
     * @param serverName the server name
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void deleteServer(String serverName) throws LdapConfigDataException, IOException {
        this.serverDetailsService.remove(serverName);
    }


    /**
     * Enable server.
     *
     * @param serverName the server name
     * @param enableServer the enable server
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void enableServer(String serverName, boolean enableServer) throws LdapConfigDataException, IOException {
        this.serverDetailsService.enableServer(serverName, enableServer);
    }


    public void setPlatform(Platform platform) {
        this.platform = platform;
    }


    public Platform getPlatForm() {
        return platform;
    }


    /**
     * Gets the all ldap properties.
     *
     * @param ldapPropertiesVM the ldap properties VM
     * @return the all ldap properties
     * @throws LdapConfigDataException the ldap config data exception
     */
    @SuppressWarnings (value = "PMD.UseConcurrentHashMap")
    private Map<String, Map<String, String>> getAllLdapProperties(LdapPropertiesVM ldapPropertiesVM) throws LdapConfigDataException {
        Map<String, Map<String, String>> returnObject = new HashMap<>();
        try {
            List<LdapTree> ldapSearchResponse = ldapUtilityService.search(ldapPropertiesVM.getDn(), ldapPropertiesVM.getFilter(),
                            ldapPropertiesVM.getServerName(), SearchScope.SUB, null);
            logger.debug("Attribute List" + ldapSearchResponse.get(0).getAttributeMap());
            Set<String> attributes = new HashSet<>();
            if (platform.equals(Platform.Net.toString())) {
                for (LdapTree ldapTree : ldapSearchResponse) {
                    attributes.addAll(ldapTree.getAttributeMap().keySet());
                }
            } else {
                for (LdapTree ldapTree : ldapSearchResponse) {
                    for (Entry<String, LdapTreeAttributeNode> entry : ldapTree.getAttributeMap().entrySet()) {
                        attributes.add(entry.getValue().getLdapKey());
                    }
                }
            }

            if (attributes.isEmpty()) {
                returnObject.put(
                                STATIC_ATTRIBUTES,
                                getStaticAttributes(ldapPropertiesVM.getClassType(), ldapPropertiesVM.getServerTypeEnum(),
                                                ldapPropertiesVM.getModelGrouping()));
                logger.debug("Static attributes :: " + ldapSearchResponse.get(0).getAttributeMap());
            } else {
                Map<String, String> attributeMap = new HashMap<>();
                for (String attribute : attributes) {
                    attributeMap.put(attribute, attribute);
                }
                returnObject.put(LDAP_ATTRIBUTES, attributeMap);
                logger.debug("Attributes fetched From LDAP :: " + ldapSearchResponse.get(0).getAttributeMap());
            }
        } catch (Exception e) {
            logger.error("fetch attributeMap error " + e);
            returnObject.put(
                            STATIC_ATTRIBUTES,
                            getStaticAttributes(ldapPropertiesVM.getClassType(), ldapPropertiesVM.getServerTypeEnum(),
                                            ldapPropertiesVM.getModelGrouping()));
        }
        return returnObject;
    }


    /**
     * Gets the all ldap properties by DN.
     *
     * @param ldapPropertiesVM the ldap properties VM
     * @return the all ldap properties by DN
     * @throws LdapConfigDataException the ldap config data exception
     */
    public Map<String, Map<String, String>> getAllLdapPropertiesByDN(LdapPropertiesDNVM ldapPropertiesVM) throws LdapConfigDataException {
        ServerDetailsModel serverDetailsModel = findServerModelByServerName(ldapPropertiesVM.getServerName());
        ServerType serverTypeEnum = ServerType.valueOf(serverDetailsModel.getServerType());
        return this.getAllLdapProperties(new LdapPropertiesVM(ldapPropertiesVM.getServerName(), ldapPropertiesVM.getDn(), ldapPropertiesVM
                        .getClassType(), serverTypeEnum, ldapPropertiesVM.getModelGrouping(), ldapPropertiesVM.getFilter()));
    }


    /**
     * Gets the static attributes.
     *
     * @param classType the class type
     * @param serverType the server type
     * @param modelGrouping the model grouping
     * @return the static attributes
     */
    @SuppressWarnings (value = "PMD.UseConcurrentHashMap")
    private Map<String, String> getStaticAttributes(String classType, ServerType serverType, String modelGrouping) {
        List<AttributeMapNode> attributeMapList = new ArrayList<>();
        Map<String, String> identityLdapPropertyMap = new HashMap<>();
        switch (classType) {
        case LdapConfigConstant.DOMAIN:
            attributeMapList = AttributeMapSettings.DOMAINSETTINGS.get(serverType);
            break;
        case LdapConfigConstant.ROLE:
            attributeMapList = AttributeMapSettings.ROLESETTINGS.get(serverType);
            break;
        case LdapConfigConstant.USER:
            attributeMapList = AttributeMapSettings.USERSETTINGS.get(serverType);
            break;
        case LdapConfigConstant.GROUP:
            if (LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED.equals(modelGrouping)) {
                attributeMapList = AttributeMapSettings.SG_GROUPSETTINGS.get(serverType);
            } else {
                attributeMapList = AttributeMapSettings.OU_GROUPSETTINGS.get(serverType);
            }
            break;
        default:
            break;
        }
        for (AttributeMapNode attributeMapNode : attributeMapList) {
            identityLdapPropertyMap.put(attributeMapNode.getIdentityProperty(), attributeMapNode.getLdapProperty());
        }
        return identityLdapPropertyMap;
    }

}
