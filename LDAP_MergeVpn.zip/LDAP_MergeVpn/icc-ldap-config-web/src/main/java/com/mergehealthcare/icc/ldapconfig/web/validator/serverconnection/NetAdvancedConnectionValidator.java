
package com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.validator.ValidationHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;

import org.springframework.validation.Errors;

/**
 * The Class NetAdvancedConnectionValidator.
 */
public final class NetAdvancedConnectionValidator {

  private static final int PROTOCOL_VERSION = 3;


  /**
   * Instantiates a new net advanced connection validator.
   */
  private NetAdvancedConnectionValidator() {
  }


  /**
   * Validate net advanced connection options.
   *
   * @param advancedConnectionVm the advanced connection vm
   * @param errors the errors
   */
  public static void validateNetAdvancedConnectionOptions(
      AdvancedConnectionOptionsViewModel advancedConnectionVm, Errors errors) {
    validateProtocolVersion(advancedConnectionVm.getProtocolVersion(), errors);
    validatePageSize(
        advancedConnectionVm.getPageSize(), advancedConnectionVm.getSizeLimit(), errors);
    validateSizeLimit(advancedConnectionVm.getSizeLimit(), errors);
    validateTimeLimit(advancedConnectionVm.getTimeLimit(), errors);
    validatePingLimit(advancedConnectionVm.getPingLimit(), errors);
    validateReferralHopLimit(advancedConnectionVm.getReferralHopLimit(), errors);
  }


  /**
   * Validate protocol version.
   *
   * @param protocolVersion the protocol version
   * @param errors the errors
   */
  private static void validateProtocolVersion(Integer protocolVersion, Errors errors) {
    boolean isProtocolVersionNull = ValidationHelper.rejectNull(
        protocolVersion, "advancedConnectionVm.protocolVersion",
        "error.advancedConnectionVm.protocolVersion.null", errors);
    if (!isProtocolVersionNull) {
      int protocolVersionValue = protocolVersion.intValue();
      if (!(protocolVersionValue == 2 || protocolVersionValue == PROTOCOL_VERSION)) {
        errors.rejectValue(
            "advancedConnectionVm.protocolVersion", "error.advancedConnectionVm.protocolVersion");
      }
    }
  }


  /**
   * Validate page size.
   *
   * @param pageSize the page size
   * @param sizeLimit the size limit
   * @param errors the errors
   */
  private static void validatePageSize(Integer pageSize, Integer sizeLimit, Errors errors) {
    boolean isPageSizeNull = ValidationHelper.rejectNull(
        pageSize, "advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize.required",
        errors);
    boolean isSizeLimitNull = ObjectUtils.isNull(sizeLimit);
    if (!isPageSizeNull) {
      int pageSizeValue = pageSize.intValue();
      int sizeLimitValue = isSizeLimitNull ? 0 : sizeLimit.intValue();
      if (pageSizeValue > sizeLimitValue) {
        errors.rejectValue("advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize");
      }
      ValidationHelper.rejectNegative(
          pageSize, "advancedConnectionVm.pageSize", "error.advancedConnectionVm.pageSize.positive",
          errors);
    }
  }


  /**
   * Validate size limit.
   *
   * @param sizeLimit the size limit
   * @param errors the errors
   */
  private static void validateSizeLimit(Integer sizeLimit, Errors errors) {
    boolean isSizeLimitNull = ValidationHelper.rejectNull(
        sizeLimit, "advancedConnectionVm.sizeLimit",
        "error.advancedConnectionVm.sizeLimit.required", errors);
    if (!isSizeLimitNull) {
      ValidationHelper.rejectNegative(
          sizeLimit, "advancedConnectionVm.sizeLimit",
          "error.advancedConnectionVm.sizeLimit.positive", errors);
    }
  }


  /**
   * Validate time limit.
   *
   * @param timeLimit the time limit
   * @param errors the errors
   */
  private static void validateTimeLimit(String timeLimit, Errors errors) {
    ValidationHelper.rejectNull(
        timeLimit, "advancedConnectionVm.timeLimit",
        "error.advancedConnectionVm.timeLimit.required", errors);
  }


  /**
   * Validate ping limit.
   *
   * @param pingLimit the ping limit
   * @param errors the errors
   */
  private static void validatePingLimit(Integer pingLimit, Errors errors) {
    ValidationHelper.rejectNegative(
        pingLimit, "advancedConnectionVm.pingLimit",
        "error.advancedConnectionVm.pingLimit.positive", errors);
  }


  /**
   * Validate referral hop limit.
   *
   * @param referralHopLimit the referral hop limit
   * @param errors the errors
   */
  private static void validateReferralHopLimit(Integer referralHopLimit, Errors errors) {
    ValidationHelper.rejectNegative(
        referralHopLimit, "advancedConnectionVm.referralHopLimit",
        "error.advancedConnectionVm.referralHopLimit.positive", errors);
  }
}
