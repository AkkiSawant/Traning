package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class ConnectionDetailsModel.
 */
@Component
public class ConnectionDetailsModel {

    private String domainHost;

    private int defaultPort;

    private boolean fullyQualifiedDomainName = true;

    private String connectionType;

    private boolean advancedConnectionOption;

    private SSLOptionsJava sslOptionsJavaVm;

    private SSLOptionsNet sslOptionsNetVm;

    private AdvancedConnectionOptionsViewModel advancedConnectionVm;


    /**
     * Instantiates a new connection details model.
     */
    public ConnectionDetailsModel() {
        sslOptionsJavaVm = new SSLOptionsJava();
        sslOptionsNetVm = new SSLOptionsNet();
        advancedConnectionVm = new AdvancedConnectionOptionsViewModel();
    }


    public String getDomainHost() {
        return domainHost;
    }


    public void setDomainHost(String domainHost) {
        this.domainHost = domainHost;
    }


    public int getDefaultPort() {
        return defaultPort;
    }


    public void setDefaultPort(int defaultPort) {
        this.defaultPort = defaultPort;
    }


    public boolean isFullyQualifiedDomainName() {
        return fullyQualifiedDomainName;
    }


    public void setFullyQualifiedDomainName(boolean fullyQualifiedDomainName) {
        this.fullyQualifiedDomainName = fullyQualifiedDomainName;
    }


    public String getConnectionType() {
        return connectionType;
    }


    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }


    public boolean isAdvancedConnectionOption() {
        return advancedConnectionOption;
    }


    public void setAdvancedConnectionOption(boolean advancedConnectionOption) {
        this.advancedConnectionOption = advancedConnectionOption;
    }


    public SSLOptionsJava getSslOptionsJavaVm() {
        return sslOptionsJavaVm;
    }


    public void setSslOptionsJavaVm(SSLOptionsJava sslOptionsJavaVm) {
        this.sslOptionsJavaVm = sslOptionsJavaVm;
    }


    public SSLOptionsNet getSslOptionsNetVm() {
        return sslOptionsNetVm;
    }


    public void setSslOptionsNetVm(SSLOptionsNet sslOptionsNetVm) {
        this.sslOptionsNetVm = sslOptionsNetVm;
    }


    public AdvancedConnectionOptionsViewModel getAdvancedConnectionVm() {
        return advancedConnectionVm;
    }


    public void setAdvancedConnectionVm(AdvancedConnectionOptionsViewModel advancedConnectionVm) {
        this.advancedConnectionVm = advancedConnectionVm;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ConnectionDetailsModel [domainHost=");
        builder.append(domainHost);
        builder.append(", defaultPort=");
        builder.append(defaultPort);
        builder.append(", fullyQualifiedDomainName=");
        builder.append(fullyQualifiedDomainName);
        builder.append(", connectionType=");
        builder.append(connectionType);
        builder.append(", advancedConnectionOption=");
        builder.append(advancedConnectionOption);
        builder.append(", sslOptionsJavaVm=");
        builder.append(sslOptionsJavaVm);
        builder.append(", sslOptionsNetVm=");
        builder.append(sslOptionsNetVm);
        builder.append(", advancedConnectionVm=");
        builder.append(advancedConnectionVm);
        builder.append("]");
        return builder.toString();
    }

}
