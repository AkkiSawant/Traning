
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class UserDomainDetailViewModel.
 */
public class UserDomainDetailViewModel {

  private String domainId;

  private String domainAdminLevel;

  private String role;


  /*
   * @return the domainId
   */
  public String getDomainId() {
    return domainId;
  }


  /*
   * @param domainId the domainId to set
   */
  public void setDomainId(String domainId) {
    this.domainId = domainId;
  }


  /*
   * @return the domainAdminLevel
   */
  public String getDomainAdminLevel() {
    return domainAdminLevel;
  }


  /*
   * @param domainAdminLevel the domainAdminLevel to set
   */
  public void setDomainAdminLevel(String domainAdminLevel) {
    this.domainAdminLevel = domainAdminLevel;
  }


  /*
   * @return the role
   */
  public String getRole() {
    return role;
  }


  /*
   * @param role the role to set
   */
  public void setRole(String role) {
    this.role = role;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("UserDomainDetailViewModel [domainId=");
    builder.append(domainId);
    builder.append(", domainAdminLevel=");
    builder.append(domainAdminLevel);
    builder.append(", role=");
    builder.append(role);
    builder.append("]");
    return builder.toString();
  }
}
