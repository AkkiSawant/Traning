
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.HashSet;
import java.util.Set;

/**
 * The Class AttributeMapNode.
 */
public class AttributeMapNode {

  private String identityProperty;

  private String ldapProperty;

  private boolean ignore;

  private Set<String> ldapProperties = new HashSet<>();


  /**
   * Instantiates a new attribute map node.
   */
  public AttributeMapNode() {
    // Spring requires a default constructor
  }


  /**
   * Instantiates a new attribute map node.
   *
   * @param identityProperty the identity property
   * @param ldapProperty the ldap property
   * @param ignore the ignore
   */
  public AttributeMapNode(String identityProperty, String ldapProperty, boolean ignore) {
    this.identityProperty = identityProperty;
    this.ldapProperty = ldapProperty;
    this.ldapProperties.add(ldapProperty);
    this.ignore = ignore;
  }


  /**
   * Instantiates a new attribute map node.
   *
   * @param identityProperty the identity property
   * @param ldapProperty the ldap property
   */
  public AttributeMapNode(String identityProperty, String ldapProperty) {
    this.identityProperty = identityProperty;
    this.ldapProperty = ldapProperty;
    this.ldapProperties.add(ldapProperty);
  }


  /**
   * Gets the identity property.
   *
   * @return the identity property
   */
  public String getIdentityProperty() {
    return identityProperty;
  }


  /**
   * Sets the identity property.
   *
   * @param identityProperty the new identity property
   */
  public void setIdentityProperty(String identityProperty) {
    this.identityProperty = identityProperty;
  }


  /**
   * Gets the ldap property.
   *
   * @return the ldap property
   */
  public String getLdapProperty() {
    return ldapProperty;
  }


  /**
   * Sets the ldap property.
   *
   * @param ldapProperty the new ldap property
   */
  public void setLdapProperty(String ldapProperty) {
    this.ldapProperty = ldapProperty;
  }


  /**
   * Checks if is ignore.
   *
   * @return true, if is ignore
   */
  public boolean isIgnore() {
    return ignore;
  }


  /**
   * Sets the ignore.
   *
   * @param ignore the new ignore
   */
  public void setIgnore(boolean ignore) {
    this.ignore = ignore;
  }


  /**
   * Gets the ldap properties.
   *
   * @return the ldap properties
   */
  public Set<String> getLdapProperties() {
    return ldapProperties;
  }


  /**
   * Sets the ldap properties.
   *
   * @param ldapProperties the new ldap properties
   */
  public void setLdapProperties(Set<String> ldapProperties) {
    this.ldapProperties = ldapProperties;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("AttributeMapNode [identityProperty=");
    builder.append(identityProperty);
    builder.append(", ldapProperty=");
    builder.append(ldapProperty);
    builder.append(", ignore=");
    builder.append(ignore);
    builder.append(", ldapProperties=");
    builder.append(ldapProperties);
    builder.append("]");
    return builder.toString();
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    return identityProperty.length();
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    AttributeMapNode attributeMapNode = null;
    if (obj instanceof AttributeMapNode) {
      attributeMapNode = (AttributeMapNode) obj;
    }
    return this.toString().equals(attributeMapNode.toString());
  }

}
