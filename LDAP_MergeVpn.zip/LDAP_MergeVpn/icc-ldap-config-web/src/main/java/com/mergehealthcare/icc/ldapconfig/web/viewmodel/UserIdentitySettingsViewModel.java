
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

public class UserIdentitySettingsViewModel extends IdentitySettingsViewModel {

  public UserIdentitySettingsViewModel(BasicInfoItemViewModelBase basicInfoVm,
      ReturnedAttributesItemViewModel returnedAttributesVm,
      AttributeMapItemViewModel attributeMapVm, ValueMapItemViewModel valueMapVm) {
    super(basicInfoVm, returnedAttributesVm, attributeMapVm, valueMapVm);
    // TODO Auto-generated constructor stub
  }


  @Override
  public String getIdentityName() {
    return LdapConfigConstant.USER;
  }


  public UserIdentitySettingsViewModel() {
    super();
    // Spring requires a default constructor
  }

}
