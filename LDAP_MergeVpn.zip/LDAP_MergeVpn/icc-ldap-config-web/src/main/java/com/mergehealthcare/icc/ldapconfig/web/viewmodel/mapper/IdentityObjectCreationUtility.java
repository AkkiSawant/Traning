/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.web.cache.AttributeMapSettings;
import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AttributeMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.BasicInfoItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.DomainIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.GroupIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.IdentitySettingsViewModelComposite;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapperIdentitySettingsVM;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ReturnedAttributesItemViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.RoleIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerType;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserIdentitySettingsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ValueMapItemViewModel;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 *
 * @author sarikam2
 */
@Component
public class IdentityObjectCreationUtility {

    private static final Logger logger = LogService.getLogger(IdentityObjectCreationUtility.class);

    @Autowired
    ReturnAttributeSettings returnAttributeSettings;


    /**
     * Creates the role id settings view model.
     *
     * @param basicInfo
     *            the basic info
     * @param attributes
     *            the attributes
     * @param attributeMap
     *            the attribute map
     * @param valueMap
     *            the value map
     * @return the role identity settings view model
     */
  // @formatter:off
    private RoleIdentitySettingsViewModel createRoleIdSettingsViewModel(
                    BasicInfoItemViewModelBase basicInfo,
                    ReturnedAttributesItemViewModel attributes,
                    AttributeMapItemViewModel attributeMap,
                    ValueMapItemViewModel valueMap) {
        // @formatter:on
        RoleIdentitySettingsViewModel viewModel = new RoleIdentitySettingsViewModel(basicInfo, attributes, attributeMap, valueMap);
        logger.debug("New Role Identity Model = " + viewModel);
        return viewModel;
    }


    /**
     * Gets the new user identity setting view model.
     *
     * @param serverType
     *            the server type
     * @return the new user identity setting view model
     */
    public UserIdentitySettingsViewModel getNewUserIdentitySettingViewModel(ServerType serverType) {
    // @formatter:off
        IdentitySettingsViewModelComposite viewModel = new IdentitySettingsViewModelComposite(serverType, 
                        returnAttributeSettings.getUserSettings(), returnAttributeSettings.getDefalutUserSettings(), AttributeMapSettings.USERSETTINGS);
        if (null != serverType) {
            switch (serverType) {
            case AD:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.USER_AND_PERSON_FILTER);
                break;
            case Apache:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.INETORG_PERSON_FILTER);
                break;
            case OpenLdap:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.INETORG_PERSON_FILTER);
                break;
            default:
                break;
            }
        }
        return createUserIdSettingsViewModel(viewModel.getBasicInfo(), viewModel.getReturnAttributes(), viewModel.getAttributeMap(), viewModel.getValueMap());
        // @formatter:on
    }


    /**
     * Creates the domain id settings view model.
     *
     * @param basicInfo
     *            the basic info
     * @param attributesModel
     *            the attributes model
     * @param attributeMap
     *            the attribute map
     * @param valueMap
     *            the value map
     * @return the domain identity settings view model
     */
  // @formatter:off
    private DomainIdentitySettingsViewModel createDomainIdSettingsViewModel(
                    BasicInfoItemViewModelBase basicInfo,
                    ReturnedAttributesItemViewModel attributesModel,
                    AttributeMapItemViewModel attributeMap,
                    ValueMapItemViewModel valueMap) {
        // @formatter:on
        DomainIdentitySettingsViewModel viewModel = new DomainIdentitySettingsViewModel(basicInfo, attributesModel, attributeMap, valueMap);
        logger.debug("New Domain Identity Model = " + viewModel);
        return viewModel;
    }


    /**
     * Gets the new role identity setting view model.
     *
     * @param serverType
     *            the server type
     * @return the new role identity setting view model
     */
    public RoleIdentitySettingsViewModel getNewRoleIdentitySettingViewModel(ServerType serverType) {
    // @formatter:off
        IdentitySettingsViewModelComposite viewModel = new IdentitySettingsViewModelComposite(serverType, returnAttributeSettings.getRoleSettings(), returnAttributeSettings.getDefalutRoleSettings(), AttributeMapSettings.ROLESETTINGS);
        if (null != serverType) {
            switch (serverType) {
            case AD:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.GROUP_FILTER);
                break;
            case Apache:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.GROUP_OF_NAMES_FILTER);
                break;
            case OpenLdap:
                viewModel.getBasicInfo().setFilter(LdapConfigConstant.GROUP_OF_NAMES_FILTER);
                break;
            default:
                break;
            }
        }
        return createRoleIdSettingsViewModel(viewModel.getBasicInfo(), viewModel.getReturnAttributes(), viewModel.getAttributeMap(), viewModel.getValueMap());
        // @formatter:on
    }


    /**
     * Creates the user id settings view model.
     *
     * @param basicInfo
     *            the basic info
     * @param attributes
     *            the attributes
     * @param attributeMap
     *            the attribute map
     * @param valueMap
     *            the value map
     * @return the user identity settings view model
     */
  // @formatter:off
    private UserIdentitySettingsViewModel createUserIdSettingsViewModel(
                    BasicInfoItemViewModelBase basicInfo,
                    ReturnedAttributesItemViewModel attributes,
                    AttributeMapItemViewModel attributeMap,
                    ValueMapItemViewModel valueMap) {
        // @formatter:on
        UserIdentitySettingsViewModel viewModel = new UserIdentitySettingsViewModel(basicInfo, attributes, attributeMap, valueMap);
        logger.debug("New User Identity Model = " + viewModel);
        return viewModel;
    }


    /**
     * Gets the new domain identity setting view model.
     *
     * @param serverType
     *            the server type
     * @return the new domain identity setting view model
     */
    public DomainIdentitySettingsViewModel getNewDomainIdentitySettingViewModel(ServerType serverType) {
    // @formatter:off
        IdentitySettingsViewModelComposite viewModel = new IdentitySettingsViewModelComposite(serverType, returnAttributeSettings.getDomainSettings(), returnAttributeSettings.getDefalutDomainSettings(), AttributeMapSettings.DOMAINSETTINGS);
        return createDomainIdSettingsViewModel(viewModel.getBasicInfo(), viewModel.getReturnAttributes(), viewModel.getAttributeMap(), viewModel.getValueMap());
        // @formatter:on
    }


    /**
     * Gets the new group identity setting view model.
     *
     * @param serverType
     *            the server type
     * @param modelGrouping
     *            the model grouping
     * @return the new group identity setting view model
     */
    public GroupIdentitySettingsViewModel getNewGroupIdentitySettingViewModel(ServerType serverType, String modelGrouping) {
    // @formatter:off
        IdentitySettingsViewModelComposite viewModel;
        if (LdapConfigConstant.SINGLE_DOMAIN_HIERARCHICAL_GROUPED.equalsIgnoreCase(modelGrouping)) {
            viewModel = new IdentitySettingsViewModelComposite(serverType, returnAttributeSettings.getOuGroupSettings(), returnAttributeSettings.getDefalutOuGroupSettings(), AttributeMapSettings.OU_GROUPSETTINGS);
            viewModel.getBasicInfo().setFilter(LdapConfigConstant.OU_UNIT);
        } else {
            viewModel = new IdentitySettingsViewModelComposite(serverType, returnAttributeSettings.getSgGroupSettings(), returnAttributeSettings.getDefalutSgGroupSettings(), AttributeMapSettings.SG_GROUPSETTINGS);
            viewModel.getBasicInfo().setFilter(LdapConfigConstant.GROUP_OF_NAMES_FILTER);
        }
        viewModel.getBasicInfo().setLdapGroupRepresentation(LdapConfigConstant.ORG_UNIT_GROUP_TYPE);
        viewModel.getBasicInfo().setEnableGroupHierarchyPattern(true);
        viewModel.getBasicInfo().setGroupHierarchy("true");
        return createGroupIdSettingsViewModel(viewModel.getBasicInfo(), viewModel.getReturnAttributes(), viewModel.getAttributeMap(), viewModel.getValueMap());
        // @formatter:on
    }


    /**
     * Creates the group id settings view model.
     *
     * @param basicInfo
     *            the basic info
     * @param attributes
     *            the attributes
     * @param attributeMap
     *            the attribute map
     * @param valueMap
     *            the value map
     * @return the group identity settings view model
     */
  // @formatter:off
    private GroupIdentitySettingsViewModel createGroupIdSettingsViewModel(
                    BasicInfoItemViewModelBase basicInfo,
                    ReturnedAttributesItemViewModel attributes,
                    AttributeMapItemViewModel attributeMap,
                    ValueMapItemViewModel valueMap) {
        // @formatter:on
        GroupIdentitySettingsViewModel viewModel = new GroupIdentitySettingsViewModel(basicInfo, attributes, attributeMap, valueMap);
        logger.debug("New Group Identity Model = " + viewModel);
        return viewModel;
    }


    public IdentitySettingsViewModel createNewIdentitySettings(MapperIdentitySettingsVM mapperIdentitySettingsVM, ServerType serverTypeEnum)
                    throws LdapConfigDataException {
        IdentitySettingsViewModel identitySettings;

        switch (mapperIdentitySettingsVM.getClassType()) {
        case LdapConfigConstant.DOMAIN:
            identitySettings = getNewDomainIdentitySettingViewModel(serverTypeEnum);
            break;
        case LdapConfigConstant.ROLE:
            identitySettings = getNewRoleIdentitySettingViewModel(serverTypeEnum);
            break;
        case LdapConfigConstant.USER:
            identitySettings = getNewUserIdentitySettingViewModel(serverTypeEnum);
            break;
        case LdapConfigConstant.GROUP:
            identitySettings = getNewGroupIdentitySettingViewModel(serverTypeEnum, mapperIdentitySettingsVM.getModelGrouping());
            break;
        default:
            throw new LdapConfigDataException("IdentityMethodVM classtype is wrong.It must be between Domain/User/Role/Group");
        }
        identitySettings.getAttributeMapVm().setMapOption(MapItemViewModelBase.MapOption.DICTIONARY);
        identitySettings.getValueMapVm().setMapOption(MapItemViewModelBase.MapOption.NO_MAP);
        return identitySettings;
    }

}
