
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class ValueMapItemViewModel.
 */
public class ValueMapItemViewModel extends MapItemViewModelBase {

  private List<ValueMapNode> valueMap = new ArrayList<ValueMapNode>();


  public List<ValueMapNode> getValueMap() {
    return valueMap;
  }


  public void setValueMap(List<ValueMapNode> valueMap) {
    this.valueMap = valueMap;
  }


  /*
   * (non-Javadoc)
   * @see com.mergehealthcare.icc.ldapconfig.web.viewmodel.MapItemViewModelBase#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ValueMapItemViewModel [valueMap=");
    builder.append(valueMap);
    builder.append("]");
    return builder.toString();
  }

}
