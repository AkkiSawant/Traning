
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

/**
 * The Class IdentitySettingsViewModel.
 */
public class IdentitySettingsViewModel {

  private BasicInfoItemViewModelBase basicInfoVm = new BasicInfoItemViewModelBase();

  private ReturnedAttributesItemViewModel returnedAttributesVm =
      new ReturnedAttributesItemViewModel();

  private AttributeMapItemViewModel attributeMapVm = new AttributeMapItemViewModel();

  private ValueMapItemViewModel valueMapVm = new ValueMapItemViewModel();


  /**
   * Instantiates a new identity settings view model.
   */
  // Need to create below constructor to avoid no default constructor error
  public IdentitySettingsViewModel() {
    // Spring requires a default constructor
  }


  /**
   * Gets the identity name.
   *
   * @return the identity name
   */
  public String getIdentityName() {
    return LdapConfigConstant.IDENTITY;
  }


  /**
   * Instantiates a new identity settings view model.
   *
   * @param basicInfoVm the basic info vm
   * @param returnedAttributesVm the returned attributes vm
   * @param attributeMapVm the attribute map vm
   * @param valueMapVm the value map vm
   */
  public IdentitySettingsViewModel(BasicInfoItemViewModelBase basicInfoVm,
      ReturnedAttributesItemViewModel returnedAttributesVm,
      AttributeMapItemViewModel attributeMapVm, ValueMapItemViewModel valueMapVm) {
    this.basicInfoVm = basicInfoVm;
    this.returnedAttributesVm = returnedAttributesVm;
    this.attributeMapVm = attributeMapVm;
    this.valueMapVm = valueMapVm;
  }


  /**
   * Gets the basic info vm.
   *
   * @return the basic info vm
   */
  public BasicInfoItemViewModelBase getBasicInfoVm() {
    return basicInfoVm;
  }


  /**
   * Sets the basic info vm.
   *
   * @param basicInfoVm the new basic info vm
   */
  public void setBasicInfoVm(BasicInfoItemViewModelBase basicInfoVm) {
    this.basicInfoVm = basicInfoVm;
  }


  /**
   * Gets the returned attributes vm.
   *
   * @return the returned attributes vm
   */
  public ReturnedAttributesItemViewModel getReturnedAttributesVm() {
    return returnedAttributesVm;
  }


  /**
   * Sets the returned attributes vm.
   *
   * @param returnedAttributesVm the new returned attributes vm
   */
  public void setReturnedAttributesVm(ReturnedAttributesItemViewModel returnedAttributesVm) {
    this.returnedAttributesVm = returnedAttributesVm;
  }


  /**
   * Gets the attribute map vm.
   *
   * @return the attribute map vm
   */
  public AttributeMapItemViewModel getAttributeMapVm() {
    return attributeMapVm;
  }


  /**
   * Sets the attribute map vm.
   *
   * @param attributeMapVm the new attribute map vm
   */
  public void setAttributeMapVm(AttributeMapItemViewModel attributeMapVm) {
    this.attributeMapVm = attributeMapVm;
  }


  /**
   * Gets the value map vm.
   *
   * @return the value map vm
   */
  public ValueMapItemViewModel getValueMapVm() {
    return valueMapVm;
  }


  /**
   * Sets the value map vm.
   *
   * @param valueMapVm the new value map vm
   */
  public void setValueMapVm(ValueMapItemViewModel valueMapVm) {
    this.valueMapVm = valueMapVm;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("IdentitySettingsViewModel [basicInfoVm=");
    builder.append(basicInfoVm);
    builder.append(", returnedAttributesVm=");
    builder.append(returnedAttributesVm);
    builder.append(", attributeMapVm=");
    builder.append(attributeMapVm);
    builder.append(", valueMapVm=");
    builder.append(valueMapVm);
    builder.append("]");
    return builder.toString();
  }

}
