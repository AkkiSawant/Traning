package com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.validator.ValidationHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsNet;

import org.springframework.validation.Errors;

/**
 * The Class NetSSLValidator.
 */
public final class NetSSLValidator {

    /**
     * Instantiates a new net SSL validator.
     */
    private NetSSLValidator() {
    }


    /**
     * Validate net SSL.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    public static void validateNetSSL(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        validateClientCertificate(sslOptionsNetVm, errors);
        validateServerIdentity(sslOptionsNetVm, errors);
        validateServerCertificate(sslOptionsNetVm, errors);
    }


    /**
     * Validate client certificate.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    private static void validateClientCertificate(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        boolean clientCertificateEnabled = sslOptionsNetVm.isClientCertificateEnabled();
        if (clientCertificateEnabled) {
            boolean clientCertificateStoreEnabled = sslOptionsNetVm.isClientCertificateStoreEnabled();
            if (clientCertificateStoreEnabled) {
                validateClientCertificateStore(sslOptionsNetVm, errors);
            } else {
                validateCertificateFilePath(sslOptionsNetVm, errors);
            }
        }
    }


    /**
     * Validate client certificate store.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    private static void validateClientCertificateStore(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        String clientCertificateCn = sslOptionsNetVm.getCn();
        ValidationHelper.rejectEmpty(clientCertificateCn, "sslOptionsNetVm.cn", "error.sslOptionsNetVm.cn.required", errors);
    }


    /**
     * Validate certificate file path.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    private static void validateCertificateFilePath(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        String clientCertificatePath = sslOptionsNetVm.getClientCertificatePath();
        ValidationHelper.rejectEmpty(clientCertificatePath, "sslOptionsNetVm.clientCertificatePath",
                        "error.sslOptionsNetVm.clientCertificatePath.required", errors);
    }


    /**
     * Validate server identity.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    private static void validateServerIdentity(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        boolean serverIdentityEnabled = sslOptionsNetVm.isServerIdentityEnabled();
        if (serverIdentityEnabled) {
            String serverCertificateIdentity = sslOptionsNetVm.getServerCertificateIdentity();
            ValidationHelper.rejectEmpty(serverCertificateIdentity, "sslOptionsNetVm.serverCertificateIdentity",
                            "error.sslOptionsNetVm.serverCertificateIdentity.required", errors);
        }
    }


    /**
     * Validate server certificate.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param errors the errors
     */
    private static void validateServerCertificate(SSLOptionsNet sslOptionsNetVm, Errors errors) {
        boolean serverCertificateEnabled = sslOptionsNetVm.isServerCertificateEnabled();
        boolean serverCertificateStoreEnabled = sslOptionsNetVm.isServerCertificateStoreEnabled();
        String certificatePathRegex = "([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+\\\\?.crt";
        String serverCertificatePath = sslOptionsNetVm.getServerCertificatePath();

        if (serverCertificateEnabled && !serverCertificateStoreEnabled) {

            if (ObjectUtils.isNotNullOrEmpty(serverCertificatePath)) {
                if (!serverCertificatePath.matches(certificatePathRegex)) {
                    errors.rejectValue("sslOptionsNetVm.serverCertificatePath", "error.sslOptionsNetVm.serverCertificatePath.invalid");
                }
            }

            ValidationHelper.rejectEmpty(serverCertificatePath, "sslOptionsNetVm.serverCertificatePath",
                            "error.sslOptionsNetVm.serverCertificatePath.required", errors);
        }
    }
}
