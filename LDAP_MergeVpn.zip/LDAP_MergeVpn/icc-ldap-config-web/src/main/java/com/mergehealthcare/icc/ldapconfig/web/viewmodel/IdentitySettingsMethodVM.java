
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Class IdentitySettingsMethodVM.
 */
public class IdentitySettingsMethodVM {

  private String classType;

  private String serverName;

  private String serverType;

  private String modelGrouping;


  /**
   * @return the classType
   */
  public String getClassType() {
    return classType;
  }


  /**
   * @param classType the classType to set
   */
  public void setClassType(String classType) {
    this.classType = classType;
  }


  /**
   * @return the serverName
   */
  public String getServerName() {
    return serverName;
  }


  /**
   * @param serverName the serverName to set
   */
  public void setServerName(String serverName) {
    this.serverName = serverName;
  }


  /**
   * @return the serverType
   */
  public String getServerType() {
    return serverType;
  }


  /**
   * @param serverType the serverType to set
   */
  public void setServerType(String serverType) {
    this.serverType = serverType;
  }


  /**
   * @return the modelGrouping
   */
  public String getModelGrouping() {
    return modelGrouping;
  }


  /**
   * @param modelGrouping the modelGrouping to set
   */
  public void setModelGrouping(String modelGrouping) {
    this.modelGrouping = modelGrouping;
  }


  /**
   * Instantiates a new identity settings method VM.
   *
   * @param classType the class type
   * @param serverName the server name
   * @param serverType the server type
   * @param modelGrouping the model grouping
   */
  public IdentitySettingsMethodVM(String classType, String serverName, String serverType,
      String modelGrouping) {
    this.classType = classType;
    this.serverName = serverName;
    this.serverType = serverType;
    this.modelGrouping = modelGrouping;
  }


  @Override
  public int hashCode() {
    int prime = 31;
    int result = 1;
    result = prime * result + ((classType == null) ? 0 : classType.hashCode());
    result = prime * result + ((modelGrouping == null) ? 0 : modelGrouping.hashCode());
    result = prime * result + ((serverName == null) ? 0 : serverName.hashCode());
    result = prime * result + ((serverType == null) ? 0 : serverType.hashCode());
    return result;
  }


  @Override
  public boolean equals(Object obj) {

    boolean result = true;
    if (this == obj) {
      result = true;
    }

    if (obj == null) {
      result = false;
    }
    if (getClass() != obj.getClass()) {
      result = false;
    }
    IdentitySettingsMethodVM other = (IdentitySettingsMethodVM) obj;
    if (classType == null) {
      if (other.classType != null) {
        result = false;
      }
    } else if (!classType.equals(other.classType)) {
      result = false;
    }
    if (modelGrouping == null) {
      if (other.modelGrouping != null) {
        result = false;
      }
    } else if (!modelGrouping.equals(other.modelGrouping)) {
      result = false;
    }
    if (serverName == null) {
      if (other.serverName != null) {
        result = false;
      }
    } else if (!serverName.equals(other.serverName)) {
      result = false;
    }
    if (serverType == null) {
      if (other.serverType != null) {
        result = false;
      }
    } else if (!serverType.equals(other.serverType)) {
      result = false;
    }
    return result;
  }
}
