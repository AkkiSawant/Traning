package com.mergehealthcare.icc.ldapconfig.web.ldap.utility.net;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.ILdapService;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;
import com.unboundid.ldap.sdk.SearchScope;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ProcessBuilder.Redirect;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@Component
@Qualifier (value = "ldapServiceImplNet")
public class LdapServiceImplNet implements ILdapService {

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;

    private String setCurrentServer;

    private static final Logger logger = LogService.getLogger(LdapServiceImplNet.class);

    private static String testAuthenticationProcess = "TestAuthentication";

    private static String testConnectionProcess = "TestConnection";

    private static String getServerIdentityProcess = "GetServerIdentity";

    private static String getServerCertificatesProcess = "GetServerCerts";

    private static String userSystemAdminLevelProcess = "UserSystemAdminLevel";

    private static String userManagedDomainsProcess = "UserManagedDomains";

    private static String userManagedGroupsProcess = "UserManagedGroups";

    private static String userDomainRolesProcess = "UserDomainRoles";

    private static String userGroupRolesProcess = "UserGroupRoles";


    @Override
    public List<LdapTree> search(String targetDn, String filter, String serverName, SearchScope searchScope, List<String> attributeList)
                    throws LdapConfigDataException {
        throw new LdapConfigDataException("Not supported operation search", new UnsupportedOperationException());
    }


    @Override
    public LdapTree getLdapTree(String serverName, String targetDn) throws LdapConfigDataException {
        throw new LdapConfigDataException("Not supported operation getLdapTree", new UnsupportedOperationException());
    }


    @Override
    public String getServerIdentity(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();

        arguments.add(connectionDetails.get(LdapConfigConstant.CURRENT_SERVER).toString());

        return callProcess(getServerIdentityProcess, arguments, true);
    }


    @Override
    public String getServerCertificate(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();
        String output;
        String domainHost = (String) connectionDetails.get("domainHost");
        Integer port = Integer.parseInt((String) connectionDetails.get("port"));
        String storeLocation = (String) connectionDetails.get("storeLocation");
        String storePassword = (String) connectionDetails.get("storePassword");
        arguments.add(connectionDetails.get(LdapConfigConstant.CURRENT_SERVER).toString());
        arguments.add(storeLocation);
        arguments.add(storePassword);
        output = callProcess(getServerCertificatesProcess, arguments, true);

        if (output.isEmpty()) {
            output = "Certificate retrieved successfully";
        }
        return output;
    }


    @Override
    public boolean checkLdapConnection(String serverName) throws LdapConfigDataException {
        boolean isSuccessful = true;
        List<String> arguments = new LinkedList<String>();

        arguments.add(serverName);
        try {
            callProcess(testConnectionProcess, arguments, true);
        } catch (Exception ex) {
            logger.error("Error while checking Ldap Connection ", ex);
            throw ex;
        }
        return isSuccessful;
    }


    @Override
    public boolean authenticateUser(String userName, String password) throws LdapConfigDataException {
        boolean isAuthenticated = true;
        List<String> arguments = new LinkedList<String>();

        arguments.add(userName);
        arguments.add(password);
        try {
            callProcess(testAuthenticationProcess, arguments, false);
        } catch (Exception ex) {
            logger.error("Error while aunthecating user ", ex);
            isAuthenticated = false;
        }
        return isAuthenticated;
    }


    @Override
    public String getUserSystemAdminLevel(String userId) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();
        arguments.add(userId);
        return callProcess(userSystemAdminLevelProcess, arguments, false);
    }


    @Override
    public List<String> getUserGroupRoles(String userId, String groupId, String domainId) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();
        List<String> lst = new ArrayList<>();
        arguments.add(userId);
        arguments.add(domainId);
        arguments.add(groupId);
        try {
            String output = callProcess(userGroupRolesProcess, arguments, false);
            String[] list = output.split("%");
            lst = Arrays.asList(list);
        } catch (Exception ex) {
            logger.error("Error while getting user grp roles", ex);
            logger.equals(String.format("Userid %s, Group ID %s, Domain ID %s", userId, groupId, domainId));
        }
        return lst;
    }


    @Override
    public List<String> getUserDomainRoles(String userId, String domainId) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();

        arguments.add(userId);
        arguments.add(domainId);
        String output = callProcess(userDomainRolesProcess, arguments, false);
        String[] list = output.split("%");
        List<String> lst = Arrays.asList(list);
        return output.isEmpty() ? new ArrayList<String>() : lst;
    }


    @Override
    public List<String> getUserManagedDomains(String userId) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();

        arguments.add(userId);

        String output = callProcess(userManagedDomainsProcess, arguments, false);
        String[] list = output.split("%");
        return Arrays.asList(list);
    }


    @Override
    public List<String> getUserManagedGroups(String userId, String domainId) throws LdapConfigDataException {
        List<String> arguments = new LinkedList<String>();

        arguments.add(userId);
        arguments.add(domainId);
        String output = callProcess(userManagedGroupsProcess, arguments, false);
        String[] list = output.split("%");
        return Arrays.asList(list);
    }


    private String callProcess(String processName, List<String> arguments, boolean isTestConnection) throws LdapConfigDataException {
        Process process = null;
        String exePath = null;
        String output = "";
        try {
            LinkedList<String> data = (LinkedList<String>) arguments;
            exePath = iCCEnvironmentConfig.environment.getProperty("icc.configuration.net.processpath");

            if (isTestConnection) {
                data.addFirst(iCCEnvironmentConfig.getTestFileName());
            } else {
                data.addFirst(iCCEnvironmentConfig.getTempFileName(this.setCurrentServer));
            }

            data.addFirst(processName);
            ProcessBuilder processBuilder = new ProcessBuilder(arguments);

            data.addFirst(exePath + "NetLdapTestTool.exe");
            processBuilder.directory(new File(exePath));

            processBuilder.redirectOutput(Redirect.PIPE);

            process = processBuilder.start();

            StringBuilder sb = new StringBuilder();

            for (String string : arguments) {
                sb.append(string);
                sb.append(" ");
            }

            if (!sb.toString().isEmpty()) {
                sb.delete(sb.length() - 1, sb.length());
            }
            logger.info("Arguments to the process (" + processName + ")" + sb.toString());

            int waitFlag = process.waitFor();

            logger.fatal("callProcess:arguments " + arguments + ", callProcess:Process Flag " + waitFlag);

            output = parserOutput(process.getInputStream());
            if (waitFlag == 0) {
                int returnVal = process.exitValue();
                logger.fatal("Exit Flag = " + waitFlag);
                if (returnVal != 0) {
                    throw new LdapConfigDataException(output);
                }
            } else {
                throw new LdapConfigDataException(output);
            }

        } catch (IOException e) {
            String errorMsg = "IOException occured during process Call for Process =" + processName + ", Argument =" + arguments;
            logger.error(errorMsg, e);
            throw new LdapConfigDataException(output);
        } catch (Exception ex) {
            String errorMsg = "IOException occured during process Call for Process =" + processName + ", Argument =" + arguments;
            logger.error(errorMsg, ex);
            throw new LdapConfigDataException(output);
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        return output;
    }


    private String parserOutput(InputStream is) throws LdapConfigDataException {
        StringBuilder output = new StringBuilder();
        InputStreamReader isr = null;
        BufferedReader br = null;
        try {
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            String line = null;
            do {
                line = br.readLine();
                if (line != null) {
                    output.append(line);
                }
            } while (line != null);
        } catch (IOException e) {
            String errorMsg = "IOException occured during process Call for Process";
            logger.error(errorMsg, e);
            throw new LdapConfigDataException(output.toString());
        } catch (Exception ex) {
            String errorMsg = "Exception occured during process Call for Process";
            logger.error(errorMsg, ex);
            throw new LdapConfigDataException(output.toString());
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
                if (isr != null) {
                    isr.close();
                }
                if (br != null) {
                    br.close();
                }
            } catch (Exception ex) {
                logger.error("Exception occured during process Call for Process", ex);
            }

        }
        return output.toString();

    }


    @Override
    public void setCurrentServer(String currentServer) {
        this.setCurrentServer = currentServer;
    }

}
