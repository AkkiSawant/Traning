/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;

import icc.ldap.server.configuration.Attribute;
import icc.ldap.server.configuration.Attributes;
import icc.ldap.server.configuration.OperationCommand;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnection;
import icc.ldap.server.configuration.ServerConnectionOptions;

/**
 *
 * @author sarikam2
 */
@Component
public class AdvancedConnectionModelMapper {

    private static final Logger logger = LogService.getLogger(AdvancedConnectionModelMapper.class);

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private ObjectFactory objectFactory;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;


    private void advancedJavaModel(ServerConnectionOptions serverConnectionOptions,
                    AdvancedConnectionOptionsViewModel advancedConnectionOptionsViewModel) {
        serverConnectionOptions.setAutoReconnect(String.valueOf(advancedConnectionOptionsViewModel.isAutoReconnect()));
        serverConnectionOptions.setTcpKeepAlive(String.valueOf(advancedConnectionOptionsViewModel.isTcpKeepAlive()));
        if (advancedConnectionOptionsViewModel.getConnectionTimeOut() != null) {
            serverConnectionOptions.setConnectionTimeOut(
                            new ServerConnectionOptions.TimeSpanDuration(advancedConnectionOptionsViewModel.getConnectionTimeOut()));
        }
    }


    /**
     * Find advance connection model by server name.
     *
     * @param serverName the server name
       @param connectionModelOptionModelMapper
     * @return the advanced connection options view model
     */
    public AdvancedConnectionOptionsViewModel findAdvanceConnectionModelByServerName(String serverName) {
        AdvancedConnectionOptionsViewModel advancedConnectionOptionsViewModel = BeanUtils
                        .instantiateClass(AdvancedConnectionOptionsViewModel.class);
        try {
            ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
            ServerConnection serverConnection = serverConfiguration.getServerConnection();
            ServerConnectionOptions serverConnectionOptions = serverConnection.getServerConnectionOptions();
            OperationCommand operationCommand = serverConfiguration.getOperationCommand();
            ObjectUtils.checkIsNullAndAssign(serverConnectionOptions, advancedConnectionOptionsViewModel);
            advancedConnectionOptionsViewModel.setAutoBind(serverConnectionOptions.isAutoBind());
            advancedConnectionOptionsViewModel.setAutoReconnect(serverConnectionOptions.isAutoReconnect());
            advancedConnectionOptionsViewModel.setReferralChasingOptions(serverConnectionOptions.getReferralChasingOptions().toString());
            if (serverConnectionOptions.getPingKeepAliveTimeout() != null) {
                advancedConnectionOptionsViewModel
                                .setPingKeepAliveTimeout(serverConnectionOptions.getPingKeepAliveTimeout().getTimeSpanString());
            }
            if (serverConnectionOptions.getPingWaitTimeout() != null) {
                advancedConnectionOptionsViewModel.setPingWaitTimeout(serverConnectionOptions.getPingWaitTimeout().getTimeSpanString());
            }
            if (serverConnectionOptions.getConnectionTimeOut() != null) {
                advancedConnectionOptionsViewModel.setConnectionTimeOut(serverConnectionOptions.getConnectionTimeOut().getTimeSpanString());
            }
            advancedConnectionOptionsViewModel.setAuthenticationMethod(serverConnectionOptions.getAuthenticationMethod().toString());
            advancedConnectionOptionsViewModel.setTcpKeepAlive(serverConnectionOptions.isTcpKeepAlive());
            if (operationCommand != null) {
                ObjectUtils.checkIsNullAndAssign(serverConfiguration.getOperationCommand(), advancedConnectionOptionsViewModel);
                advancedConnectionOptionsViewModel.setTimeLimit(serverConfiguration.getOperationCommand().getTimeLimit().getTimeSpanString());
                @SuppressWarnings ("PMD.UseConcurrentHashMap")
                Map<String, Attribute> addAttribute = new HashMap<>();
                if (!ObjectUtils.isNull(operationCommand.getAttributes())) {
                    addAttribute = operationCommand.getAttributes().getAttribute();

                }

                // if (operationCommand.getAttributes() != null) {
                // Map<String, Attribute> addAttribute =
                // operationCommand.getAttributes().getAttribute();
                if (!addAttribute.isEmpty() && addAttribute.containsKey("pageSize")) {
                    advancedConnectionOptionsViewModel.setPageSize(Integer.parseInt(addAttribute.get("pageSize").getValue()));
                }
                // }
            }
        } catch (Exception ex) {
            logger.error("Reversed Mapping Exception occured from LdapConfiguration to AdvancedConnectionOptionsViewModel", ex);
        }
        return advancedConnectionOptionsViewModel;
    }


    private void advancedNetModel(ServerConnectionOptions serverConnectionOptions,
                    AdvancedConnectionOptionsViewModel advancedConnectionOptionsViewModel) {
        serverConnectionOptions.setAutoBind(String.valueOf(advancedConnectionOptionsViewModel.isAutoBind()));
        serverConnectionOptions.setAutoReconnect(String.valueOf(advancedConnectionOptionsViewModel.isAutoReconnect()));
        if (!ObjectUtils.isNull(advancedConnectionOptionsViewModel.getReferralChasingOptions())) {

            serverConnectionOptions.setReferralChasingOptions(ServerConnectionOptions.ReferralChasingOptions
                            .valueOf(advancedConnectionOptionsViewModel.getReferralChasingOptions()));
        }
        if (advancedConnectionOptionsViewModel.getPingKeepAliveTimeout() != null) {
            serverConnectionOptions.setPingKeepAliveTimeout(
                            new ServerConnectionOptions.TimeSpanDuration(advancedConnectionOptionsViewModel.getPingKeepAliveTimeout()));
        }
        if (advancedConnectionOptionsViewModel.getPingWaitTimeout() != null) {
            serverConnectionOptions.setPingWaitTimeout(
                            new ServerConnectionOptions.TimeSpanDuration(advancedConnectionOptionsViewModel.getPingWaitTimeout()));
        }
        if (advancedConnectionOptionsViewModel.getConnectionTimeOut() != null) {
            serverConnectionOptions.setConnectionTimeOut(
                            new ServerConnectionOptions.TimeSpanDuration(advancedConnectionOptionsViewModel.getConnectionTimeOut()));
        }
        if (!ObjectUtils.isNull(advancedConnectionOptionsViewModel.getAuthenticationMethod())) {
            serverConnectionOptions.setAuthenticationMethod(
                            ServerConnectionOptions.AuthType.valueOf(advancedConnectionOptionsViewModel.getAuthenticationMethod()));
        }
        if (!ObjectUtils.isNull(advancedConnectionOptionsViewModel.isTcpKeepAlive())) {
            serverConnectionOptions.setTcpKeepAlive(String.valueOf(advancedConnectionOptionsViewModel.isTcpKeepAlive()));
        }
    }


    /**
     * Save advance server configuration.
     *
     * @param serverConfiguration the server configuration
     * @param serverConnection the server connection
     * @param connectionModel the connection model
     * @param serverName the server name
     * @param connectionModelOptionModelMapper
     * @throws Exception the exception
     */
    public void saveAdvanceServerConfiguration(ServerConfiguration serverConfiguration, ServerConnection serverConnection,
                    ConnectionDetailsModel connectionModel, String serverName) throws Exception {
        AdvancedConnectionOptionsViewModel advancedConnectionOptionsViewModel = connectionModel.getAdvancedConnectionVm();

        ServerConnectionOptions serverConnectionOptions = serverConnection.getServerConnectionOptions();
        ObjectUtils.checkIsNullAndAssign(advancedConnectionOptionsViewModel, serverConnectionOptions);
        String currentPlatform = iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform");
        if (currentPlatform.equals(Platform.Net.toString())) {
            advancedNetModel(serverConnectionOptions, advancedConnectionOptionsViewModel);
        } else {
            advancedJavaModel(serverConnectionOptions, advancedConnectionOptionsViewModel);
        }
        serverConnection.setServerConnectionOptions(serverConnectionOptions);

        OperationCommand operationCommand = serverConfiguration.getOperationCommand();
        if (ObjectUtils.isNull(operationCommand)) {
            operationCommand = objectFactory.createOperationCommand();
            serverConfiguration.setOperationCommand(operationCommand);
        }
        Attributes attributes = objectFactory.createAttributes();
        Attribute attribute = objectFactory.createAttribute();
        if (connectionModel.isAdvancedConnectionOption()) {
            operationCommand.setSizeLimit(advancedConnectionOptionsViewModel.getSizeLimit());
            operationCommand.setType(advancedConnectionOptionsViewModel.getType());
            operationCommand.setTimeLimit(new ServerConnectionOptions.TimeSpanDuration(advancedConnectionOptionsViewModel.getTimeLimit()));
            attribute.setAttributeId("pageSize");
            if (advancedConnectionOptionsViewModel.getPageSize() != null) {
                attribute.setValue(String.valueOf(advancedConnectionOptionsViewModel.getPageSize().intValue()));
            }
            attributes.getAttribute().put("pageSize", attribute);
        }
        operationCommand.setAttributes(attributes);
        serverConfiguration.setOperationCommand(operationCommand);
    }

}
