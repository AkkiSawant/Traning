
package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.web.viewmodel.TestServerConfigurationViewModel;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * The Class TestLdapServerValidator.
 */
@Component
public class TestLdapServerValidator implements Validator {

  /*
   * (non-Javadoc)
   * @see org.springframework.validation.Validator#supports(java.lang.Class)
   */
  @Override
  public boolean supports(Class<?> clazz) {
    return TestServerConfigurationViewModel.class.equals(clazz);
  }


  /*
   * (non-Javadoc)
   * @see org.springframework.validation.Validator#validate(java.lang.Object,
   * org.springframework.validation.Errors)
   */
  @Override
  public void validate(Object target, Errors errors) {

    TestServerConfigurationViewModel testServerConfigurationViewModel =
        (TestServerConfigurationViewModel) target;
    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "userName.required");
    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");

    if (testServerConfigurationViewModel.getAction().equalsIgnoreCase("authorize")) {
      if (testServerConfigurationViewModel.isGroupsAdministratorTestEnabled()) {
        ValidationUtils.rejectIfEmptyOrWhitespace(
            errors, "groupDomainText", "error.testServer.groupDomainText");
      }

      if (testServerConfigurationViewModel.isRolesInDomainTestEnabled()) {
        ValidationUtils
            .rejectIfEmptyOrWhitespace(errors, "roleDomainText", "error.testServer.roleDomainText");
      }

      if (testServerConfigurationViewModel.isGroupRolesInDomainTestEnabled()) {
        ValidationUtils.rejectIfEmptyOrWhitespace(
            errors, "groupRoleDomainText", "error.testServer.groupRoleDomainText");
        ValidationUtils.rejectIfEmptyOrWhitespace(
            errors, "groupRoleGroupText", "error.testServer.groupRoleGroupText");
      }
    }
  }

}
