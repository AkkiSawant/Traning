
package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;

/**
 * The Class ValidationHelper.
 */
public final class ValidationHelper {

  /**
   * Instantiates a new validation helper.
   */
  private ValidationHelper() {

  }


  /**
   * Reject null.
   *
   * @param property the property
   * @param command the command
   * @param error the error
   * @param errors the errors
   * @return true, if successful
   */
  public static boolean rejectNull(Object property, String command, String error, Errors errors) {
    boolean rejected = false;
    if (ObjectUtils.isNull(property)) {
      rejected = true;
      errors.rejectValue(command, error);
    }
    return rejected;
  }


  /**
   * Reject empty.
   *
   * @param property the property
   * @param command the command
   * @param error the error
   * @param errors the errors
   */
  public static void rejectEmpty(Object property, String command, String error, Errors errors) {
    if (StringUtils.isEmpty(property)) {
      errors.rejectValue(command, error);
    }
  }


  /**
   * Reject negative.
   *
   * @param property the property
   * @param command the command
   * @param error the error
   * @param errors the errors
   */
  public static void rejectNegative(Integer property, String command, String error, Errors errors) {
    if (!ObjectUtils.isNull(property) && property.intValue() < 0) {
      errors.rejectValue(command, error);
    }
  }
}
