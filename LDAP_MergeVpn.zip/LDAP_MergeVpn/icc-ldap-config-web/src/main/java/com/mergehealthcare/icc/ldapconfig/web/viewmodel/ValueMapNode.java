
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class ValueMapNode.
 */
@Component
public class ValueMapNode {

  private String ldapValue;

  private String applicationValue;


  /**
   * Instantiates a new value map node.
   */
  public ValueMapNode() {
    // Spring requires a default constructor
  }


  /**
   * Instantiates a new value map node.
   *
   * @param ldapValue the ldap value
   * @param applicationValue the application value
   */
  public ValueMapNode(String ldapValue, String applicationValue) {
    this.ldapValue = ldapValue;
    this.applicationValue = applicationValue;
  }


  public String getLdapValue() {
    return ldapValue;
  }


  public void setLdapValue(String ldapValue) {
    this.ldapValue = ldapValue;
  }


  public String getApplicationValue() {
    return applicationValue;
  }


  public void setApplicationValue(String applicationValue) {
    this.applicationValue = applicationValue;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("ValueMapNode [ldapValue=");
    builder.append(ldapValue);
    builder.append(", applicationValue=");
    builder.append(applicationValue);
    builder.append("]");
    return builder.toString();
  }

}
