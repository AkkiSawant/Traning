
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum StoreName.
 */
public enum StoreName {
  AddressBook, AuthRoot, CertificateAuthority, Disallowed, My, Root, TrustedPeople, TrustedPublisher
}
