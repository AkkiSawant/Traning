
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum AuthenticationMethod.
 */
public enum AuthenticationMethod {
  Anonymous, Basic, Negotiate, Ntlm, Digest, Sicily, Dpa, Msn, External, Kerberos

}
