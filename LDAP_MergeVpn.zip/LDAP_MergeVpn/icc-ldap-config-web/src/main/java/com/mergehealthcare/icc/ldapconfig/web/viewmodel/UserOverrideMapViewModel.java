
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.List;

public class UserOverrideMapViewModel {

  private List<UserOverrideMapDetailsViewModel> userOverrideMapDetailsViewModel;


  public List<UserOverrideMapDetailsViewModel> getUserOverrideMapDetailsViewModel() {
    return userOverrideMapDetailsViewModel;
  }


  public void setUserOverrideMapDetailsViewModel(
      List<UserOverrideMapDetailsViewModel> userOverrideMapDetailsViewModel) {
    this.userOverrideMapDetailsViewModel = userOverrideMapDetailsViewModel;
  }


  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("UserOverrideMapViewModel [userOverrideMapDetailsViewModel=");
    builder.append(userOverrideMapDetailsViewModel);
    builder.append("]");
    return builder.toString();
  }

}
