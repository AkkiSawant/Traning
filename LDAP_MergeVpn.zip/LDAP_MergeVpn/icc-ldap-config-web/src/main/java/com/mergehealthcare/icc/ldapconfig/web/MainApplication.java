package com.mergehealthcare.icc.ldapconfig.web;

import icc.base.exception.IOCException;
import icc.base.ioc.ObjectFactory;
import icc.core.exception.ExpiredSessionException;
import icc.core.foundation.ServiceFactory;
import icc.core.security.authentication.UserNameCredentials;
import icc.core.security.session.ISecuritySessionUser;
import icc.core.security.session.ITokenSecuritySessionManager;

public class MainApplication {

    ObjectFactory objFact;

    ServiceFactory servFact;

    // @Autowired
    ITokenSecuritySessionManager mgr;


    public void configure() throws IOCException, ClassNotFoundException {

        // Class cs = Class.forName("icc.core.ioc.impl.SpringObjectFactory");

        objFact = ObjectFactory.getInstance();
        objFact.configure("icc.xml");
        servFact = ServiceFactory.getInstance();
        // servFact.configure("icc.xml");

    }


    public static void main(String args[]) throws IOCException, ClassNotFoundException {
        MainApplication app = new MainApplication();
        app.configure();
        app.authenticate();
        // app.authenticate();

    }


    public void authenticate() {

        try {

            mgr.setUserCredentials(new UserNameCredentials("testmerge1", "testpassword1", "User"));
            ISecuritySessionUser ssu = mgr.getSecuritySessionUser();
            System.out.println(ssu);
        } catch (ExpiredSessionException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
