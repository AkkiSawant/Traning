package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class ServerDetailsModel.
 */
@Component
public class ServerDetailsModel {

    private String serverName;

    private String serverType;

    private String networkDomain;

    private String userName;

    private String password;

    private boolean serverDetailsEnable;


    public String getServerName() {
        return this.serverName;
    }


    public void setServerName(String serverName) {
        this.serverName = serverName;
    }


    public String getServerType() {
        return this.serverType;
    }


    public void setServerType(String serverType) {
        this.serverType = serverType;
    }


    public String getNetworkDomain() {
        return this.networkDomain;
    }


    public void setNetworkDomain(String networkDomain) {
        this.networkDomain = networkDomain;
    }


    public String getUserName() {
        return this.userName;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }


    public String getPassword() {
        return this.password;
    }


    public void setPassword(String password) {
        this.password = password;
    }


    public boolean isServerDetailsEnable() {
        return serverDetailsEnable;
    }


    public void setServerDetailsEnable(boolean serverDetailsEnable) {
        this.serverDetailsEnable = serverDetailsEnable;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder toStringBuilder;
        toStringBuilder = new StringBuilder("ServerDetails{");
        toStringBuilder.append(",serverName=").append(this.serverName);
        toStringBuilder.append(",serverType=").append(this.serverType);
        toStringBuilder.append(",networkDomain=").append(this.networkDomain);
        toStringBuilder.append(",user=").append(this.userName);
        toStringBuilder.append(",password=").append(this.password);
        toStringBuilder.append(",serverDetailsEnable=").append(this.serverDetailsEnable);
        toStringBuilder.append('}');
        return toStringBuilder.toString();
    }
}
