/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig;

import com.mergehealthcare.icc.ldapconfig.web.cache.ReturnAttributeSettings;
import com.mergehealthcare.icc.ldapconfig.web.controller.DomainRoleUserGroupController;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.LdapServiceFactory;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper.IdentitySearchUtility;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import java.util.List;

/**
 *
 * @author sarikam2
 */
@Configuration
@EnableWebMvc
@ComponentScan (basePackages = {
                "com.mergehealthcare.icc.ldapconfig" }, excludeFilters = @Filter (type = FilterType.REGEX, pattern = "com.mergehealthcare.icc.ldapconfig.web.unit.*"))
public class LdapConfigApplication extends WebMvcConfigurerAdapter {

    @Bean
    public ViewResolver viewResolver() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setViewClass(JstlView.class);
        viewResolver.setPrefix("/WEB-INF/views/");
        viewResolver.setSuffix(".jsp");

        return viewResolver;
    }


    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder().indentOutput(true);
        converters.add(new MappingJackson2HttpMessageConverter(builder.build()));
    }


    @Bean
    public ICCLdapDataConfig iCCLdapDataConfig() {
        return new ICCLdapDataConfig();
    }


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**").addResourceLocations("classpath:/static/");

    }


    @Bean (name = "multipartResolver")
    public MultipartResolver multipartResolver() {
        return new CommonsMultipartResolver();
    }


    @Bean
    public DomainRoleUserGroupController domainRoleUserGroupController() {
        return new DomainRoleUserGroupController();
    }


    @Bean
    public LdapServiceFactory getLdapServiceFactory() {
        return new LdapServiceFactory();
    }


    @Bean
    public IdentitySearchUtility getIdentitySearchUtility() {
        return new IdentitySearchUtility();
    }


    @Bean
    public ReturnAttributeSettings returnAttributeSettings() {
        return new ReturnAttributeSettings();
    }


    @Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasenames("messages");
        return messageSource;
    }

}
