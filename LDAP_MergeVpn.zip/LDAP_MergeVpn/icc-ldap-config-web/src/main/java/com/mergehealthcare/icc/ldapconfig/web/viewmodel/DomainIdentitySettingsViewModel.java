
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;

public class DomainIdentitySettingsViewModel extends IdentitySettingsViewModel {

  // Need to create below constructor to avoid no default constructor error
  public DomainIdentitySettingsViewModel() {
    super();
    // Spring requires a default constructor
  }


  @Override
  public String getIdentityName() {
    return LdapConfigConstant.DOMAIN;
  }


  public DomainIdentitySettingsViewModel(BasicInfoItemViewModelBase basicInfoVm,
      ReturnedAttributesItemViewModel returnedAttributesVm,
      AttributeMapItemViewModel attributeMapVm, ValueMapItemViewModel valueMapVm) {
    super(basicInfoVm, returnedAttributesVm, attributeMapVm, valueMapVm);
    // TODO Auto-generated constructor stub
  }

}
