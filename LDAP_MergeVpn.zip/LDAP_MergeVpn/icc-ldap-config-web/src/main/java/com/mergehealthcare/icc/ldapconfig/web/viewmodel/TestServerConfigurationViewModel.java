package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import org.springframework.stereotype.Component;

/**
 * The Class TestServerConfigurationViewModel.
 */
@Component
public class TestServerConfigurationViewModel {

    private String userName;

    private String password;

    private boolean userAdminLevelTestEnabled;

    private boolean domainsAdministratorTestEnabled;

    private boolean groupsAdministratorTestEnabled;

    private boolean rolesInDomainTestEnabled;

    private boolean groupRolesInDomainTestEnabled;

    private boolean userAuthenticated;

    private String result;

    private String groupDomainText;

    private String roleDomainText;

    private String groupRoleGroupText;

    private String groupRoleDomainText;

    private String action;


    public String getUserName() {
        return userName;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }


    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }


    public boolean isUserAdminLevelTestEnabled() {
        return userAdminLevelTestEnabled;
    }


    public void setUserAdminLevelTestEnabled(boolean userAdminLevelTestEnabled) {
        this.userAdminLevelTestEnabled = userAdminLevelTestEnabled;
    }


    public boolean isDomainsAdministratorTestEnabled() {
        return domainsAdministratorTestEnabled;
    }


    public void setDomainsAdministratorTestEnabled(boolean domainsAdministratorTestEnabled) {
        this.domainsAdministratorTestEnabled = domainsAdministratorTestEnabled;
    }


    public boolean isGroupsAdministratorTestEnabled() {
        return groupsAdministratorTestEnabled;
    }


    public void setGroupsAdministratorTestEnabled(boolean groupsAdministratorTestEnabled) {
        this.groupsAdministratorTestEnabled = groupsAdministratorTestEnabled;
    }


    public boolean isRolesInDomainTestEnabled() {
        return rolesInDomainTestEnabled;
    }


    public void setRolesInDomainTestEnabled(boolean rolesInDomainTestEnabled) {
        this.rolesInDomainTestEnabled = rolesInDomainTestEnabled;
    }


    public boolean isGroupRolesInDomainTestEnabled() {
        return groupRolesInDomainTestEnabled;
    }


    public void setGroupRolesInDomainTestEnabled(boolean groupRolesInDomainTestEnabled) {
        this.groupRolesInDomainTestEnabled = groupRolesInDomainTestEnabled;
    }


    public boolean isUserAuthenticated() {
        return userAuthenticated;
    }


    public void setUserAuthenticated(boolean userAuthenticated) {
        this.userAuthenticated = userAuthenticated;
    }


    public String getResult() {
        return result;
    }


    public void setResult(String result) {
        this.result = result;
    }


    public String getGroupDomainText() {
        return groupDomainText;
    }


    public void setGroupDomainText(String groupDomainText) {
        this.groupDomainText = groupDomainText;
    }


    public String getRoleDomainText() {
        return roleDomainText;
    }


    public void setRoleDomainText(String roleDomainText) {
        this.roleDomainText = roleDomainText;
    }


    public String getGroupRoleGroupText() {
        return groupRoleGroupText;
    }


    public void setGroupRoleGroupText(String groupRoleGroupText) {
        this.groupRoleGroupText = groupRoleGroupText;
    }


    public String getGroupRoleDomainText() {
        return groupRoleDomainText;
    }


    public void setGroupRoleDomainText(String groupRoleDomainText) {
        this.groupRoleDomainText = groupRoleDomainText;
    }


    public String getAction() {
        return action;
    }


    public void setAction(String action) {
        this.action = action;
    }


    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("TestServerConfigurationViewModel [userName=");
        builder.append(userName);
        builder.append(", password=");
        builder.append(password);
        builder.append(", groupsAdminInDomain=");
        builder.append(", rolesDomain=");
        builder.append(", groupRolesGroup=");
        builder.append(", groupRolesDomain=");
        builder.append(", userAdminLevelTestEnabled=");
        builder.append(userAdminLevelTestEnabled);
        builder.append(", domainsAdministratorTestEnabled=");
        builder.append(domainsAdministratorTestEnabled);
        builder.append(", groupsAdministratorTestEnabled=");
        builder.append(groupsAdministratorTestEnabled);
        builder.append(", rolesInDomainTestEnabled=");
        builder.append(rolesInDomainTestEnabled);
        builder.append(", groupRolesInDomainTestEnabled=");
        builder.append(groupRolesInDomainTestEnabled);
        builder.append(", userAuthenticated=");
        builder.append(userAuthenticated);
        builder.append(", result=");
        builder.append(result);
        builder.append(", groupDomainText=");
        builder.append(groupDomainText);
        builder.append(", roleDomainText=");
        builder.append(roleDomainText);
        builder.append(", groupRoleGroupText=");
        builder.append(groupRoleGroupText);
        builder.append(", groupRoleDomainText=");
        builder.append(groupRoleDomainText);
        builder.append("]");
        return builder.toString();
    }

}
