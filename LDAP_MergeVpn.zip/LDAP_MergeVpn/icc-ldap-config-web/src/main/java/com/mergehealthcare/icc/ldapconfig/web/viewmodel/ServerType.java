
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

/**
 * The Enum ServerType.
 */
public enum ServerType {
  AD, Apache, OpenLdap
}
