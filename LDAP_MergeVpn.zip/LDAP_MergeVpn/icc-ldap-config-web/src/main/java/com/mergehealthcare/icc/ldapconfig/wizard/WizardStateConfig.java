
package com.mergehealthcare.icc.ldapconfig.wizard;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * The Class WizardStateConfig.
 *
 * @author monilg This class maintains Wizard navigation Objects.
 */
@Component
public class WizardStateConfig {

  /**
   * This object contains wizardStateCommand objects for each page as a linked
   * list.
   */
  @SuppressWarnings ("PMD.UseConcurrentHashMap")
  public static final Map<String, WizardStateCommand> WIZARD_MAP = new HashMap<>();


  /**
   * Creates the server list.
   */
  private void createServerList() {
    WizardStateCommand serverListCommand = new WizardStateCommand();
    serverListCommand.setCommandUrl("home");
    serverListCommand.setPageHeader("Configured Servers List");
    serverListCommand.setViewName("serverList");
    serverListCommand.setButtonTitle("Servers List");
    serverListCommand.setSubmitable(false);
    serverListCommand.setShowNavbar(false);
    serverListCommand.setShowTreeViewer(false);
    WIZARD_MAP.put("serverList", serverListCommand);
  }


  /**
   * Creates the save server.
   */
  private void createSaveServer() {
    WizardStateCommand saveServerCommand = new WizardStateCommand();
    saveServerCommand.setCommandUrl("saveServer");
    saveServerCommand.setPageHeader("Add Server");
    saveServerCommand.setViewName("saveServer");
    saveServerCommand.setButtonTitle("Add new LDAP Server");
    saveServerCommand.setSubmitable(true);
    saveServerCommand.setModelVariable("serverDetails");
    WIZARD_MAP.put("saveServer", saveServerCommand);
  }


  /**
   * Creates the connection details.
   */
  private void createConnectionDetails() {
    WizardStateCommand connectionDetailsCommand = new WizardStateCommand();
    connectionDetailsCommand.setCommandUrl("connections");
    connectionDetailsCommand.setPageHeader("Add Connection Details");
    connectionDetailsCommand.setViewName("connectionDetails");
    connectionDetailsCommand.setButtonTitle("Add Connection Details");
    connectionDetailsCommand.setSubmitable(true);
    connectionDetailsCommand.setModelVariable("serverConnection");
    WIZARD_MAP.put("addConnection", connectionDetailsCommand);
  }


  /**
   * Creates the model option.
   */
  private void createModelOption() {
    WizardStateCommand modelOptionCommand = new WizardStateCommand();
    modelOptionCommand.setCommandUrl("modelOptions");
    modelOptionCommand.setPageHeader("Select model options");
    modelOptionCommand.setViewName("modelOptions");
    modelOptionCommand.setButtonTitle("Select Model Options");
    modelOptionCommand.setSubmitable(true);
    modelOptionCommand.setModelVariable("modelOption");
    WIZARD_MAP.put("modelOption", modelOptionCommand);
  }


  /**
   * Creates the domain identity.
   */
  private void createDomainIdentity() {
    WizardStateCommand domainIdentityCommand = new WizardStateCommand();
    domainIdentityCommand.setCommandUrl("domainIdentitySettings");
    domainIdentityCommand.setPageHeader("Domain Identity Settings");
    domainIdentityCommand.setViewName("domainIdentitySettings");
    domainIdentityCommand.setButtonTitle("Domain Identity Settings");
    domainIdentityCommand.setSubmitable(true);
    domainIdentityCommand.setModelVariable("domainIdentitySettingsViewModel");
    WIZARD_MAP.put("domainIdentitySettings", domainIdentityCommand);
  }


  /**
   * Creates the role identity.
   */
  private void createRoleIdentity() {
    WizardStateCommand roleIdentityCommand = new WizardStateCommand();
    roleIdentityCommand.setCommandUrl("roleIdentitySettings");
    roleIdentityCommand.setPageHeader("Role Identity Settings");
    roleIdentityCommand.setViewName("roleIdentitySettings");
    roleIdentityCommand.setButtonTitle("Role Identity Settings");
    roleIdentityCommand.setSubmitable(true);
    roleIdentityCommand.setModelVariable("roleIdentitySettingsViewModel");
    WIZARD_MAP.put("roleIdentitySettings", roleIdentityCommand);
  }


  /**
   * Creates the user identity.
   */
  private void createUserIdentity() {
    WizardStateCommand userIdentityCommand = new WizardStateCommand();
    userIdentityCommand.setCommandUrl("userIdentitySettings");
    userIdentityCommand.setPageHeader("User Identity Settings");
    userIdentityCommand.setViewName("userIdentitySettings");
    userIdentityCommand.setButtonTitle("User Identity Settings");
    userIdentityCommand.setSubmitable(true);
    userIdentityCommand.setModelVariable("userIdentitySettingsViewModel");
    WIZARD_MAP.put("userIdentitySettings", userIdentityCommand);
  }


  /**
   * Creates the user override map.
   */
  private void createUserOverrideMap() {
    WizardStateCommand userOverrideMapCommand = new WizardStateCommand();
    userOverrideMapCommand.setCommandUrl("userOverrideMap");
    userOverrideMapCommand.setPageHeader("User Override Map");
    userOverrideMapCommand.setViewName("userOverrideMap");
    userOverrideMapCommand.setButtonTitle("user Override Map");
    userOverrideMapCommand.setSubmitable(true);
    userOverrideMapCommand.setModelVariable("userOverrideMap");
    WIZARD_MAP.put("userOverrideMap", userOverrideMapCommand);
  }


  /**
   * Creates the group identity.
   */
  private void createGroupIdentity() {
    WizardStateCommand groupIdentityCommand = new WizardStateCommand();
    groupIdentityCommand.setCommandUrl("groupIdentitySettings");
    groupIdentityCommand.setPageHeader("Group Identity Settings");
    groupIdentityCommand.setViewName("groupIdentitySettings");
    groupIdentityCommand.setButtonTitle("Group Identity Settings");
    groupIdentityCommand.setSubmitable(true);
    groupIdentityCommand.setModelVariable("groupIdentitySettingsViewModel");
    WIZARD_MAP.put("groupIdentitySettings", groupIdentityCommand);
  }


  /**
   * Creates the test.
   */
  private void createTest() {
    WizardStateCommand testCommand = new WizardStateCommand();
    testCommand.setCommandUrl("testServer");
    testCommand.setPageHeader("Test Server");
    testCommand.setViewName("testServer");
    testCommand.setButtonTitle("Test");
    testCommand.setSubmitable(false);
    testCommand.setModelVariable("testServerConfigurationModel");
    WIZARD_MAP.put("testServer", testCommand);
  }


  /**
   * Creates the finish.
   */
  private void createFinish() {
    WizardStateCommand finishCommand = new WizardStateCommand();
    finishCommand.setCommandUrl("home");
    finishCommand.setPreviousCommand(null);
    finishCommand.setPageHeader("Finish");
    finishCommand.setViewName("finish");
    finishCommand.setButtonTitle("FINISH");
    finishCommand.setSubmitable(false);
    finishCommand.setModelVariable("");
    WIZARD_MAP.put("finish", finishCommand);
  }


  /**
   * Assign forward pointers.
   */
  private void assignForwardPointers() {
    WizardStateCommand serverListCommand = WIZARD_MAP.get("serverList");

    WizardStateCommand saveServerCommand = WIZARD_MAP.get("saveServer");
    serverListCommand.setNextCommand(saveServerCommand);

    WizardStateCommand connectionDetailsCommand = WIZARD_MAP.get("addConnection");
    saveServerCommand.setNextCommand(connectionDetailsCommand);

    WizardStateCommand modelOptionCommand = WIZARD_MAP.get("modelOption");
    connectionDetailsCommand.setNextCommand(modelOptionCommand);

    WizardStateCommand domainIdentityCommand = WIZARD_MAP.get("domainIdentitySettings");
    modelOptionCommand.setNextCommand(domainIdentityCommand);

    WizardStateCommand roleIdentityCommand = WIZARD_MAP.get("roleIdentitySettings");
    domainIdentityCommand.setNextCommand(roleIdentityCommand);

    WizardStateCommand userIdentityCommand = WIZARD_MAP.get("userIdentitySettings");
    roleIdentityCommand.setNextCommand(userIdentityCommand);

    WizardStateCommand groupIdentityCommand = WIZARD_MAP.get("groupIdentitySettings");
    userIdentityCommand.setNextCommand(groupIdentityCommand);

    WizardStateCommand userOverrideMapCommand = WIZARD_MAP.get("userOverrideMap");
    groupIdentityCommand.setNextCommand(userOverrideMapCommand);

    WizardStateCommand testCommand = WIZARD_MAP.get("testServer");
    userOverrideMapCommand.setNextCommand(testCommand);

    WizardStateCommand finishCommand = WIZARD_MAP.get("finish");
    testCommand.setNextCommand(finishCommand);

    finishCommand.setNextCommand(null);

  }


  /**
   * Assign reverse pointers.
   */
  private void assignReversePointers() {
    WizardStateCommand serverListCommand = WIZARD_MAP.get("serverList");
    serverListCommand.setPreviousCommand(null);

    WizardStateCommand saveServerCommand = WIZARD_MAP.get("saveServer");
    saveServerCommand.setPreviousCommand(serverListCommand);

    WizardStateCommand connectionDetailsCommand = WIZARD_MAP.get("addConnection");
    connectionDetailsCommand.setPreviousCommand(saveServerCommand);

    WizardStateCommand modelOptionCommand = WIZARD_MAP.get("modelOption");
    modelOptionCommand.setPreviousCommand(connectionDetailsCommand);

    WizardStateCommand domainIdentityCommand = WIZARD_MAP.get("domainIdentitySettings");
    domainIdentityCommand.setPreviousCommand(modelOptionCommand);

    WizardStateCommand roleIdentityCommand = WIZARD_MAP.get("roleIdentitySettings");
    roleIdentityCommand.setPreviousCommand(domainIdentityCommand);

    WizardStateCommand userIdentityCommand = WIZARD_MAP.get("userIdentitySettings");
    userIdentityCommand.setPreviousCommand(roleIdentityCommand);

    WizardStateCommand groupIdentityCommand = WIZARD_MAP.get("groupIdentitySettings");
    groupIdentityCommand.setPreviousCommand(userIdentityCommand);

    WizardStateCommand userOverrideMapCommand = WIZARD_MAP.get("userOverrideMap");
    userOverrideMapCommand.setPreviousCommand(groupIdentityCommand);

    WizardStateCommand testCommand = WIZARD_MAP.get("testServer");
    testCommand.setPreviousCommand(userOverrideMapCommand);

    WizardStateCommand finishCommand = WIZARD_MAP.get("finish");
    finishCommand.setPreviousCommand(testCommand);
  }


  /**
   * Instantiates a new wizard state config.
   *
   * @param propertyReader the property reader
   */
  @Autowired
  public WizardStateConfig(PropertyReader propertyReader) {
    createServerList();
    createSaveServer();
    createConnectionDetails();
    createModelOption();
    createDomainIdentity();
    createRoleIdentity();
    createUserIdentity();
    createGroupIdentity();
    createUserOverrideMap();
    createTest();
    createFinish();
    assignForwardPointers();
    assignReversePointers();
  }


  /**
   * Removes the group identity node.
   */
  public static void removeGroupIdentityNode() {
    WizardStateCommand groupIdentityCommand = WIZARD_MAP.get("groupIdentitySettings");
    WizardStateCommand previousCommand = groupIdentityCommand.getPreviousCommand();
    WizardStateCommand nextCommand = groupIdentityCommand.getNextCommand();
    previousCommand.setNextCommand(nextCommand);
    nextCommand.setPreviousCommand(previousCommand);
  }


  /**
   * Adds the group identity node.
   */
  public static void addGroupIdentityNode() {
    WizardStateCommand groupIdentityCommand = WIZARD_MAP.get("groupIdentitySettings");
    WizardStateCommand previousCommand = groupIdentityCommand.getPreviousCommand();
    WizardStateCommand nextCommand = groupIdentityCommand.getNextCommand();
    previousCommand.setNextCommand(groupIdentityCommand);
    nextCommand.setPreviousCommand(groupIdentityCommand);
  }
}
