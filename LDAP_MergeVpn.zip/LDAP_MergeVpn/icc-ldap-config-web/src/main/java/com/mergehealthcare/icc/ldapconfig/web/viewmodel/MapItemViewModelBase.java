
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

public class MapItemViewModelBase {

  public enum MapOption {
    NO_MAP, DICTIONARY;
  }


  private MapOption mapOption;


  public MapOption getMapOption() {
    return mapOption;
  }


  public void setMapOption(MapOption mapOption) {
    this.mapOption = mapOption;
  }


  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("MapItemViewModelBase [mapOption=");
    builder.append(mapOption);
    builder.append("]");
    return builder.toString();
  }

}
