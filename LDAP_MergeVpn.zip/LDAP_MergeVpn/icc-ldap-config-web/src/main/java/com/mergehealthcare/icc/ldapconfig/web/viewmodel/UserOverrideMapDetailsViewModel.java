
package com.mergehealthcare.icc.ldapconfig.web.viewmodel;

import java.util.List;

/*
 * The Class UserOverrideMapDetailsViewModel.
 */
public class UserOverrideMapDetailsViewModel {

  private String userId;

  private String systemAdminLevel;

  private List<UserGroupDetailViewModel> groupDetails;

  private List<UserDomainDetailViewModel> domainDetails;


  /*
   * @return the userId
   */
  public String getUserId() {
    return userId;
  }


  /*
   * @param userId the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }


  /*
   * @return the systemAdminLevel
   */
  public String getSystemAdminLevel() {
    return systemAdminLevel;
  }


  /*
   * @param systemAdminLevel the systemAdminLevel to set
   */
  public void setSystemAdminLevel(String systemAdminLevel) {
    this.systemAdminLevel = systemAdminLevel;
  }


  /*
   * @return the groupDetails
   */
  public List<UserGroupDetailViewModel> getGroupDetails() {
    return groupDetails;
  }


  /*
   * @param groupDetails the groupDetails to set
   */
  public void setGroupDetails(List<UserGroupDetailViewModel> groupDetails) {
    this.groupDetails = groupDetails;
  }


  /*
   * @return the domainDetails
   */
  public List<UserDomainDetailViewModel> getDomainDetails() {
    return domainDetails;
  }


  /*
   * @param domainDetails the domainDetails to set
   */
  public void setDomainDetails(List<UserDomainDetailViewModel> domainDetails) {
    this.domainDetails = domainDetails;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("UserOverrideMapDetailsViewModel [userId=");
    builder.append(userId);
    builder.append(", systemAdminLevel=");
    builder.append(systemAdminLevel);
    builder.append(", groupDetails=");
    builder.append(groupDetails);
    builder.append(", domainDetails=");
    builder.append(domainDetails);
    builder.append("]");
    return builder.toString();
  }

}
