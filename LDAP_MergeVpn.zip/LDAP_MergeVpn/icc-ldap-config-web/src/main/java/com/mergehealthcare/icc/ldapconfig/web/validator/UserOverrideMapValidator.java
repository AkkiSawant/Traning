package com.mergehealthcare.icc.ldapconfig.web.validator;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserDomainDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserGroupDetailViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapDetailsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.UserOverrideMapViewModel;

@Component
public class UserOverrideMapValidator implements Validator {

    private static final String vm = "userOverrideMapDetailsViewModel";


    @Override
    public boolean supports(Class<?> clazz) {
        return UserOverrideMapViewModel.class.equals(clazz);
    }


    @Override
    public void validate(Object target, Errors errors) {
        UserOverrideMapViewModel userOverrideMapViewModel = (UserOverrideMapViewModel) target;
        Set<String> userIdSet = new HashSet<>();
        for (UserOverrideMapDetailsViewModel UserOverrideMapVm : userOverrideMapViewModel.getUserOverrideMapDetailsViewModel()) {
            String userId = UserOverrideMapVm.getUserId();
            boolean validated = validateUserId(userId, userIdSet, errors);
            if (validated) {
                validateDomainVm(UserOverrideMapVm.getDomainDetails(), userId, errors);
                validateGroupVm(UserOverrideMapVm.getGroupDetails(), userId, errors);
            }
        }
    }


    private boolean validateUserId(String userId, Set<String> userIdSet, Errors errors) {
        boolean validated = false;
        boolean empty = checkEmptyUserId(userId, errors);
        boolean duplicate = isUserIdDuplicate(userId, userIdSet, errors);
        validated = !(empty || duplicate);
        return validated;
    }


    private boolean checkEmptyUserId(String userId, Errors errors) {
        boolean empty = ObjectUtils.isNullOrEmpty(userId);
        if (empty) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.userId", "UserId is required");
        }
        return empty;
    }


    private boolean isUserIdDuplicate(String userId, Set<String> userIdSet, Errors errors) {
        boolean duplicate = !userIdSet.add(userId);
        if (duplicate) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.userId.duplicate", "Duplicate user Id : " + userId);
        }
        return duplicate;
    }


    private void validateDomainVm(List<UserDomainDetailViewModel> domainVm, String userId, Errors errors) {
        if (!ObjectUtils.isNull(domainVm)) {
            validateEmptyDomain(domainVm, userId, errors);
            validateDuplicateDomain(domainVm, errors);
        }
    }


    private void validateEmptyDomain(List<UserDomainDetailViewModel> domainVm, String userId, Errors errors) {
        for (UserDomainDetailViewModel domainViewModel : domainVm) {
            validateDomainId(domainViewModel.getDomainId(), userId, errors);
        }
    }


    private void validateDuplicateDomain(List<UserDomainDetailViewModel> domainVm, Errors errors) {
        Set<String> domainIdSet = new HashSet<String>();
        for (UserDomainDetailViewModel domainViewModel : domainVm) {
            rejectDuplicateDomain(domainViewModel.getDomainId(), domainIdSet, errors);
        }
    }


    private void rejectDuplicateDomain(String domainId, Set<String> domainIdSet, Errors errors) {
        boolean duplicate = !domainIdSet.add(domainId);
        if (duplicate) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.domainId.duplicate", "Duplicate domain Id : " + domainId);
        }
    }


    private void validateDomainId(String domainId, String userId, Errors errors) {
        if (ObjectUtils.isNullOrEmpty(domainId)) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.domainId", "For User " + userId + ": Domain Id is required");
        }
    }


    private void validateGroupVm(List<UserGroupDetailViewModel> groupVm, String userId, Errors errors) {
        if (!ObjectUtils.isNull(groupVm)) {
            validateEmptyGroup(groupVm, userId, errors);
            validateDuplicateGroup(groupVm, errors);
        }
    }

    
    private void validateDuplicateGroup(List<UserGroupDetailViewModel> groupVm, Errors errors) {
        Set<DomainGroupNode> domainGroupSet = new HashSet<DomainGroupNode>();
        for (UserGroupDetailViewModel groupViewModel : groupVm) {
            rejectDuplicateGroup(groupViewModel, domainGroupSet, errors);
        }
    }
    
    
    private void rejectDuplicateGroup(UserGroupDetailViewModel groupViewModel, Set<DomainGroupNode> domainGroupSet, Errors errors) {
        String groupId = groupViewModel.getGroupId();
        String domainId = groupViewModel.getDomainId();
        DomainGroupNode domainGroupNode = new DomainGroupNode(groupId, domainId);
        boolean duplicate = !domainGroupSet.add(domainGroupNode);
        if (duplicate) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.domainGroupNode.duplicate", "Duplicate entry in domain group table");
        }
    }
    
    
    private void validateEmptyGroup(List<UserGroupDetailViewModel> groupVm, String userId, Errors errors) {
        for (UserGroupDetailViewModel groupViewModel : groupVm) {
            validateGroupDomainId(groupViewModel.getDomainId(), userId, errors);
            validateGroupId(groupViewModel.getGroupId(), userId, errors);
        }
    }
    

    private void validateGroupDomainId(String domainId, String userId, Errors errors) {
        if (ObjectUtils.isNullOrEmpty(domainId)) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.domainId", "For User " + userId + ": Domain Id is required");
        }
    }


    private void validateGroupId(String groupId, String userId, Errors errors) {
        if (ObjectUtils.isNullOrEmpty(groupId)) {
            errors.rejectValue(vm, "error.userOverrideMapViewModel.GroupId", "For User " + userId + ": Group Id is required");
        }
    }
}
