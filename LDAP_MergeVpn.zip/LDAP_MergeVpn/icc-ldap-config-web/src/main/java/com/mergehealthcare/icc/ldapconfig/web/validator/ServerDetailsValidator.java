package com.mergehealthcare.icc.ldapconfig.web.validator;

import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ServerDetailsModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.Set;

/**
 * The Class ServerDetailsValidator.
 */
@Component
public class ServerDetailsValidator implements Validator {

    @Autowired
    private ServerDetailsService serverDetailsService;


    /*
     * (non-Javadoc)
     * @see org.springframework.validation.Validator#supports(java.lang.Class)
     */
    @Override
    public boolean supports(Class<?> clazz) {
        return ServerDetailsModel.class.equals(clazz);
    }


    /*
     * (non-Javadoc)
     * @see org.springframework.validation.Validator#validate(java.lang.Object,
     * org.springframework.validation.Errors)
     */
    @Override
    public void validate(Object target, Errors errors) {

        ServerDetailsModel targetServerDetailsModel = (ServerDetailsModel) target;
        String serverName = targetServerDetailsModel.getServerName();

        if (StringUtils.isEmpty(targetServerDetailsModel.getNetworkDomain())) {
            errors.rejectValue("networkDomain", "NotNull");
        }

        if (StringUtils.isEmpty(targetServerDetailsModel.getUserName())) {
            errors.rejectValue("userName", "NotNull");
        }

        if (StringUtils.isEmpty(targetServerDetailsModel.getPassword())) {
            errors.rejectValue("password", "NotNull");
        }

        if (StringUtils.isEmpty(serverName)) {
            errors.rejectValue("serverName", "NotNull");
        }

    }


    public void validateModify(Object target, Errors errors) {

        ServerDetailsModel targetServerDetailsModel = (ServerDetailsModel) target;
        String serverName = targetServerDetailsModel.getServerName();

        Set<String> serverConfig = serverDetailsService.listServerNames();
        if (serverConfig.contains(serverName)) {
            errors.rejectValue("serverName", "error.serverName");
        }
    }

}
