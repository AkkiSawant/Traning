package com.mergehealthcare.icc.ldapconfig.web.ldap.utility.java;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ldap.IccLdapServiceHelper;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;
import com.mergehealthcare.icc.ldapconfig.web.ldap.utility.ILdapService;
import com.mergehealthcare.icc.ldapconfig.wizard.LdapConfigConstant;
import com.unboundid.ldap.sdk.Attribute;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.SearchScope;

import icc.base.exception.IOCException;
import icc.ldap.server.LdapSearchResponse;
import icc.ldap.server.LdapSearchResultEntry;
import icc.ldap.server.LdapServer;
import icc.ldap.server.connection.LdapSslConnection;
import icc.ldap.server.connection.LdapTlsConnection;
import icc.ldap.server.connection.SslInfo;
import icc.ldap.server.exception.LdapConnectionException;
import icc.ldap.testtool.utils.ICCInterceptingTrustManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component ("ldapServiceImplJava")
public class LdapServiceImplJava implements ILdapService {

    private static final Logger logger = LogService.getLogger(LdapServiceImplJava.class);

    private ICCInterceptingTrustManager interceptingTrustManager = new ICCInterceptingTrustManager();

    @Autowired
    private IccLdapServiceHelper ldapServiceHelper;

    private String currentServer;


    @Override
    public boolean authenticateUser(String userName, String password) throws LdapConfigDataException {
        logger.info("Looking into ldap server throug java service " + userName);
        try {
            return ldapServiceHelper.authenticateUser(userName, password);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException(ex);
        }
    }


    @Override
    public List<LdapTree> search(String targetDn, String filter, String serverName, SearchScope searchScope, List<String> attributeList)
                    throws LdapConfigDataException {
        LdapServer ldapServer;
        try {
            ldapServer = ldapServiceHelper.findServer(serverName);
            LdapSearchResponse ldapSearchResponse = ldapServiceHelper.search(targetDn, filter, SearchScope.SUB, ldapServer);
            return mapLdapSearchResponseToLdapTree(ldapSearchResponse, attributeList);
        } catch (IOCException | LDAPException ex) {
            logger.error(String.format("Error Occured in search operation parameters are: %s %s %s %s", targetDn, filter, serverName,
                            attributeList), ex);
            throw new LdapConfigDataException(ex);
        }
    }


    private List<LdapTree> mapLdapSearchResponseToLdapTree(LdapSearchResponse ldapSearchResponse, List<String> attributeList) {
        List<LdapTree> entityList = new ArrayList<LdapTree>();
        Iterator<LdapSearchResultEntry> iterator = ldapSearchResponse.iterator();
        while (iterator.hasNext()) {
            LdapSearchResultEntry ldapSearchResultEntry = iterator.next();
            LdapTree ldapTree = new LdapTree();
            ldapTree.setFullyQualifiedName(ldapSearchResultEntry.getDistinguishedName());
            if (!ldapSearchResultEntry.getAttributes().isEmpty()) {
                setAttributeMap(ldapTree, ldapSearchResultEntry.getAttributes(), attributeList);
            }
            ldapTree.setValue(ldapTree, ldapTree.getFullyQualifiedName());
            entityList.add(ldapTree);
        }
        return entityList;
    }


    private LdapTree setAttributeMap(final LdapTree ldapTree, Map<String, Attribute> attributes, List<String> attributeList) {
        if (attributeList == null) {
            for (Map.Entry<String, Attribute> entry : attributes.entrySet()) {
                Attribute attribute = entry.getValue();
                ldapTree.addIntoAttributes(entry.getKey(), attribute.getValue());
            }
        } else {
            for (Map.Entry<String, Attribute> entry : attributes.entrySet()) {
                Attribute attribute = entry.getValue();
                if (attributeList.contains(entry.getKey())) {
                    ldapTree.addIntoAttributes(entry.getKey(), attribute.getValue());
                }
            }
        }
        return ldapTree;
    }


    @Override
    public LdapTree getLdapTree(String serverName, String targetDn) throws LdapConfigDataException {
        LdapServer ldapServer;
        LdapTree ldapTree = new LdapTree();
        LdapSearchResponse ldapSearchResponse = null;
        try {
            ldapServer = ldapServiceHelper.findServer(serverName);
            ldapSearchResponse = ldapServiceHelper.search(targetDn, "objectclass=*", SearchScope.BASE, ldapServer);
            Iterator<LdapSearchResultEntry> ldapSearchRseultIterator = ldapSearchResponse.iterator();
            if ((ldapSearchResponse != null) && ldapSearchResponse.size() > 0) {
                while (ldapSearchRseultIterator.hasNext()) {
                    LdapSearchResultEntry ldapSearchResultEntry = ldapSearchRseultIterator.next();
                    if (!ldapSearchResultEntry.getAttributes().isEmpty()) {
                        setAttributeMap(ldapTree, ldapSearchResultEntry.getAttributes(), null);
                    }
                    ldapTree.setTitle();
                    ldapTree.setFullyQualifiedName(ldapSearchResultEntry.getDistinguishedName());
                    ldapTree.setValue(ldapTree, ldapTree.getFullyQualifiedName());

                    LdapTree childLdapTree = new LdapTree();
                    childLdapTree.setTitle("");
                    ArrayList<LdapTree> arrLdapTree = new ArrayList<>();
                    arrLdapTree.add(childLdapTree);
                    ldapTree.setNodes(arrLdapTree);
                }
            }
        } catch (IOCException | LDAPException ex) {
            logger.error(ex);
            throw new LdapConfigDataException(ex);
        }

        return getLdapTree(ldapTree, targetDn, ldapServer);
    }


    @SuppressWarnings ("PMD.OnlyOneReturn")
    private LdapTree getLdapTree(LdapTree ldapTree, String targetDn, LdapServer ldapServer) throws LdapConfigDataException {
        int count = 0;
        LdapSearchResponse ldapSearchResponse;
        try {
            ldapSearchResponse = ldapServiceHelper.search(targetDn, "objectclass=*", SearchScope.ONE, ldapServer);
            Iterator<LdapSearchResultEntry> ldapSearchRseultIterator = ldapSearchResponse.iterator();
            if (ldapSearchResponse.size() > count) {
                while (ldapSearchRseultIterator.hasNext()) {
                    LdapTree ldapTreeTemp = new LdapTree();
                    LdapSearchResultEntry ldapSearchResultEntry = ldapSearchRseultIterator.next();
                    if (!ldapSearchResultEntry.getAttributes().isEmpty()) {
                        setAttributeMap(ldapTreeTemp, ldapSearchResultEntry.getAttributes(), null);
                    }
                    ldapTreeTemp.setTitle();
                    ldapTreeTemp.setFullyQualifiedName(ldapSearchResultEntry.getDistinguishedName());
                    ldapTreeTemp.setValue(ldapTreeTemp, ldapTreeTemp.getFullyQualifiedName());
                    LdapTree childLdapTree = new LdapTree();
                    childLdapTree.setTitle("");
                    ArrayList<LdapTree> arrLdapTree = new ArrayList<>();
                    arrLdapTree.add(childLdapTree);

                    ldapTreeTemp.setNodes(arrLdapTree);
                    ldapTree.addChildNode(ldapTreeTemp);
                    // getLdapTree(ldapTreeTemp,
                    // ldapSearchResultEntry.getDistinguishedName(),
                    // ldapServer);
                }
            }
            if (ldapTree.getTitle() == null) {
                return null;
            } else {
                return ldapTree;
            }
        } catch (LDAPException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }

    }


    @Override
    public boolean checkLdapConnection(String serverName) throws LdapConfigDataException {
        logger.info("Testing connection though java service " + serverName);
        boolean returnValue = false;
        LdapServer ldapServer;
        try {
            ldapServer = ldapServiceHelper.findServer(serverName);
            if (ldapServer != null) {
                returnValue = ldapServiceHelper.checkConnection(ldapServer);
            }
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }

        return returnValue;
    }


    @Override
    public String getUserSystemAdminLevel(String userId) throws LdapConfigDataException {
        try {
            return ldapServiceHelper.getUserSystemAdminLevel(userId);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }

    }


    @Override
    public List<String> getUserGroupRoles(String userId, String groupId, String domainId) throws LdapConfigDataException {
        try {
            return ldapServiceHelper.getUserGroupRoles(userId, groupId, domainId);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }

    }


    @Override
    public List<String> getUserDomainRoles(String userId, String domainId) throws LdapConfigDataException {
        try {
            return ldapServiceHelper.getUserDomainRoles(userId, domainId);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }

    }


    @Override
    public List<String> getUserManagedDomains(String userId) throws LdapConfigDataException {
        try {
            return ldapServiceHelper.getUserManagedDomains(userId);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }
    }


    @Override
    public List<String> getUserManagedGroups(String userId, String domainId) throws LdapConfigDataException {
        try {
            return ldapServiceHelper.getUserManagedGroups(userId, domainId);
        } catch (IOCException ex) {
            logger.error(ex);
            throw new LdapConfigDataException("Issue Occured while getLdapTree:", ex);
        }
    }


    @Override
    public String getServerIdentity(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        logger.debug("getServerIdentity" + connectionDetails);
        String domainHost = (String) connectionDetails.get("domainHost");
        Integer port = Integer.parseInt((String) connectionDetails.get("port"));
        String temp = new String();
        String connectionType = (String) connectionDetails.get("connectionType");
        LdapSslConnection connection;
        if (LdapConfigConstant.SSL.equalsIgnoreCase(connectionType)) {
            connection = new LdapSslConnection(domainHost, port, getSSLInfoWithInterceptor());
        } else {
            connection = new LdapTlsConnection(domainHost, port, getSSLInfoWithInterceptor());
        }
        try {
            connection.connect();
        } catch (LdapConnectionException ex) {

        }

        X509Certificate[] chain = interceptingTrustManager.getChain();
        interceptingTrustManager = new ICCInterceptingTrustManager();
        if (chain == null || chain.length == 0) {
            logger.error("No certs were returned from the server! exiting...");
            throw new LdapConfigDataException("Enter valid domainhost and port");
        }

        try {
            // We want to get the server identity from the top level cert.
            Pattern pattern = Pattern.compile("(?:cn|CN)=([^,]*)");
            Matcher matcher = pattern.matcher(chain[0].getSubjectX500Principal().getName());
            if (matcher.find()) {
                temp = matcher.group(1);
            } else {
                logger.error("Unable to find server identity from subject name");
            }
        } catch (Exception ex) {
            logger.error("Error while getting server identity: ", ex);
            throw new LdapConfigDataException("Enter valid domainhost and port", ex);
        }
        return temp;
    }


    private SslInfo getSSLInfoWithInterceptor() {
        SslInfo sslInfo = new SslInfo();
        sslInfo.setTrustManager(interceptingTrustManager);
        return sslInfo;
    }


    @Override
    public String getServerCertificate(Map<String, Object> obj) throws LdapConfigDataException {
        logger.debug("Inside getServerCertificate" + obj);
        String domainHost = (String) obj.get("domainHost");
        Integer port = Integer.parseInt((String) obj.get("port"));
        String storeLocation = (String) obj.get("storeLocation");
        String storePassword = (String) obj.get("storePassword");
        String connectionType = (String) obj.get("connectionType");
        String message = "Certificate retrieved successfully";
        LdapSslConnection connection;
        if (connectionType.equalsIgnoreCase(LdapConfigConstant.SSL)) {
            connection = new LdapSslConnection(domainHost, port, getSSLInfoWithInterceptor());
        } else {
            connection = new LdapTlsConnection(domainHost, port, getSSLInfoWithInterceptor());
        }

        try {
            connection.connect();
        } catch (LdapConnectionException ex) {

        }

        X509Certificate[] chain = interceptingTrustManager.getChain();
        interceptingTrustManager = new ICCInterceptingTrustManager();
        if (chain == null || chain.length == 0) {
            logger.error("No certs were returned from the server! exiting...");
            throw new LdapConfigDataException("Enter valid domainhost and port");
        }
        try {
            KeyStore ks = KeyStore.getInstance("jks");
            ks.load(null);

            // the last cert in the chain is the root cert.
            ks.setCertificateEntry("cert", chain[chain.length - 1]);
            ks.store(new FileOutputStream(storeLocation), storePassword.toCharArray());
            logger.info(storeLocation + "|" + storePassword);
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException ex) {
            logger.error("Error while getting server certificate: ", ex);
            message = ex.getMessage();
            throw new LdapConfigDataException(message, ex);
        }

        return message;
    }


    @Override
    public void setCurrentServer(String currentServer) {
        this.currentServer = currentServer;
    }

}
