
package com.mergehealthcare.icc.ldapconfig.web.ldap.utility;

import com.mergehealthcare.icc.ldapconfig.data.LdapConfigDataException;
import com.mergehealthcare.icc.ldapconfig.data.ldap.LdapTree;

import com.unboundid.ldap.sdk.SearchScope;

import icc.ldap.server.exception.LdapConnectionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class LdapServiceManager implements Cloneable {

    @Autowired
    @Qualifier (value = "ldapServiceImplJava")
    private ILdapService ldapService;

    @Autowired
    private LdapServiceFactory ldapServiceFactory;


    public ILdapService getLdapService() {
        return ldapService;
    }


    public boolean authenticateUser(String userName, String password) throws LdapConfigDataException {
        return ldapService.authenticateUser(userName, password);
    }


    public List<LdapTree> search(String targetDn, String filter, String serverName, SearchScope searchScope, List<String> attributeList)
                    throws LdapConfigDataException {
        return ldapService.search(targetDn, filter, serverName, searchScope, attributeList);
    }


    public LdapTree getLdapTree(String serverName, String targetDn) throws LdapConfigDataException {
        return ldapService.getLdapTree(serverName, targetDn);
    }


    public boolean checkLdapConnection(String serverName) throws LdapConfigDataException {
        ldapService.setCurrentServer(serverName);
        return ldapService.checkLdapConnection(serverName);
    }


    public String getUserSystemAdminLevel(String userId) throws LdapConfigDataException {
        return ldapService.getUserSystemAdminLevel(userId);

    }


    public List<String> getUserGroupRoles(String userId, String groupId, String domainId) throws LdapConfigDataException {
        return ldapService.getUserGroupRoles(userId, groupId, domainId);

    }


    public List<String> getUserDomainRoles(String userId, String domainId) throws LdapConfigDataException {
        return ldapService.getUserDomainRoles(userId, domainId);

    }


    public List<String> getUserManagedDomains(String userId) throws LdapConfigDataException {
        return ldapService.getUserManagedDomains(userId);

    }


    public List<String> getUserManagedGroups(String userId, String domainId) throws LdapConfigDataException {
        return ldapService.getUserManagedGroups(userId, domainId);
    }


    public String getServerIdentity(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        return ldapService.getServerIdentity(connectionDetails);
    }


    public String getServerCertificates(Map<String, Object> connectionDetails) throws LdapConfigDataException {
        return ldapService.getServerCertificate(connectionDetails);
    }
    
    public void setCurrentServer(String currentServer) {
        ldapService.setCurrentServer(currentServer);
    }


    /**
     * Gets the pltform specific service manager.
     *
     * @return the pltform specific service manager
     */
    public LdapServiceManager getPltformSpecificServiceManager() {
        try {
            LdapServiceManager ldapServiceManager = (LdapServiceManager) clone();
            ldapServiceManager.ldapService = ldapServiceFactory.getInstance();
            return ldapServiceManager;
        } catch (CloneNotSupportedException ex) {
            throw new LdapConnectionException("Clone not supported in getPltformSpecificServiceManager", ex);
        }
    }


    

}
