package com.mergehealthcare.icc.ldapconfig.web.validator.serverconnection;

import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.web.validator.ValidationHelper;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsJava;

import org.springframework.validation.Errors;

/**
 * The Class JavaSSLValidator.
 */
public final class JavaSSLValidator {

    /**
     * Instantiates a new java SSL validator.
     */
    private JavaSSLValidator() {
    }


    /**
     * Validate java SSL.
     *
     * @param sslOptionsJavaVm the ssl options java vm
     * @param errors the errors
     */
    public static void validateJavaSSL(SSLOptionsJava sslOptionsJavaVm, Errors errors) {
        validateClientCertificate(sslOptionsJavaVm, errors);
        validateServerIdentity(sslOptionsJavaVm, errors);
        validateServerCertificate(sslOptionsJavaVm, errors);
    }


    /**
     * Validate client certificate.
     *
     * @param sslOptionsJavaVm the ssl options java vm
     * @param errors the errors
     */
    private static void validateClientCertificate(SSLOptionsJava sslOptionsJavaVm, Errors errors) {
        boolean clientCertificateEnabled = sslOptionsJavaVm.isClientCertificateEnabled();
        if (clientCertificateEnabled) {
            String clientCertificatePath = sslOptionsJavaVm.getClientCertificatePath();
            ValidationHelper.rejectEmpty(clientCertificatePath, "sslOptionsJavaVm.clientCertificatePath",
                            "error.sslOptionsJavaVm.clientCertificatePath.required", errors);
        }
    }


    /**
     * Validate server identity.
     *
     * @param sslOptionsJavaVm the ssl options java vm
     * @param errors the errors
     */
    private static void validateServerIdentity(SSLOptionsJava sslOptionsJavaVm, Errors errors) {
        boolean serverIdentityEnabled = sslOptionsJavaVm.isServerIdentityEnabled();
        if (serverIdentityEnabled) {
            String serverCertificateIdentity = sslOptionsJavaVm.getServerCertificateIdentity();
            ValidationHelper.rejectEmpty(serverCertificateIdentity, "sslOptionsJavaVm.serverCertificateIdentity",
                            "error.sslOptionsJavaVm.serverCertificateIdentity.required", errors);
        }
    }


    /**
     * Validate server certificate.
     *
     * @param sslOptionsJavaVm the ssl options java vm
     * @param errors the errors
     */
    private static void validateServerCertificate(SSLOptionsJava sslOptionsJavaVm, Errors errors) {
        boolean serverCertificateEnabled = sslOptionsJavaVm.isServerCertificateEnabled();
        boolean serverKeystoreEnabled = sslOptionsJavaVm.isServerKeystoreEnabled();
        String certificatePathRegex = "([a-zA-Z]:)?(\\\\[a-zA-Z0-9_.-]+)+\\\\?.jks";
        String serverCertificatePath = sslOptionsJavaVm.getServerCertificatePath();

        if (serverCertificateEnabled && !serverKeystoreEnabled) {

            if (ObjectUtils.isNotNullOrEmpty(serverCertificatePath)) {
                if (!serverCertificatePath.matches(certificatePathRegex)) {
                    errors.rejectValue("sslOptionsJavaVm.serverCertificatePath", "error.sslOptionsJavaVm.serverCertificatePath.invalid");
                }
            }

            ValidationHelper.rejectEmpty(serverCertificatePath, "sslOptionsJavaVm.serverCertificatePath",
                            "error.sslOptionsJavaVm.serverCertificatePath.required", errors);
        }
    }
}
