/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.web.viewmodel.mapper;

import com.mergehealthcare.icc.ldapconfig.ICCEnvironmentConfig;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.mergehealthcare.icc.ldapconfig.data.ObjectFactory;
import com.mergehealthcare.icc.ldapconfig.data.ServerDetailsService;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AdvancedConnectionOptionsViewModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.AuthenticationMethod;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.ConnectionDetailsModel;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.Platform;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptions;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsJava;
import com.mergehealthcare.icc.ldapconfig.web.viewmodel.SSLOptionsNet;

import icc.ldap.server.configuration.CertificatePath;
import icc.ldap.server.configuration.CertificateStore;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnection;
import icc.ldap.server.configuration.SslConnection;

import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author sarikam2
 */
@Component
public class ConnectionModelMapper {

    private static final Logger logger = LogService.getLogger(ConnectionModelMapper.class);

    @Autowired
    private ServerDetailsService serverDetailsService;

    @Autowired
    private ObjectFactory objectFactory;

    @Autowired
    private AdvancedConnectionModelMapper advancedConnectionModelMapper;

    @Autowired
    private ICCEnvironmentConfig iCCEnvironmentConfig;

    private static final int PROTOCOL_VERSION = 3;

    private static final int PAGE_SIZE = 699;

    private static final int HOP_LIMIT = 32;

    private static final int PING_LIMIT = 4;

    private static final int SIZE_LIMIT = 700;


    /**
     * Save SSL options java.
     *
     * @param sslOptionsJavaVm the ssl options java vm
     * @param sslConnection the ssl connection
     */
    private void saveSSLOptionsJava(SSLOptionsJava sslOptionsJavaVm, SslConnection sslConnection) {
        if (sslOptionsJavaVm.isClientCertificateEnabled()) {
            CertificatePath clientCertificatePath = objectFactory.createCertificatePath();
            clientCertificatePath.setPath(uploadCertificate(sslOptionsJavaVm));
            clientCertificatePath.setPassword(sslOptionsJavaVm.getClientCertificatePassword());
            sslConnection.setClientCertificatePath(clientCertificatePath);
        }
        if (sslOptionsJavaVm.isServerIdentityEnabled()) {
            sslConnection.setLdapIdentity(sslOptionsJavaVm.getServerCertificateIdentity());
        }
        if (sslOptionsJavaVm.isServerCertificateEnabled()) {
            sslConnection.setVerifyServerCertificate(true);
            if (!sslOptionsJavaVm.isServerKeystoreEnabled()) {
                CertificatePath serverCertificatePath = objectFactory.createCertificatePath();
                serverCertificatePath.setPath(sslOptionsJavaVm.getServerCertificatePath());
                serverCertificatePath.setPassword(sslOptionsJavaVm.getServerCertificatePassword());
                sslConnection.setServerCertificatePath(serverCertificatePath);
            }
        }
    }


    /**
     * Find connection model by server name.
     *
     * @param serverName the server name
     * @return the connection details model
     */
    public ConnectionDetailsModel findConnectionModelByServerName(String serverName) {
        ConnectionDetailsModel connectionModel = BeanUtils.instantiateClass(ConnectionDetailsModel.class);
        try {
            ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
            ServerConnection serverConnection = serverConfiguration.getServerConnection();
            SslConnection sslConnection = serverConnection.getSslConnection();
            String platform = iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform");

            if (!ObjectUtils.isNull(serverConnection.getDefaultPort())) {
                connectionModel.setDefaultPort(serverConnection.getDefaultPort());
                connectionModel.setDomainHost(serverConnection.getDomainHost());
                connectionModel.setFullyQualifiedDomainName(serverConnection.isFullyQualifiedDomainName());
                ObjectUtils.checkIsNullAndAssign(sslConnection, connectionModel);
                if (!serverConnection.getType().equalsIgnoreCase("Basic")
                                && (platform.equals(Platform.Net.toString()) && !ObjectUtils.isNull(sslConnection))) {
                    // if (platform.equals(Platform.Net.toString()) &&
                    // !ObjectUtils.isNull(sslConnection)) {
                    connectionNetModel(sslConnection, connectionModel);

                } else if (!serverConnection.getType().equalsIgnoreCase("Basic") && (platform.equals(Platform.Java.toString()))) {
                    connectionJavaModel(sslConnection, connectionModel);

                }
                connectionModel.setConnectionType(serverConnection.getType());
            }
            logger.debug("Getting Advanced Connection Options for... " + serverName);
            AdvancedConnectionOptionsViewModel advancedConnectionOptionsViewModel = advancedConnectionModelMapper
                            .findAdvanceConnectionModelByServerName(serverName);
            logger.debug("Advanced Connection Options  = " + advancedConnectionOptionsViewModel);
            if (ObjectUtils.isNull(advancedConnectionOptionsViewModel.getPageSize())) {
                if (platform.equals(Platform.Java.toString())) {
                    connectionModel.setAdvancedConnectionVm(getDefaultJavaData());
                } else {
                    connectionModel.setAdvancedConnectionVm(getDefaultNetData());
                }
            } else {
                connectionModel.setAdvancedConnectionOption(true);
                connectionModel.setAdvancedConnectionVm(advancedConnectionOptionsViewModel);
            }

            logger.debug("connectionViewModel = " + connectionModel);
        } catch (Exception ex) {
            logger.error("Reversed Mapping Exception occured from LdapConfiguration to ServerDetailsModel", ex);
        }
        return connectionModel;
    }


    private void connectionJavaModel(SslConnection sslConnection, ConnectionDetailsModel connectionModel) {
        CertificatePath clientCertificatPath;
        CertificatePath serverCertificatePath;
        clientCertificatPath = sslConnection.getClientCertificatePath();
        serverCertificatePath = sslConnection.getServerCertificatePath();
        if (ObjectUtils.isNotNullOrEmpty(clientCertificatPath.getPath())) {
            connectionModel.getSslOptionsJavaVm().setClientCertificateEnabled(true);
            connectionModel.getSslOptionsJavaVm().setClientCertificatePassword(clientCertificatPath.getPassword());
            connectionModel.getSslOptionsJavaVm().setClientCertificatePath(clientCertificatPath.getPath());
        }
        if (sslConnection.getLdapIdentity() != null && !sslConnection.getLdapIdentity().isEmpty()) {
            connectionModel.getSslOptionsJavaVm().setServerIdentityEnabled(true);
            connectionModel.getSslOptionsJavaVm().setServerCertificateIdentity(sslConnection.getLdapIdentity());
        }
        if (sslConnection.isVerifyServerCertificate()) {
            if (ObjectUtils.isNotNullOrEmpty(serverCertificatePath.getPath())) {
                connectionModel.getSslOptionsJavaVm().setServerKeystoreEnabled(false);
                connectionModel.getSslOptionsJavaVm().setServerCertificateEnabled(true);
                connectionModel.getSslOptionsJavaVm().setServerCertificatePath(serverCertificatePath.getPath());
                connectionModel.getSslOptionsJavaVm().setServerCertificatePassword(serverCertificatePath.getPassword());
            } else {
                connectionModel.getSslOptionsJavaVm().setServerKeystoreEnabled(true);
                connectionModel.getSslOptionsJavaVm().setServerCertificateEnabled(true);
            }
        } else {
            connectionModel.getSslOptionsJavaVm().setServerCertificateEnabled(false);
        }
    }


    private void connectionNetModel(SslConnection sslConnection, ConnectionDetailsModel connectionModel) {
        CertificatePath clientCertificatPath;
        CertificatePath serverCertificatePath;
        CertificateStore clientCertificatStore;
        clientCertificatPath = sslConnection.getClientCertificatePath();
        serverCertificatePath = sslConnection.getServerCertificatePath();
        clientCertificatStore = sslConnection.getClientCertificateStore();
        if (ObjectUtils.isNotNullOrEmpty(clientCertificatPath.getPath())) {
            connectionModel.getSslOptionsNetVm().setClientCertificateEnabled(true);
            connectionModel.getSslOptionsNetVm().setClientCertificatePassword(clientCertificatPath.getPassword());
            connectionModel.getSslOptionsNetVm().setClientCertificatePath(clientCertificatPath.getPath());
            connectionModel.getSslOptionsNetVm().setClientCertificateStoreEnabled(false);
        }
        if (!clientCertificatStore.getCn().isEmpty()) {
            connectionModel.getSslOptionsNetVm().setClientCertificateEnabled(true);
            connectionModel.getSslOptionsNetVm().setCn(clientCertificatStore.getCn());
            connectionModel.getSslOptionsNetVm().setStoreLocation(clientCertificatStore.getStoreLocation().toString());
            connectionModel.getSslOptionsNetVm().setStoreName(clientCertificatStore.getStoreName().toString());
            connectionModel.getSslOptionsNetVm().setClientCertificateStoreEnabled(true);
        }
        if (sslConnection.getLdapIdentity() != null && !sslConnection.getLdapIdentity().isEmpty()) {
            connectionModel.getSslOptionsNetVm().setServerIdentityEnabled(true);
            connectionModel.getSslOptionsNetVm().setServerCertificateIdentity(sslConnection.getLdapIdentity());
        }
        if (sslConnection.isVerifyServerCertificate()) {
            if (ObjectUtils.isNotNullOrEmpty(serverCertificatePath.getPath())) {
                connectionModel.getSslOptionsNetVm().setServerCertificateEnabled(true);
                connectionModel.getSslOptionsNetVm().setServerCertificatePath(serverCertificatePath.getPath());
                connectionModel.getSslOptionsNetVm().setServerCertificatePassword(serverCertificatePath.getPassword());
                connectionModel.getSslOptionsNetVm().setServerCertificateStoreEnabled(false);
            } else {
                connectionModel.getSslOptionsNetVm().setServerCertificateEnabled(true);
                connectionModel.getSslOptionsNetVm().setServerCertificateStoreEnabled(true);
            }
        } else {
            connectionModel.getSslOptionsNetVm().setServerCertificateEnabled(false);
        }
    }


    /**
     * Save connection details.
     *
     * @param connectionModel the connection model
     * @param serverName the server name
     * @throws Exception the exception
     */
    public void saveConnectionDetails(ConnectionDetailsModel connectionModel, String serverName) throws Exception {
        ServerConfiguration serverConfiguration = serverDetailsService.fetchSaveConfiguration(serverName);
        ServerConnection serverConnection = serverConfiguration.getServerConnection();
        if (serverConnection == null) {
            serverConnection = objectFactory.createServerConnection();
        }
        serverConnection.setDefaultPort(connectionModel.getDefaultPort());
        serverConnection.setDomainHost(connectionModel.getDomainHost());
        serverConnection.setFullyQualifiedDomainName(Boolean.toString(connectionModel.isFullyQualifiedDomainName()));
        serverConnection.setType(connectionModel.getConnectionType());

        SslConnection sslConnection = objectFactory.createSslConnection();
        if (!connectionModel.getConnectionType().equalsIgnoreCase("Basic")) {
            String platform = iCCEnvironmentConfig.environment.getProperty("icc.configuration.platform");
            if (platform.equals(Platform.Java.toString())) {
                saveSSLOptionsJava(connectionModel.getSslOptionsJavaVm(), sslConnection);
            } else {
                saveSSLOptionsNet(connectionModel.getSslOptionsNetVm(), sslConnection);
            }
        }
        serverConnection.setSslConnection(sslConnection);
        serverConfiguration.setServerConnection(serverConnection);
        advancedConnectionModelMapper.saveAdvanceServerConfiguration(serverConfiguration, serverConnection, connectionModel, serverName);
        serverDetailsService.modify(serverConfiguration);

        String temp = iCCEnvironmentConfig.getPlatform();
        Platform platform = Platform.getPlatform(temp);
        if (platform == Platform.Net) {
            serverDetailsService.saveTestConnectionConfig(serverName);
        }
    }


    /**
     * Save SSL options net.
     *
     * @param sslOptionsNetVm the ssl options net vm
     * @param sslConnection the ssl connection
     */
    private void saveSSLOptionsNet(SSLOptionsNet sslOptionsNetVm, SslConnection sslConnection) {
        if (sslOptionsNetVm.isClientCertificateEnabled()) {
            if (sslOptionsNetVm.isClientCertificateStoreEnabled()) {
                CertificateStore clientCertificatestore = objectFactory.createCertificateStore();
                clientCertificatestore.setCn(sslOptionsNetVm.getCn());
                clientCertificatestore.setStoreLocation(CertificateStore.StoreLocation.valueOf(sslOptionsNetVm.getStoreLocation()));
                clientCertificatestore.setStoreName(CertificateStore.StoreName.valueOf(sslOptionsNetVm.getStoreName()));
                sslConnection.setClientCertificateStore(clientCertificatestore);
            } else {
                CertificatePath clientCertificatePath = objectFactory.createCertificatePath();
                // clientCertificatePath.setPath(sslOptionsNetVm.getClientCertificatePath());
                clientCertificatePath.setPath(uploadCertificate(sslOptionsNetVm));
                clientCertificatePath.setPassword(sslOptionsNetVm.getClientCertificatePassword());
                sslConnection.setClientCertificatePath(clientCertificatePath);
            }
        }
        if (sslOptionsNetVm.isServerIdentityEnabled()) {
            sslConnection.setLdapIdentity(sslOptionsNetVm.getServerCertificateIdentity());
        }
        if (sslOptionsNetVm.isServerCertificateEnabled()) {
            sslConnection.setVerifyServerCertificate(true);
            if (!sslOptionsNetVm.isServerCertificateStoreEnabled()) {
                CertificatePath serverCertificatePath = objectFactory.createCertificatePath();
                serverCertificatePath.setPath(sslOptionsNetVm.getServerCertificatePath());
                serverCertificatePath.setPassword(sslOptionsNetVm.getServerCertificatePassword());
                sslConnection.setServerCertificatePath(serverCertificatePath);
            }
        }
    }


    public AdvancedConnectionOptionsViewModel getDefaultNetData() {
        AdvancedConnectionOptionsViewModel advancedConnection = BeanUtils.instantiate(AdvancedConnectionOptionsViewModel.class);
        advancedConnection.setProtocolVersion(PROTOCOL_VERSION);
        advancedConnection.setAutoReconnect(true);
        advancedConnection.setAutoBind(false);
        advancedConnection.setTcpKeepAlive(false);
        advancedConnection.setType("paged");
        advancedConnection.setReferralHopLimit(HOP_LIMIT);
        advancedConnection.setPingKeepAliveTimeout("00:02:00");
        advancedConnection.setPingWaitTimeout("00:00:02");
        advancedConnection.setPingLimit(PING_LIMIT);
        advancedConnection.setConnectionTimeOut("00:00:30");
        advancedConnection.setSizeLimit(20);
        advancedConnection.setTimeLimit("00:00:01");
        advancedConnection.setPageSize(3);
        advancedConnection.setAuthenticationMethod(AuthenticationMethod.Basic.name());

        return advancedConnection;
    }


    public AdvancedConnectionOptionsViewModel getDefaultJavaData() {
        AdvancedConnectionOptionsViewModel advancedConnection = BeanUtils.instantiate(AdvancedConnectionOptionsViewModel.class);
        advancedConnection.setAutoReconnect(true);
        advancedConnection.setReferralHopLimit(HOP_LIMIT);
        advancedConnection.setConnectionTimeOut("00:00:30");
        advancedConnection.setSizeLimit(SIZE_LIMIT);
        advancedConnection.setTimeLimit("00:00:00");
        advancedConnection.setPageSize(PAGE_SIZE);
        return advancedConnection;
    }


    public String uploadCertificate(SSLOptions sslOptions) {

        MultipartFile file = sslOptions.getUploadCertificate();
        String clientCertificatePath = null;
        BufferedOutputStream stream;
        if (sslOptions instanceof SSLOptionsJava) {
            SSLOptionsJava sslOptionJava = (SSLOptionsJava) sslOptions;
            clientCertificatePath = sslOptionJava.getClientCertificatePath();
        } else if (sslOptions instanceof SSLOptionsNet) {
            SSLOptionsNet sslOptionNet = (SSLOptionsNet) sslOptions;
            clientCertificatePath = sslOptionNet.getClientCertificatePath();
        }
        String rootPath = iCCEnvironmentConfig.environment.getProperty("certificate.location");
        File checkFile = new File(clientCertificatePath);
        if (!checkFile.exists()) {
            byte[] bytes;
            try {
                bytes = file.getBytes();

                File dir = new File(rootPath);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                clientCertificatePath = dir.getPath() + File.separator + file.getOriginalFilename();
                File serverFile = new File(clientCertificatePath);
                stream = new BufferedOutputStream(new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();
                logger.info("Server File Location=" + serverFile.getAbsolutePath());

            } catch (IOException ex) {
                logger.error("Issues while uploading certificate to server" + ex);
            }
        }
        return clientCertificatePath;
    }

}
