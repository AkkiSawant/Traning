
package com.mergehealthcare.icc.ldapconfig.common.utils;

import org.apache.log4j.Logger;

public class LogService {

  private static Logger logger = getLogger(LogService.class);


  public static Logger getLogger(Class className) {
    Logger classLogger = null;
    try {
      classLogger = Logger.getLogger(className);
    } catch (Exception e) {
      logger.error("There was an error creating the logger.", e);
    }
    return classLogger;
  }

}
