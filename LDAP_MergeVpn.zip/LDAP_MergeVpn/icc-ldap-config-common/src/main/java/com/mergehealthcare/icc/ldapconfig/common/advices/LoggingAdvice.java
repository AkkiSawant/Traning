/*
 *
 */

package com.mergehealthcare.icc.ldapconfig.common.advices;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/*
 * @author nithin
 */
@Aspect
@Component
@SuppressWarnings ({ "PMD.UncommentedEmptyMethodBody" })
public class LoggingAdvice {

    private static final Logger logger = Logger.getLogger(LoggingAdvice.class);


    @Pointcut ("execution(* com.mergehealthcare.icc.ldapconfig.web..*.*.*(..))")
    private void allPublicMethods() {
        // It is used in below teo methods
    }


    @Before ("allPublicMethods()")
    public void logBefore(JoinPoint joinPoint) throws Throwable {
        logger.debug("** Entering method: " + joinPoint.getSignature().toShortString());
    }


    @After ("allPublicMethods()")
    public void logAfter(JoinPoint joinPoint) throws Throwable {
        logger.debug("** Leaving method: " + joinPoint.getSignature().toShortString());
    }
}
