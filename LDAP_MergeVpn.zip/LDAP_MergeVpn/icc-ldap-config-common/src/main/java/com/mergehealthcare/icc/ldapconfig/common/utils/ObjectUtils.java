package com.mergehealthcare.icc.ldapconfig.common.utils;

import org.springframework.beans.BeanUtils;

import java.util.Collection;
import java.util.Iterator;

public final class ObjectUtils {

  /*
   * PMS: private constructor
   */
  private ObjectUtils() {
  }


  public static boolean isNull(Object obj) {
    return obj == null;
  }


  /**
   * Check is null and assign.
   *
   * @param source the source
   * @param target the target
   */
  public static void checkIsNullAndAssign(Object source, Object target) {
    if (!isNull(source) && !isNull(target)) {
      BeanUtils.copyProperties(source, target);
    }
  }


  public static boolean isNullOrEmpty(String source) {
    return null == source || "".equals(source) || "null".equals(source);
  }


  public static boolean isNotNullOrEmpty(String source) {
    return !isNullOrEmpty(source);
  }


  public static Object assignEmptyIfNull(String source) {
    return isNullOrEmpty(source) ? "" : source;
  }


  public static String removeEnd(String str, String remove) {
    String retValue = str;
    if ((isNotNullOrEmpty(str) && isNotNullOrEmpty(remove)) && (str.endsWith(remove))) {
      retValue = str.substring(0, str.length() - remove.length());
    }
    return retValue;
  }


  public static String join(Collection collection, String separator) {
    String retValue = "";
    if (collection != null) {
      retValue = join(collection.iterator(), separator);
    }
    return retValue;
  }


  public static String toString(Object obj) {
    return obj == null ? "" : obj.toString();
  }


  public static String join(Iterator iterator, String separator) {
    String retValue = "";
    // handle null, zero and one elements before building a buffer
    if (iterator != null) {

      Object first = iterator.next();
      if (iterator.hasNext()) {

        // two or more elements
        StringBuilder buf = new StringBuilder(256); // Java default is 16, probably too small
        if (first != null) {
          buf.append(first);
        }

        while (iterator.hasNext()) {
          if (separator != null) {
            buf.append(separator);
          }
          Object obj = iterator.next();
          if (obj != null) {
            buf.append(obj);
          }
        }

        retValue = buf.toString();
      } else {
        retValue = ObjectUtils.toString(first);
      }
    }
    return retValue;
  }

}
