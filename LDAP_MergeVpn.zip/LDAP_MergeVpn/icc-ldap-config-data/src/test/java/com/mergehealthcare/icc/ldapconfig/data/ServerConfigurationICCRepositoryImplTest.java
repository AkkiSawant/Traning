/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.data;

import com.mergehealthcare.icc.ldapconfig.ICCLdapDataConfigTest;

import icc.ldap.server.configuration.ServerConfiguration;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.io.IOException;

/*
 * @author sarikam2
 */
@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = ICCLdapDataConfigTest.class,
    loader = AnnotationConfigContextLoader.class)
public class ServerConfigurationICCRepositoryImplTest {

  @Autowired
  private ServerConfigurationICCRepositoryImpl serverConfigurationICCRepository;


  @Test
  public void addServerConfigurationTest() throws LdapConfigDataException, IOException {
    ServerConfiguration serverConfiguration = new ServerConfiguration();
    serverConfiguration.setServerName("LDAPTest");
    serverConfigurationICCRepository.addServerConfiguration(serverConfiguration);

  }


  public void testDeleteServer() throws Exception {
    serverConfigurationICCRepository.deleteServerConfiguration("LDAPTest");

  }


  @After
  public void tear() throws Exception {
    testDeleteServer();
  }

}
