package com.mergehealthcare.icc.ldapconfig.data.ldap.test.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.ldap.IccLdapServiceHelper;

import icc.base.exception.IOCException;
import icc.ldap.testtool.utils.ContextInitializer;

import org.apache.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.util.List;
import org.junit.Test;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = IccLdapServiceHelperTest.class, loader = AnnotationConfigContextLoader.class)
public class IccLdapServiceHelperTest {

    private static String configFile = "ldapConfig_AD.xml";

    private IccLdapServiceHelper iccLdapServiceHelper = new IccLdapServiceHelper();

    private static final Logger logger = LogService.getLogger(IccLdapServiceHelperTest.class);


    @BeforeClass
    public static void setUp() {
        try {
            ContextInitializer.loadLdapEngine(configFile);
        } catch (IOCException ex) {
            logger.error("Exception in setUp method ", ex);
        }
    }


    @Test
    public void testAuthenticateUserValidcredetentials() {
        String login = "user2";
        String password = "Cedara99";
        boolean isAuthenticated = false;
        IOCException exception = null;
        try {
            isAuthenticated = iccLdapServiceHelper.authenticateUser(login, password);
        } catch (IOCException ex) {
            logger.error("Exception in testAuthenticateUserValidcredetentials method ", ex);
        }
        assertNull(exception);
        assertTrue(isAuthenticated);
    }


    @Test
    public void testAuthenticateUserInvalidcredetentials() {
        logger.info("Executing testAuthenticateUserInvalidcredetentials method");
        String login = "user2";
        String password = "Cedara102";
        boolean isAuthenticated = true;
        IOCException exception = null;
        try {
            isAuthenticated = iccLdapServiceHelper.authenticateUser(login, password);
        } catch (IOCException ex) {
            logger.error("Exception in testAuthenticateUserInvalidcredetentials method ", ex);
        }
        assertNull(exception);
        assertFalse(isAuthenticated);
    }


    @Test
    public void testGetUserSystemAdminLevelSuperAdmin() {
        logger.info("Executing testGetUserSystemAdminLevelSuperAdmin method");
        String userId = "user7";
        String systemAdminLevel = null;
        IOCException exception = null;
        try {
            systemAdminLevel = iccLdapServiceHelper.getUserSystemAdminLevel(userId);
        } catch (IOCException ex) {
            logger.error("Exception in testGetUserSystemAdminLevelSuperAdmin method ", ex);
        }
        assertNull(exception);
        assertEquals("SuperAdmin", systemAdminLevel);

    }


    @Test
    public void testGetUserSystemAdminLevelUser() throws IOCException {
        String userId = "user2";
        String systemAdminLevel = iccLdapServiceHelper.getUserSystemAdminLevel(userId);
        assertEquals("User", systemAdminLevel);
    }


    @Test
    public void testGetUserGroupRoles() {
        logger.info("Executing testGetUserGroupRoles method");
        String userId = "user3";
        String groupId = "Group1";
        String domainId = "SDomainHG";
        List<String> userGrpRoles = null;
        IOCException exception = null;
        try {
            userGrpRoles = iccLdapServiceHelper.getUserGroupRoles(userId, groupId, domainId);
        } catch (IOCException ex) {
            logger.error("Exception in testGetUserGroupRoles method ", ex);
        }
        assertNull(exception);
        assertNotNull(userGrpRoles);
    }


    @Test
    public void testGetUserDomainRoles() {
        logger.info("Executing testGetUserDomainRoles method");
        String userId = "user2";
        String domainId = "SDomainHG";
        List<String> userDomainRoles = null;
        IOCException exception = null;
        try {
            userDomainRoles = iccLdapServiceHelper.getUserDomainRoles(userId, domainId);
        } catch (IOCException ex) {
            logger.error("Exception in testGetUserDomainRoles method ", ex);
        }
        assertNull(exception);
        assertNotNull(userDomainRoles);
    }


    @Test
    public void testGetUserManagedDomains() {
        logger.info("Executing testGetUserManagedDomains method");
        String userId = "user2";
        List<String> userManagedDomains = null;
        IOCException exception = null;
        try {
            userManagedDomains = iccLdapServiceHelper.getUserManagedDomains(userId);
        } catch (IOCException ex) {
            logger.error("Exception in testGetUserManagedDomains method ", ex);
        }
        assertNull(exception);
        assertNotNull(userManagedDomains);
    }


    @Test
    public void testGetUserManagedGroups() {
        logger.info("Executing testGetUserManagedGroups method");
        String userId = "user3";
        String domainId = "SDomainHG";
        List<String> userManagedGrps = null;
        IOCException exception = null;
        try {
            userManagedGrps = iccLdapServiceHelper.getUserManagedGroups(userId, domainId);
        } catch (IOCException ex) {
            ex.printStackTrace();
        }
        assertNull(exception);
        assertNotNull(userManagedGrps);
    }

}
