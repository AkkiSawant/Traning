/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig;

import com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationICCRepositoryImpl;
import com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationICCRepositoryUtility;
import com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository;
import com.mergehealthcare.icc.ldapconfig.data.convertor.XMLICCConverter;

import icc.ldap.server.configuration.LdapServerManagerConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;

/*
 * @author sarikam2
 */
@Configuration
@PropertySource ("classpath:ldap.properties")
public class ICCLdapDataConfigTest {

  public static Environment environment;


  /*
   * Gets the XMLICC converter.
   * @return the XMLICC converter
   * @throws JAXBException the JAXB exception
   */
  @Bean
  public XMLICCConverter getXMLICCConverter() throws JAXBException {
    XMLICCConverter handler = new XMLICCConverter();
    handler.setMarshaller(getXMLICCMarshaller());
    handler.setUnmarshaller(getXMLICCUnmarshaller());
    return handler;
  }


  /*
   * Gets the JAXB context.
   * @return the JAXB context
   * @throws JAXBException the JAXB exception
   */
  @Bean
  public JAXBContext getJAXBContext() throws JAXBException {
    return JAXBContext.newInstance(LdapServerManagerConfiguration.class);
  }


  /*
   * Gets the XMLICC marshaller.
   * @return the XMLICC marshaller
   * @throws PropertyException the property exception
   * @throws JAXBException the JAXB exception
   */
  @Bean
  public Marshaller getXMLICCMarshaller() throws PropertyException, JAXBException {
    Marshaller marshal = getJAXBContext().createMarshaller();
    marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    marshal.setProperty(Marshaller.JAXB_FRAGMENT, true);
    return marshal;
  }


  /*
   * Gets the XMLICC unmarshaller.
   * @return the XMLICC unmarshaller
   * @throws PropertyException the property exception
   * @throws JAXBException the JAXB exception
   */
  @Bean
  public Unmarshaller getXMLICCUnmarshaller() throws PropertyException, JAXBException {
    Unmarshaller unMarshal = getJAXBContext().createUnmarshaller();
    return unMarshal;
  }


  /*
   * Gets the server configuration repository.
   * @return the server configuration repository
   */
  @Bean
  public ServerConfigurationRepository getServerConfigurationRepository() {
    return new ServerConfigurationICCRepositoryImpl();

  }


  /*
   * Gets the server configuration ICC repository utility.
   * @return the server configuration ICC repository utility
   */
  @Bean
  public ServerConfigurationICCRepositoryUtility getServerConfigurationICCRepositoryUtility() {
    return new ServerConfigurationICCRepositoryUtility();
  }

}
