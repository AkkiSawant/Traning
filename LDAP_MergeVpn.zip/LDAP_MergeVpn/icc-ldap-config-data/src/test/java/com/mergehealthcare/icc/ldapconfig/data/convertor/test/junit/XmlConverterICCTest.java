/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mergehealthcare.icc.ldapconfig.data.convertor.test.junit;

import com.mergehealthcare.icc.ldapconfig.ICCLdapDataConfig;

import icc.ldap.server.configuration.Attribute;
import icc.ldap.server.configuration.Attributes;
import icc.ldap.server.configuration.LdapConfiguration;
import icc.ldap.server.configuration.LdapServerManagerConfiguration;
import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.OperationCommand;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnection;
import icc.ldap.server.configuration.ServerConnectionOptions;
import icc.ldap.server.configuration.ServerDetails;
import icc.ldap.server.configuration.ServerManagerConfiguration;
import icc.ldap.server.configuration.SiteDomains;
import icc.ldap.server.configuration.UserOverrideMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

/**
 * The Class XmlConverterICCTest.
 */
/*
 * @author sarikam2
 */
@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (classes = ICCLdapDataConfig.class, loader = AnnotationConfigContextLoader.class)
public class XmlConverterICCTest {

    /*
     * Marshal server config.
     */
    /**
     * Marshal server config.
     */
    // @Test
    public void marshalServerConfig() {
        try {

            ServerConfiguration serverConfiguration = new ServerConfiguration();
            serverConfiguration.setServerName("LDAPICC");
            List<Object> serverConfigurationList = new ArrayList<Object>();
            serverConfigurationList.add(serverConfiguration);

            File xml = new File("C:\\configuration\\path\\XMLICC.xml");

            // configuration.setServerConfiguration(serverConfigurationList);
            JAXBContext context;

            context = JAXBContext.newInstance(LdapConfiguration.class);

            Marshaller marshal = context.createMarshaller();
            marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            LdapServerManagerConfiguration configuration = new LdapServerManagerConfiguration();
            marshal.marshal(configuration, xml);
        } catch (JAXBException ex) {
            ex.printStackTrace();
        }

    }


    /**
     * Marshal ldap server manager config.
     */
    @Test
    public void marshalLdapServerManagerConfig() {
        try {
            ServerConfiguration serverConfiguration = new ServerConfiguration();
            serverConfiguration.setServerName("LDAP");
            ServerConnection serverConnection = new ServerConnection();

            ServerConnectionOptions serverConnectionOptions = new ServerConnectionOptions();
            serverConnectionOptions.setReferralChasingOptions(ServerConnectionOptions.ReferralChasingOptions.All);
            serverConnection.setServerConnectionOptions(prepareServerConnection(serverConnectionOptions));
            serverConfiguration.setServerConnection(serverConnection);
            OperationCommand operationCommand = new OperationCommand();
            operationCommand.setTimeLimit(new ServerConnectionOptions.TimeSpanDuration());
            Attributes attributes = new Attributes();
            attributes.setAttribute(new HashMap<String, Attribute>());
            operationCommand.setAttributes(attributes);
            serverConfiguration.setOperationCommand(operationCommand);

            ServerDetails serverDetails = new ServerDetails();
            SiteDomains siteDomains = new SiteDomains();
            siteDomains.getSiteDomain();
            serverDetails.setSiteDomains(siteDomains);

            serverConfiguration.setServerDetails(serverDetails);
            UserOverrideMap userOverrideMap = new UserOverrideMap();
            userOverrideMap.getUserOverrideDetail();
            serverConfiguration.setUserOverrideMap(userOverrideMap);

            Model model = new Model();
            Locators locators = new Locators();
            locators.getLocator();
            model.setLocators(locators);

            Mappers mappers = new Mappers();
            mappers.getMapper();
            model.setMappers(mappers);
            serverConfiguration.setModel(model);

            LdapConfiguration ldapConfiguration = new LdapConfiguration();
            ldapConfiguration.getServerConfiguration().put("LDAP", serverConfiguration);

            LdapConfiguration.LdapConfigurationAdapter ldapConfigurationAdapter = new LdapConfiguration.LdapConfigurationAdapter();
            LdapServerManagerConfiguration ldapConfiguration1 = ldapConfigurationAdapter.marshal(ldapConfiguration);

            JAXBContext context = JAXBContext.newInstance(LdapServerManagerConfiguration.class);
            File xml = new File("C:\\configuration\\path\\ldapConfig.xml");
            Marshaller marshal = context.createMarshaller();
            marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshal.marshal(ldapConfiguration1, xml);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }


    /**
     * Un marshal ldap server manager config.
     */
    @Test
    public void unMarshalLdapServerManagerConfig() {
        if (System.getenv("ICC_LDAP_CONFIG_DIR") != null) {
            LdapConfiguration ldapConfiguration = new ServerManagerConfiguration().getGetLdapConfiguration();
            ldapConfiguration.getServerConfiguration();
        }
    }


    /**
     * Prepare server connection.
     *
     * @param serverConnectionOptions the server connection options
     * @return the server connection options
     */
    private ServerConnectionOptions prepareServerConnection(ServerConnectionOptions serverConnectionOptions) {
        serverConnectionOptions.setAuthenticationMethod(ServerConnectionOptions.AuthType.Basic);
        serverConnectionOptions.setConnectionTimeOut(new ServerConnectionOptions.TimeSpanDuration());
        serverConnectionOptions.setPingKeepAliveTimeout(new ServerConnectionOptions.TimeSpanDuration());
        serverConnectionOptions.setPingWaitTimeout(new ServerConnectionOptions.TimeSpanDuration());
        serverConnectionOptions.setReferralChasingOptions(ServerConnectionOptions.ReferralChasingOptions.All);
        return serverConnectionOptions;
    }

}
