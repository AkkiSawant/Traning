/**
 *
 */

package com.mergehealthcare.icc.ldapconfig.data;

/**
 * The Class LdapConfigDataException.
 *
 * @author nithin
 */
public class LdapConfigDataException extends Exception {

  /*
   *
   */
  private static final long serialVersionUID = -1902286071449326270L;


  /*
   * Instantiates a new ldap config data exception.
   * @param message the message
   * @param cause the cause
   */
  public LdapConfigDataException(String message, Throwable cause) {
    super(message, cause);
  }


  /*
   * Instantiates a new ldap config data exception.
   * @param message the message
   */
  public LdapConfigDataException(String message) {
    super(message);
  }
  
  public LdapConfigDataException(Exception ex) {
      super(ex);
  }

}
