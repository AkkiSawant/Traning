package com.mergehealthcare.icc.ldapconfig;

import com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationICCRepositoryUtility;
import com.mergehealthcare.icc.ldapconfig.data.convertor.XMLICCConverter;

import icc.core.security.session.ITokenSecuritySessionManager;
import icc.core.security.session.IUserCredentialsSessionManager;
import icc.core.security.session.SamlSecuritySessionManager;
import icc.core.security.session.UserCredentialsSessionManager;
import icc.core.session.SingleSessionStateManager;
import icc.ldap.server.configuration.LdapServerManagerConfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;

/**
 * The Class ICCLdapDataConfig.
 */
@Configuration
public class ICCLdapDataConfig {

    @Bean
    public ICCLdapDataConfig iCCLdapDataConfig() {
        return new ICCLdapDataConfig();
    }


    /**
     * Gets the XMLICC converter.
     *
     * @return the XMLICC converter
     * @throws JAXBException the JAXB exception
     */
    @Bean
    public XMLICCConverter getXMLICCConverter() throws JAXBException {
        XMLICCConverter handler = new XMLICCConverter();
        handler.setMarshaller(getXMLICCMarshaller());
        handler.setUnmarshaller(getXMLICCUnmarshaller());
        return handler;
    }


    /**
     * Gets the XMLICC marshaller.
     *
     * @return the XMLICC marshaller
     * @throws PropertyException the property exception
     * @throws JAXBException the JAXB exception
     */
    @Bean
    public Marshaller getXMLICCMarshaller() throws PropertyException, JAXBException {
        Marshaller marshal = getJAXBContext().createMarshaller();
        marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshal.setProperty(Marshaller.JAXB_FRAGMENT, true);
        return marshal;
    }


    /**
     * Gets the XMLICC unmarshaller.
     *
     * @return the XMLICC unmarshaller
     * @throws PropertyException the property exception
     * @throws JAXBException the JAXB exception
     */
    @Bean
    public Unmarshaller getXMLICCUnmarshaller() throws PropertyException, JAXBException {
        return getJAXBContext().createUnmarshaller();
    }


    /**
     * Gets the JAXB context.
     *
     * @return the JAXB context
     * @throws JAXBException the JAXB exception
     */
    @Bean
    public JAXBContext getJAXBContext() throws JAXBException {
        return JAXBContext.newInstance(LdapServerManagerConfiguration.class);
    }


    /**
     * Gets the server configuration ICC repository utility.
     *
     * @return the server configuration ICC repository utility
     */
    @Bean
    public ServerConfigurationICCRepositoryUtility getServerConfigurationICCRepositoryUtility() {
        return new ServerConfigurationICCRepositoryUtility();
    }


    @Bean
    public ITokenSecuritySessionManager getSecuritySessionManagerBean() {
        SamlSecuritySessionManager sessionManager = new SamlSecuritySessionManager(15, 60);
        sessionManager.setSessionStateManager(getSessionstateManagerBean());
        return sessionManager;
    }


    @Bean
    public SingleSessionStateManager getSessionstateManagerBean() {
        return new SingleSessionStateManager();
    }


    @Bean
    public IUserCredentialsSessionManager getSessionManager() {
        return new UserCredentialsSessionManager("urn:merge:icc:services:all");
    }

}
