
package com.mergehealthcare.icc.ldapconfig.data;

import java.io.IOException;
import java.util.List;
import java.util.Set;

/**
 * The Interface ServerConfigurationRepository.
 */
public interface ServerConfigurationRepository {

  /**
   * Adds the server configuration.
   *
   * @param serverConfiguration the server configuration
   * @throws LdapConfigDataException the ldap config data exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  void addServerConfiguration(Object serverConfiguration)
      throws LdapConfigDataException,
        IOException;


  /**
   * Update server configuration.
   *
   * @param serverConfiguration the server configuration
   * @throws LdapConfigDataException the ldap config data exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  void updateServerConfiguration(Object serverConfiguration)
      throws LdapConfigDataException,
        IOException;


  /**
   * Gets the server configuration.
   *
   * @param serverName the server name
   * @return the server configuration
   * @throws LdapConfigDataException the ldap config data exception
   */
  Object getServerConfiguration(String serverName) throws LdapConfigDataException;


  /**
   * Delete server configuration.
   *
   * @param serverName the server name
   * @throws LdapConfigDataException the ldap config data exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  void deleteServerConfiguration(String serverName) throws LdapConfigDataException, IOException;


  List<Object> getAllServerConfiguration() throws LdapConfigDataException;


  /**
   * List server names.
   *
   * @return the sets the
   */
  Set<String> listServerNames();


  /**
   * Save server configuration.
   *
   * @param serverName the server name
   * @throws LdapConfigDataException the ldap config data exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  void saveServerConfiguration(String serverName) throws LdapConfigDataException, IOException;

  
  void saveTestConnectionConfiguration(String serverName)  throws LdapConfigDataException, IOException;
  
}
