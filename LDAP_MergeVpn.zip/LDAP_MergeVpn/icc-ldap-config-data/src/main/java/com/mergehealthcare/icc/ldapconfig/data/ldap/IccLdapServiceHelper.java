
package com.mergehealthcare.icc.ldapconfig.data.ldap;

import com.merge.icc.services.management.user.membership.IUserRoleMembership;
import com.merge.icc.services.management.user.membership.datacontract.UserDomainRolesRequest;
import com.merge.icc.services.management.user.membership.datacontract.UserDomainRolesResponse;
import com.merge.icc.services.management.user.membership.datacontract.UserGroupRolesRequest;
import com.merge.icc.services.management.user.membership.datacontract.UserGroupRolesResponse;
import com.merge.icc.services.management.user.membership.datacontract.UserManagedDomainsRequest;
import com.merge.icc.services.management.user.membership.datacontract.UserManagedDomainsResponse;
import com.merge.icc.services.management.user.membership.datacontract.UserManagedGroupsRequest;
import com.merge.icc.services.management.user.membership.datacontract.UserManagedGroupsResponse;
import com.merge.icc.services.management.user.membership.datacontract.UserSystemAdminLevelRequest;
import com.merge.icc.services.management.user.membership.datacontract.UserSystemAdminLevelResponse;
import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.SearchRequest;
import com.unboundid.ldap.sdk.SearchScope;

import icc.base.exception.IOCException;
import icc.base.ioc.ObjectFactory;
import icc.ldap.server.ILdapServer;
import icc.ldap.server.ILdapServerManager;
import icc.ldap.server.ILdapUserCredentials;
import icc.ldap.server.LdapSearchRequest;
import icc.ldap.server.LdapSearchResponse;
import icc.ldap.server.LdapServer;
import icc.ldap.server.LdapServerManager;
import icc.ldap.server.LdapUserCredentials;
import icc.ldap.server.connection.ILdapConnection;
import icc.ldap.server.connection.NetworkCredential;
import icc.ldap.server.query.AuthenticateRequest;
import icc.ldap.server.query.IAuthenticateRequest;
import icc.ldap.server.query.IAuthenticateResponse;
import icc.ldap.server.query.ILdapQuerySearchEngine;
import icc.ldap.server.query.LdapQuerySearchEngine;
import icc.ldap.testtool.utils.ContextInitializer;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * The Class IccLdapServiceHelper.
 */
@Component
public class IccLdapServiceHelper {

    private static ArrayList<LdapServer> servers;

    private static final Logger logger = LogService.getLogger(IccLdapServiceHelper.class);

    public static final String AD_SERVER_TYPE = "AD";


    /**
     * Gets the user role membership.
     *
     * @return the user role membership
     * @throws IOCException the IOC exception
     */
    public IUserRoleMembership getUserRoleMembership() throws IOCException {
        try {
            return ContextInitializer.getUserRoleMembership();
        } catch (IOCException ex) {
            logger.error("Unable to load User role memebership", ex);
            throw ex;
        }
    }


    /**
     * Authenticate user.
     *
     * @param login the login
     * @param password the password
     * @return true, if successful
     * @throws IOCException the IOC exception
     */
    public boolean authenticateUser(String login, String password) throws IOCException {
        try {
            ILdapServerManager serverManager = ObjectFactory.getInstance().resolve(ILdapServerManager.class);
            IAuthenticateRequest userAuthRequest = new AuthenticateRequest();
            userAuthRequest.setUserCredentials(new LdapUserCredentials(login, password));
            IAuthenticateResponse response = serverManager.authenticateUser(userAuthRequest);
            return response.isUserAuthenticated();
        } catch (IOCException ex) {
            logger.error(String.format("Error while authenticating user, where user=%s  %n", login), ex);
            throw ex;
        }
    }


    /**
     * Gets the user system admin level.
     *
     * @param userId the user id
     * @return the user system admin level
     * @throws IOCException the IOC exception
     */
    public String getUserSystemAdminLevel(String userId) throws IOCException {
        try {
            UserSystemAdminLevelRequest sysrequest = new UserSystemAdminLevelRequest(userId);
            UserSystemAdminLevelResponse systemAdminLevelResponse = getUserRoleMembership().getUserSystemAdminLevel(sysrequest);
            return systemAdminLevelResponse.getUserSystemLevel();
        } catch (IOCException ex) {
            logger.error(String.format("Error while getting user SystemAdmin Level, where user=%s  %n", userId), ex);
            throw ex;
        }

    }


    /**
     * Gets the user group roles.
     *
     * @param userId the user id
     * @param groupId the group id
     * @param domainId the domain id
     * @return the user group roles
     * @throws IOCException the IOC exception
     */
    public List<String> getUserGroupRoles(String userId, String groupId, String domainId) throws IOCException {
        List<String> rolesList = new ArrayList<String>();
        try {
            IUserRoleMembership userRoleMembership = getUserRoleMembership();
            UserGroupRolesRequest request = new UserGroupRolesRequest(userId, groupId, domainId);
            UserGroupRolesResponse result = userRoleMembership.getUserGroupRoles(request);
            if (result.getRolesIdentifier() != null && !result.getRolesIdentifier().getRoleId().isEmpty()) {
                rolesList = result.getRolesIdentifier().getRoleId();
            }

        } catch (IOCException ex) {
            logger.error(String.format("Error while getting user group roles, where user=%s, domain=%s, group=%s  %n", userId, domainId,
                            groupId), ex);
            throw ex;
        }
        return rolesList;
    }


    /**
     * Gets the user domain roles.
     *
     * @param userId the user id
     * @param domainId the domain id
     * @return the user domain roles
     * @throws IOCException the IOC exception
     */
    public List<String> getUserDomainRoles(String userId, String domainId) throws IOCException {
        List<String> rolesList = new ArrayList<String>();
        try {
            IUserRoleMembership userRoleMembership = getUserRoleMembership();
            UserDomainRolesRequest request = new UserDomainRolesRequest(userId, domainId);
            UserDomainRolesResponse result = userRoleMembership.getUserDomainRoles(request);
            if (result.getRolesIdentifier() != null && !result.getRolesIdentifier().getRoleId().isEmpty()) {
                rolesList = result.getRolesIdentifier().getRoleId();
            }
        } catch (IOCException ex) {
            logger.error(String.format("Error while getting user domain roles, where user=%s, domain=%s,  %n", userId, domainId), ex);
            throw ex;
        }
        return rolesList;
    }


    /**
     * Gets the user managed domains.
     *
     * @param userId the user id
     * @return the user managed domains
     * @throws IOCException the IOC exception
     */
    public List<String> getUserManagedDomains(String userId) throws IOCException {
        List<String> domainList = new ArrayList<String>();
        try {
            IUserRoleMembership userRoleMembership = getUserRoleMembership();
            UserManagedDomainsRequest request = new UserManagedDomainsRequest(userId);
            UserManagedDomainsResponse result = userRoleMembership.getUserManagedDomains(request);
            if (result.getDomainsIdentifier() != null && !result.getDomainsIdentifier().getDomainId().isEmpty()) {
                domainList = result.getDomainsIdentifier().getDomainId();
            }

        } catch (IOCException ex) {
            logger.error(String.format("Error while getting domains where user is administator, where user=%s  %n", userId), ex);
            throw ex;
        }
        return domainList;
    }


    /**
     * Gets the user managed groups.
     *
     * @param userId the user id
     * @param domainId the domain id
     * @return the user managed groups
     * @throws IOCException the IOC exception
     */
    public List<String> getUserManagedGroups(String userId, String domainId) throws IOCException {
        List<String> groupList = new ArrayList<String>();
        try {
            IUserRoleMembership userRoleMembership = getUserRoleMembership();
            UserManagedGroupsRequest request = new UserManagedGroupsRequest(userId, domainId);
            UserManagedGroupsResponse result = userRoleMembership.getUserManagedGroups(request);
            if (result.getGroups() != null && !result.getGroups().getGroupId().isEmpty()) {
                groupList = result.getGroups().getGroupId();
            }
        } catch (IOCException ex) {
            logger.error(String.format("Error while getting groups where user is administator, where user=%s, domain=%s  %n", userId, domainId),
                            ex);
            throw ex;

        }
        return groupList;
    }


    /**
     * Search.
     *
     * @param targetDn the target dn
     * @param filter the filter
     * @param scope the scope
     * @param ldapServer the ldap server
     * @return the ldap search response
     * @throws LDAPException the LDAP exception
     */
    public LdapSearchResponse search(String targetDn, String filter, SearchScope scope, LdapServer ldapServer) throws LDAPException {
        ILdapConnection connection = null;
        ILdapConnection ldapConnection = null;
        LdapSearchResponse ldapSearchResponse = null;
        try {
            ILdapUserCredentials serviceCredentials = ldapServer.getServiceCredentials();
            NetworkCredential connectionCredentials = new NetworkCredential(serviceCredentials.getUserId(), serviceCredentials.getPassword(),
                            serviceCredentials.getNetworkDomain());
            connection = ldapServer.getLdapConnection();
            if (connection != null) {
                ldapConnection = connection.getNewConnection();
            }
            if (ldapConnection != null) {
                if (AD_SERVER_TYPE.equals(ldapServer.getServerType())) {
                    ldapConnection.setDomainAsPrefix(true);
                }
                ldapConnection.setConnectionCredentials(connectionCredentials);

                SearchRequest searchRequest = new SearchRequest(targetDn, scope, filter, SearchRequest.ALL_USER_ATTRIBUTES);
                LdapSearchRequest ldapSearchRequest = new LdapSearchRequest(searchRequest);
                ldapSearchResponse = ldapServer.getLdapCommandOperation().executeQuery(ldapSearchRequest, ldapConnection);
            }
        } catch (LDAPException ex) {
            logger.error(String.format("Error while searching from ldap, where targetDn=%s, filter=%s  %n", targetDn, filter), ex);
            throw ex;
        } finally {
            if (ldapConnection != null) {
                ldapConnection.disconnect();
            }
        }
        return ldapSearchResponse;

    }


    /**
     * Load servers.
     *
     * @throws IOCException the IOC exception
     */
    private void loadServers() throws IOCException {
        try {
            servers = new ArrayList<LdapServer>();
            LdapQuerySearchEngine querySearchEngine = (LdapQuerySearchEngine) ObjectFactory.getInstance().resolve(ILdapQuerySearchEngine.class);
            ILdapServerManager serverManager = querySearchEngine.getServerManager();
            List<ILdapServer> ldapServers = ((LdapServerManager) serverManager).getServers();
            for (ILdapServer server : ldapServers) {
                servers.add((LdapServer) server);
            }
        } catch (IOCException ex) {
            logger.error("Error while loading ldap servers from config file %n", ex);
            throw ex;
        }
    }


    /**
     * Find server.
     *
     * @param serverId the server id
     * @return the ldap server
     * @throws IOCException the IOC exception
     */
    public LdapServer findServer(String serverId) throws IOCException {
        LdapServer ldapServer = null;
        try {
            loadServers();
            for (LdapServer server : servers) {
                if (server.getServerId().equals(serverId)) {
                    ldapServer = server;
                    break;
                }
            }
            if (ObjectUtils.isNull(ldapServer)) {
                throw new IOCException();
            }

        } catch (IOCException ex) {
            logger.error(String.format("Error while finding ldap server from config file, where server name=%s  %n", serverId), ex);
            throw ex;
        }
        return ldapServer;
    }


    /**
     * Check connection.
     *
     * @param ldapServer the ldap server
     * @return true, if successful
     */
    public boolean checkConnection(LdapServer ldapServer) {

        ILdapUserCredentials serviceCredentials = ldapServer.getServiceCredentials();
        NetworkCredential connectionCredentials = new NetworkCredential(serviceCredentials.getUserId(), serviceCredentials.getPassword(),
                        serviceCredentials.getNetworkDomain());

        ILdapConnection ldapConnection = ldapServer.getLdapConnection();
        if (AD_SERVER_TYPE.equals(ldapServer.getServerType())) {
            ldapConnection.setDomainAsPrefix(true);
        }
        ldapConnection.getNewConnection().connect(connectionCredentials);
        return true;

    }

}
