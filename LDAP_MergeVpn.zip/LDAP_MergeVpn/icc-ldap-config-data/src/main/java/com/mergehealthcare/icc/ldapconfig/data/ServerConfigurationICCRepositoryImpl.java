
package com.mergehealthcare.icc.ldapconfig.data;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.data.convertor.XMLICCConverter;

import icc.ldap.server.configuration.LdapConfiguration;
import icc.ldap.server.configuration.LdapServerManagerConfiguration;
import icc.ldap.server.configuration.Locators;
import icc.ldap.server.configuration.Mappers;
import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.ServerConfiguration;

/**
 * The Class ServerConfigurationICCRepositoryImpl.
 */
@Repository
public class ServerConfigurationICCRepositoryImpl implements ServerConfigurationRepository {

    private static final Logger logger = LogService.getLogger(ServerConfigurationICCRepositoryImpl.class);

    @Autowired
    private XMLICCConverter xmlIccConverter;

    private final Map<String, Integer> serverConfigIndexMap = new ConcurrentHashMap<>();

    @Autowired
    private Environment environment;

    // This object cannot Autowired.
    private final ObjectFactory objectFactory = new ObjectFactory();

    @Autowired
    private ServerConfigurationICCRepositoryUtility serverConfigurationICCRepositoryUtility;


    /**
     * Save.
     *
     * @param ldapServerConfiguration the ldap server configuration
     * @param fileName the file name
     * @throws LdapConfigDataException the ldap config data exception
     */
    private void save(LdapConfiguration ldapServerConfiguration, String fileName) throws LdapConfigDataException {
        logger.info("Saving LDAP Server configuration to file...");

        LdapServerManagerConfiguration ldapServerManagerConfiguration;

        try {
            logger.debug("Saveing configuration into " + fileName);
            LdapConfiguration.LdapConfigurationAdapter ldapConfigurationAdapter = new LdapConfiguration.LdapConfigurationAdapter();
            ldapServerManagerConfiguration = ldapConfigurationAdapter.marshal(ldapServerConfiguration);

            this.xmlIccConverter.marshal(fileName, ldapServerManagerConfiguration);

        } catch (IOException ex) {
            logger.error("Error while marshalling server configuration: ", ex);
            throw new LdapConfigDataException("Marshalling error!", ex);
        } catch (JAXBException ex) {
            logger.error("Error while marshalling server configuration: ", ex);
            throw new LdapConfigDataException("Marshalling error!", ex);
        } catch (Exception ex) {
            logger.error("Error while marshalling server configuration: ", ex);
            throw new LdapConfigDataException("Marshalling error!", ex);
        }

    }


    /**
     * Load.
     *
     * @return the ldap configuration
     * @throws LdapConfigDataException the ldap config data exception
     */
    private LdapConfiguration load() throws LdapConfigDataException {
        logger.debug("Loading server configurations...");

        LdapConfiguration ldapConfig = null;
        try {
            logger.debug("Reading configuration from file...");
            ldapConfig = retrieve();
            logger.debug("Successfully read all the configuration available!");
        } catch (LdapConfigDataException ex) {
            logger.info("No configuration exists.  Creating a new configuration...");
            ldapConfig = objectFactory.createLdapConfiguration();

            logger.info("Saving the new configuration to file...");
            // save(ldapConfig);
            logger.info("Configuration is saved to file!");
        }
        return ldapConfig;
    }


    /**
     * Retrieve.
     *
     * @return the ldap configuration
     * @throws LdapConfigDataException the ldap config data exception
     */
    private LdapConfiguration retrieve() throws LdapConfigDataException {
        logger.info("Reading LDAP Server configuration...");
        LdapConfiguration ldapConfiguration = objectFactory.createLdapConfiguration();
        try {
            String filename = getFileName(this);
            logger.debug("Unmarshalling file: " + filename);
            File file = new File(filename);
            if (file.exists() && file.length() > 0) {
                // ldapConfiguration = prepareLdapConfig(filename,
                // ldapConfiguration);
                LdapServerManagerConfiguration ldapServerManagerConfig = (LdapServerManagerConfiguration) this.xmlIccConverter
                                .unmarshal(filename);
                if (ldapServerManagerConfig != null) {
                    LdapConfiguration.LdapConfigurationAdapter ldapConfigurationAdapter = new LdapConfiguration.LdapConfigurationAdapter();
                    ldapConfiguration = ldapConfigurationAdapter.unmarshal(ldapServerManagerConfig);
                }
                logger.info("File unmarshalled successfully!");
                boolean isValidServerConfig = (ldapServerManagerConfig.getServerConfiguration() != null
                                && !ldapServerManagerConfig.getServerConfiguration().isEmpty());
                boolean isValidConfigIndexMap = (this.serverConfigIndexMap != null && this.serverConfigIndexMap.isEmpty());
                if (isValidServerConfig && isValidConfigIndexMap) {
                    normalizeIndices(ldapServerManagerConfig.getServerConfiguration(), this);
                }
                // Check whether all default values have their data
                for (Map.Entry<String, ServerConfiguration> entry : ldapConfiguration.getServerConfiguration().entrySet()) {
                    entry.setValue(serverConfigurationICCRepositoryUtility.createInternalObjects(entry.getValue()));
                }
            }

        } catch (IOException ex) {
            logger.error("Error while retrieving server configuration", ex);
            throw new LdapConfigDataException("Unable to retrieve server configuration", ex);
        } catch (JAXBException ex) {
            logger.error("Error while retrieving server configuration", ex);
            throw new LdapConfigDataException("Unable to retrieve server configuration", ex);
        } catch (Exception ex) {
            logger.error("Error while retrieving server configuration", ex);
            throw new LdapConfigDataException("Unable to retrieve server configuration", ex);
        }
        return ldapConfiguration;
    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * addServerConfiguration
     * (java.lang.Object)
     */
    @Override
    public void addServerConfiguration(Object objectConfig) throws LdapConfigDataException, IOException {
        ServerConfiguration serverConfiguration = (ServerConfiguration) objectConfig;
        LdapConfiguration ldapConfiguration = objectFactory.createLdapConfiguration();

        try {
            logger.debug("Attempting to load server configurtion from file...");
            ldapConfiguration = load();

        } catch (LdapConfigDataException fnfe) {
            logger.warn("Could not load configuration, creating a new one. Root case is: " + fnfe.getMessage());
        }
        logger.info("Building a server configuration...");

        ldapConfiguration.getServerConfiguration().put(serverConfiguration.getServerName(),
                        serverConfigurationICCRepositoryUtility.createInternalObjects(serverConfiguration));
        logger.info("Saving Server configuration " + serverConfiguration);

        save(ldapConfiguration, getFileName(this));
        logger.info("Server configuration is saved!");

    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * updateServerConfiguration
     * (java.lang.Object)
     */
    @Override
    public void updateServerConfiguration(Object objectConfig) throws LdapConfigDataException, IOException {
        ServerConfiguration newserverConfig = (ServerConfiguration) objectConfig;

        LdapConfiguration ldapConfiguration = load();
        ldapConfiguration.getServerConfiguration().put(newserverConfig.getServerName(),
                        serverConfigurationICCRepositoryUtility.createInternalObjects(newserverConfig));

        save(ldapConfiguration, getFileName(this));
        logger.info("Server modification information is saved!");
    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * getServerConfiguration
     * (java.lang.String)
     */
    @Override
    public ServerConfiguration getServerConfiguration(String serverName) throws LdapConfigDataException {
        logger.info("Fetching LDAP server configuration...");

        LdapConfiguration ldapConfig = null;
        List<ServerConfiguration> serverConfigurations = null;
        ServerConfiguration serverConfigurationToModify = null;

        try {
            logger.debug("Loading server configuration...");
            ldapConfig = load();
            logger.info("Server configuration is loaded: " + ldapConfig);
        } catch (LdapConfigDataException fe) {
            logger.info("Server configuration not found! Recreating fresh configuration...");
            ldapConfig = retrieve();
            logger.info("Server configuration reloaded: " + ldapConfig);
        }

        serverConfigurations = new ArrayList<>(ldapConfig.getServerConfiguration().values());
        logger.debug("Server configuration read from file: " + serverConfigurations);

        if (ldapConfig.getServerConfiguration().containsKey(serverName)) {
            serverConfigurationToModify = ldapConfig.getServerConfiguration(serverName);
        } else {
            throw new LdapConfigDataException("Server Not Found =" + serverName);
        }

        logger.debug("Server configuration to modify: " + serverConfigurationToModify);

        return serverConfigurationToModify;
    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * deleteServerConfiguration
     * (java.lang.String)
     */
    @Override
    public void deleteServerConfiguration(String serverName) throws LdapConfigDataException, IOException {
        LdapConfiguration ldapConfiguration = null;

        try {
            ldapConfiguration = load();
            ldapConfiguration.getServerConfiguration().remove(serverName);
            save(ldapConfiguration, getFileName(this));
        } catch (LdapConfigDataException ex) {
            logger.warn("Unable to remove from the configuration!", ex);
            throw new LdapConfigDataException("Unable to remove configuration", ex);
        }
    }


    @Override
    public List<Object> getAllServerConfiguration() throws LdapConfigDataException {
        LdapConfiguration ldapConfiguration = load();

        if (ldapConfiguration.getServerConfiguration() == null) {
            throw new LdapConfigDataException("No Server found.");
        }
        return new ArrayList<Object>(ldapConfiguration.getServerConfiguration().values());
    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * listServerNames()
     */
    @Override
    public Set<String> listServerNames() {
        LdapConfiguration ldapConfiguration = null;
        try {
            ldapConfiguration = load();
        } catch (LdapConfigDataException ex) {
            logger.warn("Unable to remove from the configuration!", ex);
        }
        return ldapConfiguration.getServerConfiguration().keySet();
    }


    /**
     * Normalize indices.
     *
     * @param serverConfigurations the server configurations
     * @param serverConfigurationICCRepositoryImpl the server configuration ICC repository impl
     */
    private void normalizeIndices(List<ServerConfiguration> serverConfigurations,
                    ServerConfigurationICCRepositoryImpl serverConfigurationICCRepositoryImpl) {
        int index = 0;
        logger.debug("Normalizing the indices after add/remove operation...");
        if (!serverConfigurationICCRepositoryImpl.serverConfigIndexMap.isEmpty()) {
            logger.info("Cleaning up in memory data store...");
            serverConfigurationICCRepositoryImpl.serverConfigIndexMap.clear();
            for (ServerConfiguration serverConfiguration : serverConfigurations) {
                String serverName = serverConfiguration.getServerName();
                serverConfigurationICCRepositoryImpl.serverConfigIndexMap.put(serverName, index);
                index++;
                logger.debug("Added a server configuration to the store: " + serverName);
            }
        }
        logger.debug("Reindex data " + serverConfigurationICCRepositoryImpl.serverConfigIndexMap);
    }


    /**
     * Gets the file name.
     *
     * @param serverConfigurationICCRepositoryImpl the server configuration ICC repository impl
     * @return the file name
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public String getFileName(ServerConfigurationICCRepositoryImpl serverConfigurationICCRepositoryImpl) throws IOException {
        String filePath = environment.getProperty("icc.configuration.path");
        File folder = new File(filePath);
        if (!folder.isDirectory()) {
            logger.info("Folder not found!");
            logger.info("Creating folder at this location " + filePath);
            boolean status = folder.mkdir();
            if (status) {
                logger.info("Folder created successfully at this location " + filePath);
            } else {
                logger.error("Error in creating folder at this location " + filePath);
                throw new IOException("Error while creating folder");
            }
        }
        String fileName = environment.getProperty("icc.configuration.filename");
        String fileExt = environment.getProperty("icc.configuration.filext");
        return filePath + fileName + fileExt;
    }


    /**
     * Gets the temp file name.
     *
     * @param serverName the server name
     * @param serverConfigurationICCRepositoryImpl the server configuration ICC repository impl
     * @return the temp file name
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public String getTempFileName(String serverName, ServerConfigurationICCRepositoryImpl serverConfigurationICCRepositoryImpl)
                    throws IOException {
        String filePath = environment.getProperty("icc.configuration.temp.path");
        File folder = new File(filePath);
        if (!folder.isDirectory()) {
            logger.info("Folder not found!");
            logger.info("Creating folder at this location " + filePath);
            boolean status = folder.mkdir();
            if (status) {
                logger.info("Folder created successfully at this location " + filePath);
            } else {
                logger.error("Error in creating folder at this location " + filePath);
                throw new IOException("Error while creating folder");
            }
        }
        String fileExt = environment.getProperty("icc.configuration.temp.filext");
        return filePath + serverName + fileExt;
    }


    /*
     * (non-Javadoc)
     * @see
     * com.mergehealthcare.icc.ldapconfig.data.ServerConfigurationRepository#
     * saveServerConfiguration
     * (java.lang.String)
     */
    @Override
    public void saveServerConfiguration(String serverName) throws LdapConfigDataException, IOException {
        ServerConfiguration serverConfiguration = getServerConfiguration(serverName);
        LdapConfiguration ldapConfiguration = objectFactory.createLdapConfiguration();

        ldapConfiguration.getServerConfiguration().put(serverConfiguration.getServerName(),
                        serverConfigurationICCRepositoryUtility.createInternalObjects(serverConfiguration));
        logger.info("Saving Server configuration " + serverConfiguration);

        save(ldapConfiguration, getTempFileName(serverName, this));
        logger.info("Server configuration is saved!");
    }
    
    @Override
    public void saveTestConnectionConfiguration(String serverName) throws LdapConfigDataException, IOException {
        logger.info("Creating testConnection Configuration " + serverName);
        
        String suffix = environment.getProperty("icc.configuration.testconnection.file_suffix");
        String filePath = environment.getProperty("icc.configuration.path");
        String fileExt = environment.getProperty("icc.configuration.filext");
        
        File dir = new File(filePath);
        if(!dir.exists()) {
            dir.mkdir();
        }

        ServerConfiguration serverConfiguration = getServerConfiguration(serverName);
        LdapConfiguration ldapConfiguration = objectFactory.createLdapConfiguration();

        ldapConfiguration.getServerConfiguration().put(
                        serverConfiguration.getServerName(),
                        serverConfigurationICCRepositoryUtility.createInternalObjects(serverConfiguration));

        ServerConfiguration serverConfig = ldapConfiguration.getServerConfiguration().get(serverName);
        Model model = serverConfig.getModel();
        
        model.setRootDistinguishedName("");
        model.setType("");

        Locators locators =  model.getLocators();
        locators.getLocator().clear();

        Mappers mappers =  model.getMappers();
        mappers.getMapper().clear();
        
        save(ldapConfiguration, filePath+suffix+fileExt);
        logger.info("Saving Server configuration For Test Connection " + serverConfiguration);      
    }

}
