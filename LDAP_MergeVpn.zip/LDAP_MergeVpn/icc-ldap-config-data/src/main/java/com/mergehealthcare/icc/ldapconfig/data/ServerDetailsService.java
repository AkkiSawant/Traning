
package com.mergehealthcare.icc.ldapconfig.data;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import icc.ldap.server.configuration.ServerConfiguration;

/**
 * The Class ServerDetailsService.
 */
@Service
public class ServerDetailsService {

    private static final Logger logger = Logger.getLogger(ServerDetailsService.class);

    @Autowired
    private ServerConfigurationRepository serverConfigurationRepository;


    /**
     * Adds the.
     *
     * @param newserverConfig the newserver config
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void add(ServerConfiguration newserverConfig) throws LdapConfigDataException, IOException {
        serverConfigurationRepository.addServerConfiguration(newserverConfig);
    }


    /**
     * Load all server names.
     *
     * @return the list
     * @throws LdapConfigDataException the ldap config data exception
     */
    @SuppressWarnings ({ "unchecked", "rawtypes" })
    public List<ServerConfiguration> loadAllServerNames() throws LdapConfigDataException {
        logger.info("Load All Server Names ....");
        return (List) serverConfigurationRepository.getAllServerConfiguration();
    }


    /**
     * Removes the.
     *
     * @param serverName the server name
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void remove(String serverName) throws LdapConfigDataException, IOException {
        logger.info("Removing ServerConfiguration for " + serverName);
        serverConfigurationRepository.deleteServerConfiguration(serverName);
    }


    /**
     * Modify.
     *
     * @param newserverConfig the newserver config
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void modify(ServerConfiguration newserverConfig) throws LdapConfigDataException, IOException {
        logger.info("Modifying Server Configuration... " + newserverConfig);
        serverConfigurationRepository.updateServerConfiguration(newserverConfig);
    }


    /**
     * List server names.
     *
     * @return the sets the
     */
    public Set<String> listServerNames() {
        logger.info("Listing server Names.. ");
        return serverConfigurationRepository.listServerNames();
    }


    /**
     * Fetch save configuration.
     *
     * @param serverName the server name
     * @return the server configuration
     * @throws LdapConfigDataException the ldap config data exception
     */
    public ServerConfiguration fetchSaveConfiguration(String serverName) throws LdapConfigDataException {
        logger.info("Retriveing server Information for... " + serverName);
        return (ServerConfiguration) serverConfigurationRepository.getServerConfiguration(serverName);
    }


    /**
     * Enable server.
     *
     * @param serverName the server name
     * @param enableServer the enable server
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void enableServer(String serverName, boolean enableServer) throws LdapConfigDataException, IOException {
        logger.info("Enable flag for server " + serverName + ", enableServer = " + enableServer);
        ServerConfiguration serconfig = (ServerConfiguration) serverConfigurationRepository.getServerConfiguration(serverName);
        if (serconfig != null && serconfig.getServerDetails() != null) {
            serconfig.getServerDetails().setEnable(Boolean.toString(enableServer));
        }
        serverConfigurationRepository.updateServerConfiguration(serconfig);
        logger.info("Succesffully updated flag");
    }


    /**
     * Save selected configuration.
     *
     * @param serverName the server name
     * @throws LdapConfigDataException the ldap config data exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void saveSelectedConfiguration(String serverName) throws LdapConfigDataException, IOException {
        serverConfigurationRepository.saveServerConfiguration(serverName);
    }
    
    
    public void saveTestConnectionConfig(String serverName) throws LdapConfigDataException, IOException {
        serverConfigurationRepository.saveTestConnectionConfiguration(serverName);
    }

}
