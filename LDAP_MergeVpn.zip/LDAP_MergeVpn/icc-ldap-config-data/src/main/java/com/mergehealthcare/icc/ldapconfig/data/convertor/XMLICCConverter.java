
package com.mergehealthcare.icc.ldapconfig.data.convertor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;

/**
 * The Class XMLICCConverter.
 */
public class XMLICCConverter {

  private static final Logger logger = LogService.getLogger(XMLICCConverter.class);

  private Marshaller marshaller;

  private Unmarshaller unmarshaller;


  public void setMarshaller(Marshaller marshaller) {
    this.marshaller = marshaller;
  }


  public void setUnmarshaller(Unmarshaller unmarshaller) {
    this.unmarshaller = unmarshaller;
  }


  /**
   * Do Marshaling from object to XML file.
   *
   * @param fileName the file name
   * @param graph the graph
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws JAXBException the JAXB exception
   */
  public void marshal(String fileName, Object graph) throws IOException, JAXBException {
    FileOutputStream fos = null;
    try {
      logger.info("Opening file: " + fileName);
      fos = new FileOutputStream(fileName);
      marshaller.marshal(graph, fos);

    } catch (FileNotFoundException fnfe) {
      logger.error("File not found: " + fileName);
      throw new IOException(fnfe);

    } catch (JAXBException ex) {
      logger.error("Error while Marshalling XML: " + fileName);
      throw ex;
    } finally {
      if (fos != null) {
        logger.info("Closing file: " + fileName);
        fos.close();
      }
    }
  }


  /**
   * Unmarshal.
   *
   * @param fileName the file name
   * @return the object
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws JAXBException the JAXB exception
   */
  public Object unmarshal(String fileName) throws IOException, JAXBException {
    FileInputStream fis = null;

    try {
      logger.info("Opening file: " + fileName);
      fis = new FileInputStream(fileName);
      return this.unmarshaller.unmarshal(new StreamSource(fis));

    } catch (FileNotFoundException fnfe) {
      logger.error("File not found: " + fileName);
      throw new IOException(fnfe);

    } finally {
      if (fis != null) {
        logger.info("Closing file: " + fileName);
        fis.close();
      }
    }
  }

}
