
package com.mergehealthcare.icc.ldapconfig.data.ldap;

import java.io.Serializable;
import java.util.List;

/**
 * The Class LdapTreeAttributeNode.
 */
public class LdapTreeAttributeNode implements Serializable {

  private static final long serialVersionUID = 7032697460492137820L;

  private String ldapKey;

  private List<String> attributes;


  /**
   * Instantiates a new ldap tree attribute node.
   *
   * @param ldapKey the ldap key
   * @param attributes the attributes
   */
  public LdapTreeAttributeNode(String ldapKey, List<String> attributes) {
    super();
    this.ldapKey = ldapKey;
    this.attributes = attributes;
  }


  public String getLdapKey() {
    return ldapKey;
  }


  public void setLdapKey(String ldapKey) {
    this.ldapKey = ldapKey;
  }


  public List<String> getAttributes() {
    return attributes;
  }


  public void setAttributes(List<String> attributes) {
    this.attributes = attributes;
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("LdapTreeAttributeNode [ldapKey=");
    builder.append(ldapKey);
    builder.append(", attributes=");
    builder.append(attributes);
    builder.append("]");
    return builder.toString();
  }

}
