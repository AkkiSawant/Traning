
package com.mergehealthcare.icc.ldapconfig.data.convertor;

import javax.xml.bind.annotation.XmlValue;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * The Class StringAdapter.
 */
public class StringAdapter extends XmlAdapter<StringAdapter.AdaptedString, String> {

  /*
   * (non-Javadoc)
   * @see javax.xml.bind.annotation.adapters.XmlAdapter#unmarshal(java.lang.Object)
   */
  @Override
  public String unmarshal(AdaptedString adaptedString) throws Exception {
    if (null == adaptedString) {
      return null;
    }
    String string = adaptedString.value;
    if ("".equals(string)) {
      return null;
    }
    return string;
  }


  /*
   * (non-Javadoc)
   * @see javax.xml.bind.annotation.adapters.XmlAdapter#marshal(java.lang.Object)
   */
  @Override
  public AdaptedString marshal(String string) throws Exception {
    AdaptedString adaptedString = new AdaptedString();
    adaptedString.value = string;
    return adaptedString;
  }


  /**
   * The Class AdaptedString.
   */
  public static class AdaptedString {

    @XmlValue
    public String value;
  }

}
