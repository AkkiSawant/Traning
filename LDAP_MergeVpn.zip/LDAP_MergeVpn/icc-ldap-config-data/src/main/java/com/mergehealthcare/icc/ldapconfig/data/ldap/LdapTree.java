package com.mergehealthcare.icc.ldapconfig.data.ldap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The Class LdapTree.
 */
public class LdapTree implements Serializable {

  /*
   *
   */
  private static final long serialVersionUID = -6850409269154809619L;

  private String title;

  private Map<String, LdapTreeAttributeNode> attributeMap;

  private List<LdapTree> nodes;

  private String value;

  private String fullyQualifiedName;


  /**
   * Gets the title.
   *
   * @return the title
   */
  public String getTitle() {
    return title;
  }


  /**
   * Sets the title.
   *
   * @param title the new title
   */
  public void setTitle(String title) {
    this.title = title;
  }


  /**
   * Sets the title.
   */
  /*
   * Sets the title.
   */
  public void setTitle() {
    LdapTree ldapTree = this;
    String titleTemp = null;
    if (ldapTree.getAttributeMap().containsKey("cn")) {
      titleTemp = ldapTree.getAttributeMap().get("cn").getAttributes().get(0);
    } else if (ldapTree.getAttributeMap().containsKey("ou")) {
      titleTemp = ldapTree.getAttributeMap().get("ou").getAttributes().get(0);
    }
    ldapTree.setTitle(titleTemp);
  }


  /**
   * Gets the value.
   *
   * @return the value
   */
  public String getValue() {
    return value;
  }


  /**
   * Gets the value from dn.
   *
   * @param fullyQualifiedName the fully qualified name
   * @return the value from dn
   */
  /*
   * Gets the value from dn.
   * @param fullyQualifiedName the fully qualified name
   * @return the value from dn
   */
  private String getValueFromDn(String fullyQualifiedName) {
    String ldapTreeValue = null;
    String[] values = fullyQualifiedName.split(",");
    for (String value : values) {
      if (value.contains("ou=") || value.contains("OU=")) {
        ldapTreeValue = value.replace("ou=", "");
        ldapTreeValue = ldapTreeValue.replace("OU=", "");
        break;
      }
    }
    return ldapTreeValue;
  }


  /**
   * Sets the value.
   *
   * @param value the new value
   */
  public void setValue(String value) {
    this.value = value;
  }


  /**
   * Sets the value.
   *
   * @param ldapTree the ldap tree
   * @param fullyQualifiedName the fully qualified name
   */
  /*
   * Sets the value.
   * @param ldapTree the ldap tree
   * @param fullyQualifiedName the fully qualified name
   */
  public void setValue(LdapTree ldapTree, String fullyQualifiedName) {
    String value = null;
    if (fullyQualifiedName != null) {
      value = getValueFromDn(fullyQualifiedName);
    }
    if (value == null) {
      value = fullyQualifiedName;
    }
    ldapTree.setValue(value);
  }


  /**
   * Gets the fully qualified name.
   *
   * @return the fully qualified name
   */
  public String getFullyQualifiedName() {
    return fullyQualifiedName;
  }


  /**
   * Sets the fully qualified name.
   *
   * @param fullyQualifiedName the new fully qualified name
   */
  public void setFullyQualifiedName(String fullyQualifiedName) {
    this.fullyQualifiedName = fullyQualifiedName;
  }


  /**
   * Gets the attribute map.
   *
   * @return the attribute map
   */
  public Map<String, LdapTreeAttributeNode> getAttributeMap() {
    return attributeMap;
  }


  /**
   * Sets the attribute map.
   *
   * @param attributeMap the attribute map
   */
  public void setAttributeMap(Map<String, LdapTreeAttributeNode> attributeMap) {
    this.attributeMap = attributeMap;
  }


  /**
   * Gets the nodes.
   *
   * @return the nodes
   */
  public List<LdapTree> getNodes() {
    return nodes;
  }


  /**
   * Sets the nodes.
   *
   * @param childNode the new nodes
   */
  public void setNodes(List<LdapTree> childNode) {
    this.nodes = childNode;
  }


  /**
   * Adds the child node.
   *
   * @param ldapTree the ldap tree
   */
  /*
   * Adds the child node.
   * @param ldapTree the ldap tree
   */
  public void addChildNode(LdapTree ldapTree) {
    if (nodes == null) {
      nodes = new ArrayList<LdapTree>();
    }
    nodes.add(ldapTree);
  }


  /**
   * Adds the into attributes.
   *
   * @param key the key
   * @param object the object
   */
  /*
   * Adds the into attributes.
   * @param key the key
   * @param object the object
   */
  public void addIntoAttributes(String key, String object) {
    if (attributeMap == null) {
      attributeMap = new HashMap<String, LdapTreeAttributeNode>();
    }
    String lowercaseKey = key.toLowerCase(Locale.getDefault());

    if (attributeMap.containsKey(lowercaseKey)) {
      LdapTreeAttributeNode ldapTreeAttributeNode = attributeMap.get(lowercaseKey);
      List<String> attributes = ldapTreeAttributeNode.getAttributes();
      attributes.add(object);
      ldapTreeAttributeNode.setAttributes(attributes);
    } else {
      List<String> valueList = new ArrayList<String>();
      valueList.add(object);
      LdapTreeAttributeNode ldapTreeAttributeNode = new LdapTreeAttributeNode(key, valueList);
      attributeMap.put(lowercaseKey, ldapTreeAttributeNode);
    }
  }


  /*
   * (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append("LdapTree [title=");
    builder.append(title);
    builder.append(", attributeMap=");
    builder.append(attributeMap);
    builder.append(", nodes=");
    builder.append(nodes);
    builder.append(", value=");
    builder.append(value);
    builder.append(", fullyQualifiedName=");
    builder.append(fullyQualifiedName);
    builder.append("]");
    return builder.toString();
  }

}
