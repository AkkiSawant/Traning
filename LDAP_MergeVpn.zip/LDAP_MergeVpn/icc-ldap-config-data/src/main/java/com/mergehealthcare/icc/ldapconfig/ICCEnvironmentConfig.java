package com.mergehealthcare.icc.ldapconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
@PropertySource ("classpath:ldap.properties")
public class ICCEnvironmentConfig {

    @Autowired
    public Environment environment;


    /**
     * Gets the file name.
     *
     * @return the file name
     */
    public String getTestFileName() {
        String filePath = environment.getProperty("icc.configuration.path");
        String fileSuffix = environment.getProperty("icc.configuration.testconnection.file_suffix");
        String fileExt = environment.getProperty("icc.configuration.filext");

        StringBuilder sb = new StringBuilder();
        sb.append(filePath);
        sb.append(fileSuffix);
        sb.append(fileExt);
        return sb.toString();
    }


    public String getTempFileName(String serverName) {
        String filePath = environment.getProperty("icc.configuration.temp.path");
        String fileExt = environment.getProperty("icc.configuration.filext");
        return filePath + serverName + fileExt;
    }


    public String getServerName() {
        String filePath = environment.getProperty("icc.configuration.temp.path");
        File file = new File(filePath);
        String[] lstFiles = file.list();
        String serverName = null;
        if (lstFiles.length > 0 && lstFiles.length < 2) {
            serverName = lstFiles[1];
        }

        return serverName;
    }


    public String getPlatform() {
        return environment.getProperty("icc.configuration.platform");
    }

}
