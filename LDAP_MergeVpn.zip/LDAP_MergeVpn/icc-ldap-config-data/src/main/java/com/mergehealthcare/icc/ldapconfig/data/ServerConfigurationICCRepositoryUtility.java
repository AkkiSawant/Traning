/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mergehealthcare.icc.ldapconfig.data;

import java.util.Map;

import org.apache.log4j.Logger;

import com.mergehealthcare.icc.ldapconfig.common.utils.LogService;
import com.mergehealthcare.icc.ldapconfig.common.utils.ObjectUtils;

import icc.ldap.server.configuration.AttributeMap;
import icc.ldap.server.configuration.DomainsAdminLevel;
import icc.ldap.server.configuration.GroupsAdminLevel;
import icc.ldap.server.configuration.Locator;
import icc.ldap.server.configuration.LocatorProperties;
import icc.ldap.server.configuration.LocatorProperty;
import icc.ldap.server.configuration.Mapper;
import icc.ldap.server.configuration.MapperConverterProperties;
import icc.ldap.server.configuration.Model;
import icc.ldap.server.configuration.ReturnedDefaultAttributes;
import icc.ldap.server.configuration.ServerConfiguration;
import icc.ldap.server.configuration.ServerConnectionOptions;
import icc.ldap.server.configuration.UserDomainRoles;
import icc.ldap.server.configuration.UserGroupRoles;
import icc.ldap.server.configuration.UserOverrideDetail;
import icc.ldap.server.configuration.ValueMap;

/**
 * The Class ServerConfigurationICCRepositoryUtility.
 *
 * @author sarikam2
 */
@SuppressWarnings ({ "PMD.DataflowAnomalyAnalysis" })
public class ServerConfigurationICCRepositoryUtility {

    private static final int SIZE_LIMIT = 100;

    private static final int PROTOCOL_VERSION = 3;

    private static final int PING_LIMIT = 4;

    private static final int REFERRAL_HOP_LIMIT = 32;

    private static final Logger logger = LogService.getLogger(ServerConfigurationICCRepositoryUtility.class);

    // This object cannot Autowired.
    private final ObjectFactory objectFactory = new ObjectFactory();


    /**
     * Creates the server connection objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createServerConnectionObjects(ServerConfiguration serverConfiguration) {
        if (ObjectUtils.isNull(serverConfiguration.getServerConnection())) {
            serverConfiguration.setServerConnection(objectFactory.createServerConnection());
        } else if (!ObjectUtils.isNull(serverConfiguration.getServerConnection())) {
            serverConfiguration.getServerConnection().getServerConnectionOptions();
            serverConfiguration.getServerConnection().getSslConnection();
        }
        createSSLConnectionObjects(serverConfiguration);
        createServerConnectionOpsObjects(serverConfiguration);
    }


    /**
     * Creates the server details objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createServerDetailsObjects(ServerConfiguration serverConfiguration) {
        if (ObjectUtils.isNull(serverConfiguration.getServerDetails())) {
            serverConfiguration.setServerDetails(objectFactory.createServerDetails());
        } else if (ObjectUtils.isNull(serverConfiguration.getServerDetails().getSiteDomains())) {
            serverConfiguration.getServerDetails().setSiteDomains(objectFactory.createSiteDomains());
        }
    }


    /**
     * Creates the server connection ops objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createServerConnectionOpsObjects(ServerConfiguration serverConfiguration) {
        if (!ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions())) {
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getAuthenticationMethod())) {
                serverConfiguration.getServerConnection().getServerConnectionOptions()
                                .setAuthenticationMethod(ServerConnectionOptions.AuthType.Basic);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getConnectionTimeOut())) {
                ServerConnectionOptions.TimeSpanDuration timeSpanDuration = new ServerConnectionOptions.TimeSpanDuration("00:00:00");
                serverConfiguration.getServerConnection().getServerConnectionOptions().setConnectionTimeOut(timeSpanDuration);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getPingKeepAliveTimeout())) {
                ServerConnectionOptions.TimeSpanDuration pingKeepAliveTimeout = new ServerConnectionOptions.TimeSpanDuration("00:00:00");
                serverConfiguration.getServerConnection().getServerConnectionOptions().setPingKeepAliveTimeout(pingKeepAliveTimeout);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getReferralChasingOptions())) {
                serverConfiguration.getServerConnection().getServerConnectionOptions()
                                .setReferralChasingOptions(ServerConnectionOptions.ReferralChasingOptions.All);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getPingWaitTimeout())) {
                ServerConnectionOptions.TimeSpanDuration pingTimeout = new ServerConnectionOptions.TimeSpanDuration("00:00:00");
                serverConfiguration.getServerConnection().getServerConnectionOptions().setPingWaitTimeout(pingTimeout);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getPingLimit())) {
                serverConfiguration.getServerConnection().getServerConnectionOptions().setPingLimit(PING_LIMIT);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getProtocolVersion())) {
                serverConfiguration.getServerConnection().getServerConnectionOptions().setProtocolVersion(PROTOCOL_VERSION);
            }
            if (ObjectUtils.isNull(serverConfiguration.getServerConnection().getServerConnectionOptions().getReferralHopLimit())) {
                serverConfiguration.getServerConnection().getServerConnectionOptions().setReferralHopLimit(REFERRAL_HOP_LIMIT);
            }
        }
    }


    /**
     * Creates the user override map objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createUserOverrideMapObjects(ServerConfiguration serverConfiguration) {
        if (ObjectUtils.isNull(serverConfiguration.getUserOverrideMap())) {
            serverConfiguration.setUserOverrideMap(objectFactory.createUserOverrideMap());
        }
        if (ObjectUtils.isNull(serverConfiguration.getUserOverrideMap().getUserOverrideDetail())) {
            serverConfiguration.getUserOverrideMap().getUserOverrideDetail();
        } else if (!ObjectUtils.isNull(serverConfiguration.getUserOverrideMap().getUserOverrideDetail())) {
            if (!serverConfiguration.getUserOverrideMap().getUserOverrideDetail().isEmpty()) {
                for (Map.Entry<String, UserOverrideDetail> entry : serverConfiguration.getUserOverrideMap().getUserOverrideDetail()
                                .entrySet()) {
                    UserOverrideDetail userOverrideDetail = entry.getValue();
                    if (ObjectUtils.isNull(userOverrideDetail.getDomainsAdminLevel())) {
                        DomainsAdminLevel domainsAdminLevel = new DomainsAdminLevel();
                        domainsAdminLevel.getDomainAdminLevel();
                        userOverrideDetail.setDomainsAdminLevel(domainsAdminLevel);
                    } else {
                        userOverrideDetail.getDomainsAdminLevel().getDomainAdminLevel();
                    }
                    if (ObjectUtils.isNull(userOverrideDetail.getGroupsAdminLevel())) {
                        GroupsAdminLevel groupsAdminLevel = new GroupsAdminLevel();
                        groupsAdminLevel.getGroupAdminLevel();
                        userOverrideDetail.setGroupsAdminLevel(groupsAdminLevel);
                    } else {
                        userOverrideDetail.getGroupsAdminLevel().getGroupAdminLevel();
                    }
                    if (ObjectUtils.isNull(userOverrideDetail.getUserDomainRoles())) {
                        UserDomainRoles userDomainRoles = new UserDomainRoles();
                        userDomainRoles.getUserDomainRole();
                        userOverrideDetail.setUserDomainRoles(userDomainRoles);
                    } else {
                        userOverrideDetail.getUserDomainRoles().getUserDomainRole();
                    }
                    if (ObjectUtils.isNull(userOverrideDetail.getUserGroupRoles())) {
                        UserGroupRoles userGroupRoles = new UserGroupRoles();
                        userGroupRoles.getUserGroupRole();
                        userOverrideDetail.setUserGroupRoles(userGroupRoles);
                    } else {
                        userOverrideDetail.getUserGroupRoles().getUserGroupRole();
                    }
                    entry.setValue(userOverrideDetail);
                }
            }
        }
    }


    /**
     * Creates the operation command objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createOperationCommandObjects(ServerConfiguration serverConfiguration) {
        if (ObjectUtils.isNull(serverConfiguration.getOperationCommand())) {
            serverConfiguration.setOperationCommand(objectFactory.createOperationCommand());
        } else if (!ObjectUtils.isNull(serverConfiguration.getOperationCommand())) {
            if (ObjectUtils.isNull(serverConfiguration.getOperationCommand().getTimeLimit())) {
                serverConfiguration.getOperationCommand().setTimeLimit(new ServerConnectionOptions.TimeSpanDuration("00:00:00"));
            }
            if (ObjectUtils.isNull(serverConfiguration.getOperationCommand().getAttributes())) {
                serverConfiguration.getOperationCommand().setAttributes(objectFactory.createAttributes());
            } else if (serverConfiguration.getOperationCommand().getAttributes() != null) {
                serverConfiguration.getOperationCommand().getAttributes().getAttribute();
            }
            if (ObjectUtils.isNull(serverConfiguration.getOperationCommand().getType())) {
                serverConfiguration.getOperationCommand().setType("simple");
            }
            if (ObjectUtils.isNull(serverConfiguration.getOperationCommand().getSizeLimit())) {
                serverConfiguration.getOperationCommand().setSizeLimit(SIZE_LIMIT);
            }
        }
    }


    /**
     * Creates the model objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createModelObjects(ServerConfiguration serverConfiguration) {
        if (ObjectUtils.isNull(serverConfiguration.getModel())) {
            serverConfiguration.setModel(objectFactory.createModel());
        } else if (ObjectUtils.isNull(serverConfiguration.getModel().getLocators().getLocator())) {
            serverConfiguration.getModel().setLocators(objectFactory.createLocators());
        } else if (ObjectUtils.isNull(serverConfiguration.getModel().getMappers().getMapper())) {
            serverConfiguration.getModel().setMappers(objectFactory.createMappers());
        }
        Model model = serverConfiguration.getModel();
        int size = model.getLocators().getLocator().size();
        for (int i = 0; i < size; i++) {
            Locator locator = model.getLocators().getLocatorByIndex(i);
            LocatorProperties properties = locator.getLocatorProperties();
            Map<String, LocatorProperty> propert = properties.getLocatorProperty();
            properties.setLocatorProperty(propert);
            locator.setLocatorProperties(properties);
        }
        int mappperSize = model.getMappers().getMapper().size();
        for (int i = 0; i < mappperSize; i++) {
            Mapper mapper = model.getMappers().getMapperByIndex(i);
            ValueMap valueMap = mapper.getValueMap();
            AttributeMap attribbuteMap = mapper.getAttributeMap();
            MapperConverterProperties attributeMapConvertorProperties = attribbuteMap.getMapperConverterProperties();
            attributeMapConvertorProperties.getMapperConverterProperty();
            attribbuteMap.setMapperConverterProperties(attributeMapConvertorProperties);
            MapperConverterProperties valueMapConvertorProp = valueMap.getMapperConverterProperties();
            valueMapConvertorProp.getMapperConverterProperty();
            valueMap.setMapperConverterProperties(valueMapConvertorProp);
            mapper.setValueMap(valueMap);
            mapper.setAttributeMap(attribbuteMap);
            if (ObjectUtils.isNull(mapper.getReturnedDefaultAttributes())) {
                ReturnedDefaultAttributes returnedDefaultAttributes = new ReturnedDefaultAttributes();
                returnedDefaultAttributes.getReturnedDefaultAttribute();
                mapper.setReturnedDefaultAttributes(returnedDefaultAttributes);
            } else if (!ObjectUtils.isNull(mapper.getReturnedDefaultAttributes())) {
                mapper.getReturnedDefaultAttributes().getReturnedDefaultAttribute();
            }
        }
    }


    /**
     * Below method will create internal objects of ServerConfiguration since in
     * marshal/unmarshal methods of Data layer, internal objects are accessed
     * directly so if
     * they are uninitialized they throws null pointer exception.
     *
     * @param serverConfiguration the server configuration
     * @return the server configuration
     */
    public ServerConfiguration createInternalObjects(ServerConfiguration serverConfiguration) {
        createServerDetailsObjects(serverConfiguration);
        createServerConnectionObjects(serverConfiguration);
        createOperationCommandObjects(serverConfiguration);
        createUserOverrideMapObjects(serverConfiguration);
        createModelObjects(serverConfiguration);
        return serverConfiguration;
    }


    /**
     * Creates the SSL connection objects.
     *
     * @param serverConfiguration the server configuration
     */
    private void createSSLConnectionObjects(ServerConfiguration serverConfiguration) {
        if (!ObjectUtils.isNull(serverConfiguration.getServerConnection().getSslConnection())) {
            serverConfiguration.getServerConnection().getSslConnection().getClientCertificateStore().getCn();
            serverConfiguration.getServerConnection().getSslConnection().getClientCertificateStore().getStoreLocation();
            serverConfiguration.getServerConnection().getSslConnection().getClientCertificateStore().getStoreName();
            serverConfiguration.getServerConnection().getSslConnection().getClientCertificatePath();
            serverConfiguration.getServerConnection().getSslConnection().getServerCertificatePath();
        }
    }

}
